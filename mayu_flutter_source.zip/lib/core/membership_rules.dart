class MembershipRules {
  MembershipRules._();

  static const double vatRate = 0;
  static const double signupFee = 0;

  static const Map<int, double> monthlyPrices = {
    1: 42,
    2: 52,
    3: 62,
  };

  static const Map<int, double> ambassadorCommissions = {
    1: 5,
    2: 6,
    3: 7,
  };

  static double monthlyPrice(int level) => monthlyPrices[level] ?? 0;

  static double ambassadorCommission(int level) =>
      ambassadorCommissions[level] ?? 0;

  static String money(double value) => value == value.roundToDouble()
      ? value.toStringAsFixed(0)
      : value.toStringAsFixed(2);

  static String planName(int level) {
    switch (level) {
      case 1:
        return 'Nivel 1 - Cobre';
      case 2:
        return 'Nivel 2 - Plata';
      case 3:
        return 'Nivel 3 - Oro';
      default:
        return 'Plan Mayu';
    }
  }

  static const String recurringDebitDisclosure =
      'Al aprobar en PayPal autorizas el débito automático mensual del valor '
      'de tu plan hasta que canceles la suscripción.';

  static const String ambassadorRule =
      'La comisión se genera únicamente por cada socio referido con pago '
      'mensual confirmado y membresía activa: Nivel 1 = \$5, Nivel 2 = \$6 '
      'y Nivel 3 = \$7. El pago se realiza el día 10 con corte del mes anterior.';
}
