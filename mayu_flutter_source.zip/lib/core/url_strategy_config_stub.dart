void configureUrlStrategy() {}
