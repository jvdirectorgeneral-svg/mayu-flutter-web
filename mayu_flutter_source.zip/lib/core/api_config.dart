class ApiConfig {
  static const String baseUrl = 'https://mayu-wellness-backend-v1.onrender.com';
}