import 'package:flutter/material.dart';

class MayuLogo extends StatelessWidget {
  final double height;

  const MayuLogo({
    super.key,
    this.height = 90,
  });

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      'assets/images/mayu_logo.png',
      height: height,
      fit: BoxFit.contain,
      errorBuilder: (context, error, stackTrace) {
        return const Text('Logo no encontrado');
      },
    );
  }
}