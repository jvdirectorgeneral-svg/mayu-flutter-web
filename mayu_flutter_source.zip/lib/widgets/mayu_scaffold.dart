import 'package:flutter/material.dart';

class MayuScaffold extends StatelessWidget {
  final Widget child;
  final PreferredSizeWidget? appBar;
  final Color backgroundColor;

  const MayuScaffold({
    super.key,
    required this.child,
    this.appBar,
    this.backgroundColor = const Color(0xFFF4F4F1),
  });

  Widget _margenImage() {
    return Image.asset(
      'assets/images/margen1.png',
      width: double.infinity,
      fit: BoxFit.cover,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: appBar,
      body: SafeArea(
        child: Column(
          children: [
            _margenImage(),

            Expanded(
              child: child,
            ),

            _margenImage(),
          ],
        ),
      ),
    );
  }
}