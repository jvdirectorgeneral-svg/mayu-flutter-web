import 'package:flutter/material.dart';

class MarketplaceOrderTimeline extends StatelessWidget {
  const MarketplaceOrderTimeline({
    super.key,
    required this.order,
  });

  final Map<String, dynamic> order;

  static const _statusOrder = [
    'paid',
    'admin_approved',
    'prepared',
    'shipped',
    'delivered',
  ];

  static String label(String status) {
    switch (status) {
      case 'created':
        return 'Creado';
      case 'paid':
        return 'Pago confirmado';
      case 'approved':
      case 'admin_approved':
        return 'Aprobado por Farmacia';
      case 'prepared':
        return 'Pedido preparado';
      case 'shipped':
        return 'Pedido enviado';
      case 'delivered':
        return 'Pedido entregado';
      case 'cancelled':
        return 'Pedido cancelado';
      default:
        return status.isEmpty ? 'Sin estado' : status;
    }
  }

  static Color color(String status) {
    switch (status) {
      case 'delivered':
        return Colors.green;
      case 'shipped':
        return Colors.blue;
      case 'prepared':
        return Colors.deepPurple;
      case 'approved':
      case 'admin_approved':
        return Colors.teal;
      case 'paid':
        return Colors.orange;
      case 'cancelled':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentStatus = (order['status'] ?? '').toString();
    final history = order['tracking_history'] is List
        ? List<dynamic>.from(order['tracking_history'])
        : <dynamic>[];
    final currentIndex = _statusOrder.indexOf(
      currentStatus == 'approved' ? 'admin_approved' : currentStatus,
    );

    if (currentStatus == 'cancelled') {
      return _statusBanner(
        context,
        Icons.cancel,
        label(currentStatus),
        Colors.red,
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Seguimiento del pedido',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        const SizedBox(height: 10),
        ..._statusOrder.asMap().entries.map((entry) {
          final reached = currentIndex >= entry.key;
          final event = history.cast<dynamic>().where((raw) {
            if (raw is! Map) return false;
            final eventStatus = (raw['status'] ?? '').toString();
            return eventStatus == entry.value ||
                (entry.value == 'admin_approved' && eventStatus == 'approved');
          }).lastOrNull;
          final eventMap =
              event is Map ? Map<String, dynamic>.from(event) : null;

          return _timelineStep(
            context,
            label(entry.value),
            reached,
            eventMap?['created_at']?.toString(),
            eventMap?['note']?.toString(),
            isLast: entry.key == _statusOrder.length - 1,
          );
        }),
      ],
    );
  }

  Widget _statusBanner(
    BuildContext context,
    IconData icon,
    String text,
    Color color,
  ) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(icon, color: color),
          const SizedBox(width: 8),
          Text(
            text,
            style: TextStyle(color: color, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _timelineStep(
    BuildContext context,
    String title,
    bool reached,
    String? date,
    String? note, {
    required bool isLast,
  }) {
    final color = reached ? Colors.teal : Colors.grey.shade400;
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            width: 28,
            child: Column(
              children: [
                Icon(
                  reached ? Icons.check_circle : Icons.radio_button_unchecked,
                  color: color,
                  size: 22,
                ),
                if (!isLast)
                  Expanded(
                    child:
                        Container(width: 2, color: color.withValues(alpha: .4)),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontWeight: reached ? FontWeight.bold : FontWeight.normal,
                      color: reached ? null : Colors.grey,
                    ),
                  ),
                  if (date != null && date.isNotEmpty)
                    Text(date, style: Theme.of(context).textTheme.bodySmall),
                  if (note != null && note.trim().isNotEmpty)
                    Text(note, style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
