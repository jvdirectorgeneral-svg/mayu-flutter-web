Object? reserveExternalWindow() => null;

bool navigateExternalWindow(Object? window, String url) => false;

void closeExternalWindow(Object? window) {}
