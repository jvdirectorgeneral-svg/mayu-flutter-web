export 'external_window_stub.dart'
    if (dart.library.html) 'external_window_web.dart';
