// ignore: deprecated_member_use
import 'dart:html' as html;

Object? reserveExternalWindow() => html.window.open('about:blank', '_blank');

bool navigateExternalWindow(Object? window, String url) {
  if (window is! html.WindowBase) return false;
  window.location.href = url;
  return true;
}

void closeExternalWindow(Object? window) {
  if (window is html.WindowBase) window.close();
}
