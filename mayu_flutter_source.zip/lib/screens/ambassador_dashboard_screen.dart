import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/ambassador_service.dart';
import '../services/auth_service.dart';
import '../widgets/mayu_scaffold.dart';

import 'login_screen.dart';
import 'wallet_card_screen.dart';

class AmbassadorDashboardScreen extends StatefulWidget {
  final int ambassadorId;

  const AmbassadorDashboardScreen({
    super.key,
    required this.ambassadorId,
  });

  @override
  State<AmbassadorDashboardScreen> createState() =>
      _AmbassadorDashboardScreenState();
}

class _AmbassadorDashboardScreenState extends State<AmbassadorDashboardScreen> {
  final AuthService _authService = AuthService();

  Map<String, dynamic>? dashboardData;
  Map<String, dynamic>? commissionSummary;
  List<dynamic> commissions = [];

  bool loading = true;
  String? error;
  String searchQuery = '';

  @override
  void initState() {
    super.initState();
    loadDashboard();
  }

  Future<void> loadDashboard() async {
    setState(() {
      loading = true;
      error = null;
    });

    try {
      final result = await AmbassadorService.getDashboard(widget.ambassadorId);
      final commissionResult =
          await AmbassadorService.getCommissions(widget.ambassadorId);
      final summaryResult =
          await AmbassadorService.getCommissionSummary(widget.ambassadorId);

      if (!mounted) return;

      if (result['statusCode'] == 200 && result['data'] != null) {
        final commissionData = commissionResult['data'] is Map
            ? Map<String, dynamic>.from(commissionResult['data'])
            : {};

        setState(() {
          dashboardData = Map<String, dynamic>.from(result['data']);

          commissions = commissionData['items'] is List
              ? List<dynamic>.from(commissionData['items'])
              : [];

          commissionSummary =
              summaryResult['statusCode'] == 200 && summaryResult['data'] is Map
                  ? Map<String, dynamic>.from(summaryResult['data'])
                  : {};

          loading = false;
        });
      } else {
        setState(() {
          error = result['data']?['detail'] ?? 'Error cargando datos';
          loading = false;
        });
      }
    } catch (_) {
      if (!mounted) return;

      setState(() {
        error = 'Error de conexión con el servidor';
        loading = false;
      });
    }
  }

  Future<void> _logout() async {
    await _authService.logout();

    if (!mounted) return;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  String _safe(dynamic value) {
    if (value == null) return '-';
    final text = value.toString().trim();
    return text.isEmpty ? '-' : text;
  }

  String _money(dynamic value) {
    final parsed = double.tryParse((value ?? 0).toString()) ?? 0;
    return parsed.toStringAsFixed(2);
  }

  double _moneyNumber(dynamic value) {
    return double.tryParse((value ?? 0).toString()) ?? 0;
  }

  Future<void> _openUrl(String? url, String emptyMessage) async {
    final cleanUrl = _safe(url);

    if (cleanUrl == '-') {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(emptyMessage)),
      );
      return;
    }

    final uri = Uri.tryParse(cleanUrl);

    if (uri == null || !uri.hasScheme) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Link inválido.')),
      );
      return;
    }

    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Future<void> _openWhatsApp(String? url) async {
    await _openUrl(url, 'No hay WhatsApp disponible para este socio.');
  }

  Future<void> _openTracking(String? url) async {
    await _openUrl(url, 'No hay link de tracking disponible.');
  }

  void _openWalletMayu(Map<String, dynamic> card) {
    final int ambassadorUserId = int.tryParse(
          (card['user_id'] ??
                  dashboardData?['user_id'] ??
                  dashboardData?['ambassador_user_id'] ??
                  0)
              .toString(),
        ) ??
        0;

    final String userName = _safe(
      dashboardData?['name'] ??
          dashboardData?['ambassador_name'] ??
          card['user_name'] ??
          card['name'] ??
          'Embajador Mayu',
    );

    if (ambassadorUserId == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No se pudo identificar el usuario del embajador.'),
        ),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => WalletCardScreen(
          userId: ambassadorUserId,
          userName: userName,
        ),
      ),
    );
  }

  String _levelName(dynamic level) {
    final int parsed = int.tryParse((level ?? 0).toString()) ?? 0;

    switch (parsed) {
      case 1:
        return 'Nivel 1 - Cobre';
      case 2:
        return 'Nivel 2 - Plata';
      case 3:
        return 'Nivel 3 - Oro';
      default:
        return 'Sin nivel';
    }
  }

  String _monthLabel(dynamic month, dynamic year) {
    final int m = int.tryParse((month ?? 0).toString()) ?? 0;
    final String y = _safe(year);

    const months = {
      1: 'Enero',
      2: 'Febrero',
      3: 'Marzo',
      4: 'Abril',
      5: 'Mayo',
      6: 'Junio',
      7: 'Julio',
      8: 'Agosto',
      9: 'Septiembre',
      10: 'Octubre',
      11: 'Noviembre',
      12: 'Diciembre',
    };

    if (m == 0 || y == '-') return '-';
    return '${months[m] ?? 'Mes'} $y';
  }

  String _nextPaymentLabel(dynamic day) {
    return 'Día 10';
  }

  bool _matchesSearch(Map<String, dynamic> affiliate) {
    if (searchQuery.trim().isEmpty) return true;

    final q = searchQuery.toLowerCase();

    final values = [
      affiliate['name'],
      affiliate['email'],
      affiliate['phone'],
      affiliate['cedula'],
      affiliate['city'],
      affiliate['address'],
      affiliate['membership_level'],
      affiliate['membership_level_name'],
      affiliate['last_order_code'],
      affiliate['last_order_status'],
      affiliate['tracking_number'],
      affiliate['tracking_url'],
      affiliate['carrier'],
      affiliate['shipping_notes'],
      affiliate['commission_amount'],
      affiliate['monthly_commission_amount'],
      affiliate['commission_rule'],
    ];

    for (final value in values) {
      if (value != null && value.toString().toLowerCase().contains(q)) {
        return true;
      }
    }

    final deliveryProducts = affiliate['delivery_products'];

    if (deliveryProducts is List) {
      for (final p in deliveryProducts) {
        if (p.toString().toLowerCase().contains(q)) return true;
      }
    }

    return false;
  }

  Widget _buildStat({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: Colors.white.withValues(alpha: 0.90),
        border: Border.all(color: color.withValues(alpha: 0.25)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 30),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          Text(title, textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _badge(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.bold,
          fontSize: 12,
        ),
      ),
    );
  }

  Widget _productsList(dynamic products) {
    if (products is! List || products.isEmpty) {
      return const Text('Sin productos registrados.');
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: products.map((p) {
        final map = p is Map ? Map<String, dynamic>.from(p) : null;

        final name = map == null
            ? p.toString()
            : _safe(map['name'] ?? map['product_name_snapshot']);

        final quantity = map == null ? '1' : _safe(map['quantity']);

        return Padding(
          padding: const EdgeInsets.only(bottom: 4),
          child: Text('• $name x$quantity'),
        );
      }).toList(),
    );
  }

  Widget _affiliateCommissionBox(Map<String, dynamic> affiliate) {
    final amount = affiliate['monthly_commission_amount'] ??
        affiliate['commission_amount'] ??
        0;

    final rule = _safe(affiliate['commission_rule']);

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 10, bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: Colors.teal.withValues(alpha: 0.10),
        border: Border.all(color: Colors.teal.withValues(alpha: 0.25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Comisión mensual por este socio',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 4),
          Text(
            '\$${_money(amount)}',
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.teal,
            ),
          ),
          if (rule != '-') ...[
            const SizedBox(height: 4),
            Text(rule),
          ],
        ],
      ),
    );
  }

  Widget _buildAffiliateTile(Map<String, dynamic> affiliate) {
    final bool isActive = affiliate['membership_active'] == true;

    final String name = _safe(affiliate['name']);
    final String email = _safe(affiliate['email']);
    final String phone = _safe(affiliate['phone']);
    final String whatsappUrl = _safe(affiliate['whatsapp_url']);
    final String trackingUrl = _safe(affiliate['tracking_url']);

    final String initial =
        name != '-' ? name.substring(0, 1).toUpperCase() : '?';

    final deliveryProducts = affiliate['delivery_products'] is List
        ? affiliate['delivery_products'] as List
        : [];

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: Colors.white.withValues(alpha: 0.92),
        border: Border.all(color: Colors.black12),
      ),
      child: ExpansionTile(
        tilePadding: EdgeInsets.zero,
        childrenPadding: const EdgeInsets.only(top: 10),
        leading: CircleAvatar(
          backgroundColor: Colors.deepPurple.withValues(alpha: 0.12),
          child: Text(
            initial,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.deepPurple,
            ),
          ),
        ),
        title: Text(
          name,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          '$email\nCelular: $phone\n${_safe(affiliate['membership_level_name'] ?? _levelName(affiliate['membership_level']))}',
        ),
        trailing: _badge(
          isActive ? 'Activo' : 'Inactivo',
          isActive ? Colors.green : Colors.red,
        ),
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _affiliateCommissionBox(affiliate),
                Text('Ciudad: ${_safe(affiliate['city'])}'),
                Text('Dirección: ${_safe(affiliate['address'])}'),
                const SizedBox(height: 8),
                Text('Última orden: ${_safe(affiliate['last_order_code'])}'),
                Text(
                    'Estado entrega: ${_safe(affiliate['last_order_status'])}'),
                Text('Transportadora: ${_safe(affiliate['carrier'])}'),
                Text('Guía: ${_safe(affiliate['tracking_number'])}'),
                Text('Tracking: $trackingUrl'),
                const SizedBox(height: 10),
                const Text(
                  'Productos última entrega:',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                _productsList(deliveryProducts),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    if (whatsappUrl != '-')
                      OutlinedButton.icon(
                        onPressed: () => _openWhatsApp(whatsappUrl),
                        icon: const Icon(Icons.chat),
                        label: const Text('WhatsApp'),
                      ),
                    if (trackingUrl != '-')
                      OutlinedButton.icon(
                        onPressed: () => _openTracking(trackingUrl),
                        icon: const Icon(Icons.open_in_new),
                        label: const Text('Tracking'),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAffiliateSection(
    String title,
    List<Map<String, dynamic>> affiliates,
  ) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: Colors.white.withValues(alpha: 0.88),
        border: Border.all(color: Colors.black12),
      ),
      child: ExpansionTile(
        initiallyExpanded: true,
        tilePadding: EdgeInsets.zero,
        childrenPadding: const EdgeInsets.only(top: 8),
        title: Text(
          '$title (${affiliates.length})',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        children: affiliates.isEmpty
            ? const [
                Align(
                  alignment: Alignment.centerLeft,
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 8),
                    child: Text('No hay afiliados en este nivel'),
                  ),
                ),
              ]
            : affiliates.map(_buildAffiliateTile).toList(),
      ),
    );
  }

  Widget _simpleBox(String text) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: Colors.white.withValues(alpha: 0.90),
        border: Border.all(color: Colors.black12),
      ),
      child: Text(text, textAlign: TextAlign.center),
    );
  }

  Widget _buildCardImage(Map<String, dynamic> card) {
    final String imageUrl = (card['image_url'] ?? '').toString();

    if (imageUrl.isEmpty) {
      return _simpleBox('Tarjeta de embajador no disponible');
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: Colors.white.withValues(alpha: 0.90),
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Image.network(
              imageUrl,
              fit: BoxFit.contain,
              errorBuilder: (_, __, ___) {
                return _simpleBox('No se pudo cargar la tarjeta');
              },
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => _openWalletMayu(card),
              icon: const Icon(Icons.account_balance_wallet),
              label: const Text('Abrir Wallet Mayu'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _projectionSection(
    Map<String, dynamic> stats,
    Map<String, dynamic> projection,
  ) {
    final monthly = projection['monthly_income'] ??
        stats['projected_monthly_commission'] ??
        stats['monthly_commission'] ??
        0;

    final yearly = projection['yearly_income'] ??
        stats['projected_yearly_commission'] ??
        (_moneyNumber(monthly) * 12);

    final nextPaymentDay =
        projection['next_payment_day'] ?? stats['next_payment_day'];

    final paymentFrequency = _safe(
      projection['payment_frequency'] ??
          stats['payment_frequency'] ??
          'Pago mensual el día 10. Corte del 1 al 30 del mes anterior',
    );

    final message = _safe(
      projection['message'] ??
          'Con tus socios activos actuales, tu próxima comisión es de \$${_money(monthly)}. Se paga el día 10 con corte del 1 al 30 del mes anterior.',
    );

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 24),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.teal.withValues(alpha: 0.10),
        border: Border.all(color: Colors.teal.withValues(alpha: 0.25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Proyección de ingresos',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _buildStat(
                  title: 'Mensual',
                  value: '\$${_money(monthly)}',
                  icon: Icons.calendar_month,
                  color: Colors.teal,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildStat(
                  title: 'Anual',
                  value: '\$${_money(yearly)}',
                  icon: Icons.trending_up,
                  color: Colors.deepPurple,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            'Próximo pago: ${_nextPaymentLabel(nextPaymentDay)}',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          Text(paymentFrequency),
          const SizedBox(height: 10),
          Text(message),
        ],
      ),
    );
  }

  Widget _commissionSection(
    Map<String, dynamic> stats,
    Map<String, dynamic> projection,
  ) {
    final totalPending = commissionSummary?['total_pending'] ?? 0;
    final totalPaid = commissionSummary?['total_paid'] ?? 0;
    final totalGenerated = commissionSummary?['total_generated'] ??
        stats['monthly_commission'] ??
        stats['projected_monthly_commission'] ??
        0;

    final paymentFrequency = _safe(
      projection['payment_frequency'] ??
          stats['payment_frequency'] ??
          'Pago mensual el día 10. Corte del 1 al 30 del mes anterior',
    );

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 24),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: Colors.white.withValues(alpha: 0.90),
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Mis comisiones',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Text('Total generado: \$${_money(totalGenerated)}'),
          Text('Próxima comisión: \$${_money(totalPending)}'),
          Text('Pago realizado: \$${_money(totalPaid)}'),
          const SizedBox(height: 8),
          Text('Regla de pago: $paymentFrequency'),
          const SizedBox(height: 12),
          const Text(
            'Regla: Nivel 1 = \$5, Nivel 2 = \$6, Nivel 3 = \$7 por socio activo pagado.',
          ),
          const SizedBox(height: 16),
          if (commissions.isEmpty)
            const Text('Aún no hay comisiones generadas.')
          else
            ...commissions.map((item) {
              final c = Map<String, dynamic>.from(item as Map);

              final status = _safe(c['status']);
              final isPaid = status == 'paid';

              return Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.black12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _safe(c['referred_user_name']),
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text('Mes: ${_monthLabel(c['month'], c['year'])}'),
                    Text('Plan: ${_safe(c['plan_name'])}'),
                    Text('Regla: ${_safe(c['commission_rule'])}'),
                    Text('Comisión: \$${_money(c['commission_amount'])}'),
                    const SizedBox(height: 6),
                    _badge(
                      isPaid ? 'Pagado' : 'Pendiente',
                      isPaid ? Colors.green : Colors.orange,
                    ),
                  ],
                ),
              );
            }),
        ],
      ),
    );
  }

  Widget _goalBox(Map<String, dynamic> stats) {
    final current =
        int.tryParse((stats['active_referrals'] ?? 0).toString()) ?? 0;
    final goal = int.tryParse((stats['goal'] ?? 100).toString()) ?? 100;

    final progress = goal <= 0 ? 0.0 : (current / goal).clamp(0.0, 1.0);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: Colors.orange.withValues(alpha: 0.12),
        border: Border.all(color: Colors.orange.withValues(alpha: 0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Meta: $current/$goal afiliados',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          LinearProgressIndicator(value: progress),
          const SizedBox(height: 10),
          const Text('Premio: Viaje a la playa 🏝️'),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final card = Map<String, dynamic>.from(dashboardData?['card'] ?? {});
    final stats = Map<String, dynamic>.from(dashboardData?['stats'] ?? {});
    final projection = Map<String, dynamic>.from(
      dashboardData?['commission_projection'] ?? {},
    );

    final affiliatesRaw = dashboardData?['affiliates'];

    final affiliates = affiliatesRaw is List
        ? affiliatesRaw
            .map<Map<String, dynamic>>((e) => Map<String, dynamic>.from(e))
            .where(_matchesSearch)
            .toList()
        : <Map<String, dynamic>>[];

    final level1 = affiliates
        .where(
            (a) => int.tryParse((a['membership_level'] ?? 0).toString()) == 1)
        .toList();

    final level2 = affiliates
        .where(
            (a) => int.tryParse((a['membership_level'] ?? 0).toString()) == 2)
        .toList();

    final level3 = affiliates
        .where(
            (a) => int.tryParse((a['membership_level'] ?? 0).toString()) == 3)
        .toList();

    final monthlyProjected = stats['projected_monthly_commission'] ??
        stats['monthly_commission'] ??
        projection['monthly_income'] ??
        0;

    final nextPaymentDay =
        stats['next_payment_day'] ?? projection['next_payment_day'];

    return MayuScaffold(
      appBar: AppBar(
        title: const Text('Panel de Embajador'),
        centerTitle: true,
        actions: [
          IconButton(onPressed: loadDashboard, icon: const Icon(Icons.refresh)),
          IconButton(onPressed: _logout, icon: const Icon(Icons.logout)),
        ],
      ),
      child: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(
                      error!,
                      style: const TextStyle(color: Colors.red),
                      textAlign: TextAlign.center,
                    ),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: loadDashboard,
                  child: SingleChildScrollView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(18),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 720),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Dashboard de Embajador',
                              style: TextStyle(
                                fontSize: 28,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              'Consulta tu tarjeta, afiliados, entregas, tracking y comisiones.',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.black54,
                              ),
                            ),
                            const SizedBox(height: 20),
                            _buildCardImage(card),
                            const SizedBox(height: 24),
                            Row(
                              children: [
                                Expanded(
                                  child: _buildStat(
                                    title: 'Afiliados',
                                    value: '${stats['total_referrals'] ?? 0}',
                                    icon: Icons.groups,
                                    color: Colors.deepPurple,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: _buildStat(
                                    title: 'Activos',
                                    value: '${stats['active_referrals'] ?? 0}',
                                    icon: Icons.verified,
                                    color: Colors.green,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                Expanded(
                                  child: _buildStat(
                                    title: 'Mensual',
                                    value: '\$${_money(monthlyProjected)}',
                                    icon: Icons.monetization_on,
                                    color: Colors.teal,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: _buildStat(
                                    title: 'Próximo pago',
                                    value: _nextPaymentLabel(nextPaymentDay),
                                    icon: Icons.event_available,
                                    color: Colors.orange,
                                  ),
                                ),
                              ],
                            ),
                            _projectionSection(stats, projection),
                            _commissionSection(stats, projection),
                            const SizedBox(height: 24),
                            _goalBox(stats),
                            const SizedBox(height: 24),
                            TextField(
                              decoration: const InputDecoration(
                                hintText:
                                    'Buscar afiliado, correo, celular, guía, tracking, orden o producto',
                                prefixIcon: Icon(Icons.search),
                                border: OutlineInputBorder(),
                              ),
                              onChanged: (value) {
                                setState(() {
                                  searchQuery = value;
                                });
                              },
                            ),
                            const SizedBox(height: 24),
                            const Text(
                              'Afiliados registrados',
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            _buildAffiliateSection('Nivel 1 - Cobre', level1),
                            _buildAffiliateSection('Nivel 2 - Plata', level2),
                            _buildAffiliateSection('Nivel 3 - Oro', level3),
                            const SizedBox(height: 24),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
    );
  }
}
