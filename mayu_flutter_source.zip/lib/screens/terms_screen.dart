import 'package:flutter/material.dart';

class TermsScreen extends StatelessWidget {
  const TermsScreen({super.key});

  Widget _margenImage() {
    return Image.asset(
      'assets/images/margen1.png',
      width: double.infinity,
      fit: BoxFit.cover,
      errorBuilder: (context, error, stackTrace) {
        return const SizedBox.shrink();
      },
    );
  }

  Widget _sectionTitle(String text) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, bottom: 10),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _sectionText(String text) {
    return Text(
      text,
      style: const TextStyle(
        fontSize: 16,
        height: 1.5,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      body: SafeArea(
        child: Column(
          children: [
            _margenImage(),

            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(22),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(
                      maxWidth: 700,
                    ),
                    child: Container(
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.92),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(
                          color: Colors.black12,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.gavel,
                                color: Colors.deepPurple,
                                size: 34,
                              ),
                              const SizedBox(width: 12),
                              const Expanded(
                                child: Text(
                                  'Términos y Condiciones',
                                  style: TextStyle(
                                    fontSize: 28,
                                    fontWeight:
                                        FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),

                          const SizedBox(height: 14),

                          const Text(
                            'MAYU WELLNESS CLUB',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight:
                                  FontWeight.w600,
                              color: Colors.black54,
                            ),
                          ),

                          _sectionTitle(
                            '1. Uso de la plataforma',
                          ),

                          _sectionText(
                            'El usuario se compromete a proporcionar información real, actualizada y verificable para registro, contacto, facturación y entrega de productos dentro del ecosistema Mayu Wellness Club.',
                          ),

                          _sectionTitle(
                            '2. Membresía',
                          ),

                          _sectionText(
                            'La membresía puede encontrarse activa, inactiva o pendiente dependiendo del estado de pago, validación administrativa y cumplimiento de las condiciones operativas del plan seleccionado.',
                          ),

                          _sectionTitle(
                            '3. Planes y beneficios',
                          ),

                          _sectionText(
                            'Los beneficios, descuentos, productos y condiciones pueden variar según el nivel seleccionado: Cobre, Plata u Oro. Mayu Wellness Club podrá actualizar condiciones, productos y beneficios para mejorar la experiencia y operación del sistema.',
                          ),

                          _sectionTitle(
                            '4. Pagos',
                          ),

                          _sectionText(
                            'El usuario acepta que el acceso a beneficios, entregas y servicios depende de la validación correcta de pagos y procesos administrativos internos. Los pagos podrán realizarse mediante los métodos habilitados por Mayu Wellness Club.',
                          ),

                          _sectionTitle(
                            '5. Entregas y logística',
                          ),

                          _sectionText(
                            'Las entregas dependen de disponibilidad, ciudad registrada, dirección ingresada, validación administrativa y operación logística interna o externa. El usuario es responsable de mantener actualizada su información.',
                          ),

                          _sectionTitle(
                            '6. Uso responsable',
                          ),

                          _sectionText(
                            'El usuario se compromete a no utilizar la plataforma para fines fraudulentos, suplantación de identidad, manipulación de información o actividades que afecten el funcionamiento del sistema.',
                          ),

                          _sectionTitle(
                            '7. Cambios y actualizaciones',
                          ),

                          _sectionText(
                            'Mayu Wellness Club podrá actualizar estos términos y condiciones para mejorar la operación, seguridad, cumplimiento legal y experiencia de usuario dentro de la plataforma.',
                          ),

                          const SizedBox(height: 24),

                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(
                              18,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.deepPurple
                                  .withValues(alpha: 0.08),
                              borderRadius:
                                  BorderRadius.circular(
                                18,
                              ),
                            ),
                            child: const Text(
                              'Al continuar con el registro y uso de la plataforma, declaras haber leído y aceptado estos términos y condiciones.',
                              style: TextStyle(
                                fontSize: 16,
                                height: 1.4,
                                fontWeight:
                                    FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),

            _margenImage(),
          ],
        ),
      ),
    );
  }
}