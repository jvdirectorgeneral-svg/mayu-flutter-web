import 'package:flutter/material.dart';
import '../services/superadmin_service.dart';
import '../services/auth_service.dart';
import 'login_screen.dart';

class SuperAdminDashboardScreen extends StatefulWidget {
  const SuperAdminDashboardScreen({super.key});

  @override
  State<SuperAdminDashboardScreen> createState() =>
      _SuperAdminDashboardScreenState();
}

class _SuperAdminDashboardScreenState extends State<SuperAdminDashboardScreen> {
  final SuperAdminService _service = SuperAdminService();
  final AuthService _authService = AuthService();

  bool _loading = true;
  String? _error;

  Map<String, dynamic>? _superAdminProfile;
  List<dynamic> _internalUsers = [];
  List<dynamic> _allUsers = [];
  List<dynamic> _products = [];

  String _searchQuery = '';
  String _productSearchQuery = '';
  String _selectedProductCategoryFilter = 'todas';

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _cedulaController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  String _selectedRole = 'admin';
  bool _creatingUser = false;

  final List<String> _categories = const [
    'coloides',
    'cbd',
    'bienestar',
    'hongos',
    'soporte_funcional',
  ];

  @override
  void initState() {
    super.initState();
    _loadAllData();
  }

  Future<void> _loadAllData() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final profileResult = await _service.getSuperAdminProfile();
    final internalUsersResult = await _service.getInternalUsers();
    final allUsersResult = await _service.getAllUsers();
    final productsResult = await _service.getProducts();

    if (!mounted) return;

    if (profileResult['statusCode'] == 200 &&
        internalUsersResult['statusCode'] == 200 &&
        allUsersResult['statusCode'] == 200 &&
        productsResult['statusCode'] == 200) {
      final internalData = internalUsersResult['data'];
      final allUsersData = allUsersResult['data'];
      final productsData = productsResult['data'];

      setState(() {
        _superAdminProfile = Map<String, dynamic>.from(profileResult['data']);
        _internalUsers =
            internalData['items'] is List ? internalData['items'] : [];
        _allUsers = allUsersData['users'] is List ? allUsersData['users'] : [];

        if (productsData is Map && productsData['items'] is List) {
          _products = productsData['items'];
        } else if (productsData is List) {
          _products = productsData;
        } else {
          _products = [];
        }

        _loading = false;
      });
    } else {
      setState(() {
        _loading = false;
        _error = profileResult['data']?['detail'] ??
            internalUsersResult['data']?['detail'] ??
            allUsersResult['data']?['detail'] ??
            productsResult['data']?['detail'] ??
            'No se pudo cargar la información';
      });
    }
  }

  String _roleLabel(String role) {
    switch (role) {
      case 'superadmin':
        return 'Control Maestro';
      case 'admin':
        return 'Administrador';
      case 'supervisor':
        return 'Supervisor';
      case 'logistics':
        return 'Logística';
      case 'marketing':
        return 'Marketing';
      case 'pharmacy_admin':
        return 'Farmacia Mayu';
      case 'education_admin':
        return 'Mayu Educación';
      case 'ambassador':
        return 'Embajador';
      case 'member':
        return 'Socio';
      default:
        return role;
    }
  }

  bool _canEditInternalRole(String role) {
    return role == 'admin' ||
        role == 'supervisor' ||
        role == 'logistics' ||
        role == 'marketing' ||
        role == 'pharmacy_admin' ||
        role == 'education_admin';
  }

  bool _isProtectedSystemRole(String role) {
    return role == 'superadmin' ||
        role == 'admin' ||
        role == 'supervisor' ||
        role == 'logistics' ||
        role == 'marketing' ||
        role == 'pharmacy_admin' ||
        role == 'education_admin';
  }

  bool _isFarmaciaMayuUser(Map<String, dynamic> user) {
    final role = (user['role'] ?? '').toString();
    final name = (user['name'] ?? '').toString().toLowerCase();
    final email = (user['email'] ?? '').toString().toLowerCase();

    return role == 'pharmacy_admin' &&
        (name.contains('farmacia') || email.contains('farma@'));
  }

  String _categoryLabel(String category) {
    switch (category) {
      case 'coloides':
        return 'Coloides';
      case 'cbd':
        return 'CBD';
      case 'bienestar':
        return 'Bienestar';
      case 'hongos':
        return 'Hongos';
      case 'soporte_funcional':
        return 'Soporte funcional';
      default:
        return category;
    }
  }

  Future<void> _showProductDialog({Map<String, dynamic>? product}) async {
    final bool isEdit = product != null;

    final nameController = TextEditingController(
      text: isEdit ? (product['name'] ?? '').toString() : '',
    );
    final priceController = TextEditingController(
      text: isEdit ? (product['price'] ?? 0).toString() : '0',
    );
    final descriptionController = TextEditingController(
      text: isEdit ? (product['description'] ?? '').toString() : '',
    );
    final imageController = TextEditingController(
      text: isEdit ? (product['image_url'] ?? '').toString() : '',
    );

    String selectedCategory =
        (isEdit ? product['category']?.toString() : null) ?? 'coloides';

    if (!_categories.contains(selectedCategory)) {
      selectedCategory = 'coloides';
    }

    bool active = isEdit ? product['active'] == true : true;

    await showDialog(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text(isEdit ? 'Editar producto' : 'Crear producto'),
              content: SizedBox(
                width: 520,
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      TextField(
                        controller: nameController,
                        decoration: const InputDecoration(
                          labelText: 'Nombre del producto',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: priceController,
                        keyboardType: const TextInputType.numberWithOptions(
                          decimal: true,
                        ),
                        decoration: const InputDecoration(
                          labelText: 'Costo / precio interno',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String>(
                        initialValue: selectedCategory,
                        decoration: const InputDecoration(
                          labelText: 'Categoría',
                          border: OutlineInputBorder(),
                        ),
                        items: _categories.map((category) {
                          return DropdownMenuItem<String>(
                            value: category,
                            child: Text(_categoryLabel(category)),
                          );
                        }).toList(),
                        onChanged: (value) {
                          if (value == null) return;
                          setDialogState(() {
                            selectedCategory = value;
                          });
                        },
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: descriptionController,
                        minLines: 2,
                        maxLines: 4,
                        decoration: const InputDecoration(
                          labelText: 'Descripción',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: imageController,
                        decoration: const InputDecoration(
                          labelText: 'URL imagen opcional',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 8),
                      SwitchListTile(
                        value: active,
                        title: const Text('Producto activo'),
                        contentPadding: EdgeInsets.zero,
                        onChanged: (value) {
                          setDialogState(() {
                            active = value;
                          });
                        },
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Cancelar'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    final name = nameController.text.trim();
                    final price =
                        double.tryParse(priceController.text.trim()) ?? 0;
                    final description = descriptionController.text.trim();
                    final imageUrl = imageController.text.trim();

                    if (name.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('El nombre del producto es obligatorio'),
                        ),
                      );
                      return;
                    }

                    final result = isEdit
                        ? await _service.updateProduct(
                            productId: product['id'],
                            name: name,
                            price: price,
                            description: description,
                            category: selectedCategory,
                            imageUrl: imageUrl.isEmpty ? null : imageUrl,
                            active: active,
                          )
                        : await _service.createProduct(
                            name: name,
                            price: price,
                            description: description,
                            category: selectedCategory,
                            imageUrl: imageUrl.isEmpty ? null : imageUrl,
                            active: active,
                          );

                    if (!mounted) return;

                    Navigator.pop(dialogContext);

                    if (result['statusCode'] == 200 ||
                        result['statusCode'] == 201) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            isEdit
                                ? 'Producto actualizado correctamente'
                                : 'Producto creado correctamente',
                          ),
                        ),
                      );

                      await _loadAllData();
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            result['data']?['detail'] ??
                                'No se pudo guardar el producto',
                          ),
                        ),
                      );
                    }
                  },
                  child: const Text('Guardar'),
                ),
              ],
            );
          },
        );
      },
    );

    nameController.dispose();
    priceController.dispose();
    descriptionController.dispose();
    imageController.dispose();
  }

  Future<void> _toggleProductActive(Map<String, dynamic> product) async {
    final int id = int.tryParse((product['id'] ?? 0).toString()) ?? 0;
    final bool active = product['active'] == true;

    if (id == 0) return;

    final result = await _service.updateProduct(
      productId: id,
      active: !active,
    );

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(active ? 'Producto inactivado' : 'Producto activado'),
        ),
      );
      await _loadAllData();
    }
  }

  Future<void> _showEditSuperAdminProfileDialog() async {
    final profile = _superAdminProfile;
    if (profile == null) return;

    final nameController =
        TextEditingController(text: (profile['name'] ?? '').toString());
    final emailController =
        TextEditingController(text: (profile['email'] ?? '').toString());
    final phoneController =
        TextEditingController(text: (profile['phone'] ?? '').toString());
    final cedulaController =
        TextEditingController(text: (profile['cedula'] ?? '').toString());

    await showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Editar mi perfil'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(
                    labelText: 'Nombre',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: emailController,
                  decoration: const InputDecoration(
                    labelText: 'Email',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: phoneController,
                  decoration: const InputDecoration(
                    labelText: 'Teléfono',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: cedulaController,
                  decoration: const InputDecoration(
                    labelText: 'Cédula',
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () async {
                final result = await _service.updateSuperAdminProfile(
                  name: nameController.text.trim(),
                  email: emailController.text.trim(),
                  phone: phoneController.text.trim(),
                  cedula: cedulaController.text.trim(),
                );

                if (!mounted) return;
                Navigator.pop(dialogContext);

                if (result['statusCode'] == 200) {
                  await _loadAllData();
                }
              },
              child: const Text('Guardar'),
            ),
          ],
        );
      },
    );

    nameController.dispose();
    emailController.dispose();
    phoneController.dispose();
    cedulaController.dispose();
  }

  Future<void> _showChangeSuperAdminPasswordDialog() async {
    final passwordController = TextEditingController();

    await showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Cambiar mi contraseña'),
          content: TextField(
            controller: passwordController,
            obscureText: true,
            decoration: const InputDecoration(
              labelText: 'Nueva contraseña',
              border: OutlineInputBorder(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () async {
                final result = await _service.updateSuperAdminPassword(
                  newPassword: passwordController.text.trim(),
                );

                if (!mounted) return;
                Navigator.pop(dialogContext);

                if (result['statusCode'] == 200) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Contraseña actualizada correctamente'),
                    ),
                  );
                }
              },
              child: const Text('Guardar'),
            ),
          ],
        );
      },
    );

    passwordController.dispose();
  }

  Future<void> _createInternalUser() async {
    if (_nameController.text.trim().isEmpty ||
        _emailController.text.trim().isEmpty ||
        _phoneController.text.trim().isEmpty ||
        _cedulaController.text.trim().isEmpty ||
        _passwordController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Completa todos los campos')),
      );
      return;
    }

    setState(() {
      _creatingUser = true;
    });

    final result = await _service.createInternalUser(
      name: _nameController.text.trim(),
      email: _emailController.text.trim().toLowerCase(),
      password: _passwordController.text.trim(),
      cedula: _cedulaController.text.trim(),
      role: _selectedRole.trim().toLowerCase(),
      phone: _phoneController.text.trim(),
    );

    debugPrint('CREATE INTERNAL USER RESULT: $result');

    if (!mounted) return;

    setState(() {
      _creatingUser = false;
    });

    if (result['statusCode'] == 200 || result['statusCode'] == 201) {
      _nameController.clear();
      _emailController.clear();
      _phoneController.clear();
      _cedulaController.clear();
      _passwordController.clear();

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Usuario interno creado correctamente')),
      );

      await _loadAllData();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No se pudo crear el usuario interno',
          ),
        ),
      );
    }
  }

  Future<void> _toggleStatus(Map<String, dynamic> user) async {
    final int userId = user['id'];
    final bool currentStatus = user['is_active'] == true;

    final result = await _service.updateInternalUserStatus(
      userId: userId,
      isActive: !currentStatus,
    );

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      await _loadAllData();
    }
  }

  Future<void> _showResetPasswordDialog(Map<String, dynamic> user) async {
    final controller = TextEditingController();

    await showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: Text('Cambiar contraseña - ${user['name']}'),
          content: TextField(
            controller: controller,
            obscureText: true,
            decoration: const InputDecoration(
              labelText: 'Nueva contraseña',
              border: OutlineInputBorder(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () async {
                final result = await _service.resetAnyUserPassword(
                  userId: user['id'],
                  newPassword: controller.text.trim(),
                );

                if (!mounted) return;
                Navigator.pop(dialogContext);

                if (result['statusCode'] == 200) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Contraseña actualizada correctamente'),
                    ),
                  );
                }
              },
              child: const Text('Guardar'),
            ),
          ],
        );
      },
    );

    controller.dispose();
  }

  Future<void> _showPharmacyAccessCodesDialog() async {
    final pointsController = TextEditingController(text: '0001');
    final doctorController = TextEditingController(text: '0001');
    final adminController = TextEditingController(text: '4444');
    final logisticsController = TextEditingController(text: '8888');

    final currentResult = await _service.getPharmacyAccessCodes();

    if (currentResult['statusCode'] == 200) {
      final items = currentResult['data']?['items'];
      if (items is Map) {
        pointsController.text =
            (items['pharmacy_points']?['code'] ?? '0001').toString();
        doctorController.text =
            (items['doctor_prescriber']?['code'] ?? '0001').toString();
        adminController.text =
            (items['pharmacy_admin']?['code'] ?? '4444').toString();
        logisticsController.text =
            (items['pharmacy_logistics']?['code'] ?? '8888').toString();
      }
    }

    if (!mounted) return;

    await showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Códigos de acceso Farmacia'),
          content: SizedBox(
            width: 460,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: pointsController,
                    decoration: const InputDecoration(
                      labelText: 'Puntos Farmacia',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: doctorController,
                    decoration: const InputDecoration(
                      labelText: 'Doctor Prescriptor',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: adminController,
                    decoration: const InputDecoration(
                      labelText: 'Administrador Farmacia',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: logisticsController,
                    decoration: const InputDecoration(
                      labelText: 'Logística Farmacia',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancelar'),
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.vpn_key),
              label: const Text('Guardar códigos'),
              onPressed: () async {
                final result = await _service.updatePharmacyAccessCodes(
                  pharmacyPoints: pointsController.text,
                  doctorPrescriber: doctorController.text,
                  pharmacyAdmin: adminController.text,
                  pharmacyLogistics: logisticsController.text,
                );

                if (!mounted) return;
                Navigator.pop(dialogContext);

                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      result['statusCode'] == 200
                          ? 'Códigos de farmacia actualizados'
                          : (result['data']?['detail'] ??
                                  'No se pudieron guardar los códigos')
                              .toString(),
                    ),
                  ),
                );
              },
            ),
          ],
        );
      },
    );

    pointsController.dispose();
    doctorController.dispose();
    adminController.dispose();
    logisticsController.dispose();
  }

  Future<void> _showEditInternalUserDialog(Map<String, dynamic> user) async {
    final currentRole = (user['role'] ?? '').toString();

    if (!_canEditInternalRole(currentRole)) return;

    final nameController =
        TextEditingController(text: (user['name'] ?? '').toString());
    final emailController =
        TextEditingController(text: (user['email'] ?? '').toString());
    final phoneController =
        TextEditingController(text: (user['phone'] ?? '').toString());
    final cedulaController =
        TextEditingController(text: (user['cedula'] ?? '').toString());

    String selectedRole = currentRole;

    await showDialog(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text('Editar usuario - ${user['name']}'),
              content: SingleChildScrollView(
                child: Column(
                  children: [
                    TextField(
                      controller: nameController,
                      decoration: const InputDecoration(
                        labelText: 'Nombre',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: emailController,
                      decoration: const InputDecoration(
                        labelText: 'Email',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: phoneController,
                      decoration: const InputDecoration(
                        labelText: 'Teléfono',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: cedulaController,
                      decoration: const InputDecoration(
                        labelText: 'Cédula',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      initialValue: selectedRole,
                      decoration: const InputDecoration(
                        labelText: 'Rol',
                        border: OutlineInputBorder(),
                      ),
                      items: const [
                        DropdownMenuItem(
                          value: 'admin',
                          child: Text('Administrador'),
                        ),
                        DropdownMenuItem(
                          value: 'supervisor',
                          child: Text('Supervisor'),
                        ),
                        DropdownMenuItem(
                          value: 'logistics',
                          child: Text('Logística'),
                        ),
                        DropdownMenuItem(
                          value: 'marketing',
                          child: Text('Marketing'),
                        ),
                        DropdownMenuItem(
                          value: 'pharmacy_admin',
                          child: Text('Farmacia Mayu'),
                        ),
                        DropdownMenuItem(
                          value: 'education_admin',
                          child: Text('Mayu Educación'),
                        ),
                      ],
                      onChanged: (value) {
                        if (value == null) return;
                        setDialogState(() {
                          selectedRole = value;
                        });
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Cancelar'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    final result = await _service.updateInternalUser(
                      userId: user['id'],
                      name: nameController.text.trim(),
                      email: emailController.text.trim(),
                      cedula: cedulaController.text.trim(),
                      role: selectedRole,
                      phone: phoneController.text.trim(),
                    );

                    if (!mounted) return;
                    Navigator.pop(dialogContext);

                    if (result['statusCode'] == 200) {
                      await _loadAllData();
                    }
                  },
                  child: const Text('Guardar'),
                ),
              ],
            );
          },
        );
      },
    );

    nameController.dispose();
    emailController.dispose();
    phoneController.dispose();
    cedulaController.dispose();
  }

  Future<void> _deleteUser(Map<String, dynamic> user) async {
    final role = (user['role'] ?? '').toString();

    if (_isProtectedSystemRole(role)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No puedes eliminar usuarios del sistema Mayu Team'),
        ),
      );
      return;
    }

    final confirm = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Eliminar usuario'),
          content: Text(
            '¿Seguro que deseas eliminar a ${user['name']}? Esta acción no se puede deshacer.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Eliminar'),
            ),
          ],
        );
      },
    );

    if (confirm != true) return;

    final result = await _service.deleteUserFull(userId: user['id']);

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      await _loadAllData();
    }
  }

  Future<void> _logout() async {
    await _authService.logout();

    if (!mounted) return;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  Widget _box({required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.black.withValues(alpha: 0.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _sectionHeader(String title, String subtitle) {
    return Padding(
      padding: const EdgeInsets.only(top: 18, bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 22,
              height: 1.12,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            style: const TextStyle(
              color: Colors.black54,
              fontSize: 14,
              height: 1.35,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSuperAdminProfileCard() {
    final profile = _superAdminProfile;

    if (profile == null) {
      return const Text('No se pudo cargar el perfil superadmin');
    }

    Widget infoLine(IconData icon, String label, String value) {
      return Padding(
        padding: const EdgeInsets.only(top: 7),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 18, color: Colors.teal.shade700),
            const SizedBox(width: 9),
            Expanded(
              child: RichText(
                text: TextSpan(
                  style: const TextStyle(
                    color: Colors.black87,
                    fontSize: 14.5,
                    height: 1.25,
                  ),
                  children: [
                    TextSpan(
                      text: '$label: ',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    TextSpan(text: value),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    }

    return _box(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: Colors.teal.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(
                  Icons.admin_panel_settings,
                  color: Colors.teal.shade700,
                  size: 28,
                ),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Mi Perfil Superadmin',
                      style: TextStyle(
                        fontSize: 20,
                        height: 1.05,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    SizedBox(height: 3),
                    Text(
                      'Control maestro del sistema',
                      style: TextStyle(color: Colors.black54, fontSize: 13),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          infoLine(Icons.person_outline, 'Nombre', '${profile['name'] ?? '-'}'),
          infoLine(Icons.email_outlined, 'Email', '${profile['email'] ?? '-'}'),
          infoLine(Icons.phone_outlined, 'Teléfono', '${profile['phone'] ?? '-'}'),
          infoLine(Icons.badge_outlined, 'Cédula', '${profile['cedula'] ?? '-'}'),
          infoLine(
            Icons.verified_user_outlined,
            'Rol',
            _roleLabel((profile['role'] ?? '').toString()),
          ),
          const SizedBox(height: 16),
          LayoutBuilder(
            builder: (context, constraints) {
              final compact = constraints.maxWidth < 420;

              final editButton = ElevatedButton.icon(
                onPressed: _showEditSuperAdminProfileDialog,
                icon: const Icon(Icons.edit, size: 18),
                label: const Text('Editar perfil'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
              );

              final passwordButton = ElevatedButton.icon(
                onPressed: _showChangeSuperAdminPasswordDialog,
                icon: const Icon(Icons.lock_reset, size: 18),
                label: const Text('Cambiar clave'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF26AFA4),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
              );

              if (compact) {
                return Column(
                  children: [
                    SizedBox(width: double.infinity, child: editButton),
                    const SizedBox(height: 10),
                    SizedBox(width: double.infinity, child: passwordButton),
                  ],
                );
              }

              return Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [editButton, passwordButton],
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildProductsCatalogCard() {
    final filteredProducts = _products.where((p) {
      final product = Map<String, dynamic>.from(p);
      final name = (product['name'] ?? '').toString().toLowerCase();
      final category = (product['category'] ?? '').toString();

      final matchesSearch = name.contains(_productSearchQuery.toLowerCase());
      final matchesCategory = _selectedProductCategoryFilter == 'todas' ||
          category == _selectedProductCategoryFilter;

      return matchesSearch && matchesCategory;
    }).toList();

    return _box(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.inventory_2_outlined, color: Colors.teal),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Catálogo maestro',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Text(
            'Crea productos, asígnalos a una categoría y mantenlos listos para las selecciones mensuales.',
            style: TextStyle(fontSize: 14.5, height: 1.35, color: Colors.black87),
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              SizedBox(
                width: 500,
                child: TextField(
                  decoration: InputDecoration(
                    hintText: 'Buscar producto',
                    prefixIcon: const Icon(Icons.search),
                    filled: true,
                    fillColor: Colors.grey.shade50,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  onChanged: (value) {
                    setState(() {
                      _productSearchQuery = value;
                    });
                  },
                ),
              ),
              SizedBox(
                width: 240,
                child: DropdownButtonFormField<String>(
                  initialValue: _selectedProductCategoryFilter,
                  decoration: InputDecoration(
                    labelText: 'Categoría',
                    filled: true,
                    fillColor: Colors.grey.shade50,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  items: [
                    const DropdownMenuItem(
                      value: 'todas',
                      child: Text('Todas'),
                    ),
                    ..._categories.map(
                      (category) => DropdownMenuItem(
                        value: category,
                        child: Text(_categoryLabel(category)),
                      ),
                    ),
                  ],
                  onChanged: (value) {
                    if (value == null) return;
                    setState(() {
                      _selectedProductCategoryFilter = value;
                    });
                  },
                ),
              ),
              SizedBox(
                height: 54,
                child: ElevatedButton.icon(
                  onPressed: () => _showProductDialog(),
                  icon: const Icon(Icons.add),
                  label: const Text('Crear producto'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 18),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 560,
            child: filteredProducts.isEmpty
                ? const Center(child: Text('No hay productos para mostrar'))
                : GridView.builder(
                    itemCount: filteredProducts.length,
                    gridDelegate:
                        const SliverGridDelegateWithMaxCrossAxisExtent(
                      maxCrossAxisExtent: 390,
                      childAspectRatio: 1.55,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 12,
                    ),
                    itemBuilder: (context, index) {
                      return _buildProductCard(
                        Map<String, dynamic>.from(filteredProducts[index]),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildProductCard(Map<String, dynamic> product) {
    final bool active = product['active'] == true;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: active ? Colors.green.shade50 : Colors.red.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: active ? Colors.green.shade100 : Colors.red.shade100,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            product['name']?.toString() ?? 'Sin nombre',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
          Text(
            'Categoría: ${_categoryLabel((product['category'] ?? '-').toString())}',
          ),
          Text('Costo: \$${product['price'] ?? 0}'),
          Text(active ? 'Activo' : 'Inactivo'),
          const Spacer(),
          Wrap(
            spacing: 4,
            runSpacing: 0,
            children: [
              TextButton.icon(
                style: TextButton.styleFrom(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
                onPressed: () => _showProductDialog(product: product),
                icon: const Icon(Icons.edit, size: 16),
                label: const Text('Editar'),
              ),
              TextButton.icon(
                style: TextButton.styleFrom(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
                onPressed: () => _toggleProductActive(product),
                icon: Icon(
                  active ? Icons.visibility_off : Icons.visibility,
                  size: 16,
                ),
                label: Text(active ? 'Inactivar' : 'Activar'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCreateInternalUserCard() {
    return _box(
      child: Column(
        children: [
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              SizedBox(
                width: 260,
                child: TextField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Nombre completo',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              SizedBox(
                width: 260,
                child: TextField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                    labelText: 'Email',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              SizedBox(
                width: 200,
                child: TextField(
                  controller: _phoneController,
                  decoration: const InputDecoration(
                    labelText: 'Teléfono',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              SizedBox(
                width: 200,
                child: TextField(
                  controller: _cedulaController,
                  decoration: const InputDecoration(
                    labelText: 'Cédula',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              SizedBox(
                width: 220,
                child: TextField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Contraseña',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              SizedBox(
                width: 220,
                child: DropdownButtonFormField<String>(
                  initialValue: _selectedRole,
                  decoration: const InputDecoration(
                    labelText: 'Rol',
                    border: OutlineInputBorder(),
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: 'admin',
                      child: Text('Administrador'),
                    ),
                    DropdownMenuItem(
                      value: 'supervisor',
                      child: Text('Supervisor'),
                    ),
                    DropdownMenuItem(
                      value: 'logistics',
                      child: Text('Logística'),
                    ),
                    DropdownMenuItem(
                      value: 'marketing',
                      child: Text('Marketing'),
                    ),
                    DropdownMenuItem(
                      value: 'pharmacy_admin',
                      child: Text('Farmacia Mayu'),
                    ),
                    DropdownMenuItem(
                      value: 'education_admin',
                      child: Text('Mayu Educación'),
                    ),
                  ],
                  onChanged: (value) {
                    if (value == null) return;
                    setState(() {
                      _selectedRole = value;
                    });
                  },
                ),
              ),
              SizedBox(
                height: 56,
                child: ElevatedButton.icon(
                  onPressed: _creatingUser ? null : _createInternalUser,
                  icon: const Icon(Icons.person_add),
                  label: const Text('Crear'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCompactUserList(String title, List<dynamic> users) {
    return _box(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$title (${users.length})',
            style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 340,
            child: users.isEmpty
                ? const Center(child: Text('No hay registros'))
                : ListView.builder(
                    itemCount: users.length,
                    itemBuilder: (context, index) {
                      return _buildUserCard(
                        Map<String, dynamic>.from(users[index]),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildUserCard(Map<String, dynamic> user) {
    final bool isActive = user['is_active'] == true;
    final String role = (user['role'] ?? '').toString();
    final bool canEditRole = _canEditInternalRole(role);
    final bool isProtectedRole = _isProtectedSystemRole(role);

    final IconData roleIcon = role == 'member'
        ? Icons.person
        : role == 'ambassador'
            ? Icons.handshake
            : role == 'marketing'
                ? Icons.campaign
                : role == 'pharmacy_admin'
                    ? Icons.local_pharmacy
                    : role == 'education_admin'
                        ? Icons.school
                        : Icons.admin_panel_settings;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(roleIcon, color: Colors.teal),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      user['name'] ?? 'Sin nombre',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      user['email'] ?? '',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Rol: ${_roleLabel(role)} | Tel: ${user['phone'] ?? '-'}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    if (role == 'member')
                      Text(
                        'Nivel: ${user['membership_level'] ?? '-'} | Membresía: ${user['membership_active'] == true ? 'Activa' : 'Inactiva'}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              Chip(
                visualDensity: VisualDensity.compact,
                label: Text(isActive ? 'Activo' : 'Inactivo'),
                backgroundColor:
                    isActive ? Colors.green.shade100 : Colors.red.shade100,
              ),
              if (canEditRole)
                IconButton.filledTonal(
                  visualDensity: VisualDensity.compact,
                  onPressed: () => _showEditInternalUserDialog(user),
                  icon: const Icon(Icons.edit),
                  tooltip: 'Editar',
                ),
              if (role != 'superadmin')
                IconButton.filledTonal(
                  visualDensity: VisualDensity.compact,
                  onPressed: () => _showResetPasswordDialog(user),
                  icon: const Icon(Icons.lock_reset),
                  tooltip: 'Resetear clave',
                ),
              if (_isFarmaciaMayuUser(user))
                IconButton.filledTonal(
                  visualDensity: VisualDensity.compact,
                  onPressed: _showPharmacyAccessCodesDialog,
                  icon: const Icon(Icons.vpn_key),
                  tooltip: 'Códigos farmacia',
                ),
              if (role != 'superadmin')
                IconButton.filledTonal(
                  visualDensity: VisualDensity.compact,
                  onPressed: () => _toggleStatus(user),
                  icon: Icon(isActive ? Icons.block : Icons.check_circle),
                  tooltip: isActive ? 'Desactivar' : 'Activar',
                ),
              if (!isProtectedRole)
                IconButton.filledTonal(
                  visualDensity: VisualDensity.compact,
                  onPressed: () => _deleteUser(user),
                  icon: const Icon(Icons.delete, color: Colors.red),
                  tooltip: 'Eliminar',
                ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _cedulaController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mayuTeam = _internalUsers.where((user) {
      final role = (user['role'] ?? '').toString();
      return role == 'superadmin' ||
          role == 'admin' ||
          role == 'supervisor' ||
          role == 'logistics' ||
          role == 'marketing' ||
          role == 'pharmacy_admin' ||
          role == 'education_admin';
    }).toList();

    final ambassadors = _internalUsers.where((user) {
      return (user['role'] ?? '').toString() == 'ambassador';
    }).toList();

    final members = _internalUsers.where((user) {
      return (user['role'] ?? '').toString() == 'member';
    }).toList();

    final filteredUsers = _allUsers.where((user) {
      final name = (user['name'] ?? '').toString().toLowerCase();
      final email = (user['email'] ?? '').toString().toLowerCase();
      final phone = (user['phone'] ?? '').toString().toLowerCase();
      final cedula = (user['cedula'] ?? '').toString().toLowerCase();
      final role = (user['role'] ?? '').toString().toLowerCase();
      final ambassadorCode =
          (user['ambassador_code'] ?? '').toString().toLowerCase();

      return name.contains(_searchQuery) ||
          email.contains(_searchQuery) ||
          phone.contains(_searchQuery) ||
          cedula.contains(_searchQuery) ||
          role.contains(_searchQuery) ||
          ambassadorCode.contains(_searchQuery);
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Control Maestro V7.4'),
        actions: [
          IconButton(
            onPressed: _loadAllData,
            icon: const Icon(Icons.refresh),
          ),
          IconButton(
            onPressed: _logout,
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Text(
                    _error!,
                    style: const TextStyle(color: Colors.red),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadAllData,
                  child: SingleChildScrollView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(18, 18, 18, 32),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildSuperAdminProfileCard(),
                        _sectionHeader(
                          'Catálogo maestro V7.4',
                          'Vista visual actualizada: buscador, filtros y productos con diseño limpio.',
                        ),
                        _buildProductsCatalogCard(),
                        _sectionHeader(
                          'Crear usuario interno',
                          'Alta rápida para administración, supervisión, logística, marketing, farmacia y educación.',
                        ),
                        _buildCreateInternalUserCard(),
                        _sectionHeader(
                          'Usuarios del sistema',
                          'Listas compactas con scroll interno.',
                        ),
                        LayoutBuilder(
                          builder: (context, constraints) {
                            final bool wide = constraints.maxWidth > 900;

                            if (wide) {
                              return Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: _buildCompactUserList(
                                      'Mayu Team',
                                      mayuTeam,
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: _buildCompactUserList(
                                      'Embajadores',
                                      ambassadors,
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: _buildCompactUserList(
                                      'Socios',
                                      members,
                                    ),
                                  ),
                                ],
                              );
                            }

                            return Column(
                              children: [
                                _buildCompactUserList('Mayu Team', mayuTeam),
                                _buildCompactUserList(
                                  'Embajadores',
                                  ambassadors,
                                ),
                                _buildCompactUserList('Socios', members),
                              ],
                            );
                          },
                        ),
                        _sectionHeader(
                          'Búsqueda general',
                          'Busca por nombre, email, teléfono, cédula, rol o código.',
                        ),
                        TextField(
                          decoration: const InputDecoration(
                            hintText: 'Buscar usuario',
                            prefixIcon: Icon(Icons.search),
                            border: OutlineInputBorder(),
                          ),
                          onChanged: (value) {
                            setState(() {
                              _searchQuery = value.toLowerCase();
                            });
                          },
                        ),
                        const SizedBox(height: 12),
                        if (_searchQuery.trim().isNotEmpty)
                          _box(
                            child: SizedBox(
                              height: 340,
                              child: filteredUsers.isEmpty
                                  ? const Center(
                                      child: Text('No se encontraron usuarios'),
                                    )
                                  : ListView.builder(
                                      itemCount: filteredUsers.length,
                                      itemBuilder: (context, index) {
                                        return _buildUserCard(
                                          Map<String, dynamic>.from(
                                            filteredUsers[index],
                                          ),
                                        );
                                      },
                                    ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
    );
  }
}