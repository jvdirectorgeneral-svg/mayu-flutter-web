import 'package:flutter/material.dart';

class MyWalletScreen extends StatelessWidget {
  final int userId;
  final String userName;

  const MyWalletScreen({
    super.key,
    required this.userId,
    required this.userName,
  });

  Widget _balanceCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.teal.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.teal.withValues(alpha: 0.35)),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Saldo disponible',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 8),
          Text(
            '\$0.00',
            style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 6),
          Text(
            'Aquí se mostrarán comisiones, saldos y movimientos disponibles.',
          ),
        ],
      ),
    );
  }

  Widget _walletItem({
    required IconData icon,
    required String title,
    required String value,
    required Color color,
  }) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 30),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoBox() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      margin: const EdgeInsets.only(top: 6),
      decoration: BoxDecoration(
        color: Colors.blueGrey.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.blueGrey.withValues(alpha: 0.25)),
      ),
      child: const Text(
        'Esta billetera interna está lista visualmente. El Wallet real del teléfono se maneja desde la pantalla Wallet Mayu con Apple Wallet y Google Wallet.',
        style: TextStyle(
          fontSize: 15,
          color: Colors.black54,
          height: 1.35,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F3),
      appBar: AppBar(
        title: const Text('Mi billetera'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 620),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  userName,
                  style: const TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'Usuario ID: $userId',
                  style: const TextStyle(color: Colors.black54),
                ),
                const SizedBox(height: 18),
                _balanceCard(),
                const SizedBox(height: 22),
                const Text(
                  'Resumen',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                _walletItem(
                  icon: Icons.pending_actions,
                  title: 'Comisiones pendientes',
                  value: '\$0.00',
                  color: Colors.orange,
                ),
                _walletItem(
                  icon: Icons.check_circle_outline,
                  title: 'Comisiones pagadas',
                  value: '\$0.00',
                  color: Colors.green,
                ),
                _walletItem(
                  icon: Icons.history,
                  title: 'Movimientos registrados',
                  value: '0',
                  color: Colors.blueGrey,
                ),
                _infoBox(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}