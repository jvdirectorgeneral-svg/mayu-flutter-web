import 'package:flutter/material.dart';
import '../services/supervisor_dashboard_service.dart';
import '../services/auth_service.dart';
import 'login_screen.dart';

class SupervisorDashboardScreen extends StatefulWidget {
  const SupervisorDashboardScreen({super.key});

  @override
  State<SupervisorDashboardScreen> createState() =>
      _SupervisorDashboardScreenState();
}

class _SupervisorDashboardScreenState extends State<SupervisorDashboardScreen> {
  final SupervisorDashboardService _service = SupervisorDashboardService();
  final AuthService _authService = AuthService();

  bool _loading = true;
  String? _error;

  Map<String, dynamic>? _kpis;
  Map<String, dynamic>? _adminSummary;
  Map<String, dynamic>? _planDistribution;

  List<dynamic> _adminPayments = [];
  List<dynamic> _adminOrders = [];
  List<dynamic> _ambassadorRanking = [];
  List<dynamic> _monthlyUsersGrowth = [];
  List<dynamic> _monthlyCommissionsGrowth = [];

  @override
  void initState() {
    super.initState();
    loadDashboard();
  }

  Map<String, dynamic> _safeMap(dynamic data) {
    if (data is Map) {
      return Map<String, dynamic>.from(data);
    }
    return {};
  }

  List<dynamic> _safeItems(dynamic data) {
    if (data is List) {
      return data;
    }
    if (data is Map && data['items'] is List) {
      return data['items'] as List<dynamic>;
    }
    return [];
  }

  void _logDashboardEndpoint(String name, Map<String, dynamic> result) {
    final statusCode = result['statusCode'];
    final data = result['data'];
    if (statusCode is int && statusCode >= 400) {
      debugPrint('SUPERVISOR $name ERROR $statusCode: $data');
    }
  }

  Future<void> loadDashboard() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final kpisResult = await _service.getKpis();
      final adminSummaryResult = await _service.getAdminSummary();
      final adminPaymentsResult = await _service.getAdminPayments();
      final adminOrdersResult = await _service.getAdminOrders();
      final planDistributionResult = await _service.getPlanDistribution();
      final ambassadorRankingResult = await _service.getAmbassadorRanking();
      final monthlyUsersGrowthResult = await _service.getMonthlyUsersGrowth();
      final monthlyCommissionsGrowthResult =
          await _service.getMonthlyCommissionsGrowth();

      _logDashboardEndpoint('kpis', kpisResult);
      _logDashboardEndpoint('summary', adminSummaryResult);
      _logDashboardEndpoint('payments', adminPaymentsResult);
      _logDashboardEndpoint('orders', adminOrdersResult);
      _logDashboardEndpoint('planDistribution', planDistributionResult);
      _logDashboardEndpoint('ambassadorRanking', ambassadorRankingResult);
      _logDashboardEndpoint('monthlyUsersGrowth', monthlyUsersGrowthResult);
      _logDashboardEndpoint(
        'monthlyCommissionsGrowth',
        monthlyCommissionsGrowthResult,
      );

      if (!mounted) return;

      setState(() {
        _kpis = _safeMap(kpisResult['data']);
        _adminSummary = _safeMap(adminSummaryResult['data']);
        _planDistribution = _safeMap(planDistributionResult['data']);

        _adminPayments = _safeItems(adminPaymentsResult['data']);
        _adminOrders = _safeItems(adminOrdersResult['data']);
        _ambassadorRanking = _safeItems(ambassadorRankingResult['data']);

        final usersGrowth = monthlyUsersGrowthResult['data'];
        _monthlyUsersGrowth = usersGrowth is List ? usersGrowth : [];

        final commissionsGrowth = monthlyCommissionsGrowthResult['data'];
        _monthlyCommissionsGrowth =
            commissionsGrowth is List ? commissionsGrowth : [];

        _loading = false;
      });
    } catch (e) {
      debugPrint('SUPERVISOR DASHBOARD LOAD ERROR: $e');

      if (!mounted) return;

      setState(() {
        _loading = false;
        _error = 'Error cargando dashboard supervisor: $e';
      });
    }
  }

  Future<void> _logout() async {
    await _authService.logout();

    if (!mounted) return;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const LoginScreen()),
      (route) => false,
    );
  }

  double _toDouble(dynamic value) {
    if (value == null) return 0;
    if (value is num) return value.toDouble();
    return double.tryParse(value.toString()) ?? 0;
  }

  String _money(dynamic value) {
    final amount = _toDouble(value);
    return '\$${amount.toStringAsFixed(2)}';
  }

  bool _paymentIsRealPaid(Map<String, dynamic> payment) {
    final status = (payment['status'] ?? '').toString();
    return status == 'verified' ||
        status == 'paid' ||
        status == 'subscription_active' ||
        status == 'subscription_paid';
  }

  bool _paymentIsPending(Map<String, dynamic> payment) {
    final status = (payment['status'] ?? '').toString();
    return status == 'created' ||
        status == 'subscription_created' ||
        status == 'pending';
  }

  double _realPaidAmount() {
    double total = 0;

    for (final item in _adminPayments) {
      final payment = Map<String, dynamic>.from(item);
      if (_paymentIsRealPaid(payment)) {
        total += _toDouble(payment['amount']);
      }
    }

    return total;
  }

  double _pendingPaymentAmount() {
    double total = 0;

    for (final item in _adminPayments) {
      final payment = Map<String, dynamic>.from(item);
      if (_paymentIsPending(payment)) {
        total += _toDouble(payment['amount']);
      }
    }

    return total;
  }

  int _countOrdersByStatus(String status) {
    return _adminOrders.where((item) {
      final order = Map<String, dynamic>.from(item);
      return (order['status'] ?? '').toString() == status;
    }).length;
  }

  int _countPaymentsByStatus(String status) {
    return _adminPayments.where((item) {
      final payment = Map<String, dynamic>.from(item);
      return (payment['status'] ?? '').toString() == status;
    }).length;
  }

  Widget _sectionTitle(String title, {String? subtitle}) {
    return Padding(
      padding: const EdgeInsets.only(top: 26, bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          if (subtitle != null) ...[
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: TextStyle(color: Colors.grey.shade700),
            ),
          ],
        ],
      ),
    );
  }

  Widget _statCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
    VoidCallback? onTap,
  }) {
    final card = Container(
      height: 145,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withValues(alpha: 0.28)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 27),
              const Spacer(),
              if (onTap != null)
                Icon(
                  Icons.touch_app,
                  color: color.withValues(alpha: 0.72),
                  size: 19,
                ),
            ],
          ),
          const Spacer(),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 21,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 13),
          ),
        ],
      ),
    );

    if (onTap == null) return card;

    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: card,
      ),
    );
  }

  Widget _responsiveStats(List<Widget> children) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final double width = constraints.maxWidth;
        final int columns = width >= 900 ? 4 : 2;
        final double spacing = 12;
        final double itemWidth =
            (width - (spacing * (columns - 1))) / columns;

        return Wrap(
          spacing: spacing,
          runSpacing: spacing,
          children: children
              .map(
                (child) => SizedBox(
                  width: itemWidth,
                  child: child,
                ),
              )
              .toList(),
        );
      },
    );
  }

  Widget _financialHero() {
    final adminSummary = _adminSummary ?? {};
    final kpis = _kpis ?? {};
    final planDistribution = _planDistribution ?? {};
    final level1Count = _toDouble(planDistribution['cobre']);
    final level2Count = _toDouble(planDistribution['plata']);
    final level3Count = _toDouble(planDistribution['oro']);
    const level1Profit = 20.00;
    const level2Profit = 25.00;
    const level3Profit = 30.00;
    final membershipNetProfit = (level1Count * level1Profit) +
        (level2Count * level2Profit) +
        (level3Count * level3Profit) -
        _toDouble(adminSummary['total_generated'] ?? kpis['total_generated'] ?? 0);
    final pharmacySales = _toDouble(
      adminSummary['marketplace_pharmacy_paid_amount'] ??
          kpis['marketplace_pharmacy_paid_amount'] ??
          0,
    );
    final educationSales = _toDouble(
      adminSummary['education_paid_amount'] ?? kpis['education_paid_amount'] ?? 0,
    );
    final totalProfit = membershipNetProfit + pharmacySales + educationSales;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.green.shade900,
            Colors.teal.shade700,
          ],
        ),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Resumen financiero real',
            style: TextStyle(
              color: Colors.white,
              fontSize: 21,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Ganancia total conectada a Mayu Wellness Club',
            style: TextStyle(color: Colors.white.withValues(alpha: 0.85)),
          ),
          const SizedBox(height: 18),
          Text(
            _money(totalProfit),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 38,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Ganancia total',
            style: TextStyle(color: Colors.white.withValues(alpha: 0.85)),
          ),
        ],
      ),
    );
  }

  Widget _stockChartCard() {
    final Map<String, double> byMonth = {};

    for (final item in _adminPayments) {
      final payment = Map<String, dynamic>.from(item);
      if (!_paymentIsRealPaid(payment)) continue;

      final rawDate = payment['paid_at'] ?? payment['created_at'];
      if (rawDate == null) continue;

      try {
        final date = DateTime.parse(rawDate.toString()).toLocal();
        final key = '${date.month}/${date.year}';
        byMonth[key] = (byMonth[key] ?? 0) + _toDouble(payment['amount']);
      } catch (_) {}
    }

    final points = byMonth.entries
        .map(
          (entry) => _ChartPoint(label: entry.key, value: entry.value),
        )
        .toList();

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Gráfico financiero real',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Evolución mensual de pagos verificados desde Admin',
            style: TextStyle(color: Colors.grey.shade700),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 220,
            child: points.isEmpty
                ? const Center(child: Text('No hay pagos reales aún'))
                : CustomPaint(
                    painter: StockChartPainter(points),
                    child: Container(),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _planDistributionCard(Map<String, dynamic> planDistribution) {
    final total = _toDouble(planDistribution['total_active_members']);
    final cobre = _toDouble(planDistribution['cobre']);
    final plata = _toDouble(planDistribution['plata']);
    final oro = _toDouble(planDistribution['oro']);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Total activos: ${total.toInt()}'),
          const SizedBox(height: 14),
          _progressLine('Cobre', cobre, total, Colors.brown),
          _progressLine('Plata', plata, total, Colors.blueGrey),
          _progressLine('Oro', oro, total, Colors.amber.shade800),
        ],
      ),
    );
  }

  Widget _progressLine(String title, double value, double total, Color color) {
    final percent = total <= 0 ? 0.0 : (value / total).clamp(0.0, 1.0);

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('$title: ${value.toInt()}'),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: LinearProgressIndicator(
              value: percent,
              minHeight: 10,
              backgroundColor: Colors.grey.shade200,
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
        ],
      ),
    );
  }

  Widget _paymentStatusCard() {
    final verified = _countPaymentsByStatus('verified');
    final paid = _countPaymentsByStatus('paid');
    final subscriptionActive = _countPaymentsByStatus('subscription_active');
    final subscriptionCreated = _countPaymentsByStatus('subscription_created');
    final created = _countPaymentsByStatus('created');

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Estado real de pagos',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          _simpleLine('Pagos verificados', verified, Colors.green),
          _simpleLine('Pagos recibidos', paid, Colors.green),
          _simpleLine('Suscripciones activas', subscriptionActive, Colors.teal),
          _simpleLine('Suscripciones creadas / pendientes',
              subscriptionCreated, Colors.orange),
          _simpleLine('Pagos creados no finalizados', created, Colors.blueGrey),
        ],
      ),
    );
  }

  Widget _orderStatusCard() {
    final pending = _countOrdersByStatus('pending_payment_review');
    final ready = _countOrdersByStatus('approved_for_logistics');
    final preparing = _countOrdersByStatus('preparing');
    final shipped = _countOrdersByStatus('shipped');
    final delivered = _countOrdersByStatus('delivered');

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Estado real de órdenes',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          _simpleLine('Revisión de pago', pending, Colors.orange),
          _simpleLine('Listas para logística', ready, Colors.green),
          _simpleLine('Preparando', preparing, Colors.blue),
          _simpleLine('Enviadas', shipped, Colors.purple),
          _simpleLine('Entregadas', delivered, Colors.green),
        ],
      ),
    );
  }

  Widget _simpleLine(String label, int value, Color color) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Icon(Icons.circle, color: color, size: 12),
          const SizedBox(width: 8),
          Expanded(child: Text(label)),
          Text(
            '$value',
            style: TextStyle(fontWeight: FontWeight.bold, color: color),
          ),
        ],
      ),
    );
  }

  Widget _ambassadorRankingCard(Map<String, dynamic> data, int index) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black12),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: Colors.teal.shade100,
            child: Text(
              '${index + 1}',
              style: TextStyle(
                color: Colors.teal.shade900,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${data['ambassador_name'] ?? 'Sin nombre'}',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text('Código: ${data['ambassador_code'] ?? '-'}'),
                Text('Registros: ${data['total_records'] ?? 0}'),
              ],
            ),
          ),
          Text(
            _money(data['total_generated']),
            style: const TextStyle(
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _growthList({
    required String emptyText,
    required List<dynamic> data,
    required String valueKey,
    required String label,
    bool money = false,
  }) {
    if (data.isEmpty) {
      return Text(emptyText);
    }

    return Column(
      children: data.map((item) {
        final row = Map<String, dynamic>.from(item);
        final value = row[valueKey] ?? 0;

        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.black12),
          ),
          child: Row(
            children: [
              Expanded(
                child: Text('${row['month']}/${row['year']}'),
              ),
              Text(
                '$label: ${money ? _money(value) : value}',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }


  Widget _detailRow(String label, String value, {Color? color}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
          const SizedBox(width: 12),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _detailNote(String text) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.teal.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.teal.shade100),
      ),
      child: Text(text),
    );
  }

  void _showDetailSheet(String title, List<Widget> children) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          title,
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.close),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ...children,
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _showActiveSociosDetail() {
    final adminSummary = _adminSummary ?? {};
    final kpis = _kpis ?? {};
    final planDistribution = _planDistribution ?? {};
    final totalSocios = adminSummary['total_socios'] ?? kpis['total_users'] ?? 0;
    final activeSocios =
        adminSummary['active_socios'] ?? kpis['active_users'] ?? 0;
    final inactiveSocios = _toDouble(totalSocios) - _toDouble(activeSocios);

    final level1Count = _toDouble(planDistribution['cobre']);
    final level2Count = _toDouble(planDistribution['plata']);
    final level3Count = _toDouble(planDistribution['oro']);

    const level1Monthly = 44.80;
    const level2Monthly = 56.00;
    const level3Monthly = 67.20;

    const level1Profit = 20.00;
    const level2Profit = 25.00;
    const level3Profit = 30.00;

    final level1Income = level1Count * level1Monthly;
    final level2Income = level2Count * level2Monthly;
    final level3Income = level3Count * level3Monthly;
    final grossMembershipIncome = level1Income + level2Income + level3Income;

    final level1NetProfit = level1Count * level1Profit;
    final level2NetProfit = level2Count * level2Profit;
    final level3NetProfit = level3Count * level3Profit;
    final netProfitBeforeAmbassador =
        level1NetProfit + level2NetProfit + level3NetProfit;

    final ambassadorCommissions =
        _toDouble(adminSummary['total_generated'] ?? kpis['total_generated'] ?? 0);
    final finalNetProfit = netProfitBeforeAmbassador - ambassadorCommissions;

    var referredSocios = 0.0;
    for (final item in _ambassadorRanking) {
      final row = Map<String, dynamic>.from(item);
      referredSocios += _toDouble(row['total_records']);
    }
    final directSocios =
        (_toDouble(totalSocios) - referredSocios).clamp(0, double.infinity);

    _showDetailSheet(
      'Socios activos',
      [
        _detailNote(
          'La ganancia neta final no usa el cobro completo. Usa ganancia real por socio: Nivel 1 = USD 20, Nivel 2 = USD 25, Nivel 3 = USD 30. Después resta comisión de embajador.',
        ),
        _detailRow('Socios activos', '$activeSocios', color: Colors.green),
        _detailRow(
          'Socios inactivos',
          inactiveSocios.toStringAsFixed(0),
          color: Colors.orange,
        ),
        _detailRow('Total socios registrados', '$totalSocios', color: Colors.teal),
        const Divider(height: 24),
        _detailRow(
          'Cobrado Nivel 1',
          '${level1Count.toStringAsFixed(0)} x ${_money(level1Monthly)} = ${_money(level1Income)}',
          color: Colors.brown,
        ),
        _detailRow(
          'Cobrado Nivel 2',
          '${level2Count.toStringAsFixed(0)} x ${_money(level2Monthly)} = ${_money(level2Income)}',
          color: Colors.blueGrey,
        ),
        _detailRow(
          'Cobrado Nivel 3',
          '${level3Count.toStringAsFixed(0)} x ${_money(level3Monthly)} = ${_money(level3Income)}',
          color: Colors.amber,
        ),
        _detailRow(
          'Ingreso cobrado mensual',
          _money(grossMembershipIncome),
          color: Colors.teal,
        ),
        const Divider(height: 24),
        _detailRow(
          'Ganancia Nivel 1',
          '${level1Count.toStringAsFixed(0)} x ${_money(level1Profit)} = ${_money(level1NetProfit)}',
          color: Colors.brown,
        ),
        _detailRow(
          'Ganancia Nivel 2',
          '${level2Count.toStringAsFixed(0)} x ${_money(level2Profit)} = ${_money(level2NetProfit)}',
          color: Colors.blueGrey,
        ),
        _detailRow(
          'Ganancia Nivel 3',
          '${level3Count.toStringAsFixed(0)} x ${_money(level3Profit)} = ${_money(level3NetProfit)}',
          color: Colors.amber,
        ),
        _detailRow(
          'Ganancia antes de embajador',
          _money(netProfitBeforeAmbassador),
          color: Colors.teal,
        ),
        const Divider(height: 24),
        _detailRow(
          'Socios bajo embajador',
          referredSocios.toStringAsFixed(0),
          color: Colors.orange,
        ),
        _detailRow(
          'Socios directos',
          directSocios.toStringAsFixed(0),
          color: Colors.teal,
        ),
        _detailRow(
          'Comisión embajador',
          '-${_money(ambassadorCommissions)}',
          color: Colors.orange,
        ),
        _detailRow(
          'Ganancia neta final socios',
          _money(finalNetProfit),
          color: Colors.green,
        ),
      ],
    );
  }

  void _showAmbassadorsDetail() {
    final adminSummary = _adminSummary ?? {};
    final kpis = _kpis ?? {};
    final totalAmbassadors =
        adminSummary['total_ambassadors'] ?? kpis['total_ambassadors'] ?? 0;

    _showDetailSheet(
      'Embajadores',
      [
        _detailNote(
          'Embajadores son los afiliadores del Wellness Club. Solo ellos tienen comisiones por socios referidos.',
        ),
        _detailRow(
          'Embajadores registrados',
          '$totalAmbassadors',
          color: Colors.orange,
        ),
        const Divider(height: 24),
        const Text(
          'Ranking por generación',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        if (_ambassadorRanking.isEmpty)
          const Text('No hay datos de embajadores todavía.')
        else
          ..._ambassadorRanking.take(8).map((item) {
            final row = Map<String, dynamic>.from(item);
            final name = row['ambassador_name'] ?? 'Sin nombre';
            final code = row['ambassador_code'] ?? '-';
            final records = row['total_records'] ?? 0;
            final amount = row['total_generated'] ?? 0;
            return _detailRow(
              '$name ($code)',
              '$records socios | ${_money(amount)}',
            );
          }),
      ],
    );
  }

  void _showCommissionsDetail() {
    final adminSummary = _adminSummary ?? {};
    final kpis = _kpis ?? {};
    final generated =
        adminSummary['total_generated'] ?? kpis['total_generated'] ?? 0;
    final pending = adminSummary['total_pending'] ?? kpis['total_pending'] ?? 0;
    final paid = adminSummary['total_paid'] ?? kpis['total_paid'] ?? 0;

    _showDetailSheet(
      'Control de embajadores',
      [
        _detailNote(
          'Supervisor solo controla. El pago real se hace desde Admin Mayu en Pago a embajadores, habilitado del día 8 al 10. Cuando Admin paga, las comisiones pasan de por pagar a pagado y esta tarjeta se limpia al refrescar.',
        ),
        _detailRow('Total generado', _money(generated), color: Colors.teal),
        _detailRow(
          'Embajador por pagar',
          _money(pending),
          color: Colors.orange,
        ),
        _detailRow(
          'Embajador pagado',
          _money(paid),
          color: Colors.green,
        ),
        const Divider(height: 24),
        const Text(
          'Detalle por embajador',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        if (_ambassadorRanking.isEmpty)
          const Text('No hay embajadores con comisión todavía.')
        else
          ..._ambassadorRanking.take(12).map((item) {
            final row = Map<String, dynamic>.from(item);
            final name = row['ambassador_name'] ?? 'Sin nombre';
            final code = row['ambassador_code'] ?? '-';
            final records = row['total_records'] ?? 0;
            final rowPending = row['total_pending'] ?? 0;
            final rowPaid = row['total_paid'] ?? 0;
            final rowGenerated = row['total_generated'] ?? 0;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _detailRow(
                  '$name ($code)',
                  '$records socios | ${_money(rowGenerated)}',
                  color: Colors.teal,
                ),
                _detailRow('Por pagar', _money(rowPending), color: Colors.orange),
                _detailRow('Pagado', _money(rowPaid), color: Colors.green),
                const Divider(height: 20),
              ],
            );
          }),
      ],
    );
  }

  void _showPaymentsDetail() {
    _showDetailSheet(
      'Pagos reales',
      [
        _detailNote(
          'Aquí se resumen pagos verificados, recibidos y suscripciones activas. Los pagos creados o pendientes no cuentan como dinero real recibido.',
        ),
        _detailRow('Pagos registrados', '${_adminPayments.length}'),
        _detailRow('Valor real recibido', _money(_realPaidAmount()),
            color: Colors.green),
        _detailRow('Valor pendiente', _money(_pendingPaymentAmount()),
            color: Colors.orange),
        const Divider(height: 24),
        _detailRow('Verificados', '${_countPaymentsByStatus('verified')}'),
        _detailRow('Recibidos', '${_countPaymentsByStatus('paid')}'),
        _detailRow(
          'Suscripciones activas',
          '${_countPaymentsByStatus('subscription_active')}',
        ),
        _detailRow(
          'Suscripciones creadas',
          '${_countPaymentsByStatus('subscription_created')}',
        ),
        _detailRow('Creados no finalizados', '${_countPaymentsByStatus('created')}'),
      ],
    );
  }

  void _showMarketplaceDetail() {
    final adminSummary = _adminSummary ?? {};
    final kpis = _kpis ?? {};
    final pharmacyPaidOrders =
        adminSummary['marketplace_pharmacy_paid_orders'] ??
            kpis['marketplace_pharmacy_paid_orders'] ??
            0;
    final pharmacyPaidAmount =
        adminSummary['marketplace_pharmacy_paid_amount'] ??
            kpis['marketplace_pharmacy_paid_amount'] ??
            0;
    final educationPaidOrders =
        adminSummary['education_paid_orders'] ?? kpis['education_paid_orders'] ?? 0;
    final educationPaidAmount =
        adminSummary['education_paid_amount'] ?? kpis['education_paid_amount'] ?? 0;

    _showDetailSheet(
      'Ventas Farmacia/Educación',
      [
        _detailNote(
          'Farmacia y Educación no pagan comisión a nadie aquí. Este detalle es solo control de ventas del ciclo mensual actual.',
        ),
        _detailRow(
          'Total ventas',
          '${(_toDouble(pharmacyPaidOrders) + _toDouble(educationPaidOrders)).toStringAsFixed(0)} ventas | ${_money(_toDouble(pharmacyPaidAmount) + _toDouble(educationPaidAmount))}',
          color: Colors.teal,
        ),
        const Divider(height: 24),
        _detailRow(
          'Ventas Farmacia',
          '$pharmacyPaidOrders ventas | ${_money(pharmacyPaidAmount)}',
          color: Colors.teal,
        ),
        _detailRow(
          'Ventas Educación',
          '$educationPaidOrders ventas | ${_money(educationPaidAmount)}',
          color: Colors.indigo,
        ),
      ],
    );
  }

  void _showOrdersDetail() {
    _showDetailSheet(
      'Órdenes',
      [
        _detailNote(
          'Este detalle ayuda al supervisor a ver qué está en revisión, qué ya puede pasar a logística y qué ya fue despachado o entregado.',
        ),
        _detailRow(
          'Revisión de pago',
          '${_countOrdersByStatus('pending_payment_review')}',
          color: Colors.orange,
        ),
        _detailRow(
          'Listas para logística',
          '${_countOrdersByStatus('approved_for_logistics')}',
          color: Colors.green,
        ),
        _detailRow('Preparando', '${_countOrdersByStatus('preparing')}'),
        _detailRow('Enviadas', '${_countOrdersByStatus('shipped')}'),
        _detailRow('Entregadas', '${_countOrdersByStatus('delivered')}'),
      ],
    );
  }


  @override
  Widget build(BuildContext context) {
    final kpis = _kpis ?? {};
    final adminSummary = _adminSummary ?? {};
    final planDistribution = _planDistribution ?? {};

    final activeSocios =
        adminSummary['active_socios'] ?? kpis['active_users'] ?? 0;
    final totalAmbassadors =
        adminSummary['total_ambassadors'] ?? kpis['total_ambassadors'] ?? 0;
    final pendingOrders = adminSummary['pending_review_orders'] ?? 0;
    final readyOrders = adminSummary['ready_for_logistics'] ?? 0;
    final ambassadorCommissionPending =
        adminSummary['total_pending'] ?? kpis['total_pending'] ?? 0;
    final ambassadorCommissionPaid =
        adminSummary['total_paid'] ?? kpis['total_paid'] ?? 0;
    final pharmacyPaidOrders = adminSummary['marketplace_pharmacy_paid_orders'] ??
        kpis['marketplace_pharmacy_paid_orders'] ??
        0;
    final pharmacyPaidAmount = adminSummary['marketplace_pharmacy_paid_amount'] ??
        kpis['marketplace_pharmacy_paid_amount'] ??
        0;
    final educationPaidOrders =
        adminSummary['education_paid_orders'] ?? kpis['education_paid_orders'] ?? 0;
    final educationPaidAmount =
        adminSummary['education_paid_amount'] ?? kpis['education_paid_amount'] ?? 0;
    final marketplaceSalesOrders =
        _toDouble(pharmacyPaidOrders) + _toDouble(educationPaidOrders);
    final marketplaceSalesAmount =
        _toDouble(pharmacyPaidAmount) + _toDouble(educationPaidAmount);

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text('Supervisor Dashboard'),
        actions: [
          IconButton(
            onPressed: loadDashboard,
            icon: const Icon(Icons.refresh),
            tooltip: 'Actualizar',
          ),
          IconButton(
            onPressed: _logout,
            icon: const Icon(Icons.logout),
            tooltip: 'Cerrar sesión',
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Text(
                    _error!,
                    style: const TextStyle(color: Colors.red),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: loadDashboard,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      _financialHero(),
                      const SizedBox(height: 18),

                      _responsiveStats([
                        _statCard(
                          title: 'Socios activos',
                          value: '$activeSocios',
                          icon: Icons.verified_user,
                          color: Colors.green,
                          onTap: _showActiveSociosDetail,
                        ),
                        _statCard(
                          title: 'Embajadores',
                          value: '$totalAmbassadors',
                          icon: Icons.handshake,
                          color: Colors.orange,
                          onTap: _showAmbassadorsDetail,
                        ),
                        _statCard(
                          title: 'Embajador por pagar',
                          value: _money(ambassadorCommissionPending),
                          icon: Icons.account_balance_wallet,
                          color: Colors.orange,
                          onTap: _showCommissionsDetail,
                        ),
                        _statCard(
                          title: 'Embajador pagado',
                          value: _money(ambassadorCommissionPaid),
                          icon: Icons.verified,
                          color: Colors.green,
                          onTap: _showCommissionsDetail,
                        ),
                        _statCard(
                          title: 'Ventas Farmacia/Educación',
                          value:
                              '${marketplaceSalesOrders.toStringAsFixed(0)} | ${_money(marketplaceSalesAmount)}',
                          icon: Icons.storefront,
                          color: Colors.teal,
                          onTap: _showMarketplaceDetail,
                        ),
                        _statCard(
                          title: 'Órdenes revisión',
                          value: '$pendingOrders',
                          icon: Icons.rate_review,
                          color: Colors.orange,
                          onTap: _showOrdersDetail,
                        ),
                        _statCard(
                          title: 'Órdenes logística',
                          value: '$readyOrders',
                          icon: Icons.local_shipping,
                          color: Colors.green,
                          onTap: _showOrdersDetail,
                        ),
                      ]),

                      _sectionTitle(
                        'Control real de pagos y órdenes',
                        subtitle: 'Información conectada al backend Mayu',
                      ),
                      _paymentStatusCard(),
                      const SizedBox(height: 12),
                      _orderStatusCard(),

                      _sectionTitle(
                        'Gráfico financiero',
                        subtitle: 'Pagos reales verificados por mes',
                      ),
                      _stockChartCard(),

                      _sectionTitle(
                        'Distribución de planes',
                        subtitle: 'Cobre, plata y oro',
                      ),
                      _planDistributionCard(planDistribution),

                      _sectionTitle(
                        'Ranking de embajadores',
                        subtitle: 'Embajadores con mayor generación',
                      ),
                      if (_ambassadorRanking.isEmpty)
                        const Text('No hay datos')
                      else
                        ..._ambassadorRanking.asMap().entries.map((entry) {
                          final data = Map<String, dynamic>.from(entry.value);
                          return _ambassadorRankingCard(data, entry.key);
                        }),

                      _sectionTitle('Crecimiento mensual de usuarios'),
                      _growthList(
                        emptyText: 'No hay datos',
                        data: _monthlyUsersGrowth,
                        valueKey: 'total_users',
                        label: 'Usuarios',
                      ),

                      _sectionTitle('Crecimiento mensual de comisiones'),
                      _growthList(
                        emptyText: 'No hay datos',
                        data: _monthlyCommissionsGrowth,
                        valueKey: 'total_generated',
                        label: 'Generado',
                        money: true,
                      ),
                    ],
                  ),
                ),
    );
  }
}

class _ChartPoint {
  final String label;
  final double value;

  _ChartPoint({
    required this.label,
    required this.value,
  });
}

class StockChartPainter extends CustomPainter {
  final List<_ChartPoint> points;

  StockChartPainter(this.points);

  @override
  void paint(Canvas canvas, Size size) {
    final axisPaint = Paint()
      ..color = Colors.grey.shade300
      ..strokeWidth = 1;

    final linePaint = Paint()
      ..color = Colors.teal
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke;

    final fillPaint = Paint()
      ..color = Colors.teal.withValues(alpha: 0.12)
      ..style = PaintingStyle.fill;

    final dotPaint = Paint()
      ..color = Colors.teal
      ..style = PaintingStyle.fill;

    final leftPadding = 40.0;
    final bottomPadding = 32.0;
    final topPadding = 16.0;
    final rightPadding = 12.0;

    final chartWidth = size.width - leftPadding - rightPadding;
    final chartHeight = size.height - topPadding - bottomPadding;

    final maxValue = points
        .map((e) => e.value)
        .fold<double>(0, (prev, value) => value > prev ? value : prev);

    final safeMax = maxValue <= 0 ? 1 : maxValue;

    canvas.drawLine(
      Offset(leftPadding, topPadding),
      Offset(leftPadding, topPadding + chartHeight),
      axisPaint,
    );

    canvas.drawLine(
      Offset(leftPadding, topPadding + chartHeight),
      Offset(leftPadding + chartWidth, topPadding + chartHeight),
      axisPaint,
    );

    final path = Path();
    final fillPath = Path();

    for (int i = 0; i < points.length; i++) {
      final x = leftPadding +
          (points.length == 1 ? 0 : (chartWidth / (points.length - 1)) * i);
      final y =
          topPadding + chartHeight - ((points[i].value / safeMax) * chartHeight);

      if (i == 0) {
        path.moveTo(x, y);
        fillPath.moveTo(x, topPadding + chartHeight);
        fillPath.lineTo(x, y);
      } else {
        path.lineTo(x, y);
        fillPath.lineTo(x, y);
      }

      canvas.drawCircle(Offset(x, y), 4, dotPaint);

      final labelPainter = TextPainter(
        text: TextSpan(
          text: points[i].label,
          style: const TextStyle(fontSize: 9, color: Colors.black54),
        ),
        textDirection: TextDirection.ltr,
      );
      labelPainter.layout();

      labelPainter.paint(
        canvas,
        Offset(x - labelPainter.width / 2, topPadding + chartHeight + 8),
      );
    }

    if (points.isNotEmpty) {
      final lastX = leftPadding + (points.length == 1 ? 0 : chartWidth);
      fillPath.lineTo(lastX, topPadding + chartHeight);
      fillPath.close();

      canvas.drawPath(fillPath, fillPaint);
      canvas.drawPath(path, linePaint);
    }

    final maxLabel = TextPainter(
      text: TextSpan(
        text: '\$${safeMax.toStringAsFixed(0)}',
        style: const TextStyle(fontSize: 10, color: Colors.black54),
      ),
      textDirection: TextDirection.ltr,
    );
    maxLabel.layout();
    maxLabel.paint(canvas, const Offset(0, 12));

    final minLabel = TextPainter(
      text: const TextSpan(
        text: '\$0',
        style: TextStyle(fontSize: 10, color: Colors.black54),
      ),
      textDirection: TextDirection.ltr,
    );
    minLabel.layout();
    minLabel.paint(canvas, Offset(0, topPadding + chartHeight - 8));
  }

  @override
  bool shouldRepaint(covariant StockChartPainter oldDelegate) {
    return oldDelegate.points != points;
  }
}