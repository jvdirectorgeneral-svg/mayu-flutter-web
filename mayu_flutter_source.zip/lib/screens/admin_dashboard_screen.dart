import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/admin_dashboard_service.dart';
import '../services/auth_service.dart';

import 'login_screen.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  final AdminDashboardService _service = AdminDashboardService();
  final AuthService _authService = AuthService();

  static const String sectionAffiliations = 'affiliations';
  static const String sectionRenewals = 'renewals';
  static const String sectionOrders = 'orders';
  static const String sectionMembers = 'members';
  static const String sectionAmbassadors = 'ambassadors';

  bool loading = true;
  String? error;

  Map<String, dynamic> summary = {};
  List<dynamic> users = [];
  List<dynamic> payments = [];
  List<dynamic> newMembershipPayments = [];
  List<dynamic> renewalPayments = [];
  List<dynamic> monthlyRenewalItems = [];
  List<dynamic> orders = [];
  List<dynamic> ambassadors = [];
  List<dynamic> pendingCommissions = [];
  List<dynamic> paidCommissions = [];

  static const double margen1 = 16;

  String newPaymentSearch = '';
  String renewalPaymentSearch = '';
  String orderSearch = '';
  String userSearch = '';
  String ambassadorSearch = '';
  String activeSection = sectionAffiliations;

  @override
  void initState() {
    super.initState();
    loadAll();
  }

  Future<void> loadAll() async {
    setState(() {
      loading = true;
      error = null;
    });

    try {
      final summaryResult = await _service.getSummary();
      final usersResult = await _service.getUsers();
      final paymentsResult = await _service.getMembershipPayments();
      final ordersResult = await _service.getOrders();
      final ambassadorsResult = await _service.getAmbassadors();
      final commissionsResult = await _service.getPendingCommissions();
      final paidCommissionsResult = await _service.getPaidCommissions();

      if (!mounted) return;

      final usersData = usersResult['data'];
      final paymentsData = paymentsResult['data'];
      final ordersData = ordersResult['data'];
      final ambassadorsData = ambassadorsResult['data'];
      final commissionsData = commissionsResult['data'];
      final paidCommissionsData = paidCommissionsResult['data'];

      final rawUsers =
          usersData is List ? usersData : usersData?['items'] ?? [];
      final rawPayments =
          paymentsData is List ? paymentsData : paymentsData?['items'] ?? [];

      setState(() {
        summary = Map<String, dynamic>.from(summaryResult['data'] ?? {});

        users = rawUsers
            .where(
              (u) =>
                  u is Map<String, dynamic> &&
                  (u['role'] ?? '').toString() == 'member',
            )
            .toList();

        payments = rawPayments;

        newMembershipPayments = payments.where((p) {
          if (p is! Map) return false;

          final type = (p['payment_type'] ?? '').toString();
          final cycleType = (p['membership_cycle_type'] ?? '').toString();

          return cycleType == 'initial' ||
              type == 'signup' ||
              type == 'membership_initial' ||
              type == 'subscription';
        }).toList();

        orders = ordersData is List ? ordersData : ordersData?['items'] ?? [];

        renewalPayments = payments.where((p) {
          if (p is! Map) return false;

          final type = (p['payment_type'] ?? '').toString();
          final cycleType = (p['membership_cycle_type'] ?? '').toString();

          return cycleType == 'renewal' || type == 'subscription_renewal';
        }).toList();

        monthlyRenewalItems = _buildMonthlyRenewalItems(
          users,
          renewalPayments,
          orders,
        );

        ambassadors = ambassadorsData is List
            ? ambassadorsData
            : ambassadorsData?['items'] ?? [];

        pendingCommissions = commissionsData is List
            ? commissionsData
            : commissionsData?['items'] ?? [];

        paidCommissions = paidCommissionsData is List
            ? paidCommissionsData
            : paidCommissionsData?['items'] ?? [];

        loading = false;
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        error = 'Error cargando dashboard';
        loading = false;
      });
    }
  }

  bool _matchesSearch(Map<String, dynamic> data, String query) {
    if (query.trim().isEmpty) return true;
    final q = query.toLowerCase();

    return data.values.any((value) {
      if (value == null) return false;
      return value.toString().toLowerCase().contains(q);
    });
  }

  Future<void> _logout() async {
    await _authService.logout();
    if (!mounted) return;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  double _ambassadorAccumulatedAmount(Map<String, dynamic> ambassador) {
    return double.tryParse(
          (ambassador['commission_balance'] ??
                  ambassador['projected_monthly_commission'] ??
                  ambassador['projected_monthly_commission_raw'] ??
                  0)
              .toString(),
        ) ??
        0;
  }

  double _ambassadorPaidTotal(Map<String, dynamic> ambassador) {
    return double.tryParse(
          (ambassador['total_paid_commissions'] ?? ambassador['paid_total'] ?? 0)
              .toString(),
        ) ??
        0;
  }

  double _ambassadorPayableAmount(Map<String, dynamic> ambassador) {
    return double.tryParse(
          (ambassador['payable_commission_amount'] ?? 0).toString(),
        ) ??
        0;
  }

  bool _ambassadorPayoutWindowOpen(Map<String, dynamic> ambassador) {
    final backendValue = ambassador['payout_window_open'];
    if (backendValue is bool) return backendValue;

    final day = DateTime.now().day;
    return day >= 8 && day <= 10;
  }

  List<Map<String, dynamic>> _ambassadorCommissions(int ambassadorId) {
    final items = [...pendingCommissions, ...paidCommissions]
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .where((item) {
          final itemAmbassadorId =
              int.tryParse((item['ambassador_id'] ?? 0).toString()) ?? 0;
          return itemAmbassadorId == ambassadorId;
        })
        .toList();

    items.sort((a, b) {
      final yearA = int.tryParse((a['year'] ?? 0).toString()) ?? 0;
      final yearB = int.tryParse((b['year'] ?? 0).toString()) ?? 0;
      final monthA = int.tryParse((a['month'] ?? 0).toString()) ?? 0;
      final monthB = int.tryParse((b['month'] ?? 0).toString()) ?? 0;
      final idA = int.tryParse((a['id'] ?? a['commission_id'] ?? 0).toString()) ?? 0;
      final idB = int.tryParse((b['id'] ?? b['commission_id'] ?? 0).toString()) ?? 0;

      final byYear = yearB.compareTo(yearA);
      if (byYear != 0) return byYear;
      final byMonth = monthB.compareTo(monthA);
      if (byMonth != 0) return byMonth;
      return idB.compareTo(idA);
    });

    return items;
  }

  String _commissionMonthLabel(dynamic month, dynamic year) {
    final m = int.tryParse((month ?? 0).toString()) ?? 0;
    final y = int.tryParse((year ?? 0).toString()) ?? 0;

    if (m <= 0 || y <= 0) return '-';

    return '$m/$y';
  }

  Future<void> verifyPayment(int paymentId) async {
    final result = await _service.verifyPayment(paymentId: paymentId);

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          result['statusCode'] == 200
              ? 'Pago verificado y orden lista para despacho'
              : result['data']?['detail'] ?? 'No se pudo verificar el pago',
        ),
      ),
    );

    await loadAll();
  }

  Future<void> approveOrder(int orderId) async {
    final result = await _service.approveOrder(orderId: orderId);

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          result['statusCode'] == 200
              ? 'Orden aprobada y liberada a logística'
              : result['data']?['detail'] ?? 'No se pudo aprobar la orden',
        ),
      ),
    );

    await loadAll();
  }

  Future<void> sendMemberPush(int userId, String userName) async {
    final result = await _service.sendMemberPush(
      userId: userId,
      title: 'Mayu Wellness Club',
      message:
          'Hola ${userName.isEmpty ? "socio" : userName}, tu membresía Mayu está activa. La salud es nuestros hábitos de todos los días.',
    );

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          result['statusCode'] == 200
              ? 'Push enviado al socio'
              : result['data']?['detail'] ?? 'No se pudo enviar push',
        ),
      ),
    );
  }

  void openRenewalsForMember(int userId, String userName) {
    setState(() {
      activeSection = sectionRenewals;
      renewalPaymentSearch = userName.trim().isNotEmpty ? userName.trim() : '$userId';
    });
  }

  Future<void> payAmbassadorPending(int ambassadorId) async {
    final result = await _service.payPendingCommissionsByAmbassador(
      ambassadorId: ambassadorId,
    );

    if (!mounted) return;

    final data = result['data'] is Map<String, dynamic>
        ? Map<String, dynamic>.from(result['data'])
        : <String, dynamic>{};

    final paidAmount =
        double.tryParse((data['paid_amount'] ?? 0).toString()) ?? 0;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          result['statusCode'] == 200
              ? 'Pago realizado. Pasó al historial y el acumulado vuelve a 0. Total: \$${paidAmount.toStringAsFixed(2)}'
              : data['detail']?.toString() ??
                  data['message']?.toString() ??
                  'No se pudo pagar el saldo del embajador',
        ),
      ),
    );

    await loadAll();
  }

  Future<void> _openExternalUrl(String url, String errorMessage) async {
    final uri = Uri.tryParse(url.trim());

    if (uri == null || url.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(errorMessage)),
      );
      return;
    }

    final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);

    if (!opened && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(errorMessage)),
      );
    }
  }

  Future<void> _openTracking(String? url) async {
    final trackingUrl = (url ?? '').toString().trim();

    if (trackingUrl.isEmpty || trackingUrl == '-') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Esta orden aún no tiene link de tracking')),
      );
      return;
    }

    await _openExternalUrl(trackingUrl, 'No se pudo abrir el tracking');
  }

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(top: 26, bottom: 12),
      child: Text(
        title,
        style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _moduleButton({
    required String keyName,
    required String title,
    required String countLabel,
    required IconData icon,
    required Color color,
  }) {
    final bool selected = activeSection == keyName;

    return Expanded(
      child: InkWell(
        onTap: () => setState(() => activeSection = keyName),
        borderRadius: BorderRadius.circular(18),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          margin: const EdgeInsets.all(6),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            color: selected ? color : color.withValues(alpha: 0.10),
            border: Border.all(
              color: selected ? color : color.withValues(alpha: 0.35),
              width: 1.3,
            ),
            boxShadow: selected
                ? [
                    BoxShadow(
                      color: color.withValues(alpha: 0.20),
                      blurRadius: 16,
                      offset: const Offset(0, 8),
                    ),
                  ]
                : null,
          ),
          child: Column(
            children: [
              Icon(
                icon,
                color: selected ? Colors.white : color,
                size: 28,
              ),
              const SizedBox(height: 10),
              Text(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: selected ? Colors.white : color,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                countLabel,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 13,
                  color: selected
                      ? Colors.white.withValues(alpha: 0.92)
                      : Colors.black87,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _panel({
    required String title,
    required String searchHint,
    required String searchValue,
    required ValueChanged<String> onSearch,
    required List<dynamic> items,
    required Widget Function(Map<String, dynamic>) itemBuilder,
    required String emptyText,
    List<Widget> headerActions = const [],
    double height = 420,
  }) {
    final filtered = items
        .where((e) => _matchesSearch(Map<String, dynamic>.from(e), searchValue))
        .toList();

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '$title (${filtered.length})',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                ...headerActions,
              ],
            ),
            const SizedBox(height: 10),
            TextField(
              decoration: InputDecoration(
                hintText: searchHint,
                prefixIcon: const Icon(Icons.search),
                border: const OutlineInputBorder(),
              ),
              onChanged: onSearch,
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: height,
              child: filtered.isEmpty
                  ? Center(child: Text(emptyText))
                  : ListView.builder(
                      itemCount: filtered.length,
                      itemBuilder: (context, index) {
                        return itemBuilder(
                          Map<String, dynamic>.from(filtered[index]),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _statCard(String title, String value, Color color) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.all(6),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: color.withValues(alpha: 0.12),
          border: Border.all(color: color.withValues(alpha: 0.35)),
        ),
        child: Column(
          children: [
            Text(
              value,
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            const SizedBox(height: 6),
            Text(title, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  Widget _badge(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: color.withValues(alpha: 0.15),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.bold,
          fontSize: 12,
        ),
      ),
    );
  }

  Color _orderColor(String status) {
    switch (status) {
      case 'approved_for_logistics':
        return Colors.green;
      case 'pending_payment_review':
        return Colors.orange;
      case 'preparing':
        return Colors.blue;
      case 'shipped':
        return Colors.purple;
      case 'delivered':
        return Colors.green;
      case 'cancelled':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  String _orderLabel(String status) {
    switch (status) {
      case 'approved_for_logistics':
        return 'LISTA PARA LOGÍSTICA';
      case 'pending_payment_review':
        return 'REVISIÓN DE PAGO';
      case 'preparing':
        return 'PREPARANDO';
      case 'shipped':
        return 'ENVIADO';
      case 'delivered':
        return 'ENTREGADO';
      case 'cancelled':
        return 'CANCELADO';
      default:
        return status.toUpperCase();
    }
  }

  String _levelLabel(dynamic level) {
    final int parsed = int.tryParse((level ?? '0').toString()) ?? 0;

    switch (parsed) {
      case 1:
        return 'Nivel 1 - Cobre';
      case 2:
        return 'Nivel 2 - Plata';
      case 3:
        return 'Nivel 3 - Oro';
      default:
        return 'Sin plan';
    }
  }

  String _formatDate(dynamic value) {
    if (value == null) return '-';

    try {
      final date = DateTime.parse(value.toString()).toLocal();
      final day = date.day.toString().padLeft(2, '0');
      final month = date.month.toString().padLeft(2, '0');
      final year = date.year.toString();
      final hour = date.hour.toString().padLeft(2, '0');
      final minute = date.minute.toString().padLeft(2, '0');
      return '$day/$month/$year $hour:$minute';
    } catch (_) {
      return value.toString();
    }
  }

  List<dynamic> _orderItems(Map<String, dynamic> order) {
    final rawItems = order['items'];
    if (rawItems is List) return rawItems;

    final monthlyProducts = order['monthly_selection_products'];
    if (monthlyProducts is List) return monthlyProducts;

    return [];
  }

  Widget _orderProductsWidget(Map<String, dynamic> order) {
    final items = _orderItems(order);

    if (items.isEmpty) {
      return const Text(
        'Productos seleccionados: No hay productos registrados en esta orden',
        style: TextStyle(color: Colors.red),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Productos seleccionados:',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        ...items.map((item) {
          final map = Map<String, dynamic>.from(item as Map);
          final name = (map['name'] ??
                  map['product_name_snapshot'] ??
                  'Producto sin nombre')
              .toString();
          final quantity = (map['quantity'] ?? 1).toString();

          return Padding(
            padding: const EdgeInsets.only(bottom: 3),
            child: Text('• $name x$quantity'),
          );
        }),
      ],
    );
  }

  Map<String, dynamic>? _memberById(int userId) {
    for (final item in users) {
      if (item is! Map) continue;
      final map = Map<String, dynamic>.from(item);
      final id = int.tryParse((map['id'] ?? 0).toString()) ?? 0;
      if (id == userId) return map;
    }
    return null;
  }

  double _monthlyAmountByLevel(dynamic level) {
    final value = int.tryParse((level ?? 0).toString()) ?? 0;
    switch (value) {
      case 1:
        return 44.80;
      case 2:
        return 56.00;
      case 3:
        return 67.20;
      default:
        return 0.0;
    }
  }

  Widget _paymentSelectedProducts(Map<String, dynamic> payment) {
    final raw = payment['selected_products'];
    if (raw is! List || raw.isEmpty) {
      return const SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Productos del socio:',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 3),
          ...raw.map((item) => Text('• ${item.toString()}')),
        ],
      ),
    );
  }


  int _asInt(dynamic value) {
    return int.tryParse((value ?? 0).toString()) ?? 0;
  }

  double _asMoney(dynamic value) {
    return double.tryParse((value ?? 0).toString()) ?? 0.0;
  }

  bool _paymentStatusAllowsRelease(dynamic status) {
    final value = (status ?? '').toString();
    return [
      'paid',
      'verified',
      'subscription_paid',
      'subscription_active',
      'completed',
    ].contains(value);
  }

  String _monthLabel(dynamic month, dynamic year) {
    final m = _asInt(month);
    final y = _asInt(year);
    if (m <= 0 || y <= 0) return 'Próximo envío';
    return '$m/$y';
  }

  String _nextDebitDateLabel(dynamic month, dynamic year, dynamic day) {
    final m = _asInt(month);
    final y = _asInt(year);
    final d = _asInt(day) > 0 ? _asInt(day) : 1;
    if (m <= 0 || y <= 0) return 'Fecha pendiente';
    final safeDay = d.clamp(1, 28);
    final date = DateTime(y, m, safeDay);
    final dd = date.day.toString().padLeft(2, '0');
    final mm = date.month.toString().padLeft(2, '0');
    return '$dd/$mm/${date.year}';
  }

  Map<String, dynamic>? _latestRenewalForUser(
    int userId,
    List<dynamic> renewalItems,
  ) {
    for (final item in renewalItems) {
      if (item is! Map) continue;
      final map = Map<String, dynamic>.from(item);
      if (_asInt(map['user_id']) == userId) return map;
    }
    return null;
  }

  Map<String, dynamic>? _orderForMonthlyCycle(
    int userId,
    dynamic month,
    dynamic year,
    List<dynamic> orderItems,
  ) {
    final m = _asInt(month);
    final y = _asInt(year);
    for (final item in orderItems) {
      if (item is! Map) continue;
      final map = Map<String, dynamic>.from(item);
      if (_asInt(map['user_id']) != userId) continue;
      if (m > 0 && y > 0) {
        if (_asInt(map['month']) == m && _asInt(map['year']) == y) return map;
      } else {
        return map;
      }
    }
    return null;
  }

  List<dynamic> _buildMonthlyRenewalItems(
    List<dynamic> memberItems,
    List<dynamic> renewalItems,
    List<dynamic> orderItems,
  ) {
    final result = <Map<String, dynamic>>[];

    for (final item in memberItems) {
      if (item is! Map) continue;
      final user = Map<String, dynamic>.from(item);
      final userId = _asInt(user['id']);
      final products = user['monthly_selection_products'];
      final hasProducts = products is List && products.isNotEmpty;
      final hasSelection = user['monthly_selection_id'] != null;
      if (userId <= 0 || (!hasProducts && !hasSelection)) continue;

      final payment = _latestRenewalForUser(userId, renewalItems);
      final order = _orderForMonthlyCycle(
        userId,
        user['monthly_selection_month'],
        user['monthly_selection_year'],
        orderItems,
      );

      result.add({
        'user_id': userId,
        'user_name': user['name'],
        'user_email': user['email'],
        'user_phone': user['phone'],
        'membership_level': user['membership_level'],
        'monthly_amount': user['monthly_amount'] ??
            _monthlyAmountByLevel(user['membership_level']),
        'next_debit_day': user['next_debit_day'] ?? 1,
        'month': user['monthly_selection_month'],
        'year': user['monthly_selection_year'],
        'selection_id': user['monthly_selection_id'],
        'selection_status': user['monthly_selection_status'],
        'selected_products': products is List ? products : [],
        'payment_id': payment?['id'] ?? payment?['payment_id'],
        'payment_status': payment?['status'] ?? payment?['payment_status'],
        'payment_amount': payment?['amount'],
        'admin_verified': payment?['admin_verified'] == true,
        'order_id': order?['id'] ?? payment?['order_id'],
        'order_status': order?['status'] ?? order?['order_status'],
        'order_code': order?['order_code'],
        'carrier': order?['carrier'],
        'tracking_number': order?['tracking_number'],
        'tracking_url': order?['tracking_url'],
        'tracking_history': order?['tracking_history'],
      });
    }

    result.sort((a, b) {
      final ay = _asInt(a['year']);
      final by = _asInt(b['year']);
      if (ay != by) return by.compareTo(ay);
      final am = _asInt(a['month']);
      final bm = _asInt(b['month']);
      if (am != bm) return bm.compareTo(am);
      return _asInt(b['user_id']).compareTo(_asInt(a['user_id']));
    });

    return result;
  }

  Widget _monthlyCycleProductsWidget(Map<String, dynamic> item) {
    final raw = item['selected_products'];
    final products = raw is List ? raw : const [];

    if (products.isEmpty) {
      return const Text(
        'Productos enviados/próximo envío: sin productos guardados',
        style: TextStyle(color: Colors.red),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Productos enviados / próximo envío:',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        ...products.map((product) {
          if (product is Map) {
            final name = (product['name'] ??
                    product['product_name_snapshot'] ??
                    'Producto')
                .toString();
            final quantity = (product['quantity'] ?? 1).toString();
            return Text('• $name x$quantity');
          }
          return Text('• ${product.toString()}');
        }),
      ],
    );
  }

  Widget _monthlyCycleTrackingWidget(Map<String, dynamic> item) {
    final carrier = (item['carrier'] ?? '').toString().trim();
    final trackingNumber = (item['tracking_number'] ?? '').toString().trim();
    final trackingUrl = (item['tracking_url'] ?? '').toString().trim();
    final rawHistory = item['tracking_history'];
    final history = rawHistory is List ? rawHistory : const [];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Historial de envío / tracking:',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        if (carrier.isNotEmpty) Text('Transportadora: $carrier'),
        if (trackingNumber.isNotEmpty) Text('Guía: $trackingNumber'),
        if (history.isEmpty)
          const Text('Aún no hay historial de tracking para este ciclo.'),
        if (history.isNotEmpty)
          ...history.map((entry) {
            if (entry is! Map) return Text('• ${entry.toString()}');
            final status = (entry['status'] ?? '-').toString();
            final note = (entry['note'] ?? '').toString();
            final date = _formatDate(entry['created_at']);
            return Text('• $date · $status${note.isEmpty ? "" : " · $note"}');
          }),
        if (trackingUrl.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: OutlinedButton.icon(
              onPressed: () => _openTracking(trackingUrl),
              icon: const Icon(Icons.local_shipping),
              label: const Text('Abrir tracking'),
            ),
          ),
      ],
    );
  }

  Widget _monthlyCycleCard(Map<String, dynamic> item) {
    final userId = _asInt(item['user_id']);
    final paymentId = _asInt(item['payment_id']);
    final orderId = _asInt(item['order_id']);
    final userName = (item['user_name'] ?? 'Socio').toString();
    final status = (item['payment_status'] ?? '').toString();
    final adminVerified = item['admin_verified'] == true;
    final canRelease =
        paymentId > 0 && _paymentStatusAllowsRelease(status) && !adminVerified;
    final monthlyAmount = _asMoney(item['monthly_amount']);
    final period = _monthLabel(item['month'], item['year']);
    final nextDebitDate = _nextDebitDateLabel(
      item['month'],
      item['year'],
      item['next_debit_day'],
    );

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '$userName · $period',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            Text('Email: ${item['user_email'] ?? "-"}'),
            Text('WhatsApp: ${item['user_phone'] ?? "-"}'),
            Text('Nivel: ${_levelLabel(item['membership_level'])}'),
            if (monthlyAmount > 0)
              Text(
                'Próximo débito mensual: \$${monthlyAmount.toStringAsFixed(2)} · Fecha: $nextDebitDate',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            Text('Pago mensual: ${status.isEmpty ? "pendiente PayPal" : status}'),
            Text('Orden logística: ${orderId > 0 ? "#$orderId" : "pendiente"}'),
            const SizedBox(height: 8),
            _monthlyCycleProductsWidget(item),
            const SizedBox(height: 8),
            _monthlyCycleTrackingWidget(item),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _badge(
                  adminVerified
                      ? 'PAGO VERIFICADO'
                      : paymentId > 0
                          ? 'PAGO RECIBIDO'
                          : 'ESPERANDO PAGO',
                  adminVerified
                      ? Colors.green
                      : paymentId > 0
                          ? Colors.orange
                          : Colors.grey,
                ),
                if (orderId > 0)
                  _badge('ORDEN CREADA', Colors.blueGrey),
                ElevatedButton.icon(
                  onPressed: canRelease ? () => verifyPayment(paymentId) : null,
                  icon: const Icon(Icons.local_shipping),
                  label: Text(
                    adminVerified
                        ? 'Liberado a logística'
                        : paymentId > 0
                            ? 'Verificar pago y liberar'
                            : 'Esperando pago mensual',
                  ),
                ),
                if (userId > 0)
                  OutlinedButton.icon(
                    onPressed: () => sendMemberPush(userId, userName),
                    icon: const Icon(Icons.notifications_active),
                    label: const Text('Disparar push'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _memberMonthlySelectionInfo(Map<String, dynamic> user) {
    final monthlyAmount = _monthlyAmountByLevel(user['membership_level']);
    final products = user['monthly_selection_products'];
    final month = user['monthly_selection_month'];
    final year = user['monthly_selection_year'];

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (monthlyAmount > 0)
            Text(
              'Cobro mensual afiliación: \$${monthlyAmount.toStringAsFixed(2)}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          if (monthlyAmount > 0)
            const Text('Próximo débito: día 1 de cada mes'),
          if (month != null && year != null)
            Text('Renovación socio: $month/$year'),
          if (products is List && products.isNotEmpty) ...[
            const SizedBox(height: 6),
            const Text(
              'Productos del mes:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 3),
            ...products.map((item) {
              if (item is Map) {
                final name = (item['name'] ?? 'Producto').toString();
                final quantity = (item['quantity'] ?? 1).toString();
                return Text('• $name x$quantity');
              }
              return Text('• ${item.toString()}');
            }),
          ],
        ],
      ),
    );
  }

  Widget _paymentCard(Map<String, dynamic> payment) {
    final int id = int.tryParse((payment['id'] ?? 0).toString()) ?? 0;
    final String status = (payment['status'] ?? '').toString();
    final String amount = (payment['amount'] ?? 0).toString();
    final String userName = (payment['user_name'] ?? '').toString();
    final String payerEmail = (payment['payer_email'] ?? '').toString();
    final String paymentType = (payment['payment_type'] ?? '').toString();
    final String cycleLabel =
        (payment['membership_cycle_label'] ?? '').toString();
    final dynamic orderId = payment['order_id'];
    final int userId = int.tryParse((payment['user_id'] ?? 0).toString()) ?? 0;
    final member = _memberById(userId);
    final monthlyAmount = _monthlyAmountByLevel(member?['membership_level']);
    final bool alreadyVerified = payment['admin_verified'] == true;

    final bool canVerify = [
          'paid',
          'verified',
          'subscription_active',
          'subscription_paid',
        ].contains(status);

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Pago #$id — \$$amount',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            if (userName.isNotEmpty) Text('Socio: $userName'),
            if (payerEmail.isNotEmpty) Text('PayPal: $payerEmail'),
            if (cycleLabel.isNotEmpty) Text('Ciclo: $cycleLabel'),
            Text('Tipo: ${paymentType.isEmpty ? "sin tipo" : paymentType}'),
            Text('Orden vinculada: ${orderId ?? "Sin orden"}'),
            if (monthlyAmount > 0)
              Text(
                'Próximo débito mensual: \$${monthlyAmount.toStringAsFixed(2)} · Fecha: ${_nextDebitDateLabel(payment['month'], payment['year'], member?['next_debit_day'])}',
              ),
            Text('Fecha: ${_formatDate(payment['created_at'])}'),
            _paymentSelectedProducts(payment),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _badge(status, Colors.orange),
                if (alreadyVerified)
                  _badge('✔ Verificado por Admin', Colors.green),
                if (canVerify && !alreadyVerified)
                  ElevatedButton(
                    onPressed: id == 0 ? null : () => verifyPayment(id),
                    child: const Text('Verificar Pago OK'),
                  ),
                if (userId > 0)
                  OutlinedButton.icon(
                    onPressed: () => sendMemberPush(userId, userName),
                    icon: const Icon(Icons.notifications_active),
                    label: const Text('Disparar push'),
                  ),
                if (userId > 0)
                  OutlinedButton.icon(
                    onPressed: () => openRenewalsForMember(userId, userName),
                    icon: const Icon(Icons.autorenew),
                    label: const Text('Renovaciones socio'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _orderCard(Map<String, dynamic> order) {
    final String status = (order['status'] ?? '').toString();
    final String code = (order['order_code'] ?? 'Sin código').toString();

    final bool locked = order['order_locked'] == true ||
        status == 'approved_for_logistics' ||
        status == 'preparing' ||
        status == 'shipped' ||
        status == 'delivered' ||
        status == 'cancelled';

    final String trackingUrl = (order['tracking_url'] ?? '').toString();
    final String trackingNumber = (order['tracking_number'] ?? '').toString();
    final String carrier = (order['carrier'] ?? '').toString();
    final int orderId = int.tryParse((order['id'] ?? 0).toString()) ?? 0;
    final bool canApproveOrder = status == 'pending_payment_review';

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(code,
                style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text('Socio: ${order['user_name'] ?? "-"}'),
            Text('Ciudad: ${order['city_snapshot'] ?? "-"}'),
            Text('Dirección: ${order['address_snapshot'] ?? "-"}'),
            Text('Nivel: ${_levelLabel(order['membership_level_snapshot'])}'),
            Text('Periodo: ${order['month'] ?? "-"}/${order['year'] ?? "-"}'),
            if (carrier.trim().isNotEmpty) Text('Transportadora: $carrier'),
            if (trackingNumber.trim().isNotEmpty) Text('Guía: $trackingNumber'),
            const SizedBox(height: 8),
            _orderProductsWidget(order),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _badge(_orderLabel(status), _orderColor(status)),
                if (canApproveOrder)
                  ElevatedButton.icon(
                    onPressed:
                        orderId == 0 ? null : () => approveOrder(orderId),
                    icon: const Icon(Icons.check),
                    label: const Text('Aprobar y pasar a logística'),
                  ),
                if (locked) _badge('SELECCIÓN CERRADA', Colors.red),
                if (trackingUrl.trim().isNotEmpty)
                  OutlinedButton.icon(
                    onPressed: () => _openTracking(trackingUrl),
                    icon: const Icon(Icons.local_shipping),
                    label: const Text('Abrir tracking'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _sociosCard(Map<String, dynamic> user) {
    final String name = (user['name'] ?? 'Sin nombre').toString();
    final String email = (user['email'] ?? '').toString();
    final String phone = (user['phone'] ?? '-').toString();
    final int userId = int.tryParse((user['id'] ?? 0).toString()) ?? 0;
    final bool active = user['membership_active'] == true;
    final dynamic level = user['membership_level'];

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          children: [
            ListTile(
              title: Text(name),
              subtitle: Text(
                '$email\nTeléfono: $phone\nCédula: ${user['cedula'] ?? "-"}\nCiudad: ${user['city'] ?? "-"}\nNivel: ${_levelLabel(level)}',
              ),
              trailing: _badge(
                active ? 'Activo' : 'Inactivo',
                active ? Colors.green : Colors.red,
              ),
            ),
            _memberMonthlySelectionInfo(user),
            Align(
              alignment: Alignment.centerLeft,
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  if (userId > 0)
                    OutlinedButton.icon(
                      onPressed: () => sendMemberPush(userId, name),
                      icon: const Icon(Icons.notifications_active),
                      label: const Text('Disparar push'),
                    ),
                  if (userId > 0)
                    OutlinedButton.icon(
                      onPressed: () => openRenewalsForMember(userId, name),
                      icon: const Icon(Icons.autorenew),
                      label: const Text('Renovaciones socio'),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _ambassadorCard(Map<String, dynamic> ambassador) {
    final int ambassadorId = int.tryParse(
            (ambassador['id'] ?? ambassador['ambassador_id'] ?? 0)
                .toString()) ??
        0;
    final double accumulatedAmount = _ambassadorAccumulatedAmount(ambassador);
    final double payableAmount = _ambassadorPayableAmount(ambassador);
    final double paidTotal = _ambassadorPaidTotal(ambassador);
    final bool payoutWindowOpen = _ambassadorPayoutWindowOpen(ambassador);
    final history = _ambassadorCommissions(ambassadorId);

    final String name =
        (ambassador['name'] ?? ambassador['user_name'] ?? 'Embajador')
            .toString();
    final String code =
        (ambassador['code'] ?? ambassador['ambassador_code'] ?? '-').toString();
    final String bankName = (ambassador['bank_name'] ?? '-').toString();
    final String accountType =
        (ambassador['bank_account_type'] ?? ambassador['account_type'] ?? '-')
            .toString();
    final String accountNumber =
        (ambassador['bank_account_number'] ?? '-').toString();

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              name,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            Text('Código: $code'),
            Text('Banco: $bankName'),
            Text('Tipo de cuenta: $accountType'),
            Text('Cuenta: $accountNumber'),
            const SizedBox(height: 8),
            Text(
              'Pago acumulado: \$${accumulatedAmount.toStringAsFixed(2)}',
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 4),
            Text('Pagos realizados: \$${paidTotal.toStringAsFixed(2)}'),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: history.isEmpty
                        ? null
                        : () => _showAmbassadorHistory(name, history),
                    icon: const Icon(Icons.history),
                    label: const Text('Historial de pagos'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: ambassadorId == 0 ||
                            payableAmount <= 0 ||
                            !payoutWindowOpen
                        ? null
                        : () => payAmbassadorPending(ambassadorId),
                    icon: const Icon(Icons.account_balance_wallet),
                    label: Text(
                      !payoutWindowOpen
                          ? 'Disponible del 8 al 10'
                          : payableAmount > 0
                              ? 'Pagar y volver a 0'
                              : 'Sin pago pendiente',
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showAmbassadorHistory(
    String ambassadorName,
    List<Map<String, dynamic>> history,
  ) {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Historial de pagos - $ambassadorName'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.separated(
            shrinkWrap: true,
            itemCount: history.length,
            separatorBuilder: (_, __) => const Divider(height: 18),
            itemBuilder: (context, index) {
              final item = history[index];
              final referred =
                  (item['referred_user_name'] ?? 'Socio referido').toString();
              final amount = double.tryParse(
                    (item['commission_amount'] ?? item['amount'] ?? 0)
                        .toString(),
                  ) ??
                  0;
              final status = (item['status'] ?? 'pendiente').toString();
              final statusLabel = status == 'paid'
                  ? 'pagado'
                  : status == 'pending'
                      ? 'pendiente'
                      : status;

              return ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text('\$${amount.toStringAsFixed(2)} - $referred'),
                subtitle: Text(
                  '${_commissionMonthLabel(item['month'], item['year'])} · $statusLabel',
                ),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cerrar'),
          ),
        ],
      ),
    );
  }

  Widget _activeSectionContent() {
    switch (activeSection) {
      case sectionRenewals:
        return _panel(
          title: 'Renovaciones mensuales / próximo débito',
          searchHint: 'Buscar renovación, socio, email o estado...',
          searchValue: renewalPaymentSearch,
          onSearch: (v) => setState(() => renewalPaymentSearch = v),
          items: monthlyRenewalItems,
          emptyText: 'No hay renovaciones mensuales ni selecciones pendientes',
          itemBuilder: _monthlyCycleCard,
        );
      case sectionOrders:
        return _panel(
          title: 'Órdenes / Despacho semanal',
          searchHint: 'Buscar orden, socio, ciudad, producto o guía...',
          searchValue: orderSearch,
          onSearch: (v) => setState(() => orderSearch = v),
          items: orders,
          emptyText: 'No hay órdenes registradas',
          itemBuilder: _orderCard,
          height: 480,
        );
      case sectionMembers:
        return _panel(
          title: 'Socios',
          searchHint: 'Buscar socio, email, teléfono, cédula o ciudad...',
          searchValue: userSearch,
          onSearch: (v) => setState(() => userSearch = v),
          items: users,
          emptyText: 'No hay socios',
          itemBuilder: _sociosCard,
          height: 460,
        );
      case sectionAmbassadors:
        return _panel(
          title: 'Pago a embajadores',
          searchHint: 'Buscar embajador, código, banco o cuenta...',
          searchValue: ambassadorSearch,
          onSearch: (v) => setState(() => ambassadorSearch = v),
          items: ambassadors,
          emptyText: 'No hay embajadores registrados',
          itemBuilder: _ambassadorCard,
          height: 520,
        );
      case sectionAffiliations:
      default:
        return _panel(
          title: 'Afiliaciones nuevas y renovaciones',
          searchHint: 'Buscar afiliación, renovación, socio, email o estado...',
          searchValue: newPaymentSearch,
          onSearch: (v) => setState(() => newPaymentSearch = v),
          items: [...newMembershipPayments, ...renewalPayments],
          emptyText: 'No hay afiliaciones ni renovaciones',
          itemBuilder: _paymentCard,
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final int rawTotalSocios =
        int.tryParse((summary['total_socios'] ?? users.length).toString()) ??
            users.length;
    final int totalSocios = [
      rawTotalSocios,
      users.length,
    ].reduce((value, element) => value > element ? value : element);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Mayu'),
        actions: [
          IconButton(onPressed: loadAll, icon: const Icon(Icons.refresh)),
          IconButton(onPressed: _logout, icon: const Icon(Icons.logout)),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: margen1, bottom: margen1),
          child: loading
              ? const Center(child: CircularProgressIndicator())
              : error != null
                  ? Center(
                      child: Text(
                        error!,
                        style: const TextStyle(color: Colors.red),
                      ),
                    )
                  : RefreshIndicator(
                      onRefresh: loadAll,
                      child: ListView(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        children: [
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              _moduleButton(
                                keyName: sectionAffiliations,
                                title: 'Afiliaciones nuevas',
                                countLabel:
                                    '${newMembershipPayments.length} afiliaciones · ${renewalPayments.length} renovaciones',
                                icon: Icons.person_add_alt_1,
                                color: Colors.teal,
                              ),
                              _moduleButton(
                                keyName: sectionRenewals,
                                title: 'Renovaciones mensuales',
                                countLabel: '${monthlyRenewalItems.length} ciclos',
                                icon: Icons.autorenew,
                                color: Colors.indigo,
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              _moduleButton(
                                keyName: sectionOrders,
                                title: 'Órdenes / despacho',
                                countLabel: '${orders.length} órdenes',
                                icon: Icons.local_shipping,
                                color: Colors.orange,
                              ),
                              _moduleButton(
                                keyName: sectionMembers,
                                title: 'Socios',
                                countLabel: '$totalSocios registrados',
                                icon: Icons.groups_2,
                                color: Colors.green,
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              _moduleButton(
                                keyName: sectionAmbassadors,
                                title: 'Pago a embajadores',
                                countLabel: '${ambassadors.length} embajadores',
                                icon: Icons.account_balance_wallet,
                                color: Colors.purple,
                              ),
                              const Expanded(child: SizedBox()),
                            ],
                          ),
                          const SizedBox(height: 10),
                          _activeSectionContent(),
                        ],
                      ),
                    ),
        ),
      ),
    );
  }
}
