import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/auth_service.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final AuthService _authService = AuthService();

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _codeController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();

  bool _loading = false;
  String? _error;
  String? _success;

  int _step = 1;

  Map<String, dynamic>? _recoveryUser;

  Widget _margenImage() {
    return Image.asset(
      'assets/images/margen1.png',
      width: double.infinity,
      fit: BoxFit.cover,
      errorBuilder: (context, error, stackTrace) {
        return const SizedBox.shrink();
      },
    );
  }

  InputDecoration _inputDecoration({
    required String label,
    String? hint,
    IconData? icon,
  }) {
    return InputDecoration(
      labelText: label,
      hintText: hint,
      prefixIcon: icon == null ? null : Icon(icon),
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: BorderSide.none,
      ),
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 18,
        vertical: 18,
      ),
    );
  }

  Future<void> _requestCode() async {
    final email = _emailController.text.trim();

    FocusScope.of(context).unfocus();

    if (email.isEmpty) {
      setState(() {
        _error = 'Ingresa tu correo electrónico';
        _success = null;
      });
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
      _success = null;
    });

    final ok = await _authService.forgotPassword(email: email);

    if (!mounted) return;

    if (ok) {
      setState(() {
        _loading = false;
        _step = 2;
        _success = 'Te enviamos un código de 4 dígitos a tu correo.';
      });
    } else {
      setState(() {
        _loading = false;
        _error = 'No se pudo enviar el código. Verifica el correo.';
      });
    }
  }

  Future<void> _verifyCode() async {
    final email = _emailController.text.trim();
    final code = _codeController.text.trim();

    FocusScope.of(context).unfocus();

    if (code.length != 4) {
      setState(() {
        _error = 'Ingresa el código de 4 dígitos';
        _success = null;
      });
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
      _success = null;
    });

    final ok = await _authService.verifyRecoveryCode(
      email: email,
      code: code,
    );

    if (!mounted) return;

    if (ok) {
      setState(() {
        _loading = false;
        _step = 3;
        _success = 'Código verificado correctamente.';
      });
    } else {
      setState(() {
        _loading = false;
        _error = 'Código incorrecto o expirado.';
      });
    }
  }

  Future<void> _resetPassword() async {
    final email = _emailController.text.trim();
    final code = _codeController.text.trim();
    final password = _passwordController.text.trim();
    final confirmPassword = _confirmPasswordController.text.trim();

    FocusScope.of(context).unfocus();

    if (password.length < 6) {
      setState(() {
        _error = 'La contraseña debe tener al menos 6 caracteres';
        _success = null;
      });
      return;
    }

    if (password != confirmPassword) {
      setState(() {
        _error = 'Las contraseñas no coinciden';
        _success = null;
      });
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
      _success = null;
    });

    final result = await _authService.resetPasswordWithCode(
      email: email,
      code: code,
      newPassword: password,
    );

    if (!mounted) return;

    if (result != null && result['user'] != null) {
      setState(() {
        _loading = false;
        _step = 4;
        _recoveryUser = Map<String, dynamic>.from(result['user']);
        _success = 'Contraseña actualizada correctamente.';
      });
    } else {
      setState(() {
        _loading = false;
        _error = 'No se pudo cambiar la contraseña.';
      });
    }
  }

  Future<void> _openUrl(String? url) async {
    if (url == null || url.trim().isEmpty) return;

    final uri = Uri.parse(url);

    await launchUrl(
      uri,
      mode: LaunchMode.externalApplication,
    );
  }

  Widget _statusMessages() {
    return Column(
      children: [
        if (_error != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Text(
              _error!,
              style: const TextStyle(
                color: Colors.red,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        if (_success != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Text(
              _success!,
              style: const TextStyle(
                color: Colors.green,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
          ),
      ],
    );
  }

  Widget _mainButton({
    required String text,
    required IconData icon,
    required VoidCallback onPressed,
    bool outlined = false,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 54,
      child: outlined
          ? OutlinedButton.icon(
              onPressed: _loading ? null : onPressed,
              icon: Icon(icon),
              label: Text(
                text,
                style: const TextStyle(fontSize: 16),
              ),
            )
          : ElevatedButton.icon(
              onPressed: _loading ? null : onPressed,
              icon: Icon(icon),
              label: _loading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : Text(
                      text,
                      style: const TextStyle(fontSize: 16),
                    ),
            ),
    );
  }

  Widget _stepOne() {
    return Column(
      children: [
        const Text(
          '¿Olvidaste tu contraseña?',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 12),
        const Text(
          'Ingresa tu correo registrado. Te enviaremos un código de 4 dígitos para recuperar tu acceso.',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 16,
            height: 1.4,
            color: Colors.black54,
          ),
        ),
        const SizedBox(height: 28),
        TextField(
          controller: _emailController,
          keyboardType: TextInputType.emailAddress,
          textInputAction: TextInputAction.done,
          onSubmitted: (_) => _requestCode(),
          decoration: _inputDecoration(
            label: 'Correo electrónico',
            hint: 'ejemplo@correo.com',
            icon: Icons.email,
          ),
        ),
        const SizedBox(height: 18),
        _statusMessages(),
        _mainButton(
          text: 'Enviar código al correo',
          icon: Icons.mark_email_read,
          onPressed: _requestCode,
        ),
      ],
    );
  }

  Widget _stepTwo() {
    return Column(
      children: [
        const Text(
          'Verifica tu código',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 12),
        Text(
          'Enviamos un código a:\n${_emailController.text.trim()}',
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 16,
            height: 1.4,
            color: Colors.black54,
          ),
        ),
        const SizedBox(height: 28),
        TextField(
          controller: _codeController,
          keyboardType: TextInputType.number,
          maxLength: 4,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 28,
            letterSpacing: 10,
            fontWeight: FontWeight.bold,
          ),
          decoration: _inputDecoration(
            label: 'Código',
            hint: '0000',
            icon: Icons.pin,
          ).copyWith(counterText: ''),
        ),
        const SizedBox(height: 18),
        _statusMessages(),
        _mainButton(
          text: 'Verificar código',
          icon: Icons.verified,
          onPressed: _verifyCode,
        ),
        const SizedBox(height: 12),
        _mainButton(
          text: 'Reenviar código',
          icon: Icons.refresh,
          outlined: true,
          onPressed: _requestCode,
        ),
      ],
    );
  }

  Widget _stepThree() {
    return Column(
      children: [
        const Text(
          'Nueva contraseña',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 12),
        const Text(
          'Crea una nueva contraseña segura para ingresar nuevamente a Mayu Wellness Club.',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 16,
            height: 1.4,
            color: Colors.black54,
          ),
        ),
        const SizedBox(height: 28),
        TextField(
          controller: _passwordController,
          obscureText: true,
          decoration: _inputDecoration(
            label: 'Nueva contraseña',
            icon: Icons.lock,
          ),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _confirmPasswordController,
          obscureText: true,
          decoration: _inputDecoration(
            label: 'Confirmar contraseña',
            icon: Icons.lock_outline,
          ),
        ),
        const SizedBox(height: 18),
        _statusMessages(),
        _mainButton(
          text: 'Cambiar contraseña',
          icon: Icons.password,
          onPressed: _resetPassword,
        ),
      ],
    );
  }

  Widget _stepFour() {
    final user = _recoveryUser ?? {};

    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.green.withValues(alpha: 0.12),
            shape: BoxShape.circle,
          ),
          child: const Icon(
            Icons.check_circle,
            size: 76,
            color: Colors.green,
          ),
        ),
        const SizedBox(height: 24),
        const Text(
          'Contraseña actualizada',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 12),
        Text(
          'Ya puedes ingresar nuevamente a tu cuenta.\n${user['email'] ?? ''}',
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 16,
            height: 1.4,
            color: Colors.black54,
          ),
        ),
        const SizedBox(height: 24),
        _mainButton(
          text: 'Volver al inicio de sesión',
          icon: Icons.login,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        const SizedBox(height: 12),
        _mainButton(
          text: 'Ver tarjeta web',
          icon: Icons.credit_card,
          outlined: true,
          onPressed: () => _openUrl(user['card_web_url']),
        ),
        const SizedBox(height: 12),
        _mainButton(
          text: 'Apple Wallet',
          icon: Icons.phone_iphone,
          outlined: true,
          onPressed: () => _openUrl(user['apple_wallet_url']),
        ),
        const SizedBox(height: 12),
        _mainButton(
          text: 'Google Wallet',
          icon: Icons.android,
          outlined: true,
          onPressed: () => _openUrl(user['google_wallet_url']),
        ),
      ],
    );
  }

  Widget _currentStep() {
    if (_step == 1) return _stepOne();
    if (_step == 2) return _stepTwo();
    if (_step == 3) return _stepThree();
    return _stepFour();
  }

  @override
  void dispose() {
    _emailController.dispose();
    _codeController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      body: SafeArea(
        child: Column(
          children: [
            _margenImage(),
            Expanded(
              child: GestureDetector(
                onTap: () => FocusScope.of(context).unfocus(),
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 430),
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (_step != 4)
                              Container(
                                padding: const EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  color: Colors.deepPurple.withValues(alpha: 0.10),
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(
                                  Icons.lock_reset,
                                  size: 72,
                                  color: Colors.deepPurple,
                                ),
                              ),
                            if (_step != 4) const SizedBox(height: 24),
                            _currentStep(),
                            const SizedBox(height: 14),
                            if (_step != 4)
                              SizedBox(
                                width: double.infinity,
                                height: 52,
                                child: OutlinedButton(
                                  onPressed: () {
                                    if (_step == 1) {
                                      Navigator.pop(context);
                                    } else {
                                      setState(() {
                                        _step = _step - 1;
                                        _error = null;
                                        _success = null;
                                      });
                                    }
                                  },
                                  child: Text(
                                    _step == 1
                                        ? 'Volver al inicio de sesión'
                                        : 'Regresar',
                                    style: const TextStyle(fontSize: 16),
                                  ),
                                ),
                              ),
                            const SizedBox(height: 20),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            _margenImage(),
          ],
        ),
      ),
    );
  }
}