import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/pharmacy_loyalty_service.dart';

class PharmacyMagistralAffiliatesScreen extends StatefulWidget {
  const PharmacyMagistralAffiliatesScreen({super.key});

  @override
  State<PharmacyMagistralAffiliatesScreen> createState() =>
      _PharmacyMagistralAffiliatesScreenState();
}

class _PharmacyMagistralAffiliatesScreenState
    extends State<PharmacyMagistralAffiliatesScreen> {
  final PharmacyLoyaltyService _service = PharmacyLoyaltyService();
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _customers = [];
  String _search = '';
  String? _redeemingIdentifier;

  List<Map<String, dynamic>> get _filteredCustomers {
    final query = _search.trim().toLowerCase();
    if (query.isEmpty) return _customers;
    return _customers.where((customer) {
      final card = customer['card'];
      final map = card is Map ? card : const {};
      return [
        customer['name'],
        customer['email'],
        customer['phone'],
        customer['city'],
        map['card_code'],
      ].any((value) => (value ?? '').toString().toLowerCase().contains(query));
    }).toList();
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final result = await _service.listPharmacyCustomers();
    if (!mounted) return;

    if (result['statusCode'] == 200) {
      final data = Map<String, dynamic>.from(result['data']);
      final customers = data['customers'];
      setState(() {
        _customers = customers is List
            ? customers
                .whereType<Map>()
                .map((item) => Map<String, dynamic>.from(item))
                .toList()
            : [];
        _loading = false;
      });
    } else {
      setState(() {
        _loading = false;
        _error = result['data']?['detail']?.toString() ??
            'No se pudo cargar afiliados';
      });
    }
  }

  Future<void> _open(String? url) async {
    final cleanUrl = url?.trim();
    if (cleanUrl == null || cleanUrl.isEmpty) return;
    await launchUrl(Uri.parse(cleanUrl), mode: LaunchMode.externalApplication);
  }

  Future<void> _testPush(Map<String, dynamic> customer) async {
    final card = customer['card'];
    if (card is! Map) return;
    final identifier = card['qr_token']?.toString() ?? '';
    if (identifier.isEmpty) return;

    final result = await _service.sendTestPush(identifier);
    if (!mounted) return;
    final data = result['data'];
    if (result['statusCode'] != 200 || data is! Map) {
      final detail = data is Map ? data['detail']?.toString() : null;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            detail?.isNotEmpty == true
                ? detail!
                : 'No se pudo ejecutar la prueba de notificaciones.',
          ),
        ),
      );
      return;
    }

    final firebase = data['firebase'];
    final apple = data['apple_wallet'];
    final googleUpdate = data['google_wallet'];
    final googleNotification = data['google_notification'];
    final firebaseSent = firebase is Map && firebase['sent'] == true;
    final appleSent = apple is Map &&
        ((apple['sent'] is num && (apple['sent'] as num) > 0) ||
            apple['updated'] == true);
    final googleSent =
        googleNotification is Map && googleNotification['sent'] == true;
    final channels = <String>[
      if (firebaseSent) 'app',
      if (appleSent) 'Apple Wallet',
      if (googleSent) 'Google Wallet',
    ];
    final diagnostics = <String>[];
    if (apple is Map && !appleSent) {
      final registered = apple['registered'] ?? 0;
      diagnostics.add('Apple registrado: $registered');
      final appleDetail = apple['detail']?.toString();
      if (appleDetail != null && appleDetail.isNotEmpty) {
        diagnostics.add(appleDetail);
      }
      final errors = apple['errors'];
      if (errors is List && errors.isNotEmpty) {
        diagnostics.add('Apple: ${errors.first}');
      }
    }
    if (googleUpdate is Map && googleUpdate['updated'] != true) {
      final detail = googleUpdate['detail']?.toString();
      if (detail != null && detail.isNotEmpty) {
        diagnostics.add('Google Wallet: $detail');
      }
    }
    if (googleNotification is Map && !googleSent) {
      final detail = googleNotification['detail']?.toString();
      if (detail != null && detail.isNotEmpty) {
        diagnostics.add('Aviso Google: $detail');
      }
    }
    final firebaseDetail =
        firebase is Map ? firebase['detail']?.toString() : null;
    if (firebaseDetail != null && firebaseDetail.isNotEmpty) {
      diagnostics.add(firebaseDetail);
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          channels.isNotEmpty
              ? 'Prueba enviada por: ${channels.join(', ')}.'
              : diagnostics.isNotEmpty
                  ? diagnostics.join(' · ')
                  : 'No se pudo enviar por ningún canal.',
        ),
      ),
    );
  }

  Future<void> _redeemAll(Map<String, dynamic> customer) async {
    final card = customer['card'];
    if (card is! Map) return;
    final identifier = card['qr_token']?.toString() ?? '';
    final points = int.tryParse('${card['points_balance'] ?? 0}') ?? 0;
    if (identifier.isEmpty || points <= 0) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Utilizar todos los puntos'),
        content: Text(
          'Se registrará el uso de $points punto(s) de ${customer['name'] ?? 'este afiliado'} y el saldo quedará en 0. La tarjeta Wallet se actualizará y recibirá una notificación.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Confirmar utilización'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    setState(() => _redeemingIdentifier = identifier);
    final result = await _service.redeemAllPoints(
      identifier,
      note: 'Puntos utilizados y confirmados por Farmacia Administrador',
    );
    if (!mounted) return;
    setState(() => _redeemingIdentifier = null);
    if (result['statusCode'] == 200) {
      await _load();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content:
                Text('$points punto(s) utilizados. Saldo actualizado a 0.')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(result['data']?['detail']?.toString() ??
              'No se pudieron utilizar los puntos.'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Afiliados Mayu Magistral'),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!))
              : _customers.isEmpty
                  ? const Center(child: Text('Todavía no hay afiliados.'))
                  : Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.fromLTRB(14, 14, 14, 4),
                          child: TextField(
                            onChanged: (value) =>
                                setState(() => _search = value),
                            decoration: const InputDecoration(
                              labelText: 'Buscar afiliado',
                              hintText:
                                  'Nombre, correo, teléfono, ciudad o código',
                              prefixIcon: Icon(Icons.search),
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                        Expanded(
                          child: _filteredCustomers.isEmpty
                              ? const Center(child: Text('No hay resultados.'))
                              : ListView.separated(
                                  padding: const EdgeInsets.all(14),
                                  itemCount: _filteredCustomers.length,
                                  separatorBuilder: (_, __) =>
                                      const SizedBox(height: 10),
                                  itemBuilder: (context, index) {
                                    final customer = _filteredCustomers[index];
                                    final card = customer['card'];
                                    final cardMap =
                                        card is Map ? card : const {};
                                    return Card(
                                      child: Padding(
                                        padding: const EdgeInsets.all(14),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              customer['name']?.toString() ??
                                                  '',
                                              style: const TextStyle(
                                                fontSize: 18,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            const SizedBox(height: 4),
                                            Text(
                                                customer['email']?.toString() ??
                                                    ''),
                                            Text(
                                                customer['phone']?.toString() ??
                                                    ''),
                                            if ((customer['city'] ?? '')
                                                .toString()
                                                .isNotEmpty)
                                              Text(
                                                  'Ciudad: ${customer['city']}'),
                                            const SizedBox(height: 8),
                                            Text(
                                              '${cardMap['points_balance'] ?? 0} puntos · ${cardMap['card_code'] ?? ''}',
                                              style: const TextStyle(
                                                  fontWeight: FontWeight.w600),
                                            ),
                                            const SizedBox(height: 12),
                                            Wrap(
                                              spacing: 8,
                                              runSpacing: 8,
                                              children: [
                                                OutlinedButton.icon(
                                                  onPressed: () => _open(
                                                    cardMap['apple_wallet_url']
                                                        ?.toString(),
                                                  ),
                                                  icon:
                                                      const Icon(Icons.wallet),
                                                  label:
                                                      const Text('Wallet iOS'),
                                                ),
                                                OutlinedButton.icon(
                                                  onPressed: () => _open(
                                                    cardMap['google_wallet_url']
                                                        ?.toString(),
                                                  ),
                                                  icon: const Icon(Icons
                                                      .account_balance_wallet),
                                                  label: const Text(
                                                      'Wallet Android'),
                                                ),
                                                OutlinedButton.icon(
                                                  onPressed: () =>
                                                      _testPush(customer),
                                                  icon: const Icon(Icons
                                                      .notifications_active),
                                                  label:
                                                      const Text('Probar push'),
                                                ),
                                                ElevatedButton.icon(
                                                  onPressed: (int.tryParse(
                                                                      '${cardMap['points_balance'] ?? 0}') ??
                                                                  0) <=
                                                              0 ||
                                                          _redeemingIdentifier ==
                                                              cardMap['qr_token']
                                                                  ?.toString()
                                                      ? null
                                                      : () =>
                                                          _redeemAll(customer),
                                                  icon:
                                                      const Icon(Icons.redeem),
                                                  label: Text(
                                                    _redeemingIdentifier ==
                                                            cardMap['qr_token']
                                                                ?.toString()
                                                        ? 'Procesando...'
                                                        : 'Utilizar puntos y dejar en 0',
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                ),
                        ),
                      ],
                    ),
    );
  }
}
