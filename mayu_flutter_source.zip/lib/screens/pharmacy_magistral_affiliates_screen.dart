import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/pharmacy_loyalty_service.dart';

class PharmacyMagistralAffiliatesScreen extends StatefulWidget {
  const PharmacyMagistralAffiliatesScreen({super.key});

  @override
  State<PharmacyMagistralAffiliatesScreen> createState() =>
      _PharmacyMagistralAffiliatesScreenState();
}

class _PharmacyMagistralAffiliatesScreenState
    extends State<PharmacyMagistralAffiliatesScreen> {
  final PharmacyLoyaltyService _service = PharmacyLoyaltyService();
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _customers = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final result = await _service.listPharmacyCustomers();
    if (!mounted) return;

    if (result['statusCode'] == 200) {
      final data = Map<String, dynamic>.from(result['data']);
      final customers = data['customers'];
      setState(() {
        _customers = customers is List
            ? customers
                  .whereType<Map>()
                  .map((item) => Map<String, dynamic>.from(item))
                  .toList()
            : [];
        _loading = false;
      });
    } else {
      setState(() {
        _loading = false;
        _error =
            result['data']?['detail']?.toString() ??
            'No se pudo cargar afiliados';
      });
    }
  }

  Future<void> _open(String? url) async {
    final cleanUrl = url?.trim();
    if (cleanUrl == null || cleanUrl.isEmpty) return;
    await launchUrl(Uri.parse(cleanUrl), mode: LaunchMode.externalApplication);
  }

  Future<void> _testPush(Map<String, dynamic> customer) async {
    final card = customer['card'];
    if (card is! Map) return;
    final identifier = card['qr_token']?.toString() ?? '';
    if (identifier.isEmpty) return;

    final result = await _service.sendTestPush(identifier);
    if (!mounted) return;
    final data = result['data'];
    final push = data is Map ? data['push'] : null;
    final sent = push is Map && push['sent'] == true;
    final detail = push is Map ? push['detail']?.toString() : null;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          sent
              ? 'Push de prueba enviado.'
              : detail ?? 'No se pudo enviar push de prueba.',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Afiliados Mayu Magistral'),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
          ? Center(child: Text(_error!))
          : _customers.isEmpty
          ? const Center(child: Text('Todavía no hay afiliados.'))
          : ListView.separated(
              padding: const EdgeInsets.all(14),
              itemCount: _customers.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                final customer = _customers[index];
                final card = customer['card'];
                final cardMap = card is Map ? card : const {};
                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          customer['name']?.toString() ?? '',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(customer['email']?.toString() ?? ''),
                        Text(customer['phone']?.toString() ?? ''),
                        if ((customer['city'] ?? '').toString().isNotEmpty)
                          Text('Ciudad: ${customer['city']}'),
                        const SizedBox(height: 8),
                        Text(
                          '${cardMap['points_balance'] ?? 0} puntos · ${cardMap['card_code'] ?? ''}',
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(height: 12),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            OutlinedButton.icon(
                              onPressed: () => _open(
                                cardMap['apple_wallet_url']?.toString(),
                              ),
                              icon: const Icon(Icons.wallet),
                              label: const Text('Wallet iOS'),
                            ),
                            OutlinedButton.icon(
                              onPressed: () => _open(
                                cardMap['google_wallet_url']?.toString(),
                              ),
                              icon: const Icon(Icons.account_balance_wallet),
                              label: const Text('Wallet Android'),
                            ),
                            OutlinedButton.icon(
                              onPressed: () => _testPush(customer),
                              icon: const Icon(Icons.notifications_active),
                              label: const Text('Probar push'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
