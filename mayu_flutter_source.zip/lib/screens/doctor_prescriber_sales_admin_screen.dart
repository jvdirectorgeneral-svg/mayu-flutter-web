import 'package:flutter/material.dart';

import '../services/doctor_prescriber_service.dart';
import 'pharmacy_qr_scanner_screen.dart';

class DoctorPrescriberSalesAdminScreen extends StatefulWidget {
  const DoctorPrescriberSalesAdminScreen({super.key});

  @override
  State<DoctorPrescriberSalesAdminScreen> createState() =>
      _DoctorPrescriberSalesAdminScreenState();
}

class _DoctorPrescriberSalesAdminScreenState
    extends State<DoctorPrescriberSalesAdminScreen> {
  final DoctorPrescriberService _service = DoctorPrescriberService();
  final _doctorController = TextEditingController();
  final _amountController = TextEditingController();
  final _deductionController = TextEditingController();
  final _referenceController = TextEditingController();
  final _noteController = TextEditingController();
  bool _saving = false;
  bool _payingDoctor = false;
  bool _checkingDoctor = false;
  Map<String, dynamic>? _doctor;

  @override
  void dispose() {
    _doctorController.dispose();
    _amountController.dispose();
    _deductionController.dispose();
    _referenceController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _scanQr() async {
    final identifier = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => const PharmacyQrScannerScreen()),
    );
    if (!mounted || identifier == null || identifier.trim().isEmpty) return;
    _doctorController.text = identifier.trim();
    await _resolveDoctor();
  }

  Future<void> _resolveDoctor() async {
    final identifier = _doctorController.text.trim();
    if (identifier.isEmpty) return;
    setState(() {
      _checkingDoctor = true;
      _doctor = null;
    });
    final result = await _service.resolveDoctor(identifier);
    if (!mounted) return;
    setState(() => _checkingDoctor = false);
    if (result['statusCode'] == 200) {
      final data = Map<String, dynamic>.from(result['data']);
      setState(() {
        _doctor = Map<String, dynamic>.from(data['doctor'] as Map);
      });
    } else {
      _showMessage(
        result['data']?['detail']?.toString() ??
            'No se pudo validar el doctor',
      );
    }
  }

  Future<void> _creditSale() async {
    final identifier = _doctorController.text.trim();
    final amount = double.tryParse(
      _amountController.text.replaceAll(',', '.').trim(),
    );
    final deductionPercent = double.tryParse(
          _deductionController.text.replaceAll(',', '.').trim(),
        ) ??
        0;
    final reference = _referenceController.text.trim();
    if (identifier.isEmpty ||
        amount == null ||
        amount <= 0 ||
        reference.isEmpty) {
      _showMessage('Completa doctor, monto y factura');
      return;
    }
    if (deductionPercent < 0 || deductionPercent > 100) {
      _showMessage('El descuento debe estar entre 0% y 100%');
      return;
    }
    setState(() => _saving = true);
    final result = await _service.creditDoctorSale(
      identifier: identifier,
      amount: amount,
      reference: reference,
      deductionPercent: deductionPercent,
      note: _noteController.text,
    );
    if (!mounted) return;
    setState(() => _saving = false);
    if (result['statusCode'] == 200) {
      final data = result['data'];
      final doctor = data['doctor'];
      if (doctor is Map) {
        setState(() => _doctor = Map<String, dynamic>.from(doctor));
      }
      final gross = data['gross_commission_earned'];
      final discount = data['deduction_amount'];
      final net = data['commission_earned'];
      _showMessage(
        'Comisión neta registrada: \$$net (bruto \$$gross - descuento \$$discount)',
      );
      _amountController.clear();
      _deductionController.clear();
      _referenceController.clear();
      _noteController.clear();
    } else {
      _showMessage(
        result['data']?['detail']?.toString() ??
            'No se pudo registrar la venta',
      );
    }
  }

  Future<void> _payDoctorBalance() async {
    final doctor = _doctor;
    final identifier = _doctorController.text.trim();
    if (doctor == null || identifier.isEmpty) {
      _showMessage('Primero valida un doctor');
      return;
    }

    final currentBalance =
        double.tryParse((doctor['commission_balance'] ?? 0).toString()) ?? 0;
    if (currentBalance <= 0) {
      _showMessage('Este doctor no tiene saldo pendiente');
      return;
    }

    setState(() => _payingDoctor = true);
    final result = await _service.payDoctorBalance(
      identifier: identifier,
      note: _noteController.text,
    );
    if (!mounted) return;
    setState(() => _payingDoctor = false);

    if (result['statusCode'] == 200) {
      final data = result['data'];
      final updatedDoctor = data['doctor'];
      if (updatedDoctor is Map) {
        setState(() => _doctor = Map<String, dynamic>.from(updatedDoctor));
      }
      final paidAmount = data['paid_amount']?.toString() ?? '0';
      final paidTransactions = data['paid_transactions']?.toString() ?? '0';
      _showMessage(
        'Doctor pagado: \$$paidAmount en $paidTransactions movimiento(s). Saldo reiniciado en 0.',
      );
    } else {
      _showMessage(
        result['data']?['detail']?.toString() ??
            'No se pudo pagar el saldo del doctor',
      );
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  void _openDoctorsList() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const DoctorPrescriberAdminListScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final doctor = _doctor;
    return Scaffold(
      appBar: AppBar(title: const Text('Ventas Doctor Prescriptor')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text(
            'El doctor comisiona 30% sobre ventas prescritas.',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _openDoctorsList,
            icon: const Icon(Icons.people),
            label: const Text('Ver Doctores Prescriptores'),
          ),
          const SizedBox(height: 18),
          TextField(
            controller: _doctorController,
            onSubmitted: (_) => _resolveDoctor(),
            decoration: InputDecoration(
              labelText: 'Código o QR Doctor Prescriptor',
              hintText: 'Ej: DOC-MAYU-000001',
              prefixIcon: IconButton(
                tooltip: 'Escanear QR',
                onPressed: _scanQr,
                icon: const Icon(Icons.qr_code_scanner),
              ),
              suffixIcon: _checkingDoctor
                  ? const Padding(
                      padding: EdgeInsets.all(12),
                      child: SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                    )
                  : IconButton(
                      tooltip: 'Validar doctor',
                      onPressed: _resolveDoctor,
                      icon: const Icon(Icons.search),
                    ),
              border: const OutlineInputBorder(),
            ),
          ),
          if (doctor != null) ...[
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                leading: const Icon(Icons.medical_services),
                title: Text(doctor['name']?.toString() ?? ''),
                subtitle: Text(doctor['doctor_code']?.toString() ?? ''),
                trailing: Text('\$${doctor['commission_balance'] ?? 0}'),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _payingDoctor ? null : _payDoctorBalance,
                icon: const Icon(Icons.account_balance_wallet_outlined),
                label: Text(
                  _payingDoctor
                      ? 'Pagando doctor...'
                      : 'Pagar saldo doctor y dejar en 0',
                ),
              ),
            ),
          ],
          const SizedBox(height: 12),
          TextField(
            controller: _amountController,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'Dólares vendidos',
              prefixText: '\$ ',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _deductionController,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: '% descuento / comisión bancaria / IVA opcional',
              hintText: 'Ej: 5 si se debe restar 5% de la comisión',
              suffixText: '%',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _referenceController,
            decoration: const InputDecoration(
              labelText: 'Número de factura',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _noteController,
            decoration: const InputDecoration(
              labelText: 'Nota opcional',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 18),
          ElevatedButton.icon(
            onPressed: _saving ? null : _creditSale,
            icon: const Icon(Icons.payments),
            label: Text(_saving ? 'Guardando...' : 'Registrar venta 30%'),
          ),
        ],
      ),
    );
  }
}

class DoctorPrescriberAdminListScreen extends StatefulWidget {
  const DoctorPrescriberAdminListScreen({super.key});

  @override
  State<DoctorPrescriberAdminListScreen> createState() =>
      _DoctorPrescriberAdminListScreenState();
}

class _DoctorPrescriberAdminListScreenState
    extends State<DoctorPrescriberAdminListScreen> {
  final DoctorPrescriberService _service = DoctorPrescriberService();

  bool _loading = true;
  String? _error;
  String? _payingDoctorCode;
  List<Map<String, dynamic>> _doctors = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final result = await _service.listDoctors();
    if (!mounted) return;

    if (result['statusCode'] == 200) {
      final data = result['data'];
      final List<dynamic> items = data is List
          ? data
          : (data is Map && data['items'] is List
                ? List<dynamic>.from(data['items'] as List)
                : <dynamic>[]);

      setState(() {
        _doctors = items
            .whereType<Map>()
            .map((item) => Map<String, dynamic>.from(item))
            .toList()
            .cast<Map<String, dynamic>>();
        _loading = false;
      });
    } else {
      setState(() {
        _loading = false;
        _error =
            result['data']?['detail']?.toString() ??
            'No se pudo cargar doctores';
      });
    }
  }

  Future<void> _payDoctor(Map<String, dynamic> doctor) async {
    final identifier = doctor['doctor_code']?.toString() ?? '';
    if (identifier.isEmpty) return;

    final balance =
        double.tryParse((doctor['commission_balance'] ?? 0).toString()) ?? 0;
    if (balance <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Este doctor no tiene saldo pendiente')),
      );
      return;
    }

    setState(() => _payingDoctorCode = identifier);
    final result = await _service.payDoctorBalance(identifier: identifier);
    if (!mounted) return;
    setState(() => _payingDoctorCode = null);

    if (result['statusCode'] == 200) {
      final paidAmount = result['data']?['paid_amount']?.toString() ?? '0';
      final updatedDoctor = result['data']?['doctor'];
      if (updatedDoctor is Map) {
        final updatedMap = Map<String, dynamic>.from(updatedDoctor);
        setState(() {
          _doctors = _doctors.map((item) {
            final itemCode = item['doctor_code']?.toString() ?? '';
            return itemCode == identifier ? updatedMap : item;
          }).toList();
        });
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Doctor pagado correctamente. Monto liquidado: \$$paidAmount',
          ),
        ),
      );
      await _load();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No se pudo pagar al doctor',
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Doctores Prescriptores'),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      _error!,
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      onPressed: _load,
                      icon: const Icon(Icons.refresh),
                      label: const Text('Reintentar'),
                    ),
                  ],
                ),
              ),
            )
          : _doctors.isEmpty
          ? const Center(child: Text('Todavía no hay doctores registrados.'))
          : ListView.separated(
              padding: const EdgeInsets.all(14),
              itemCount: _doctors.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                final doctor = _doctors[index];
                final doctorCode = doctor['doctor_code']?.toString() ?? '';
                final isPaying = _payingDoctorCode == doctorCode;
                final balance = double.tryParse(
                      (doctor['commission_balance'] ?? 0).toString(),
                    ) ??
                    0;
                final isPaidOut = balance <= 0;

                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          doctor['name']?.toString() ?? '',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text('Código: ${doctor['doctor_code'] ?? ''}'),
                        if ((doctor['email'] ?? '').toString().isNotEmpty)
                          Text(doctor['email'].toString()),
                        if ((doctor['phone'] ?? '').toString().isNotEmpty)
                          Text(doctor['phone'].toString()),
                        const SizedBox(height: 8),
                        Text(
                          'Saldo pendiente: \$${doctor['commission_balance'] ?? 0}',
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                        Text(
                          'Comisión pagada acumulada: \$${doctor['paid_commission'] ?? 0}',
                        ),
                        Text(
                          'Ventas acumuladas: \$${doctor['total_sales'] ?? 0}',
                        ),
                        const SizedBox(height: 8),
                        if ((doctor['bank_name'] ?? '').toString().isNotEmpty)
                          Text('Banco: ${doctor['bank_name']}'),
                        if ((doctor['bank_account_type'] ?? '')
                            .toString()
                            .isNotEmpty)
                          Text('Tipo cuenta: ${doctor['bank_account_type']}'),
                        if ((doctor['bank_account_last4'] ?? '')
                            .toString()
                            .isNotEmpty)
                          Text(
                            'Cuenta terminada en: ${doctor['bank_account_last4']}',
                          ),
                        const SizedBox(height: 12),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: (isPaying || isPaidOut)
                                ? null
                                : () => _payDoctor(doctor),
                            icon: const Icon(Icons.account_balance_wallet),
                            label: Text(
                              isPaying
                                  ? 'Pagando...'
                                  : isPaidOut
                                  ? 'Pagado / saldo en 0'
                                  : 'Pagar doctor y marcar saldo en 0',
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: isPaidOut
                                  ? Colors.grey.shade500
                                  : null,
                              foregroundColor: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
