import 'package:flutter/material.dart';

class DigitalPolicyScreen extends StatelessWidget {
  const DigitalPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Política digital'),
      ),
      body: const SingleChildScrollView(
        padding: EdgeInsets.all(22),
        child: Text(
          '''
POLÍTICA DIGITAL Y NOTIFICACIONES — MAYU WELLNESS CLUB

Al registrarte en Mayu Wellness Club aceptas el uso de herramientas digitales para la gestión de tu membresía, comunicación, seguimiento, tarjeta digital, notificaciones y procesos operativos.

1. Comunicación digital

Mayu Wellness Club podrá contactarte mediante correo electrónico, WhatsApp, notificaciones push, llamadas o mensajes relacionados con tu membresía, pagos, entregas, beneficios, promociones y soporte.

2. Tarjeta digital y Wallet

La plataforma podrá generar una tarjeta digital con datos de identificación de socio, estado de membresía, nivel, código QR y otros elementos necesarios para validar beneficios.

3. Notificaciones

El usuario acepta recibir notificaciones sobre:

• Estado de membresía.
• Confirmación de pago.
• Entregas.
• Tracking.
• Recordatorios.
• Promociones.
• Beneficios.
• Información postventa.

4. Tracking y logística

Mayu Wellness Club podrá mostrar información de seguimiento interno o externo relacionada con las órdenes, entregas y servicios logísticos.

5. Automatizaciones

La plataforma podrá usar procesos automáticos para enviar recordatorios, actualizar estados, generar órdenes, sincronizar información y mejorar la experiencia del usuario.

6. Actualizaciones digitales

Mayu Wellness Club podrá modificar, mejorar o ampliar sus herramientas digitales, incluyendo wallet, QR, tracking, notificaciones, paneles y funciones futuras.

Al continuar con el registro, declaras aceptar esta política digital y el uso de notificaciones.
''',
          style: TextStyle(fontSize: 16, height: 1.45),
        ),
      ),
    );
  }
}