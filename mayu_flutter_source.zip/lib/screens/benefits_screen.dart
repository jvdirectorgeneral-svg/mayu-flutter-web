import 'package:flutter/material.dart';

import '../widgets/mayu_scaffold.dart';

class BenefitsScreen extends StatelessWidget {
  const BenefitsScreen({super.key});

  Widget _benefitCard({
    required String title,
    required String description,
    required IconData icon,
    required String imagePath,
    required Color color,
  }) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 18),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.black12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(
              imagePath,
              width: double.infinity,
              height: 155,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  height: 155,
                  width: double.infinity,
                  color: color.withValues(alpha: 0.15),
                  child: Icon(icon, size: 58, color: color),
                );
              },
            ),
            Padding(
              padding: const EdgeInsets.all(18),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(icon, size: 30, color: color),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: color,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          description,
                          style: const TextStyle(
                            fontSize: 16,
                            height: 1.35,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _noteBox() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.only(top: 6, bottom: 18),
      decoration: BoxDecoration(
        color: Colors.teal.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: Colors.teal.withValues(alpha: 0.35),
        ),
      ),
      child: const Text(
        'Los beneficios aplican para socios activos de Mayu Wellness Club. '
        'Los descuentos no reemplazan el débito mensual del plan ni el pago inicial de afiliación.',
        style: TextStyle(
          fontSize: 15,
          height: 1.35,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MayuScaffold(
      appBar: AppBar(
        title: const Text('Beneficios Club Mayu'),
        centerTitle: true,
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 620),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Tus beneficios',
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Accede a descuentos preferenciales en el ecosistema Mayu.',
                  style: TextStyle(
                    fontSize: 17,
                    color: Colors.black54,
                  ),
                ),
                const SizedBox(height: 18),
                _noteBox(),
                _benefitCard(
                  title: '15% de descuento en consultorio',
                  description:
                      'Aplica para consultas del ecosistema Mayu según disponibilidad, agenda y condiciones internas.',
                  icon: Icons.medical_services_outlined,
                  imagePath: 'assets/images/consultorio.jpg',
                  color: Colors.teal,
                ),
                _benefitCard(
                  title: '15% de descuento en terapias',
                  description:
                      'Beneficio aplicable en terapias disponibles dentro del centro Mayu y servicios terapéuticos autorizados.',
                  icon: Icons.spa_outlined,
                  imagePath: 'assets/images/terapias.jpg',
                  color: Colors.deepPurple,
                ),
                _benefitCard(
                  title: '10% de descuento en Farmacia Magistral',
                  description:
                      'Aplica en productos seleccionados de la Farmacia Magistral Mayu, según disponibilidad y condiciones comerciales.',
                  icon: Icons.local_pharmacy_outlined,
                  imagePath: 'assets/images/farmacia.jpg',
                  color: Colors.orange,
                ),
                _benefitCard(
                  title: 'Acceso gratuito a Mayu Educación',
                  description:
                      'El socio activo tiene acceso gratuito a Mayu Educación, biblioteca educativa, contenidos de fitoterapia, medicina natural y formación del ecosistema Mayu.',
                  icon: Icons.school_outlined,
                  imagePath: 'assets/images/educacion.png',
                  color: Colors.blue,
                ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }
}