import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class EducationReaderScreen extends StatefulWidget {
  final String title;
  final String viewUrl;

  const EducationReaderScreen({
    super.key,
    required this.title,
    required this.viewUrl,
  });

  @override
  State<EducationReaderScreen> createState() => _EducationReaderScreenState();
}

class _EducationReaderScreenState extends State<EducationReaderScreen> {
  bool _opening = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    Future.microtask(_openInBrowser);
  }

  Future<void> _openInBrowser() async {
    final uri = Uri.tryParse(widget.viewUrl);

    if (uri == null || !uri.hasScheme) {
      setState(() {
        _error = 'Enlace inválido';
      });
      return;
    }

    setState(() {
      _opening = true;
      _error = null;
    });

    final opened = await launchUrl(
      uri,
      mode: LaunchMode.externalApplication,
    );

    if (!mounted) return;

    setState(() {
      _opening = false;
      if (!opened) {
        _error = 'No se pudo abrir el contenido educativo';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      appBar: AppBar(
        title: Text(widget.title),
        centerTitle: true,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.school,
                size: 64,
                color: Colors.teal,
              ),
              const SizedBox(height: 16),
              Text(
                _opening
                    ? 'Abriendo contenido educativo...'
                    : 'Contenido protegido Mayu Educación',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              if (_opening) const CircularProgressIndicator(),
              if (_error != null) ...[
                const SizedBox(height: 16),
                Text(
                  _error!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.red),
                ),
              ],
              const SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: _opening ? null : _openInBrowser,
                icon: const Icon(Icons.open_in_browser),
                label: const Text('Abrir contenido'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}