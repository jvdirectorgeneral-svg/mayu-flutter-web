import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/cart_service.dart';
import '../services/marketplace_service.dart';
import 'pharmacy_qr_scanner_screen.dart';

class MarketplaceCheckoutScreen extends StatefulWidget {
  const MarketplaceCheckoutScreen({super.key});

  @override
  State<MarketplaceCheckoutScreen> createState() =>
      _MarketplaceCheckoutScreenState();
}

class _MarketplaceCheckoutScreenState extends State<MarketplaceCheckoutScreen> {
  final CartService _cartService = CartService();
  final MarketplaceService _marketplaceService = MarketplaceService();

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _confirmPhoneController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _confirmEmailController = TextEditingController();
  final TextEditingController _cityController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _notesController = TextEditingController();
  final TextEditingController _discountCodeController = TextEditingController();
  final TextEditingController _pharmacyLoyaltyController = TextEditingController();
  final TextEditingController _doctorPrescriberController =
      TextEditingController();

  final TextEditingController _billingNameController = TextEditingController();
  final TextEditingController _billingIdentificationController =
      TextEditingController();
  final TextEditingController _billingEmailController = TextEditingController();
  final TextEditingController _billingPhoneController = TextEditingController();
  final TextEditingController _billingAddressController =
      TextEditingController();

  bool _loading = false;
  bool _paypalLoading = false;
  bool _needsBilling = false;

  final String _whatsAppNumber = '593962320665';

  // Temporal: luego lo conectamos al usuario real logueado.
  final int _userId = 1;

  double get _subtotal => _cartService.subtotal;

  double get _discountAmount {
    final code = _discountCodeController.text.trim();
    if (code.isEmpty) return 0;
    return _subtotal * 0.10;
  }

  double get _total => _subtotal - _discountAmount;

  bool _isValidEmail(String value) {
    final email = value.trim();
    final regex = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');
    return regex.hasMatch(email);
  }

  bool _validateCustomerData({bool requireEmail = false}) {
    final name = _nameController.text.trim();
    final phone = _phoneController.text.trim();
    final confirmPhone = _confirmPhoneController.text.trim();
    final email = _emailController.text.trim();
    final confirmEmail = _confirmEmailController.text.trim();
    final address = _addressController.text.trim();

    if (_cartService.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('El carrito está vacío')),
      );
      return false;
    }

    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('El nombre completo es obligatorio')),
      );
      return false;
    }

    if (phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('El teléfono / WhatsApp es obligatorio')),
      );
      return false;
    }

    if (confirmPhone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Confirma tu teléfono / WhatsApp')),
      );
      return false;
    }

    if (phone != confirmPhone) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Los teléfonos no coinciden')),
      );
      return false;
    }

    if (address.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('La dirección de entrega es obligatoria')),
      );
      return false;
    }

    if (requireEmail) {
      if (email.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('El email es obligatorio para pagar')),
        );
        return false;
      }

      if (!_isValidEmail(email)) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Ingresa un email válido')),
        );
        return false;
      }

      if (confirmEmail.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Confirma tu email')),
        );
        return false;
      }

      if (email.toLowerCase() != confirmEmail.toLowerCase()) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Los emails no coinciden')),
        );
        return false;
      }
    }

    return true;
  }

  bool _validateBillingData() {
    if (!_needsBilling) return true;

    final billingName = _billingNameController.text.trim();
    final billingIdentification = _billingIdentificationController.text.trim();
    final billingEmail = _billingEmailController.text.trim();

    if (billingName.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('El nombre o razón social es obligatorio')),
      );
      return false;
    }

    if (billingIdentification.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('La cédula o RUC es obligatorio')),
      );
      return false;
    }

    if (billingEmail.isNotEmpty && !_isValidEmail(billingEmail)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('El email de facturación no es válido')),
      );
      return false;
    }

    return true;
  }

  Future<void> _scanPharmacyLoyaltyQr() async {
    final result = await Navigator.push<String>(
      context,
      MaterialPageRoute(
        builder: (_) => const PharmacyQrScannerScreen(
          title: 'Escanear QR Tarjeta Farmacia',
          helperText:
              'Enfoca el QR de la Tarjeta Mayu Magistral para sumar puntos.',
        ),
      ),
    );

    if (!mounted) return;
    final value = result?.trim();
    if (value == null || value.isEmpty) return;

    setState(() {
      _pharmacyLoyaltyController.text = value;
    });
  }

  Future<void> _scanDoctorPrescriberQr() async {
    final result = await Navigator.push<String>(
      context,
      MaterialPageRoute(
        builder: (_) => const PharmacyQrScannerScreen(
          title: 'Escanear QR Doctor Prescriptor',
          helperText:
              'Enfoca el QR del Doctor Prescriptor Mayu para registrar su ganancia.',
        ),
      ),
    );

    if (!mounted) return;
    final value = result?.trim();
    if (value == null || value.isEmpty) return;

    setState(() {
      _doctorPrescriberController.text = value;
    });
  }

  Future<void> _sendOrderByWhatsApp() async {
    if (!_validateCustomerData()) return;
    if (!_validateBillingData()) return;

    setState(() {
      _loading = true;
    });

    final result = await _marketplaceService.createOrder(
      customerName: _nameController.text.trim(),
      customerPhone: _phoneController.text.trim(),
      customerEmail: _emailController.text.trim(),
      city: _cityController.text.trim(),
      address: _addressController.text.trim(),
      deliveryNotes: _notesController.text.trim(),
      billingName: _needsBilling ? _billingNameController.text.trim() : null,
      billingIdentification:
          _needsBilling ? _billingIdentificationController.text.trim() : null,
      billingEmail: _needsBilling ? _billingEmailController.text.trim() : null,
      billingPhone: _needsBilling ? _billingPhoneController.text.trim() : null,
      billingAddress:
          _needsBilling ? _billingAddressController.text.trim() : null,
      discountCode: _discountCodeController.text.trim(),
      pharmacyLoyaltyIdentifier: _pharmacyLoyaltyController.text.trim(),
      doctorPrescriberIdentifier: _doctorPrescriberController.text.trim(),
      items: _cartService.toOrderItems(),
    );

    if (!mounted) return;

    setState(() {
      _loading = false;
    });

    if (result['statusCode'] == 200 || result['statusCode'] == 201) {
      final order = result['data']?['order'] ?? {};
      final message = order['whatsapp_message']?.toString() ??
          'Hola Mayu, deseo confirmar mi pedido.';

      final uri = Uri.parse(
        'https://wa.me/$_whatsAppNumber?text=${Uri.encodeComponent(message)}',
      );

      _cartService.clear();

      await launchUrl(uri, mode: LaunchMode.externalApplication);

      if (!mounted) return;
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No se pudo crear la orden',
          ),
        ),
      );
    }
  }

  Future<void> _payWithPayPal() async {
    if (!_validateCustomerData(requireEmail: true)) return;
    if (!_validateBillingData()) return;

    setState(() {
      _paypalLoading = true;
    });

    final result = await _marketplaceService.createMarketplacePayPalCartOrder(
      userId: _userId,
      buyerName: _nameController.text.trim(),
      buyerPhone: _phoneController.text.trim(),
      buyerEmail: _emailController.text.trim(),
      city: _cityController.text.trim(),
      address: _addressController.text.trim(),
      deliveryNotes: _notesController.text.trim(),
      billingName: _needsBilling ? _billingNameController.text.trim() : null,
      billingIdentification:
          _needsBilling ? _billingIdentificationController.text.trim() : null,
      billingEmail: _needsBilling ? _billingEmailController.text.trim() : null,
      billingPhone: _needsBilling ? _billingPhoneController.text.trim() : null,
      billingAddress:
          _needsBilling ? _billingAddressController.text.trim() : null,
      discountCode: _discountCodeController.text.trim(),
      pharmacyLoyaltyIdentifier: _pharmacyLoyaltyController.text.trim(),
      doctorPrescriberIdentifier: _doctorPrescriberController.text.trim(),
      items: _cartService.toOrderItems(),
    );

    if (!mounted) return;

    setState(() {
      _paypalLoading = false;
    });

    if (result['statusCode'] == 200 || result['statusCode'] == 201) {
      final approvalUrl = result['data']?['approval_url']?.toString() ?? '';

      if (approvalUrl.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('PayPal no devolvió enlace de pago')),
        );
        return;
      }

      final uri = Uri.parse(approvalUrl);
      await launchUrl(uri, mode: LaunchMode.externalApplication);

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Completa el pago en PayPal. Luego vuelve a Mayu.'),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No se pudo crear pago PayPal',
          ),
        ),
      );
    }
  }

  Widget _summaryRow(String label, double value, {bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontWeight: bold ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ),
          Text(
            '\$${value.toStringAsFixed(2)} USD',
            style: TextStyle(
              fontWeight: bold ? FontWeight.bold : FontWeight.normal,
              color: bold ? Colors.teal : Colors.black87,
            ),
          ),
        ],
      ),
    );
  }

  Widget _cartItem(Map<String, dynamic> item) {
    final product = Map<String, dynamic>.from(item['product']);
    final quantity = int.tryParse((item['quantity'] ?? 1).toString()) ?? 1;
    final price = double.tryParse((product['price'] ?? 0).toString()) ?? 0;
    final productId = int.tryParse((product['id'] ?? 0).toString()) ?? 0;

    return Card(
      child: ListTile(
        title: Text(product['name']?.toString() ?? 'Producto'),
        subtitle: Text(
          'Cantidad: $quantity • \$${(price * quantity).toStringAsFixed(2)} USD',
        ),
        trailing: Wrap(
          children: [
            IconButton(
              icon: const Icon(Icons.remove_circle_outline),
              onPressed: () {
                setState(() {
                  _cartService.decreaseQuantity(productId);
                });
              },
            ),
            IconButton(
              icon: const Icon(Icons.add_circle_outline),
              onPressed: () {
                setState(() {
                  _cartService.increaseQuantity(productId);
                });
              },
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () {
                setState(() {
                  _cartService.removeProduct(productId);
                });
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _confirmPhoneController.dispose();
    _emailController.dispose();
    _confirmEmailController.dispose();
    _cityController.dispose();
    _addressController.dispose();
    _notesController.dispose();
    _discountCodeController.dispose();
    _pharmacyLoyaltyController.dispose();
    _doctorPrescriberController.dispose();

    _billingNameController.dispose();
    _billingIdentificationController.dispose();
    _billingEmailController.dispose();
    _billingPhoneController.dispose();
    _billingAddressController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final items = _cartService.items;

    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      appBar: AppBar(
        title: const Text('Carrito Mayu'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Productos seleccionados',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          if (items.isEmpty)
            const Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: Text('El carrito está vacío')),
            )
          else
            ...items.map((item) => _cartItem(Map<String, dynamic>.from(item))),
          const SizedBox(height: 18),
          const Text(
            'Datos del cliente / entrega',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _nameController,
            textCapitalization: TextCapitalization.words,
            decoration: const InputDecoration(
              labelText: 'Nombre completo *',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _phoneController,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
              labelText: 'Teléfono / WhatsApp *',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _confirmPhoneController,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
              labelText: 'Confirmar teléfono / WhatsApp *',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _emailController,
            keyboardType: TextInputType.emailAddress,
            textCapitalization: TextCapitalization.none,
            decoration: const InputDecoration(
              labelText: 'Email para comprobante / seguimiento',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _confirmEmailController,
            keyboardType: TextInputType.emailAddress,
            textCapitalization: TextCapitalization.none,
            decoration: const InputDecoration(
              labelText: 'Confirmar email para pago PayPal',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _cityController,
            textCapitalization: TextCapitalization.words,
            decoration: const InputDecoration(
              labelText: 'Ciudad',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _addressController,
            decoration: const InputDecoration(
              labelText: 'Dirección de entrega *',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _notesController,
            minLines: 2,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: 'Observaciones de entrega',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'Tarjeta Mayu Magistral Farmacia',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _pharmacyLoyaltyController,
            textCapitalization: TextCapitalization.characters,
            decoration: InputDecoration(
              labelText: 'QR o código FAR-MAYU para sumar puntos',
              helperText: 'Opcional: escanea tu tarjeta de farmacia para sumar puntos al pagar.',
              border: const OutlineInputBorder(),
              prefixIcon: const Icon(Icons.card_membership),
              suffixIcon: IconButton(
                tooltip: 'Escanear QR Tarjeta Mayu Magistral',
                icon: const Icon(Icons.qr_code_scanner),
                onPressed: _scanPharmacyLoyaltyQr,
              ),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _scanPharmacyLoyaltyQr,
              icon: const Icon(Icons.qr_code_scanner),
              label: const Text('Escanear QR Tarjeta Farmacia'),
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'Doctor Prescriptor Mayu',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _doctorPrescriberController,
            textCapitalization: TextCapitalization.characters,
            decoration: InputDecoration(
              labelText: 'QR o código DOC-MAYU para registrar doctor',
              helperText:
                  'Opcional: registra el Doctor Prescriptor para acreditar su ganancia del 30%.',
              border: const OutlineInputBorder(),
              prefixIcon: const Icon(Icons.medical_services_outlined),
              suffixIcon: IconButton(
                tooltip: 'Escanear QR Doctor Prescriptor',
                icon: const Icon(Icons.qr_code_scanner),
                onPressed: _scanDoctorPrescriberQr,
              ),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _scanDoctorPrescriberQr,
              icon: const Icon(Icons.qr_code_scanner),
              label: const Text('Escanear QR Doctor Prescriptor'),
            ),
          ),
          const SizedBox(height: 18),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text(
              'Necesito datos de facturación',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            subtitle: const Text('Actívalo solo si quieres factura con cédula/RUC.'),
            value: _needsBilling,
            onChanged: (value) {
              setState(() {
                _needsBilling = value;
              });
            },
          ),
          if (_needsBilling) ...[
            const SizedBox(height: 12),
            TextField(
              controller: _billingNameController,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(
                labelText: 'Nombre o razón social *',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _billingIdentificationController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Cédula / RUC *',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _billingEmailController,
              keyboardType: TextInputType.emailAddress,
              textCapitalization: TextCapitalization.none,
              decoration: const InputDecoration(
                labelText: 'Email de facturación',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _billingPhoneController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: 'Teléfono de facturación',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _billingAddressController,
              decoration: const InputDecoration(
                labelText: 'Dirección de facturación',
                border: OutlineInputBorder(),
              ),
            ),
          ],
          const SizedBox(height: 18),
          const Text(
            'Cupón / descuento Mayu Wellness Club',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _discountCodeController,
            textCapitalization: TextCapitalization.characters,
            decoration: const InputDecoration(
              labelText: 'Opcional: código socio Mayu Club',
              helperText: 'Este campo es distinto a la Tarjeta Mayu Magistral Farmacia.',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.local_offer_outlined),
            ),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 18),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _summaryRow('Subtotal', _subtotal),
                  if (_discountAmount > 0)
                    _summaryRow(
                      'Descuento socio Mayu Club 10%',
                      -_discountAmount,
                    ),
                  const Divider(),
                  _summaryRow('Total', _total, bold: true),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          SizedBox(
            height: 54,
            child: ElevatedButton.icon(
              onPressed: _paypalLoading ? null : _payWithPayPal,
              icon: const Icon(Icons.payment),
              label: Text(
                _paypalLoading
                    ? 'Conectando con PayPal...'
                    : 'Pagar carrito con PayPal',
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
              ),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 54,
            child: OutlinedButton.icon(
              onPressed: _loading ? null : _sendOrderByWhatsApp,
              icon: const Icon(Icons.chat),
              label: Text(
                _loading
                    ? 'Creando orden...'
                    : 'Confirmar pedido por WhatsApp',
              ),
            ),
          ),
        ],
      ),
    );
  }
}
