import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/order_service.dart';

class LogisticsDashboardScreen extends StatefulWidget {
  const LogisticsDashboardScreen({super.key});

  @override
  State<LogisticsDashboardScreen> createState() =>
      _LogisticsDashboardScreenState();
}

class _LogisticsDashboardScreenState extends State<LogisticsDashboardScreen> {
  final OrderService _orderService = OrderService();

  bool _loading = true;
  String? _error;
  List<dynamic> _orders = [];

  String _searchQuery = '';
  String _stageFilter = 'ready';

  static const double margen1 = 16;
  static const String _jeffWhatsappNumber = '593989683645';

  @override
  void initState() {
    super.initState();
    _loadOrders();
  }

  Future<void> _loadOrders() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final result = await _orderService.getOrders();

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      final items = result['data']['items'] ?? [];

      setState(() {
        _orders = (items as List).where((o) {
          if (o is! Map) return false;
          final map = Map<String, dynamic>.from(o);
          final status = (map['status'] ?? '').toString();
          return status != 'delivered' && status != 'cancelled';
        }).map((o) {
          return Map<String, dynamic>.from(o as Map);
        }).toList();

        _loading = false;
      });
    } else {
      setState(() {
        _loading = false;
        _error = result['data']?['detail'] ?? 'Error al cargar órdenes';
      });
    }
  }

  bool _matchesSearch(Map<String, dynamic> order) {
    if (_searchQuery.trim().isEmpty) return true;

    final q = _searchQuery.toLowerCase();

    final values = [
      order['id'],
      order['order_code'],
      order['user_name'],
      order['user_phone'],
      order['city_snapshot'],
      order['address_snapshot'],
      order['reference_snapshot'],
      order['delivery_notes_snapshot'],
      order['status'],
      order['payment_status'],
      order['payment_type'],
      order['tracking_number'],
      order['tracking_url'],
      order['carrier'],
      order['shipping_notes'],
      order['logistics_notes'],
    ];

    for (final value in values) {
      if (value != null && value.toString().toLowerCase().contains(q)) {
        return true;
      }
    }

    for (final item in _orderItems(order)) {
      final map = Map<String, dynamic>.from(item as Map);
      final name =
          (map['name'] ?? map['product_name_snapshot'] ?? '').toString();

      if (name.toLowerCase().contains(q)) return true;
    }

    return false;
  }

  bool _hasOperationalProblem(Map<String, dynamic> order) {
    final hasAddress =
        (order['address_snapshot'] ?? '').toString().trim().isNotEmpty;
    final hasPhone = (order['user_phone'] ?? '').toString().trim().isNotEmpty;
    final hasProducts = _orderItems(order).isNotEmpty;
    final status = (order['status'] ?? '').toString();
    final shippedWithoutGuide = status == 'shipped' &&
        (order['tracking_number'] ?? '').toString().trim().isEmpty;
    return !hasAddress || !hasPhone || !hasProducts || shippedWithoutGuide;
  }

  bool _matchesStage(Map<String, dynamic> order) {
    final status = (order['status'] ?? '').toString();
    final future = order['is_future_cycle'] == true;
    switch (_stageFilter) {
      case 'ready':
        return status == 'approved_for_logistics' && !future;
      case 'preparing':
        return status == 'preparing';
      case 'shipped':
        return status == 'shipped';
      case 'future':
        return future;
      case 'problems':
        return _hasOperationalProblem(order);
      default:
        return true;
    }
  }

  Widget _stageChip(String value, String label, int count) {
    return ChoiceChip(
      selected: _stageFilter == value,
      label: Text('$label ($count)'),
      onSelected: (_) => setState(() => _stageFilter = value),
    );
  }

  Future<void> _updateStatus(int orderId, String status) async {
    final result = await _orderService.updateOrderStatus(
      orderId: orderId,
      status: status,
    );

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          result['statusCode'] == 200
              ? 'Estado actualizado'
              : result['data']?['detail'] ?? 'Error actualizando estado',
        ),
      ),
    );

    if (result['statusCode'] == 200) {
      await _loadOrders();
    }
  }

  Future<void> _copyTracking(String tracking) async {
    await Clipboard.setData(ClipboardData(text: tracking));

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Guía copiada')),
    );
  }

  Future<void> _showTrackingDialog(
    Map<String, dynamic> order, {
    bool markAsShipped = false,
  }) async {
    final carrierController = TextEditingController(
      text: (order['carrier'] ?? '').toString(),
    );

    final trackingController = TextEditingController(
      text: (order['tracking_number'] ?? '').toString(),
    );

    final urlController = TextEditingController(
      text: (order['tracking_url'] ?? '').toString(),
    );

    final notesController = TextEditingController(
      text: (order['shipping_notes'] ?? '').toString(),
    );

    await showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Tracking / Guía'),
          content: SizedBox(
            width: 520,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  TextField(
                    controller: carrierController,
                    decoration: const InputDecoration(
                      labelText: 'Transportadora',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: trackingController,
                    decoration: const InputDecoration(
                      labelText: 'Número guía',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: urlController,
                    decoration: const InputDecoration(
                      labelText: 'Tracking URL',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: notesController,
                    maxLines: 3,
                    decoration: const InputDecoration(
                      labelText: 'Notas envío',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () async {
                final navigator = Navigator.of(dialogContext);
                final messenger = ScaffoldMessenger.of(context);
                final rawTrackingUrl = urlController.text.trim();
                final cleanTrackingUrl = rawTrackingUrl.isNotEmpty &&
                        !rawTrackingUrl.startsWith('http://') &&
                        !rawTrackingUrl.startsWith('https://')
                    ? 'https://$rawTrackingUrl'
                    : rawTrackingUrl;

                final result = await _orderService.updateOrderTracking(
                  orderId: int.tryParse((order['id'] ?? 0).toString()) ?? 0,
                  carrier: carrierController.text.trim(),
                  trackingNumber: trackingController.text.trim(),
                  trackingUrl: cleanTrackingUrl,
                  shippingNotes: notesController.text.trim(),
                );

                if (!dialogContext.mounted) return;
                navigator.pop();

                if (!mounted) return;

                messenger.showSnackBar(
                  SnackBar(
                    content: Text(
                      result['statusCode'] == 200
                          ? 'Tracking actualizado'
                          : result['data']?['detail'] ??
                              'No se pudo actualizar',
                    ),
                  ),
                );

                if (result['statusCode'] == 200) {
                  if (markAsShipped) {
                    await _updateStatus(
                      int.tryParse((order['id'] ?? 0).toString()) ?? 0,
                      'shipped',
                    );
                  } else {
                    await _loadOrders();
                  }
                }
              },
              child: const Text('Guardar'),
            ),
          ],
        );
      },
    );

    carrierController.dispose();
    trackingController.dispose();
    urlController.dispose();
    notesController.dispose();
  }

  String _levelLabel(dynamic level) {
    final parsed = int.tryParse((level ?? '0').toString()) ?? 0;

    switch (parsed) {
      case 1:
        return 'Nivel 1 - Cobre';
      case 2:
        return 'Nivel 2 - Plata';
      case 3:
        return 'Nivel 3 - Oro';
      default:
        return 'Sin nivel';
    }
  }

  String _paymentTypeLabel(dynamic type) {
    final clean = (type ?? '').toString();

    switch (clean) {
      case 'signup':
        return 'Afiliación inicial';
      case 'subscription':
        return 'Suscripción nueva';
      case 'subscription_renewal':
        return 'Renovación mensual';
      default:
        return clean.isEmpty ? 'Orden mensual' : clean;
    }
  }

  List<dynamic> _orderItems(Map<String, dynamic> order) {
    final raw = order['items'];
    if (raw is List) return raw;

    final monthlyProducts = order['monthly_selection_products'];
    if (monthlyProducts is List) return monthlyProducts;

    return [];
  }

  Widget _productsWidget(Map<String, dynamic> order) {
    final items = _orderItems(order);

    if (items.isEmpty) {
      return const Text(
        '• No hay productos registrados',
        style: TextStyle(color: Colors.red),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: items.map((item) {
        final map = Map<String, dynamic>.from(item as Map);

        final name = (map['name'] ?? map['product_name_snapshot'] ?? 'Producto')
            .toString();

        final quantity = (map['quantity'] ?? 1).toString();

        return Padding(
          padding: const EdgeInsets.only(bottom: 4),
          child: Text(
            '• $name x$quantity',
            style: const TextStyle(fontSize: 15),
          ),
        );
      }).toList(),
    );
  }

  String _statusLabel(String status) {
    switch (status) {
      case 'approved_for_logistics':
        return 'LISTO PARA DESPACHO';
      case 'preparing':
        return 'PREPARANDO';
      case 'shipped':
        return 'ENVIADO';
      case 'delivered':
        return 'ENTREGADO';
      default:
        return status.toUpperCase();
    }
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'approved_for_logistics':
        return Colors.green;
      case 'preparing':
        return Colors.blue;
      case 'shipped':
        return Colors.purple;
      case 'delivered':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  String _formatDate(dynamic value) {
    if (value == null) return '-';

    try {
      final date = DateTime.parse(value.toString()).toLocal();

      return '${date.day.toString().padLeft(2, '0')}/'
          '${date.month.toString().padLeft(2, '0')}/'
          '${date.year} '
          '${date.hour.toString().padLeft(2, '0')}:'
          '${date.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return value.toString();
    }
  }

  Widget _badge(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _infoLine(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text(
        '$label$value',
        style: const TextStyle(fontSize: 15),
      ),
    );
  }

  Widget _flowButton(Map<String, dynamic> order) {
    final status = (order['status'] ?? '').toString();
    final orderId = int.tryParse((order['id'] ?? 0).toString()) ?? 0;
    final futureCycle = order['is_future_cycle'] == true;
    String nextStatus = '';
    String label = '';

    if (futureCycle) {
      return ElevatedButton.icon(
        onPressed: null,
        icon: const Icon(Icons.event),
        label: const Text('Ciclo futuro · no despachar'),
      );
    }

    switch (status) {
      case 'approved_for_logistics':
        nextStatus = 'preparing';
        label = 'Iniciar preparación';
        break;
      case 'preparing':
        return ElevatedButton.icon(
          onPressed: () => _showTrackingDialog(order, markAsShipped: true),
          icon: const Icon(Icons.local_shipping),
          label: const Text('Registrar guía y enviar'),
        );
      case 'shipped':
        nextStatus = 'delivered';
        label = 'Confirmar entrega';
        break;
      default:
        return const SizedBox.shrink();
    }

    return ElevatedButton.icon(
      onPressed: () => _updateStatus(orderId, nextStatus),
      icon: const Icon(Icons.arrow_forward),
      label: Text(label),
    );
  }

  Future<void> _openTrackingUrl(String url) async {
    final cleanUrl = url.trim();

    if (cleanUrl.isEmpty || cleanUrl == '-') return;

    final uri = Uri.tryParse(cleanUrl);

    if (uri == null) return;

    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Future<void> _sendToWhatsApp(Map<String, dynamic> order) async {
    final message = '''
Nueva orden Mayu Wellness Club

Orden: ${order['order_code'] ?? '-'}
Cliente: ${order['user_name'] ?? '-'}
Teléfono: ${order['user_phone'] ?? '-'}

Ciudad: ${order['city_snapshot'] ?? '-'}
Dirección: ${order['address_snapshot'] ?? '-'}
Referencia: ${order['reference_snapshot'] ?? '-'}

Tipo de pago:
${_paymentTypeLabel(order['payment_type'])}

Nivel:
${_levelLabel(order['membership_level_snapshot'])}

Productos:
${_orderItems(order).map((item) {
      final map = Map<String, dynamic>.from(item as Map);
      final name = map['name'] ?? map['product_name_snapshot'] ?? 'Producto';
      final quantity = map['quantity'] ?? 1;
      return '- $name x$quantity';
    }).join('\n')}

Facturación / entrega:
${order['delivery_notes_snapshot'] ?? '-'}
''';

    final uri = Uri.parse(
      'https://wa.me/$_jeffWhatsappNumber?text=${Uri.encodeComponent(message)}',
    );

    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Widget _buildOrderCard(Map<String, dynamic> order) {
    final status = (order['status'] ?? '').toString();
    final paymentStatus = (order['payment_status'] ?? '').toString();
    final paymentType = (order['payment_type'] ?? '').toString();
    final futureCycle = order['is_future_cycle'] == true;

    final tracking = (order['tracking_number'] ?? '-').toString();
    final trackingUrl = (order['tracking_url'] ?? '-').toString();

    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(
          color: _statusColor(status),
          width: 2,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${order['membership_cycle_label'] ?? _paymentTypeLabel(paymentType)} · ${order['month_label'] ?? ""}',
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            const SizedBox(height: 10),
            if (futureCycle)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(10),
                color: Colors.amber.shade100,
                child: Text(
                  (order['dispatch_block_reason'] ??
                          'Ciclo futuro: no preparar ni despachar')
                      .toString(),
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            _infoLine('Código: ', (order['order_code'] ?? '-').toString()),
            _infoLine('Cliente: ', (order['user_name'] ?? '-').toString()),
            _infoLine('Teléfono: ', (order['user_phone'] ?? '-').toString()),
            _infoLine('Ciudad: ', (order['city_snapshot'] ?? '-').toString()),
            _infoLine(
              'Dirección: ',
              (order['address_snapshot'] ?? '-').toString(),
            ),
            _infoLine(
              'Referencia: ',
              (order['reference_snapshot'] ?? '-').toString(),
            ),
            _infoLine(
                'Nivel: ', _levelLabel(order['membership_level_snapshot'])),
            _infoLine('Tipo pago: ', _paymentTypeLabel(paymentType)),
            _infoLine(
              'Periodo: ',
              '${order['month'] ?? '-'}/${order['year'] ?? '-'}',
            ),
            const SizedBox(height: 12),
            const Text(
              'Productos elegidos:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            _productsWidget(order),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Facturación / entrega',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 6),
                  Text((order['delivery_notes_snapshot'] ?? '-').toString()),
                ],
              ),
            ),
            const SizedBox(height: 14),
            _infoLine('Transportadora: ', (order['carrier'] ?? '-').toString()),
            Row(
              children: [
                Expanded(child: _infoLine('Guía: ', tracking)),
                IconButton(
                  onPressed: tracking == '-' || tracking.trim().isEmpty
                      ? null
                      : () => _copyTracking(tracking),
                  icon: const Icon(Icons.copy),
                ),
              ],
            ),
            _infoLine('Tracking URL: ', trackingUrl),
            const SizedBox(height: 10),
            _infoLine('Preparado: ', _formatDate(order['prepared_at'])),
            _infoLine('Enviado: ', _formatDate(order['shipped_at'])),
            _infoLine('Entregado: ', _formatDate(order['delivered_at'])),
            const SizedBox(height: 14),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _badge(_statusLabel(status), _statusColor(status)),
                if (paymentStatus.isNotEmpty)
                  _badge(
                    paymentStatus.toUpperCase(),
                    paymentStatus == 'verified' ? Colors.green : Colors.orange,
                  ),
                if (paymentType.isNotEmpty)
                  _badge(_paymentTypeLabel(paymentType), Colors.blueGrey),
              ],
            ),
            const SizedBox(height: 14),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _flowButton(order),
                ElevatedButton.icon(
                  onPressed: () => _showTrackingDialog(order),
                  icon: const Icon(Icons.local_shipping),
                  label: const Text('Tracking'),
                ),
                if (trackingUrl.trim().isNotEmpty && trackingUrl != '-')
                  OutlinedButton.icon(
                    onPressed: () => _openTrackingUrl(trackingUrl),
                    icon: const Icon(Icons.open_in_new),
                    label: const Text('Abrir tracking'),
                  ),
                ElevatedButton.icon(
                  onPressed: () => _sendToWhatsApp(order),
                  icon: const Icon(Icons.send),
                  label: const Text('WhatsApp'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _ordersPanel({
    required String title,
    required List<Map<String, dynamic>> orders,
    required String emptyText,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '$title (${orders.length})',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            if (orders.isEmpty)
              Padding(
                padding: const EdgeInsets.all(24),
                child: Center(child: Text(emptyText)),
              )
            else
              Column(
                children: orders.map((order) {
                  return _buildOrderCard(order);
                }).toList(),
              ),
          ],
        ),
      ),
    );
  }

  Widget _operationCard({
    required int readyCount,
    required int preparingCount,
    required int shippedCount,
    required int filteredCount,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Operación semanal',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _badge('Listas: $readyCount', Colors.green),
                _badge('Preparando: $preparingCount', Colors.blue),
                _badge('Enviadas: $shippedCount', Colors.purple),
                _badge('Mostrando: $filteredCount', Colors.blueGrey),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final searchableOrders = _orders
        .whereType<Map<String, dynamic>>()
        .map((o) => Map<String, dynamic>.from(o))
        .where(_matchesSearch)
        .toList();
    final filteredOrders = searchableOrders.where(_matchesStage).toList();

    final readyCount = _orders.where((o) {
      return o is Map<String, dynamic> &&
          o['status'] == 'approved_for_logistics' &&
          o['is_future_cycle'] != true;
    }).length;

    final preparingCount = _orders.where((o) {
      return o is Map<String, dynamic> && o['status'] == 'preparing';
    }).length;

    final shippedCount = _orders.where((o) {
      return o is Map<String, dynamic> && o['status'] == 'shipped';
    }).length;

    final futureCount = _orders.where((o) {
      return o is Map<String, dynamic> && o['is_future_cycle'] == true;
    }).length;

    final problemCount = _orders.where((o) {
      return o is Map<String, dynamic> &&
          _hasOperationalProblem(Map<String, dynamic>.from(o));
    }).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Logística'),
        actions: [
          IconButton(
            onPressed: _loadOrders,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: margen1, bottom: margen1),
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : _error != null
                  ? Center(
                      child: Text(
                        _error!,
                        style: const TextStyle(color: Colors.red),
                      ),
                    )
                  : RefreshIndicator(
                      onRefresh: _loadOrders,
                      child: ListView(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        children: [
                          _operationCard(
                            readyCount: readyCount,
                            preparingCount: preparingCount,
                            shippedCount: shippedCount,
                            filteredCount: filteredOrders.length,
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            decoration: const InputDecoration(
                              hintText:
                                  'Buscar orden, cliente, guía, pago o producto',
                              prefixIcon: Icon(Icons.search),
                              border: OutlineInputBorder(),
                            ),
                            onChanged: (value) {
                              setState(() {
                                _searchQuery = value;
                              });
                            },
                          ),
                          const SizedBox(height: 14),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: [
                              _stageChip('ready', 'Por preparar', readyCount),
                              _stageChip(
                                'preparing',
                                'Preparando',
                                preparingCount,
                              ),
                              _stageChip('shipped', 'Enviadas', shippedCount),
                              _stageChip('future', 'Programadas', futureCount),
                              _stageChip(
                                'problems',
                                'Con problemas',
                                problemCount,
                              ),
                              _stageChip('all', 'Todas', _orders.length),
                            ],
                          ),
                          const SizedBox(height: 14),
                          _ordersPanel(
                            title: 'Órdenes operativas',
                            orders: filteredOrders,
                            emptyText: 'No hay órdenes en esta etapa',
                          ),
                        ],
                      ),
                    ),
        ),
      ),
    );
  }
}
