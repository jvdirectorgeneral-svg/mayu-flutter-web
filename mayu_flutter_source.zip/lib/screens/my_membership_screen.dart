import 'package:flutter/material.dart';
import '../core/membership_rules.dart';

import '../services/membership_service.dart';
import '../services/plan_change_service.dart';
import '../services/plan_service.dart';
import '../services/user_service.dart';
import '../services/member_card_service.dart';
import '../services/subscription_service.dart';

import '../widgets/mayu_scaffold.dart';

import 'membership_history_screen.dart';
import 'wallet_card_screen.dart';

class MyMembershipScreen extends StatefulWidget {
  const MyMembershipScreen({super.key});

  @override
  State<MyMembershipScreen> createState() => _MyMembershipScreenState();
}

class _MyMembershipScreenState extends State<MyMembershipScreen> {
  final MembershipService _membershipService = MembershipService();
  final PlanChangeService _planChangeService = PlanChangeService();
  final PlanService _planService = PlanService();
  final UserService _userService = UserService();
  final MemberCardService _memberCardService = MemberCardService();
  final SubscriptionService _subscriptionService = SubscriptionService();

  bool loading = true;
  String? error;

  int? userId;
  int? currentPlanId;
  int? selectionId;
  bool editable = false;
  bool cardReady = false;

  String cycleStatus = "";
  String cycleStatusLabel = "";
  String defaultRule = "";

  Map<String, dynamic>? currentUser;
  Map<String, dynamic>? currentPlanData;
  Map<String, dynamic>? subscriptionStatus;

  List<dynamic> selectedProducts = [];
  List<dynamic> editableSections = [];
  List<dynamic> planRequests = [];

  final Map<String, String?> selectedProductsBySection = {};

  String? selectedNewPlanName;
  int? selectedNewPlanId;

  final Map<String, int> availablePlans = {
    "Nivel 1 - Cobre": 1,
    "Nivel 2 - Plata": 2,
    "Nivel 3 - Oro": 3,
  };

  @override
  void initState() {
    super.initState();
    loadData();
  }

  double _monthlyPriceByLevel(int level) {
    return MembershipRules.monthlyPrice(level);
  }

  double _firstPaymentByLevel(int level) {
    return _monthlyPriceByLevel(level);
  }

  String _money(double value) {
    return value == value.roundToDouble()
        ? value.toStringAsFixed(0)
        : value.toStringAsFixed(2);
  }

  String _normalize(String value) {
    return value
        .toLowerCase()
        .replaceAll("á", "a")
        .replaceAll("é", "e")
        .replaceAll("í", "i")
        .replaceAll("ó", "o")
        .replaceAll("ú", "u")
        .replaceAll("ü", "u")
        .replaceAll("ñ", "n")
        .replaceAll("’", "'")
        .trim();
  }

  String _productName(dynamic item) {
    if (item is Map<String, dynamic>) {
      return item["name"]?.toString() ?? "";
    }

    if (item is Map) {
      return item["name"]?.toString() ?? "";
    }

    return item.toString();
  }

  List<String> _sectionProductNames(dynamic rawProducts) {
    if (rawProducts is! List) return [];

    return rawProducts
        .map((e) => _productName(e))
        .where((name) => name.trim().isNotEmpty)
        .toList();
  }

  String _sectionType(dynamic section) {
    final key = _normalize(section["section_key"]?.toString() ?? "");
    final name = _normalize(section["section_name"]?.toString() ?? "");
    final category = _normalize(section["category"]?.toString() ?? "");

    final combined = "$key $name $category";

    if (combined.contains("extra") && combined.contains("bienestar")) {
      return "wellness_extra";
    }

    if (combined.contains("coloide") ||
        combined.contains("coloides") ||
        combined.contains("colloid")) {
      return "colloid";
    }

    if (combined.contains("hongo") ||
        combined.contains("hongos") ||
        combined.contains("mushroom") ||
        combined.contains("medicinal")) {
      return "mushroom";
    }

    if (combined.contains("soporte") ||
        combined.contains("functional") ||
        combined.contains("funcional") ||
        combined.contains("soporte_funcional")) {
      return "functional_support";
    }

    if (combined.contains("cbd")) {
      return "cbd";
    }

    if (combined.contains("bienestar") || combined.contains("wellness")) {
      return "wellness";
    }

    return "unknown";
  }

  String _friendlySectionName(dynamic section) {
    final type = _sectionType(section);

    switch (type) {
      case "colloid":
        return "Coloide a libre elección";
      case "cbd":
        return "Producto CBD a elección";
      case "wellness":
        return "Producto bienestar a elección";
      case "mushroom":
        return "Hongos medicinales";
      case "functional_support":
        return "Soporte funcional";
      case "wellness_extra":
        return "Producto extra bienestar";
      default:
        return section["section_name"]?.toString() ?? "Sección";
    }
  }

  bool _sectionAllowedForPlan(dynamic section) {
    final type = _sectionType(section);
    final level = currentPlanId ?? 0;

    if (level == 1) {
      return ["colloid", "cbd", "wellness"].contains(type);
    }

    if (level == 2) {
      return ["colloid", "mushroom", "cbd", "wellness"].contains(type);
    }

    if (level == 3) {
      return [
        "colloid",
        "cbd",
        "wellness",
        "functional_support",
        "wellness_extra",
      ].contains(type);
    }

    return true;
  }

  int _sectionOrder(dynamic section) {
    final type = _sectionType(section);
    final level = currentPlanId ?? 0;

    if (level == 1) {
      return {
            "colloid": 1,
            "cbd": 2,
            "wellness": 3,
          }[type] ??
          99;
    }

    if (level == 2) {
      return {
            "colloid": 1,
            "mushroom": 2,
            "cbd": 3,
            "wellness": 4,
          }[type] ??
          99;
    }

    if (level == 3) {
      return {
            "colloid": 1,
            "cbd": 2,
            "wellness": 3,
            "functional_support": 4,
            "wellness_extra": 5,
          }[type] ??
          99;
    }

    return 99;
  }

  List<String> _orderedFilteredProductsForSection(dynamic section) {
    final rawProducts = _sectionProductNames(section["products"] ?? []);

    final cleanProducts =
        rawProducts.where((name) => name.trim().isNotEmpty).toSet().toList();

    cleanProducts.sort();

    return cleanProducts;
  }

  Future<void> _ensureMemberCard(int parsedUserId) async {
    final existingCard = await _memberCardService.getMemberCardByUser(
      parsedUserId,
    );

    if (existingCard['statusCode'] == 200) {
      cardReady = true;
      return;
    }

    final generatedCard = await _memberCardService.generateMemberCard(
      parsedUserId,
    );

    cardReady = generatedCard['statusCode'] == 200 ||
        generatedCard['statusCode'] == 201;
  }

  Future<Map<String, dynamic>> _loadOrInitSelection(int parsedUserId) async {
    final selectionResponse =
        await _membershipService.getSelection(parsedUserId);

    if (selectionResponse["statusCode"] == 200) {
      return selectionResponse;
    }

    final initResponse = await _membershipService.initSelection(parsedUserId);

    if (initResponse["statusCode"] == 200 ||
        initResponse["statusCode"] == 201) {
      return initResponse;
    }

    return selectionResponse;
  }

  Future<void> loadData() async {
    setState(() {
      loading = true;
      error = null;
    });

    try {
      final me = await _userService.getMe();

      if (!mounted) return;

      if (me == null) {
        setState(() {
          error = "No se pudo obtener el usuario actual";
          loading = false;
        });
        return;
      }

      final int parsedUserId = int.tryParse((me["id"] ?? 0).toString()) ?? 0;
      final int parsedPlanId =
          int.tryParse((me["membership_level"] ?? 0).toString()) ?? 0;

      if (parsedUserId == 0 || parsedPlanId == 0) {
        setState(() {
          error = "Datos de usuario inválidos";
          loading = false;
        });
        return;
      }

      await _ensureMemberCard(parsedUserId);

      if (!mounted) return;

      final selectionResponse = await _loadOrInitSelection(parsedUserId);
      final selection = selectionResponse["data"] ?? {};

      final requests =
          await _planChangeService.getPlanChangeRequests(parsedUserId);

      final planData = await _planService.getPlanOptions(parsedPlanId);

      final subscriptionResult =
          await _subscriptionService.getSubscriptionStatus(
        userId: parsedUserId,
      );

      final List<dynamic> loadedSelectedProducts =
          selection["products"] ?? selection["editable_products"] ?? [];

      final List<dynamic> loadedSections = selection["editable_sections"] ?? [];

      selectedProductsBySection.clear();

      for (final section in loadedSections) {
        final sectionKey = section["section_key"]?.toString() ?? "";
        final List<String> options =
            _orderedFilteredProductsForSection(section);

        String? selected;

        for (final product in loadedSelectedProducts) {
          final productName = _productName(product);

          if (productName.isNotEmpty && options.contains(productName)) {
            selected = productName;
            break;
          }
        }

        selectedProductsBySection[sectionKey] = selected;
      }

      if (!mounted) return;

      setState(() {
        currentUser = me;
        userId = parsedUserId;
        currentPlanId = parsedPlanId;

        selectionId = int.tryParse(
          (selection["selection_id"] ?? selection["id"] ?? 0).toString(),
        );

        editable = selection["editable"] ?? false;
        cycleStatus = selection["cycle_status"] ?? "";
        cycleStatusLabel = selection["cycle_status_label"] ?? "";
        defaultRule = selection["default_rule"]?.toString() ??
            selection["next_selection_rule"]?.toString() ??
            "Si no cambias productos, el sistema repetirá automáticamente tu última selección confirmada.";

        selectedProducts = loadedSelectedProducts;
        editableSections = loadedSections;
        planRequests = requests;
        currentPlanData = planData;

        subscriptionStatus = subscriptionResult["statusCode"] == 200
            ? subscriptionResult["data"]
            : null;

        error = selectionResponse["statusCode"] == 200 ||
                selectionResponse["statusCode"] == 201
            ? null
            : selectionResponse["data"]?["detail"] ??
                "No se pudo cargar la selección mensual.";

        loading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        error = "Error cargando datos: $e";
        loading = false;
      });
    }
  }

  Future<void> saveSelection() async {
    if (selectionId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("No se pudo identificar la selección")),
      );
      return;
    }

    if (!editable) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("No puedes editar en este momento")),
      );
      return;
    }

    final List<String> selectedNames = [];

    final visibleSections = editableSections
        .where((section) => _sectionAllowedForPlan(section))
        .where(
            (section) => _orderedFilteredProductsForSection(section).isNotEmpty)
        .toList()
      ..sort((a, b) => _sectionOrder(a).compareTo(_sectionOrder(b)));

    for (final section in visibleSections) {
      final key = section["section_key"]?.toString() ?? "";
      final sectionName = _friendlySectionName(section);
      final selected = selectedProductsBySection[key];

      if (selected == null || selected.trim().isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Selecciona un producto en $sectionName")),
        );
        return;
      }

      selectedNames.add(selected.trim());
    }

    final res = await _membershipService.saveSelectionItems(
      selectionId!,
      selectedNames,
    );

    if (!mounted) return;

    final data = res["data"] ?? {};

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(data["message"] ?? "Selección guardada")),
    );

    loadData();
  }

  Future<void> requestPlanChange() async {
    if (userId == null || selectedNewPlanId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Selecciona un nuevo plan")),
      );
      return;
    }

    final res = await _planChangeService.requestPlanChange(
      userId: userId!,
      requestedPlanId: selectedNewPlanId!,
    );

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(res["message"] ?? "Solicitud enviada")),
    );

    loadData();
  }

  Color _statusColor() {
    switch (cycleStatus) {
      case "editable":
        return Colors.green;
      case "admin_review":
        return Colors.orange;
      case "weekly_shipping":
        return Colors.blue;
      default:
        return Colors.grey;
    }
  }

  Color _planColor(int level) {
    switch (level) {
      case 1:
        return const Color(0xFFB87333);
      case 2:
        return const Color(0xFFC0C0C0);
      case 3:
        return const Color(0xFFD4AF37);
      default:
        return Colors.blueGrey;
    }
  }

  String _friendlyCycleStatus() {
    if (cycleStatusLabel.isNotEmpty) return cycleStatusLabel;

    switch (cycleStatus) {
      case "editable":
        return "Productos editables disponibles";
      case "admin_review":
        return "Revisión administrativa de pagos y suscripciones";
      case "weekly_shipping":
        return "Despacho semanal de logística";
      default:
        return "Productos editables disponibles";
    }
  }

  String _friendlySubscriptionStatus() {
    final status = subscriptionStatus?["subscription_status"]?.toString() ?? "";

    switch (status) {
      case "ACTIVE":
        return "Activa";
      case "APPROVAL_PENDING":
        return "Pendiente de aprobación";
      case "SUSPENDED":
        return "Suspendida";
      case "CANCELLED":
        return "Cancelada";
      case "EXPIRED":
        return "Expirada";
      case "NONE":
        return "Sin suscripción";
      default:
        return status.isEmpty ? "Sin información" : status;
    }
  }

  String _friendlyLocalSubscriptionStatus() {
    final status =
        subscriptionStatus?["local_payment_status"]?.toString() ?? "";

    switch (status) {
      case "subscription_created":
        return "Suscripción creada / pendiente";
      case "subscription_active":
        return "Suscripción activa";
      case "subscription_paid":
        return "Mensualidad pagada";
      case "subscription_inactive":
        return "Suscripción inactiva";
      case "NONE":
        return "Sin suscripción registrada";
      default:
        return status.isEmpty ? "Sin información local" : status;
    }
  }

  String _formatBillingDate() {
    final raw = subscriptionStatus?["next_billing_time"];

    if (raw == null || raw.toString().isEmpty) return "No disponible";

    try {
      final date = DateTime.parse(raw.toString()).toLocal();
      final day = date.day.toString().padLeft(2, "0");
      final month = date.month.toString().padLeft(2, "0");
      final year = date.year.toString();
      return "$day/$month/$year";
    } catch (_) {
      return raw.toString();
    }
  }

  String _levelName(int level) {
    switch (level) {
      case 1:
        return "Nivel 1 - Cobre";
      case 2:
        return "Nivel 2 - Plata";
      case 3:
        return "Nivel 3 - Oro";
      default:
        return "Sin nivel";
    }
  }

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12, top: 24),
      child: Text(
        title,
        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _card({required Widget child, Color? borderColor}) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.88),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderColor ?? Colors.black12, width: 1.5),
      ),
      child: child,
    );
  }

  Widget _membershipStatusCard(int planLevel) {
    final bool membershipActive =
        subscriptionStatus?["membership_active"] == true ||
            currentUser?["membership_active"] == true;

    final monthly = _monthlyPriceByLevel(planLevel);

    return _card(
      borderColor: membershipActive ? Colors.green : Colors.red,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            membershipActive ? "Socio activo" : "Socio inactivo",
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: membershipActive ? Colors.green.shade800 : Colors.red,
            ),
          ),
          const SizedBox(height: 10),
          Text("Estado PayPal: ${_friendlySubscriptionStatus()}"),
          const SizedBox(height: 6),
          Text("Estado interno: ${_friendlyLocalSubscriptionStatus()}"),
          const SizedBox(height: 6),
          Text("Próximo cobro: ${_formatBillingDate()}"),
          const SizedBox(height: 6),
          Text("Nivel actual: ${_levelName(planLevel)}"),
          if (monthly > 0) ...[
            const SizedBox(height: 6),
            Text("Mensualidad recurrente: \$${_money(monthly)} USD"),
          ],
        ],
      ),
    );
  }

  Widget _membershipCardPreview() {
    if (userId == null || !cardReady) {
      return _card(
        child: const Text("No se pudo cargar la tarjeta digital."),
      );
    }

    final String imageUrl =
        '${_memberCardService.getCardImageUrl(userId!)}?v=${DateTime.now().millisecondsSinceEpoch}';

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 10),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Image.network(
          imageUrl,
          fit: BoxFit.contain,
          errorBuilder: (context, error, stackTrace) {
            return _card(
              child: const Text("No se pudo cargar la tarjeta digital."),
            );
          },
        ),
      ),
    );
  }

  Widget _walletButtons() {
    if (userId == null) return const SizedBox.shrink();

    final String name = (currentUser?["name"] ?? "Socio Mayu").toString();

    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            "Wallet / Tarjeta digital",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => WalletCardScreen(
                    userId: userId!,
                    userName: name,
                  ),
                ),
              );
            },
            icon: const Icon(Icons.account_balance_wallet),
            label: const Text("Abrir Wallet Mayu"),
          ),
        ],
      ),
    );
  }

  Widget _benefitsCard() {
    return _card(
      borderColor: Colors.teal,
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Beneficios del socio activo",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 12),
          Text("• 15% de descuento en consultas"),
          Text("• 15% de descuento en terapias"),
          Text("• 10% de descuento en Farmacia Magistral Mayu"),
          Text("• Acceso gratuito a Mayu Educación"),
        ],
      ),
    );
  }

  Widget _selectedProductsCard() {
    if (selectedProducts.isEmpty) {
      return _card(
        borderColor: Colors.orange,
        child: Text(
          defaultRule.isNotEmpty
              ? defaultRule
              : "Si no seleccionas nuevos productos, el sistema repetirá automáticamente tu última selección confirmada.",
          style: const TextStyle(fontSize: 15),
        ),
      );
    }

    return _card(
      borderColor: Colors.green,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Productos seleccionados para este ciclo",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 14),
          ...selectedProducts.map((p) {
            final name = _productName(p);

            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                children: [
                  const Icon(Icons.check_circle, size: 20, color: Colors.green),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      name,
                      style: const TextStyle(fontSize: 16),
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _editableSectionsCard() {
    final visibleSections = editableSections
        .where((section) => _sectionAllowedForPlan(section))
        .where(
            (section) => _orderedFilteredProductsForSection(section).isNotEmpty)
        .toList()
      ..sort((a, b) => _sectionOrder(a).compareTo(_sectionOrder(b)));

    if (visibleSections.isEmpty) {
      return _card(
        child: const Text(
          "No se encontraron secciones editables para este plan.",
        ),
      );
    }

    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Puedes cambiar tus productos editables mientras la orden aún no fue liberada a logística.",
            style: TextStyle(fontSize: 15),
          ),
          const SizedBox(height: 16),
          ...visibleSections.map((section) {
            final String key = section["section_key"]?.toString() ?? "";
            final String name = _friendlySectionName(section);

            final List<String> products =
                _orderedFilteredProductsForSection(section);

            final String? currentValue =
                products.contains(selectedProductsBySection[key])
                    ? selectedProductsBySection[key]
                    : null;

            return Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: DropdownButtonFormField<String>(
                initialValue: currentValue,
                isExpanded: true,
                decoration: InputDecoration(
                  labelText: name,
                  border: const OutlineInputBorder(),
                ),
                items: products.map((productName) {
                  return DropdownMenuItem<String>(
                    value: productName,
                    child: Text(
                      productName,
                      overflow: TextOverflow.ellipsis,
                    ),
                  );
                }).toList(),
                onChanged: editable
                    ? (value) {
                        setState(() {
                          selectedProductsBySection[key] = value;
                        });
                      }
                    : null,
              ),
            );
          }),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: editable ? saveSelection : null,
              child: const Text("Guardar selección mensual"),
            ),
          ),
        ],
      ),
    );
  }

  Widget _selectedNewPlanInfo() {
    if (selectedNewPlanId == null) {
      return const SizedBox.shrink();
    }

    final monthly = _monthlyPriceByLevel(selectedNewPlanId!);
    final firstPayment = _firstPaymentByLevel(selectedNewPlanId!);

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.teal.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.teal.withValues(alpha: 0.30)),
      ),
      child: Text(
        "Nuevo plan: ${_levelName(selectedNewPlanId!)}\n"
        "Mensualidad recurrente: \$${_money(monthly)} USD\n"
        "Primer pago referencial para nuevos socios: \$${_money(firstPayment)} USD",
        style: const TextStyle(fontSize: 15, height: 1.35),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final plan = currentPlanData?["plan"];
    final planName = plan?["name"] ?? "Mi plan";
    final planLevel = plan?["level"] ?? currentPlanId ?? 0;
    final monthly = _monthlyPriceByLevel(planLevel);
    final firstPayment = _firstPaymentByLevel(planLevel);

    return MayuScaffold(
      appBar: AppBar(
        title: const Text("Mi membresía"),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: loadData,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      child: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null && selectionId == null
              ? Center(child: Text(error!))
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (error != null)
                        _card(
                          borderColor: Colors.orange,
                          child: Text(
                            error!,
                            style: const TextStyle(color: Colors.orange),
                          ),
                        ),
                      _sectionTitle("Estado de membresía"),
                      _membershipStatusCard(planLevel),
                      _benefitsCard(),
                      _sectionTitle("Tu tarjeta digital"),
                      _membershipCardPreview(),
                      _walletButtons(),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    const MembershipHistoryScreen(),
                              ),
                            );
                          },
                          child: const Text("Ver historial de entregas"),
                        ),
                      ),
                      _sectionTitle("Mi plan actual"),
                      _card(
                        borderColor: _planColor(planLevel),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              planName,
                              style: TextStyle(
                                fontSize: 28,
                                fontWeight: FontWeight.bold,
                                color: _planColor(planLevel),
                              ),
                            ),
                            const SizedBox(height: 8),
                            if (monthly > 0) ...[
                              Text("Mensualidad: \$${_money(monthly)} USD"),
                              Text(
                                "Primer pago para nuevo socio: \$${_money(firstPayment)} USD",
                              ),
                              const Text("Sin cuota de inscripción."),
                              const Text(
                                MembershipRules.recurringDebitDisclosure,
                              ),
                              const SizedBox(height: 8),
                            ],
                            Text(
                              "Estado operativo: ${_friendlyCycleStatus()}",
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: _statusColor(),
                              ),
                            ),
                            const SizedBox(height: 6),
                            const Text(
                              "Todos los productos del plan son editables por mes.",
                            ),
                            const Text(
                                "Revisión administrativa: lunes a jueves"),
                            const Text("Despachos semanales: viernes"),
                          ],
                        ),
                      ),
                      _sectionTitle("Productos seleccionados"),
                      _selectedProductsCard(),
                      _sectionTitle("Cambiar productos del mes"),
                      _editableSectionsCard(),
                      _sectionTitle("Actualizar plan"),
                      _card(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            DropdownButtonFormField<String>(
                              initialValue: selectedNewPlanName,
                              decoration: const InputDecoration(
                                labelText: "Selecciona tu nuevo plan",
                                border: OutlineInputBorder(),
                              ),
                              items: availablePlans.keys.map((planName) {
                                return DropdownMenuItem<String>(
                                  value: planName,
                                  child: Text(planName),
                                );
                              }).toList(),
                              onChanged: (value) {
                                setState(() {
                                  selectedNewPlanName = value;
                                  selectedNewPlanId = availablePlans[value];
                                });
                              },
                            ),
                            _selectedNewPlanInfo(),
                            const SizedBox(height: 12),
                            const Text(
                              "El cambio se aplicará al próximo ciclo operativo.",
                            ),
                            const SizedBox(height: 16),
                            SizedBox(
                              width: double.infinity,
                              child: OutlinedButton(
                                onPressed: requestPlanChange,
                                child: const Text("Solicitar cambio de plan"),
                              ),
                            ),
                          ],
                        ),
                      ),
                      _sectionTitle("Solicitudes de cambio"),
                      if (planRequests.isEmpty)
                        _card(
                          child: const Text(
                            "No hay solicitudes de cambio registradas.",
                          ),
                        )
                      else
                        ...planRequests.map(
                          (req) => _card(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "${req["current_plan"]} → ${req["requested_plan"]}",
                                  style: const TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text("Estado: ${req["status"]}"),
                                Text(
                                  "Aplicación: ${req["effective_month"]}/${req["effective_year"]}",
                                ),
                              ],
                            ),
                          ),
                        ),
                      const SizedBox(height: 24),
                    ],
                  ),
                ),
    );
  }
}
