import 'package:flutter/material.dart';
import 'home_screen.dart';

class DigitalCardScreen extends StatelessWidget {
  final int userId;
  final String name;
  final String planName;

  const DigitalCardScreen({
    super.key,
    required this.userId,
    required this.name,
    required this.planName,
  });

  @override
  Widget build(BuildContext context) {
    const String baseUrl = 'https://mayu-wellness-backend-v1.onrender.com';
    final String imageUrl = '$baseUrl/member-cards/user/$userId/image';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mi tarjeta digital'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  const Text(
                    'Tu membresía está activa',
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    '$name · $planName',
                    style: const TextStyle(fontSize: 18),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Image.network(
                      imageUrl,
                      fit: BoxFit.contain,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.45),
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(color: Colors.black12),
                          ),
                          child: const Text(
                            'No se pudo cargar la tarjeta digital',
                            style: TextStyle(fontSize: 18),
                            textAlign: TextAlign.center,
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const HomeScreen(),
                          ),
                          (route) => false,
                        );
                      },
                      child: const Text('Ir al inicio'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}