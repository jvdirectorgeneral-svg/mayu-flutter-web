import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/api_config.dart';
import '../services/auth_service.dart';
import '../services/education_service.dart';
import '../widgets/mayu_scaffold.dart';

class MayuEducationScreen extends StatefulWidget {
  const MayuEducationScreen({super.key});

  @override
  State<MayuEducationScreen> createState() => _MayuEducationScreenState();
}

class _MayuEducationScreenState extends State<MayuEducationScreen> {
  final EducationService _service = EducationService();
  final AuthService _authService = AuthService();

  bool _loading = true;
  String? _error;

  List<dynamic> _categories = [];
  List<dynamic> _resources = [];

  String _search = '';
  int _selectedCategoryId = 0;

  @override
  void initState() {
    super.initState();
    _loadEducation();
  }

  Future<void> _loadEducation() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final categoriesResult = await _service.getPublicCategories();
    final resourcesResult = await _service.getPublicResources(
      categoryId: _selectedCategoryId,
      search: _search,
    );

    if (!mounted) return;

    if (categoriesResult['statusCode'] == 200 &&
        resourcesResult['statusCode'] == 200) {
      final categoriesData = categoriesResult['data'];
      final resourcesData = resourcesResult['data'];

      setState(() {
        _categories = categoriesData is Map && categoriesData['items'] is List
            ? categoriesData['items']
            : [];

        _resources = resourcesData is Map && resourcesData['items'] is List
            ? resourcesData['items']
            : [];

        _loading = false;
      });
    } else {
      setState(() {
        _loading = false;
        _error = categoriesResult['data']?['detail']?.toString() ??
            resourcesResult['data']?['detail']?.toString() ??
            'No se pudo cargar Mayu Educación';
      });
    }
  }

  List<dynamic> get _filteredResources {
    return _resources.where((item) {
      final resource = Map<String, dynamic>.from(item);

      final title = (resource['title'] ?? '').toString().toLowerCase();
      final description =
          (resource['description'] ?? '').toString().toLowerCase();
      final content = (resource['content_text'] ?? '').toString().toLowerCase();
      final plantName =
          (resource['plant_common_name'] ?? '').toString().toLowerCase();

      final categoryId =
          int.tryParse((resource['category_id'] ?? 0).toString()) ?? 0;

      final search = _search.toLowerCase();

      final matchesSearch = title.contains(search) ||
          description.contains(search) ||
          content.contains(search) ||
          plantName.contains(search);

      final matchesCategory =
          _selectedCategoryId == 0 || categoryId == _selectedCategoryId;

      return matchesSearch && matchesCategory;
    }).toList();
  }

  String _typeLabel(String type) {
    switch (type) {
      case 'pdf':
        return 'PDF';
      case 'video':
        return 'Video';
      case 'link':
        return 'Link';
      case 'image':
        return 'Imagen';
      case 'document':
        return 'Documento';
      case 'plant_card':
        return 'Ficha de planta';
      case 'plant_registry':
        return 'Registro de planta';
      default:
        return 'Contenido';
    }
  }

  IconData _typeIcon(String type) {
    switch (type) {
      case 'video':
        return Icons.play_circle;
      case 'link':
        return Icons.link;
      case 'image':
        return Icons.image;
      case 'document':
        return Icons.description;
      case 'plant_card':
      case 'plant_registry':
        return Icons.eco;
      case 'pdf':
      default:
        return Icons.picture_as_pdf;
    }
  }

  Future<String> _buildProtectedViewUrl(String? protectedPath) async {
    final rawPath = (protectedPath ?? '').trim();

    if (rawPath.isEmpty) return '';

    final headers = await _authService.getAuthHeaders();
    final auth = headers['Authorization'] ?? headers['authorization'] ?? '';
    final token = auth.replaceFirst('Bearer ', '').trim();

    if (token.isEmpty) return '';

    final encodedToken = Uri.encodeComponent(token);

    if (rawPath.startsWith('http://') || rawPath.startsWith('https://')) {
      final separator = rawPath.contains('?') ? '&' : '?';
      return '$rawPath${separator}token=$encodedToken';
    }

    return '${ApiConfig.baseUrl}$rawPath?token=$encodedToken';
  }

  Future<void> _openUrl(String url) async {
    final cleanUrl = url.trim();

    if (cleanUrl.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No hay enlace disponible')),
      );
      return;
    }

    final uri = Uri.tryParse(cleanUrl);

    if (uri == null || !uri.hasScheme) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enlace inválido')),
      );
      return;
    }

    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Future<void> _openProtectedContent(Map<String, dynamic> resource) async {
    final secureUrl = await _buildProtectedViewUrl(
      resource['protected_view_url']?.toString(),
    );

    if (!mounted) return;

    if (secureUrl.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No se pudo generar el acceso protegido'),
        ),
      );
      return;
    }

    await _openUrl(secureUrl);
  }

  void _openResourceDetail(Map<String, dynamic> resource) {
    final protectedViewUrl =
        (resource['protected_view_url'] ?? '').toString().trim();
    final externalUrl = (resource['external_url'] ?? '').toString();
    final coverUrl = (resource['cover_image_url'] ?? '').toString();
    final type = (resource['resource_type'] ?? '').toString();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) {
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.82,
          maxChildSize: 0.94,
          minChildSize: 0.45,
          builder: (context, scrollController) {
            return SingleChildScrollView(
              controller: scrollController,
              padding: const EdgeInsets.all(22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    resource['title']?.toString() ?? 'Contenido Mayu',
                    style: const TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${resource['category_name'] ?? 'Sin categoría'} • ${_typeLabel(type)}',
                    style: const TextStyle(color: Colors.teal),
                  ),
                  const SizedBox(height: 16),
                  if (coverUrl.isNotEmpty)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: Image.network(
                        coverUrl,
                        height: 210,
                        width: double.infinity,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => _placeholder(),
                      ),
                    )
                  else
                    _placeholder(),
                  const SizedBox(height: 18),
                  _section('Descripción', resource['description']),
                  _section('Contenido educativo', resource['content_text']),
                  _section('Nombre común', resource['plant_common_name']),
                  _section('Nombre científico', resource['plant_scientific_name']),
                  _section('Familia botánica', resource['plant_family']),
                  _section('Origen', resource['plant_origin']),
                  _section('Partes usadas', resource['plant_parts_used']),
                  _section('Usos y aplicaciones', resource['plant_uses']),
                  _section('Preparación', resource['plant_preparation']),
                  _section('Advertencias', resource['plant_warnings']),
                  const SizedBox(height: 22),
                  if (protectedViewUrl.isNotEmpty)
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: ElevatedButton.icon(
                        onPressed: () => _openProtectedContent(resource),
                        icon: Icon(_typeIcon(type)),
                        label: const Text('Ver contenido protegido'),
                      ),
                    ),
                  if (externalUrl.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: OutlinedButton.icon(
                        onPressed: () => _openUrl(externalUrl),
                        icon: const Icon(Icons.open_in_new),
                        label: const Text('Abrir enlace externo'),
                      ),
                    ),
                  ],
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _section(String title, dynamic value) {
    final text = (value ?? '').toString().trim();

    if (text.isEmpty) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            text,
            style: const TextStyle(fontSize: 15, height: 1.45),
          ),
        ],
      ),
    );
  }

  Widget _placeholder() {
    return Container(
      height: 170,
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.teal.withOpacity(0.08),
        borderRadius: BorderRadius.circular(18),
      ),
      child: const Center(
        child: Icon(
          Icons.school,
          size: 64,
          color: Colors.teal,
        ),
      ),
    );
  }

  Widget _smallPlaceholder(String type) {
    return Container(
      width: 76,
      height: 76,
      color: Colors.teal.withOpacity(0.10),
      child: Icon(
        _typeIcon(type),
        color: Colors.teal,
      ),
    );
  }

  Widget _resourceCard(Map<String, dynamic> resource) {
    final type = (resource['resource_type'] ?? '').toString();
    final coverUrl = (resource['cover_image_url'] ?? '').toString();

    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () => _openResourceDetail(resource),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.black12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: coverUrl.isNotEmpty
                  ? Image.network(
                      coverUrl,
                      width: 76,
                      height: 76,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => _smallPlaceholder(type),
                    )
                  : _smallPlaceholder(type),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    resource['title']?.toString() ?? 'Contenido Mayu',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${resource['category_name'] ?? 'Sin categoría'} • ${_typeLabel(type)}',
                    style: const TextStyle(color: Colors.teal, fontSize: 13),
                  ),
                  if ((resource['description'] ?? '').toString().isNotEmpty)
                    Text(
                      resource['description'].toString(),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final resources = _filteredResources;

    return MayuScaffold(
      appBar: AppBar(
        title: const Text('Mayu Educación'),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: _loadEducation,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      child: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Text(
                    _error!,
                    style: const TextStyle(color: Colors.red),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadEducation,
                  child: ListView(
                    padding: const EdgeInsets.all(18),
                    children: [
                      const Text(
                        'Mayu Educación',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Biblioteca educativa para socios activos: plantas medicinales, fitoterapia, PDFs, videos, fichas y registros de plantas.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 15, height: 1.4),
                      ),
                      const SizedBox(height: 22),
                      TextField(
                        decoration: InputDecoration(
                          hintText: 'Buscar contenido o planta',
                          prefixIcon: const Icon(Icons.search),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(18),
                            borderSide: BorderSide.none,
                          ),
                        ),
                        onChanged: (value) {
                          setState(() {
                            _search = value;
                          });
                        },
                        onSubmitted: (_) => _loadEducation(),
                      ),
                      const SizedBox(height: 14),
                      SizedBox(
                        height: 44,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: _categories.length + 1,
                          separatorBuilder: (_, __) => const SizedBox(width: 8),
                          itemBuilder: (context, index) {
                            if (index == 0) {
                              return ChoiceChip(
                                label: const Text('Todas'),
                                selected: _selectedCategoryId == 0,
                                onSelected: (_) {
                                  setState(() {
                                    _selectedCategoryId = 0;
                                  });
                                  _loadEducation();
                                },
                              );
                            }

                            final category = Map<String, dynamic>.from(
                              _categories[index - 1],
                            );

                            final id =
                                int.tryParse(category['id'].toString()) ?? 0;

                            return ChoiceChip(
                              label: Text(category['name'] ?? 'Categoría'),
                              selected: _selectedCategoryId == id,
                              onSelected: (_) {
                                setState(() {
                                  _selectedCategoryId = id;
                                });
                                _loadEducation();
                              },
                            );
                          },
                        ),
                      ),
                      const SizedBox(height: 22),
                      if (resources.isEmpty)
                        const Center(
                          child: Padding(
                            padding: EdgeInsets.all(30),
                            child: Text('No hay contenidos disponibles.'),
                          ),
                        )
                      else
                        ...resources.map(
                          (item) => Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: _resourceCard(
                              Map<String, dynamic>.from(item),
                            ),
                          ),
                        ),
                      const SizedBox(height: 80),
                    ],
                  ),
                ),
    );
  }
}