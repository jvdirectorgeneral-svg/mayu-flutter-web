import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../services/subscription_service.dart';

class MembershipPaymentScreen extends StatefulWidget {
  final int userId;
  final int level;

  const MembershipPaymentScreen({
    super.key,
    required this.userId,
    required this.level,
  });

  @override
  State<MembershipPaymentScreen> createState() =>
      _MembershipPaymentScreenState();
}

class _MembershipPaymentScreenState extends State<MembershipPaymentScreen> {
  final SubscriptionService _service = SubscriptionService();

  bool _loading = false;

  String getPlanName() {
    switch (widget.level) {
      case 1:
        return "Nivel 1 - Cobre";
      case 2:
        return "Nivel 2 - Plata";
      case 3:
        return "Nivel 3 - Oro";
      default:
        return "";
    }
  }

  String getInscriptionPrice() {
    switch (widget.level) {
      case 1:
        return "\$45.50";
      case 2:
        return "\$55";
      case 3:
        return "\$67";
      default:
        return "";
    }
  }

  String getMonthlyPrice() {
    switch (widget.level) {
      case 1:
        return "\$38.50";
      case 2:
        return "\$48";
      case 3:
        return "\$60";
      default:
        return "";
    }
  }

  String _extractError(dynamic data) {
    if (data is Map && data['detail'] != null) {
      return data['detail'].toString();
    }

    if (data is Map && data['message'] != null) {
      return data['message'].toString();
    }

    return 'Error creando suscripción';
  }

  Future<void> startSubscription() async {
    setState(() => _loading = true);

    final result = await _service.createSubscription(
      userId: widget.userId,
      planLevel: widget.level,
    );

    if (!mounted) return;

    setState(() => _loading = false);

    if (result['statusCode'] == 200 || result['statusCode'] == 201) {
      final data = result['data'];

      final String url = (
        data?['approve_url'] ??
        data?['approval_url'] ??
        ''
      ).toString();

      if (url.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('PayPal no devolvió el enlace de aprobación'),
          ),
        );
        return;
      }

      final uri = Uri.tryParse(url);

      if (uri == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('El enlace de PayPal no es válido'),
          ),
        );
        return;
      }

      final opened = await launchUrl(
        uri,
        mode: LaunchMode.externalApplication,
      );

      if (!opened && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('No se pudo abrir PayPal'),
          ),
        );
      }

      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_extractError(result['data'])),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Activar Membresía"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 20),
            Text(
              getPlanName(),
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            Card(
              child: ListTile(
                title: const Text("Pago inicial"),
                subtitle: const Text("Incluye activación + tarjeta"),
                trailing: Text(getInscriptionPrice()),
              ),
            ),
            Card(
              child: ListTile(
                title: const Text("Mensualidad automática"),
                subtitle: const Text("Se debita cada mes"),
                trailing: Text(getMonthlyPrice()),
              ),
            ),
            const SizedBox(height: 40),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _loading ? null : startSubscription,
                child: _loading
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Text("Activar mensualidad automática"),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              "Al continuar aceptas el débito automático mensual.",
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}