import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/membership_rules.dart';
import '../services/nuvei_tokenization_bridge.dart';
import '../services/subscription_service.dart';

class MembershipPaymentScreen extends StatefulWidget {
  final int userId;
  final int level;

  const MembershipPaymentScreen({
    super.key,
    required this.userId,
    required this.level,
  });

  @override
  State<MembershipPaymentScreen> createState() =>
      _MembershipPaymentScreenState();
}

class _MembershipPaymentScreenState extends State<MembershipPaymentScreen> {
  final SubscriptionService _service = SubscriptionService();
  bool _loading = false;
  bool _loadingNuvei = true;
  Map<String, dynamic>? _nuveiConfig;
  List<Map<String, dynamic>> _cards = [];
  String? _nextDebitDate;

  String getPlanName() => MembershipRules.planName(widget.level);
  String getMonthlyPrice() =>
      '\$${MembershipRules.money(MembershipRules.monthlyPrice(widget.level))}';

  @override
  void initState() {
    super.initState();
    _loadNuvei();
  }

  String _extractError(dynamic data) {
    if (data is Map && data['detail'] != null) {
      return data['detail'].toString();
    }
    if (data is Map && data['message'] != null) {
      return data['message'].toString();
    }
    return 'No se pudo completar la operación';
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _loadNuvei() async {
    final config = await _service.getNuveiClientConfig();
    final cards = await _service.listNuveiCards();
    if (!mounted) return;
    setState(() {
      _loadingNuvei = false;
      if (config['statusCode'] == 200 && config['data'] is Map) {
        _nuveiConfig = Map<String, dynamic>.from(config['data']);
      }
      if (cards['statusCode'] == 200 && cards['data'] is Map) {
        final data = Map<String, dynamic>.from(cards['data']);
        _cards = (data['items'] as List? ?? [])
            .whereType<Map>()
            .map((item) => Map<String, dynamic>.from(item))
            .where((item) => item['is_active'] == true)
            .toList();
        _nextDebitDate = data['next_debit_date']?.toString();
      }
    });
  }

  Future<void> _registerNuveiCard() async {
    final config = _nuveiConfig;
    if (config == null) {
      _message('Nuvei Sandbox todavía no está configurado en Render.');
      return;
    }
    setState(() => _loading = true);
    try {
      final card = await tokenizeNuveiCard(config);
      final result = await _service.registerNuveiToken(
        card: card,
        chargeInitial: true,
      );
      if (result['statusCode'] == 200 || result['statusCode'] == 201) {
        final debit = result['data']?['initial_debit'];
        _message(
          debit is Map && debit['success'] == true
              ? 'Tarjeta registrada y primer débito Nuvei aprobado.'
              : 'Tarjeta Nuvei registrada. Revisa el resultado del primer débito.',
        );
        await _loadNuvei();
      } else {
        _message(_extractError(result['data']));
      }
    } catch (error) {
      _message(error.toString().replaceFirst('Error: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _deleteCard(int id) async {
    setState(() => _loading = true);
    final result = await _service.deleteNuveiCard(id);
    if (result['statusCode'] == 200) {
      _message('Tarjeta eliminada correctamente.');
      await _loadNuvei();
    } else {
      _message(_extractError(result['data']));
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _startPaypal() async {
    setState(() => _loading = true);
    final result = await _service.createSubscription(
      userId: widget.userId,
      planLevel: widget.level,
    );
    if (!mounted) return;
    setState(() => _loading = false);
    final data = result['data'];
    if (result['statusCode'] == 200 || result['statusCode'] == 201) {
      final url = _service.getApproveUrl(
        data is Map ? Map<String, dynamic>.from(data) : null,
      );
      final uri = url == null ? null : Uri.tryParse(url);
      if (uri != null &&
          await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        return;
      }
      _message('PayPal no devolvió un enlace válido.');
      return;
    }
    _message(_extractError(data));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Activar Membresía')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            getPlanName(),
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          Card(
            child: ListTile(
              title: const Text('Primer cobro'),
              subtitle: const Text('Sin cuota de inscripción.'),
              trailing: Text(getMonthlyPrice()),
            ),
          ),
          Card(
            child: ListTile(
              title: const Text('Mensualidad automática'),
              subtitle: const Text('Débito automático mensual hasta cancelar.'),
              trailing: Text(getMonthlyPrice()),
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 12),
            child: Text(
              MembershipRules.recurringDebitDisclosure,
              textAlign: TextAlign.center,
            ),
          ),
          const Divider(),
          const Text(
            'Nuvei — Desarrollo / Certificación',
            style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          const Text(
            'La tarjeta se tokeniza directamente con Nuvei. MAYU no recibe ni almacena el número completo ni el código de seguridad.',
          ),
          if (_loadingNuvei)
            const Padding(
              padding: EdgeInsets.all(18),
              child: Center(child: CircularProgressIndicator()),
            )
          else ...[
            if (_cards.isNotEmpty)
              ..._cards.map(
                (card) => Card(
                  child: ListTile(
                    leading: const Icon(Icons.credit_card),
                    title: Text(
                      '${card['card_type'] ?? 'Tarjeta'} •••• ${card['last4'] ?? ''}',
                    ),
                    subtitle: Text(
                      card['is_default'] == true
                          ? 'Principal · próximo débito ${_nextDebitDate ?? 'por confirmar'}'
                          : 'Tarjeta Nuvei guardada',
                    ),
                    trailing: IconButton(
                      tooltip: 'Eliminar tarjeta',
                      onPressed: _loading
                          ? null
                          : () => _deleteCard(card['id'] as int),
                      icon: const Icon(Icons.delete_outline),
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: _loading ? null : _registerNuveiCard,
              icon: const Icon(Icons.add_card),
              label: Text(
                _cards.isEmpty
                    ? 'Registrar tarjeta y activar con Nuvei'
                    : 'Registrar otra tarjeta Nuvei',
              ),
            ),
          ],
          const SizedBox(height: 24),
          const Divider(),
          const Text(
            'PayPal — método actual',
            style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _loading ? null : _startPaypal,
            icon: const Icon(Icons.open_in_new),
            label: const Text('Continuar con PayPal'),
          ),
          const SizedBox(height: 14),
          const Text(
            'Nuvei permanecerá en Sandbox hasta completar las pruebas y la certificación exigida por Nuvei.',
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
