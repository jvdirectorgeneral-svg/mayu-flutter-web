import 'package:flutter/material.dart';
import '../core/membership_rules.dart';

class PlansScreen extends StatelessWidget {
  const PlansScreen({super.key});

  Widget _priceBox({
    required String title,
    required String value,
    required String note,
    required Color color,
  }) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            note,
            style: const TextStyle(fontSize: 13),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final plans = [
      {
        'name': 'Nivel 1 - Cobre',
        'monthly': '\$42 USD / mes',
        'items': [
          '1 coloide a libre elección',
          'CBD 874 mg',
          'Chocomedical',
        ],
      },
      {
        'name': 'Nivel 2 - Plata',
        'monthly': '\$52 USD / mes',
        'items': [
          '1 coloide a libre elección',
          'Melena de León',
          'CBD 874 mg',
          'Chocomedical',
        ],
      },
      {
        'name': 'Nivel 3 - Oro',
        'monthly': '\$62 USD / mes',
        'items': [
          '1 coloide a libre elección',
          'CBD 874 mg',
          'Té CBD',
          'Melena de León',
          'Magnesio Bisglicinato',
          'Chocomedical',
        ],
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Planes Mayu'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: ListView.builder(
          itemCount: plans.length,
          itemBuilder: (context, index) {
            final plan = plans[index];

            return Container(
              margin: const EdgeInsets.only(bottom: 18),
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.65),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.black12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    plan['name'] as String,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  _priceBox(
                    title: 'Primer cobro',
                    value: plan['monthly'] as String,
                    note: 'Sin cuota de inscripción. IVA 0%.',
                    color: Colors.teal,
                  ),
                  _priceBox(
                    title: 'Débito mensual del plan',
                    value: plan['monthly'] as String,
                    note: MembershipRules.recurringDebitDisclosure,
                    color: Colors.deepPurple,
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Incluye:',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 8),
                  ...(plan['items'] as List<String>).map(
                    (item) => Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            '• ',
                            style: TextStyle(fontSize: 18),
                          ),
                          Expanded(
                            child: Text(
                              item,
                              style: const TextStyle(fontSize: 17),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
