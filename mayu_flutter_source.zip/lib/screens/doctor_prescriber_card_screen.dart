import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/doctor_prescriber_service.dart';
import 'doctor_prescriber_register_screen.dart';

class DoctorPrescriberCardScreen extends StatefulWidget {
  const DoctorPrescriberCardScreen({super.key});

  @override
  State<DoctorPrescriberCardScreen> createState() =>
      _DoctorPrescriberCardScreenState();
}

class _DoctorPrescriberCardScreenState
    extends State<DoctorPrescriberCardScreen> {
  final DoctorPrescriberService _service = DoctorPrescriberService();
  bool _loading = true;
  bool _needsAuth = false;
  String? _error;
  Map<String, dynamic>? _doctor;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _needsAuth = false;
      _error = null;
    });
    final hasSession = await _service.hasDoctorSession();
    if (!mounted) return;
    if (!hasSession) {
      setState(() {
        _loading = false;
        _needsAuth = true;
      });
      return;
    }
    final result = await _service.getMyDoctorCard();
    if (!mounted) return;
    if (result['statusCode'] == 200) {
      setState(() {
        _doctor = Map<String, dynamic>.from(result['data']);
        _loading = false;
      });
    } else {
      await _service.logoutDoctor();
      setState(() {
        _loading = false;
        _needsAuth = true;
        _error = result['data']?['detail']?.toString();
      });
    }
  }

  Future<void> _openRegister() async {
    final ok = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => const DoctorPrescriberRegisterScreen()),
    );
    if (ok == true) await _load();
  }

  Future<void> _openRecover() async {
    final ok = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => const _DoctorRecoverScreen()),
    );
    if (ok == true) await _load();
  }

  Future<void> _logout() async {
    await _service.logoutDoctor();
    if (!mounted) return;
    setState(() {
      _doctor = null;
      _needsAuth = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final doctor = _doctor;
    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      appBar: AppBar(
        title: const Text('Doctor Prescriptor Mayu'),
        actions: [
          if (doctor != null)
            IconButton(
              tooltip: 'Cerrar sesión doctor',
              onPressed: _logout,
              icon: const Icon(Icons.logout),
            ),
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _needsAuth
              ? _DoctorGate(
                  onRegister: _openRegister,
                  onRecover: _openRecover,
                  error: _error,
                )
              : _DoctorCard(doctor: doctor ?? {}),
    );
  }
}

class _DoctorGate extends StatelessWidget {
  const _DoctorGate({
    required this.onRegister,
    required this.onRecover,
    this.error,
  });

  final VoidCallback onRegister;
  final VoidCallback onRecover;
  final String? error;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(22),
        child: Container(
          constraints: const BoxConstraints(maxWidth: 520),
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(22),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.08),
                blurRadius: 16,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.medical_services,
                  color: Color(0xFF00695C), size: 64),
              const SizedBox(height: 14),
              const Text(
                'Afiliación Doctor Prescriptor Mayu',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text(
                'Comisiona el 30% de ventas prescritas. Farmacia registra la venta y aquí ves tu avance.',
                textAlign: TextAlign.center,
              ),
              if (error != null) ...[
                const SizedBox(height: 12),
                Text(error!, style: const TextStyle(color: Colors.red)),
              ],
              const SizedBox(height: 22),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: onRegister,
                  icon: const Icon(Icons.badge),
                  label: const Text('Activar Doctor Prescriptor Mayu'),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: onRecover,
                  icon: const Icon(Icons.restore),
                  label: const Text('Recuperar tarjeta Doctor'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DoctorCard extends StatelessWidget {
  const _DoctorCard({required this.doctor});
  final Map<String, dynamic> doctor;

  @override
  Widget build(BuildContext context) {
    final commission = _asMoney(doctor['commission_balance']);
    final backgroundUrl = doctor['card_background_url']?.toString();
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF004D40), Color(0xFF26A69A)],
            ),
            image: backgroundUrl == null || backgroundUrl.isEmpty
                ? null
                : DecorationImage(
                    image: NetworkImage(backgroundUrl),
                    fit: BoxFit.cover,
                    colorFilter: ColorFilter.mode(
                      Colors.black.withValues(alpha: 0.35),
                      BlendMode.darken,
                    ),
                  ),
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'DOCTOR PRESCRIPTOR MAYU',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 20),
              ),
              const SizedBox(height: 20),
              Text(
                doctor['name']?.toString() ?? '',
                style: const TextStyle(color: Colors.white, fontSize: 19),
              ),
              Text(
                doctor['doctor_code']?.toString() ?? '',
                style: const TextStyle(color: Colors.white70),
              ),
              const SizedBox(height: 20),
              Text(
                '\$$commission',
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 34),
              ),
              const SizedBox(height: 8),
              const Text(
                'Comisión acumulada · 30% médico prescriptor',
                style: TextStyle(color: Colors.white70),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        _DoctorQrCard(doctor: doctor),
        Card(
          child: ListTile(
            leading: const Icon(Icons.account_balance),
            title: const Text('Cuenta bancaria'),
            subtitle: Text(
              '${doctor['bank_name'] ?? 'Banco'} · ${doctor['bank_account_type'] ?? ''} · ****${doctor['bank_account_last4'] ?? ''}',
            ),
          ),
        ),
        const SizedBox(height: 10),
        _DoctorWalletButtons(doctor: doctor),
      ],
    );
  }

  String _asMoney(dynamic value) {
    if (value is num) return value.toStringAsFixed(2);
    final parsed = double.tryParse(value?.toString() ?? '0') ?? 0;
    return parsed.toStringAsFixed(2);
  }
}

class _DoctorQrCard extends StatelessWidget {
  const _DoctorQrCard({required this.doctor});

  final Map<String, dynamic> doctor;

  @override
  Widget build(BuildContext context) {
    final code = doctor['doctor_code']?.toString() ?? '';
    final qrUrl = doctor['qr_image_url']?.toString() ?? '';

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              children: [
                const Icon(Icons.qr_code, color: Color(0xFF00695C)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Código para Farmacia',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text(code),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: const Color(0xFFE0E0E0)),
              ),
              child: qrUrl.isEmpty
                  ? const Text('QR no disponible todavía')
                  : Image.network(
                      qrUrl,
                      width: 210,
                      height: 210,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => const Padding(
                        padding: EdgeInsets.all(18),
                        child: Text('No se pudo cargar el QR'),
                      ),
                    ),
            ),
            const SizedBox(height: 10),
            Text(
              code,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFF00695C),
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DoctorWalletButtons extends StatelessWidget {
  const _DoctorWalletButtons({required this.doctor});
  final Map<String, dynamic> doctor;

  Future<void> _open(BuildContext context, String? url) async {
    if (url == null || url.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Link Wallet no disponible todavía')),
      );
      return;
    }
    final uri = Uri.tryParse(url);
    if (uri == null ||
        !await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No se pudo abrir Wallet')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final appleUrl = doctor['apple_wallet_url']?.toString();
    final googleUrl = doctor['google_wallet_url']?.toString();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        ElevatedButton.icon(
          onPressed: () => _open(context, appleUrl),
          icon: const Icon(Icons.wallet),
          label: const Text('Descargar Wallet iOS'),
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: () => _open(context, googleUrl),
          icon: const Icon(Icons.account_balance_wallet),
          label: const Text('Descargar Wallet Android'),
        ),
      ],
    );
  }
}

class _DoctorRecoverScreen extends StatefulWidget {
  const _DoctorRecoverScreen();

  @override
  State<_DoctorRecoverScreen> createState() => _DoctorRecoverScreenState();
}

class _DoctorRecoverScreenState extends State<_DoctorRecoverScreen> {
  final DoctorPrescriberService _service = DoctorPrescriberService();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  bool _loading = false;

  @override
  void dispose() {
    _emailController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _recover() async {
    final email = _emailController.text.trim();
    final phone = _phoneController.text.trim();
    if (email.isEmpty || phone.isEmpty) {
      _showMessage('Ingresa correo y teléfono');
      return;
    }
    setState(() => _loading = true);
    final result = await _service.recoverCard(email: email, phone: phone);
    if (!mounted) return;
    setState(() => _loading = false);
    if (result['statusCode'] == 200) {
      _showMessage(
          'Tarjeta Doctor recuperada. Revisa tu correo con el QR y los links.');
      Navigator.pop(context, true);
    } else {
      _showMessage(
        result['data']?['detail']?.toString() ??
            'No se pudo recuperar la tarjeta Doctor',
      );
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      appBar: AppBar(title: const Text('Recuperar tarjeta Doctor')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Recupera tu Doctor Prescriptor Mayu',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Usa el correo y teléfono con el que te afiliaste.',
                ),
                const SizedBox(height: 18),
                TextField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    labelText: 'Correo',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _phoneController,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(
                    labelText: 'Teléfono',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _loading ? null : _recover,
                    icon: const Icon(Icons.restore),
                    label:
                        Text(_loading ? 'Recuperando...' : 'Recuperar tarjeta'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
