import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';

import '../services/auth_service.dart';
import '../services/education_service.dart';
import 'login_screen.dart';

class EducationDashboardScreen extends StatefulWidget {
  const EducationDashboardScreen({super.key});

  @override
  State<EducationDashboardScreen> createState() =>
      _EducationDashboardScreenState();
}

class _EducationDashboardScreenState extends State<EducationDashboardScreen> {
  final EducationService _service = EducationService();
  final AuthService _authService = AuthService();

  bool _loading = true;
  String? _error;

  List<dynamic> _categories = [];
  List<dynamic> _resources = [];

  String _search = '';
  int _categoryFilter = 0;

  final List<Map<String, String>> _resourceTypes = const [
    {'value': 'pdf', 'label': 'PDF'},
    {'value': 'video', 'label': 'Video'},
    {'value': 'link', 'label': 'Link'},
    {'value': 'image', 'label': 'Imagen'},
    {'value': 'document', 'label': 'Documento'},
    {'value': 'plant_card', 'label': 'Ficha de planta'},
    {'value': 'plant_registry', 'label': 'Registro de planta y usos'},
  ];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  String _typeLabel(String value) {
    final found = _resourceTypes.where((t) => t['value'] == value).toList();
    return found.isEmpty ? value : found.first['label'] ?? value;
  }

  String _money(dynamic value) {
    final price = double.tryParse((value ?? 0).toString()) ?? 0;
    return price == price.roundToDouble()
        ? price.toStringAsFixed(0)
        : price.toStringAsFixed(2);
  }

  Future<void> _loadData() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final categoriesResult = await _service.getAdminCategories();
    final resourcesResult = await _service.getAdminResources();

    if (!mounted) return;

    if (categoriesResult['statusCode'] == 200 &&
        resourcesResult['statusCode'] == 200) {
      final categoriesData = categoriesResult['data'];
      final resourcesData = resourcesResult['data'];

      setState(() {
        _categories = categoriesData is Map && categoriesData['items'] is List
            ? categoriesData['items']
            : [];

        _resources = resourcesData is Map && resourcesData['items'] is List
            ? resourcesData['items']
            : [];

        _loading = false;
      });
    } else {
      setState(() {
        _loading = false;
        _error = categoriesResult['data']?['detail']?.toString() ??
            resourcesResult['data']?['detail']?.toString() ??
            'No se pudo cargar Mayu Educación';
      });
    }
  }

  List<dynamic> get _filteredResources {
    return _resources.where((item) {
      final resource = Map<String, dynamic>.from(item);

      final title = (resource['title'] ?? '').toString().toLowerCase();
      final description =
          (resource['description'] ?? '').toString().toLowerCase();
      final commonName =
          (resource['plant_common_name'] ?? '').toString().toLowerCase();

      final categoryId =
          int.tryParse((resource['category_id'] ?? 0).toString()) ?? 0;

      final search = _search.toLowerCase();

      final matchesSearch = title.contains(search) ||
          description.contains(search) ||
          commonName.contains(search);

      final matchesCategory =
          _categoryFilter == 0 || categoryId == _categoryFilter;

      return matchesSearch && matchesCategory;
    }).toList();
  }

  Future<void> _logout() async {
    await _authService.logout();

    if (!mounted) return;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  Future<Map<String, dynamic>?> _uploadAnyFile() async {
    final result = await FilePicker.platform.pickFiles(
      withData: true,
      type: FileType.custom,
      allowedExtensions: [
        'pdf',
        'doc',
        'docx',
        'png',
        'jpg',
        'jpeg',
        'webp',
        'mp4',
        'mov',
      ],
    );

    if (result == null || result.files.isEmpty) return null;

    final file = result.files.first;

    if (file.bytes == null) {
      if (!mounted) return null;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No se pudo leer el archivo')),
      );
      return null;
    }

    final xfile = XFile.fromData(
      file.bytes!,
      name: file.name,
    );

    final uploadResult = await _service.uploadEducationFile(file: xfile);

    if (!mounted) return null;

    if (uploadResult['statusCode'] == 200) {
      return Map<String, dynamic>.from(uploadResult['data']);
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          uploadResult['data']?['detail']?.toString() ??
              'No se pudo subir el archivo',
        ),
      ),
    );

    return null;
  }

  Future<String?> _uploadImageOrVideo() async {
    final picker = ImagePicker();

    final picked = await picker.pickMedia(imageQuality: 85);

    if (picked == null) return null;

    final uploadResult = await _service.uploadEducationFile(file: picked);

    if (!mounted) return null;

    if (uploadResult['statusCode'] == 200) {
      return uploadResult['data']?['file_url']?.toString();
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          uploadResult['data']?['detail']?.toString() ??
              'No se pudo subir el archivo',
        ),
      ),
    );

    return null;
  }

  Future<void> _showCategoryDialog({Map<String, dynamic>? category}) async {
    final bool isEdit = category != null;

    final nameController = TextEditingController(
      text: isEdit ? (category['name'] ?? '').toString() : '',
    );

    final descriptionController = TextEditingController(
      text: isEdit ? (category['description'] ?? '').toString() : '',
    );

    bool active = isEdit ? category['active'] == true : true;

    await showDialog(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text(isEdit ? 'Editar categoría' : 'Crear categoría'),
              content: SizedBox(
                width: 480,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: nameController,
                      decoration: const InputDecoration(
                        labelText: 'Nombre de la categoría',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: descriptionController,
                      minLines: 2,
                      maxLines: 4,
                      decoration: const InputDecoration(
                        labelText: 'Descripción',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    SwitchListTile(
                      value: active,
                      title: const Text('Categoría activa'),
                      onChanged: (value) {
                        setDialogState(() {
                          active = value;
                        });
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Cancelar'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    final name = nameController.text.trim();

                    if (name.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('El nombre es obligatorio'),
                        ),
                      );
                      return;
                    }

                    final result = isEdit
                        ? await _service.updateCategory(
                            categoryId: category['id'],
                            name: name,
                            description: descriptionController.text.trim(),
                            active: active,
                          )
                        : await _service.createCategory(
                            name: name,
                            description: descriptionController.text.trim(),
                            active: active,
                          );

                    if (!mounted) return;

                    Navigator.pop(dialogContext);

                    if (result['statusCode'] == 200 ||
                        result['statusCode'] == 201) {
                      await _loadData();
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            result['data']?['detail']?.toString() ??
                                'No se pudo guardar la categoría',
                          ),
                        ),
                      );
                    }
                  },
                  child: const Text('Guardar'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _deleteCategory(Map<String, dynamic> category) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Eliminar categoría'),
          content: Text('¿Seguro que deseas eliminar "${category['name']}"?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Eliminar'),
            ),
          ],
        );
      },
    );

    if (confirm != true) return;

    final result = await _service.deleteCategory(categoryId: category['id']);

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      await _loadData();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No se pudo eliminar la categoría',
          ),
        ),
      );
    }
  }

  Future<void> _showResourceDialog({Map<String, dynamic>? resource}) async {
    final bool isEdit = resource != null;

    final titleController = TextEditingController(
      text: isEdit ? (resource['title'] ?? '').toString() : '',
    );

    final priceController = TextEditingController(
      text: isEdit ? _money(resource['price']) : '0',
    );

    final descriptionController = TextEditingController(
      text: isEdit ? (resource['description'] ?? '').toString() : '',
    );

    final contentController = TextEditingController(
      text: isEdit ? (resource['content_text'] ?? '').toString() : '',
    );

    final fileUrlController = TextEditingController(
      text: isEdit ? (resource['file_url'] ?? '').toString() : '',
    );

    final externalUrlController = TextEditingController(
      text: isEdit ? (resource['external_url'] ?? '').toString() : '',
    );

    final coverUrlController = TextEditingController(
      text: isEdit ? (resource['cover_image_url'] ?? '').toString() : '',
    );

    final plantCommonController = TextEditingController(
      text: isEdit ? (resource['plant_common_name'] ?? '').toString() : '',
    );

    final plantScientificController = TextEditingController(
      text: isEdit ? (resource['plant_scientific_name'] ?? '').toString() : '',
    );

    final plantFamilyController = TextEditingController(
      text: isEdit ? (resource['plant_family'] ?? '').toString() : '',
    );

    final plantOriginController = TextEditingController(
      text: isEdit ? (resource['plant_origin'] ?? '').toString() : '',
    );

    final plantUsesController = TextEditingController(
      text: isEdit ? (resource['plant_uses'] ?? '').toString() : '',
    );

    final plantPartsController = TextEditingController(
      text: isEdit ? (resource['plant_parts_used'] ?? '').toString() : '',
    );

    final plantPreparationController = TextEditingController(
      text: isEdit ? (resource['plant_preparation'] ?? '').toString() : '',
    );

    final plantWarningsController = TextEditingController(
      text: isEdit ? (resource['plant_warnings'] ?? '').toString() : '',
    );

    int selectedCategoryId = isEdit
        ? int.tryParse((resource['category_id'] ?? 0).toString()) ?? 0
        : 0;

    String selectedType =
        isEdit ? (resource['resource_type'] ?? 'pdf').toString() : 'pdf';

    bool active = isEdit ? resource['active'] == true : true;
    bool freeForMembers = isEdit ? resource['free_for_members'] == true : true;

    bool marketplaceOnly =
        isEdit ? resource['marketplace_only'] == true : false;

    String selectedLanguage =
        isEdit ? (resource['language'] ?? 'es').toString() : 'es';

    String selectedContentType =
        isEdit ? (resource['content_type'] ?? 'general').toString() : 'general';

    final downloadPdfController = TextEditingController(
      text: isEdit ? (resource['download_pdf_url'] ?? '').toString() : '',
    );

    List<String> videoUrls = isEdit && resource['video_urls'] is List
        ? List<String>.from(resource['video_urls'])
        : [];

    List<Map<String, dynamic>> onlineFiles =
        isEdit && resource['online_files'] is List
            ? List<Map<String, dynamic>>.from(
                (resource['online_files'] as List).map(
                  (e) => Map<String, dynamic>.from(e),
                ),
              )
            : [];

    bool uploadingFile = false;
    bool uploadingCover = false;

    await showDialog(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text(isEdit ? 'Editar contenido' : 'Crear contenido'),
              content: SizedBox(
                width: 720,
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      TextField(
                        controller: titleController,
                        decoration: const InputDecoration(
                          labelText: 'Título',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: priceController,
                        keyboardType: const TextInputType.numberWithOptions(
                          decimal: true,
                        ),
                        decoration: const InputDecoration(
                          labelText: 'Precio USD para marketplace educativo',
                          helperText:
                              'Para socios activos puede quedar gratis si activas “Gratis para socios”.',
                          helperMaxLines: 2,
                          prefixText: '\$ ',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<int>(
                        initialValue: selectedCategoryId,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'Categoría',
                          border: OutlineInputBorder(),
                        ),
                        items: [
                          const DropdownMenuItem(
                            value: 0,
                            child: Text('Sin categoría'),
                          ),
                          ..._categories.map((item) {
                            final category = Map<String, dynamic>.from(item);
                            return DropdownMenuItem<int>(
                              value: category['id'],
                              child: Text(
                                category['name'] ?? 'Categoría',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            );
                          }),
                        ],
                        onChanged: (value) {
                          if (value == null) return;
                          setDialogState(() {
                            selectedCategoryId = value;
                          });
                        },
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String>(
                        initialValue: selectedLanguage,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'Idioma del contenido',
                          border: OutlineInputBorder(),
                        ),
                        items: const [
                          DropdownMenuItem(value: 'es', child: Text('Español')),
                          DropdownMenuItem(value: 'en', child: Text('Inglés')),
                        ],
                        onChanged: (value) {
                          if (value == null) return;
                          setDialogState(() {
                            selectedLanguage = value;
                          });
                        },
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: descriptionController,
                        minLines: 2,
                        maxLines: 4,
                        decoration: const InputDecoration(
                          labelText: 'Descripción',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Wrap(
                        spacing: 10,
                        runSpacing: 10,
                        children: [
                          OutlinedButton.icon(
                            onPressed: uploadingFile
                                ? null
                                : () async {
                                    setDialogState(() {
                                      uploadingFile = true;
                                    });
                                    final uploadData = await _uploadAnyFile();
                                    setDialogState(() {
                                      uploadingFile = false;
                                      final url =
                                          uploadData?['file_url']?.toString() ??
                                              '';
                                      if (url.isNotEmpty) {
                                        fileUrlController.text = url;
                                        selectedType = 'pdf';
                                      }
                                    });
                                  },
                            icon: const Icon(Icons.picture_as_pdf),
                            label: const Text('Subir PDF protegido'),
                          ),
                          OutlinedButton.icon(
                            onPressed: uploadingFile
                                ? null
                                : () async {
                                    setDialogState(() {
                                      uploadingFile = true;
                                    });
                                    final uploadData = await _uploadAnyFile();
                                    setDialogState(() {
                                      uploadingFile = false;
                                      final url =
                                          uploadData?['file_url']?.toString() ??
                                              '';
                                      if (url.isNotEmpty) {
                                        fileUrlController.text = url;
                                        selectedType = 'video';
                                      }
                                    });
                                  },
                            icon: const Icon(Icons.video_library),
                            label: const Text('Subir video protegido'),
                          ),
                          OutlinedButton.icon(
                            onPressed: uploadingCover
                                ? null
                                : () async {
                                    setDialogState(() {
                                      uploadingCover = true;
                                    });
                                    final url = await _uploadImageOrVideo();
                                    setDialogState(() {
                                      uploadingCover = false;
                                      if (url != null) {
                                        coverUrlController.text = url;
                                      }
                                    });
                                  },
                            icon: const Icon(Icons.image),
                            label: Text(
                              uploadingCover ? 'Subiendo...' : 'Subir portada',
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: fileUrlController,
                        decoration: const InputDecoration(
                          labelText: 'URL del archivo',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: coverUrlController,
                        decoration: const InputDecoration(
                          labelText: 'URL de portada',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: downloadPdfController,
                              decoration: const InputDecoration(
                                labelText: 'PDF descargable',
                                border: OutlineInputBorder(),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          OutlinedButton.icon(
                            onPressed: () async {
                              final uploadData = await _uploadAnyFile();
                              final url =
                                  uploadData?['file_url']?.toString() ?? '';
                              if (url.isNotEmpty) {
                                setDialogState(() {
                                  downloadPdfController.text = url;
                                });
                              }
                            },
                            icon: const Icon(Icons.download),
                            label: const Text('Subir PDF'),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      SwitchListTile(
                        value: active,
                        title: const Text('Visible'),
                        subtitle: Text(
                          active ? 'Contenido publicado' : 'Contenido oculto',
                        ),
                        onChanged: (value) {
                          setDialogState(() {
                            active = value;
                          });
                        },
                      ),
                      SwitchListTile(
                        value: freeForMembers,
                        title: const Text('Gratis para socios activos'),
                        subtitle: Text(
                          freeForMembers
                              ? 'Socios activos pueden verlo gratis'
                              : 'Solo con compra/código de acceso',
                        ),
                        onChanged: (value) {
                          setDialogState(() {
                            freeForMembers = value;
                            if (value) {
                              marketplaceOnly = false;
                            }
                          });
                        },
                      ),
                      SwitchListTile(
                        value: marketplaceOnly,
                        title:
                            const Text('Solo venta en Marketplace Educación'),
                        subtitle: Text(
                          marketplaceOnly
                              ? 'No aparece gratis para socios activos'
                              : 'Puede aparecer para socios si está activado',
                        ),
                        onChanged: (value) {
                          setDialogState(() {
                            marketplaceOnly = value;
                            if (value) {
                              freeForMembers = false;
                            }
                          });
                        },
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Cancelar'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    final title = titleController.text.trim();
                    final price = double.tryParse(
                          priceController.text.replaceAll(',', '.').trim(),
                        ) ??
                        0;

                    if (title.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('El título es obligatorio'),
                        ),
                      );
                      return;
                    }

                    final result = isEdit
                        ? await _service.updateResource(
                            resourceId: resource['id'],
                            title: title,
                            categoryId: selectedCategoryId,
                            resourceType: selectedType,
                            fileUrl: fileUrlController.text.trim(),
                            externalUrl: externalUrlController.text.trim(),
                            coverImageUrl: coverUrlController.text.trim(),
                            price: price,
                            description: descriptionController.text.trim(),
                            contentText: contentController.text.trim(),
                            plantCommonName: plantCommonController.text.trim(),
                            plantScientificName:
                                plantScientificController.text.trim(),
                            plantFamily: plantFamilyController.text.trim(),
                            plantOrigin: plantOriginController.text.trim(),
                            plantUses: plantUsesController.text.trim(),
                            plantPartsUsed: plantPartsController.text.trim(),
                            plantPreparation:
                                plantPreparationController.text.trim(),
                            plantWarnings: plantWarningsController.text.trim(),
                            active: active,
                            freeForMembers: freeForMembers,
                            marketplaceOnly: marketplaceOnly,
                            language: selectedLanguage,
                            contentType: selectedContentType,
                            videoUrls: videoUrls,
                            onlineFiles: onlineFiles,
                            downloadPdfUrl: downloadPdfController.text.trim(),
                          )
                        : await _service.createResource(
                            title: title,
                            categoryId: selectedCategoryId == 0
                                ? null
                                : selectedCategoryId,
                            resourceType: selectedType,
                            fileUrl: fileUrlController.text.trim(),
                            externalUrl: externalUrlController.text.trim(),
                            coverImageUrl: coverUrlController.text.trim(),
                            price: price,
                            description: descriptionController.text.trim(),
                            contentText: contentController.text.trim(),
                            plantCommonName: plantCommonController.text.trim(),
                            plantScientificName:
                                plantScientificController.text.trim(),
                            plantFamily: plantFamilyController.text.trim(),
                            plantOrigin: plantOriginController.text.trim(),
                            plantUses: plantUsesController.text.trim(),
                            plantPartsUsed: plantPartsController.text.trim(),
                            plantPreparation:
                                plantPreparationController.text.trim(),
                            plantWarnings: plantWarningsController.text.trim(),
                            active: active,
                            freeForMembers: freeForMembers,
                            marketplaceOnly: marketplaceOnly,
                            language: selectedLanguage,
                            contentType: selectedContentType,
                            videoUrls: videoUrls,
                            onlineFiles: onlineFiles,
                            downloadPdfUrl: downloadPdfController.text.trim(),
                          );

                    if (!mounted) return;

                    Navigator.pop(dialogContext);

                    if (result['statusCode'] == 200 ||
                        result['statusCode'] == 201) {
                      await _loadData();
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            result['data']?['detail']?.toString() ??
                                'No se pudo guardar el contenido',
                          ),
                        ),
                      );
                    }
                  },
                  child: const Text('Guardar'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _showGenerateAccessCodeDialog(
    Map<String, dynamic> resource,
  ) async {
    final nameController = TextEditingController();
    final emailController = TextEditingController();
    final phoneController = TextEditingController();
    final usesController = TextEditingController(text: '30');

    await showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: Text('Generar acceso - ${resource['title']}'),
          content: SizedBox(
            width: 500,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(
                    labelText: 'Nombre comprador',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    labelText: 'Email',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: phoneController,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(
                    labelText: 'Teléfono',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: usesController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Máximo de usos',
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () async {
                final result = await _service.createAccessCode(
                  resourceId: resource['id'],
                  buyerName: nameController.text.trim(),
                  buyerEmail: emailController.text.trim(),
                  buyerPhone: phoneController.text.trim(),
                  maxUses: int.tryParse(usesController.text.trim()) ?? 30,
                );

                if (!mounted) return;

                Navigator.pop(dialogContext);

                if (result['statusCode'] == 200 ||
                    result['statusCode'] == 201) {
                  final code = result['data']?['code']?.toString() ?? '';
                  final url = result['data']?['view_url']?.toString() ?? '';

                  showDialog(
                    context: context,
                    builder: (_) => AlertDialog(
                      title: const Text('Código generado'),
                      content: SelectableText(
                        'Código:\n$code\n\nLink:\n$url',
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('Cerrar'),
                        ),
                      ],
                    ),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        result['data']?['detail']?.toString() ??
                            'No se pudo generar el código',
                      ),
                    ),
                  );
                }
              },
              child: const Text('Generar'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _deleteResource(Map<String, dynamic> resource) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Eliminar contenido'),
          content: Text('¿Seguro que deseas eliminar "${resource['title']}"?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Eliminar'),
            ),
          ],
        );
      },
    );

    if (confirm != true) return;

    final result = await _service.deleteResource(resourceId: resource['id']);

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      await _loadData();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No se pudo eliminar el contenido',
          ),
        ),
      );
    }
  }

  Future<void> _toggleResource(Map<String, dynamic> resource) async {
    final bool active = resource['active'] == true;

    final result = await _service.updateResource(
      resourceId: resource['id'],
      active: !active,
    );

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      await _loadData();
    }
  }

  Widget _categoryCard(Map<String, dynamic> category) {
    final bool active = category['active'] == true;

    return Card(
      child: ListTile(
        leading: Icon(
          Icons.folder,
          color: active ? Colors.teal : Colors.grey,
        ),
        title: Text(category['name'] ?? 'Categoría'),
        subtitle: Text(active ? 'Activa' : 'Inactiva'),
        trailing: Wrap(
          children: [
            IconButton(
              icon: const Icon(Icons.edit),
              onPressed: () => _showCategoryDialog(category: category),
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () => _deleteCategory(category),
            ),
          ],
        ),
      ),
    );
  }

  Widget _resourceCard(Map<String, dynamic> resource) {
    final bool active = resource['active'] == true;
    final bool free = resource['free_for_members'] == true;
    final price = double.tryParse((resource['price'] ?? 0).toString()) ?? 0;
    final type = (resource['resource_type'] ?? '').toString();
    final icon = type == 'video'
        ? Icons.play_circle
        : type == 'link'
            ? Icons.link
            : type == 'image'
                ? Icons.image
                : type == 'plant_card' || type == 'plant_registry'
                    ? Icons.eco
                    : Icons.picture_as_pdf;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(icon, color: active ? Colors.teal : Colors.grey),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        resource['title']?.toString() ?? 'Contenido',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${resource['category_name'] ?? 'Sin categoría'} • ${_typeLabel(type)}',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Wrap(
                        spacing: 8,
                        runSpacing: 4,
                        children: [
                          _statusChip(active ? 'Visible' : 'Oculto',
                              active ? Colors.green : Colors.red),
                          _statusChip(
                            free
                                ? 'Gratis para socios activos'
                                : 'Solo compra/código',
                            free ? Colors.teal : Colors.orange,
                          ),
                          _statusChip(
                            'Marketplace: \$${_money(price)} USD',
                            Colors.blueGrey,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: Wrap(
                spacing: 2,
                children: [
                  IconButton(
                    icon: const Icon(Icons.edit),
                    onPressed: () => _showResourceDialog(resource: resource),
                  ),
                  IconButton(
                    icon: const Icon(Icons.key, color: Colors.orange),
                    onPressed: () => _showGenerateAccessCodeDialog(resource),
                  ),
                  IconButton(
                    icon: Icon(
                      active ? Icons.visibility_off : Icons.visibility,
                      color: active ? Colors.red : Colors.green,
                    ),
                    onPressed: () => _toggleResource(resource),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () => _deleteResource(resource),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _statusChip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final resources = _filteredResources;

    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      appBar: AppBar(
        title: const Text('Dashboard Mayu Educación'),
        actions: [
          IconButton(
            onPressed: _loadData,
            icon: const Icon(Icons.refresh),
          ),
          IconButton(
            onPressed: _logout,
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Text(
                    _error!,
                    style: const TextStyle(color: Colors.red),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadData,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      const Text(
                        'Mayu Educación',
                        style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Gestiona categorías, contenidos educativos, precios, acceso gratuito para socios activos y marketplace educativo.',
                      ),
                      const SizedBox(height: 18),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () => _showCategoryDialog(),
                              icon: const Icon(Icons.create_new_folder),
                              label: const Text('Nueva categoría'),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () => _showResourceDialog(),
                              icon: const Icon(Icons.add),
                              label: const Text('Nuevo contenido'),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 18),
                      TextField(
                        decoration: const InputDecoration(
                          labelText: 'Buscar contenido o planta',
                          prefixIcon: Icon(Icons.search),
                          border: OutlineInputBorder(),
                        ),
                        onChanged: (value) {
                          setState(() {
                            _search = value;
                          });
                        },
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<int>(
                        initialValue: _categoryFilter,
                        decoration: const InputDecoration(
                          labelText: 'Filtrar por categoría',
                          border: OutlineInputBorder(),
                        ),
                        items: [
                          const DropdownMenuItem(
                            value: 0,
                            child: Text('Todas'),
                          ),
                          ..._categories.map((item) {
                            final category = Map<String, dynamic>.from(item);
                            return DropdownMenuItem<int>(
                              value: category['id'],
                              child: Text(
                                category['name'] ?? 'Categoría',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            );
                          }),
                        ],
                        onChanged: (value) {
                          if (value == null) return;
                          setState(() {
                            _categoryFilter = value;
                          });
                        },
                      ),
                      const SizedBox(height: 22),
                      const Text(
                        'Categorías educativas',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 10),
                      if (_categories.isEmpty)
                        const Text('No hay categorías registradas')
                      else
                        ..._categories.map(
                          (item) => _categoryCard(
                            Map<String, dynamic>.from(item),
                          ),
                        ),
                      const SizedBox(height: 22),
                      const Text(
                        'Contenidos educativos',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 10),
                      if (resources.isEmpty)
                        const Padding(
                          padding: EdgeInsets.all(30),
                          child: Center(
                            child: Text('No hay contenidos registrados'),
                          ),
                        )
                      else
                        ...resources.map(
                          (item) => _resourceCard(
                            Map<String, dynamic>.from(item),
                          ),
                        ),
                      const SizedBox(height: 80),
                    ],
                  ),
                ),
    );
  }
}
