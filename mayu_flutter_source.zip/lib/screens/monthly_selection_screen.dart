import 'package:flutter/material.dart';

import '../services/auth_service.dart';
import '../services/monthly_selection_service.dart';
import '../widgets/mayu_scaffold.dart';

class MonthlySelectionScreen extends StatefulWidget {
  final int? userId;

  const MonthlySelectionScreen({
    super.key,
    this.userId,
  });

  @override
  State<MonthlySelectionScreen> createState() => _MonthlySelectionScreenState();
}

class _MonthlySelectionScreenState extends State<MonthlySelectionScreen> {
  final AuthService _authService = AuthService();
  final MonthlySelectionService _monthlySelectionService =
      MonthlySelectionService();

  bool _loading = true;
  bool _saving = false;
  String? _error;

  int? _selectionId;

  String _monthLabel = '';
  String _planName = '';
  String _cycleStatusLabel = '';
  bool _editable = false;
  bool _movedToNextCycle = false;
  bool _orderLocked = false;
  String _adminReviewWindow = '';
  String _shippingWindow = '';
  String _defaultRule = '';

  List<Map<String, dynamic>> _sections = [];
  List<Map<String, dynamic>> _currentProducts = [];
  Map<String, String?> _selectedProductsBySection = {};

  @override
  void initState() {
    super.initState();
    _loadSelection();
  }

  String _extractErrorMessage(dynamic data, String fallback) {
    if (data == null) return fallback;

    if (data is String && data.trim().isNotEmpty) return data;

    if (data is Map<String, dynamic>) {
      final detail = data['detail'];
      if (detail is String && detail.trim().isNotEmpty) return detail;

      final message = data['message'];
      if (message is String && message.trim().isNotEmpty) return message;
    }

    return fallback;
  }

  Future<int?> _resolveUserId() async {
    if (widget.userId != null) return widget.userId;

    final user = await _authService.getUser();
    final rawId = user?['id'];

    if (rawId == null) return null;

    return int.tryParse(rawId.toString());
  }

  List<Map<String, dynamic>> _parseSections(dynamic rawSections) {
    if (rawSections is! List) return [];

    return rawSections
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .where((item) => item['section_key'] != null)
        .toList();
  }

  List<Map<String, dynamic>> _parseProducts(dynamic rawProducts) {
    if (rawProducts is! List) return [];

    return rawProducts
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .toList();
  }

  void _preselectProducts() {
    final Map<String, String?> selected = {};

    for (final section in _sections) {
      final key = section['section_key']?.toString();
      final category = section['category']?.toString();
      final products = section['products'];

      if (key == null || key.isEmpty) continue;

      String? currentProductName;

      for (final product in _currentProducts) {
        if (product['category']?.toString() == category) {
          currentProductName = product['name']?.toString();
          break;
        }
      }

      if (currentProductName == null && products is List && products.isNotEmpty) {
        final first = products.first;
        if (first is Map && first['name'] != null) {
          currentProductName = first['name'].toString();
        }
      }

      selected[key] = currentProductName;
    }

    _selectedProductsBySection = selected;
  }

  Future<void> _loadSelection() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final userId = await _resolveUserId();

      if (userId == null) {
        setState(() {
          _loading = false;
          _error = 'No se pudo identificar el usuario';
        });
        return;
      }

      final result = await _monthlySelectionService.initMonthlySelection(
        userId: userId,
      );

      if (!mounted) return;

      if (result['statusCode'] != 200 && result['statusCode'] != 201) {
        setState(() {
          _loading = false;
          _error = _extractErrorMessage(
            result['data'],
            'No se pudo cargar la selección mensual',
          );
        });
        return;
      }

      final data = result['data'];

      setState(() {
        _selectionId = int.tryParse(
          (data?['selection_id'] ?? data?['id'] ?? '').toString(),
        );
        _monthLabel = (data?['month_label'] ?? '').toString();
        _planName = (data?['plan_name'] ?? '').toString();
        _cycleStatusLabel = (data?['cycle_status_label'] ?? '').toString();
        _editable = data?['editable'] == true;
        _movedToNextCycle = data?['moved_to_next_cycle'] == true;
        _orderLocked = data?['order_locked'] == true;
        _adminReviewWindow = (data?['admin_review_window'] ?? '').toString();
        _shippingWindow = (data?['shipping_window'] ?? '').toString();
        _defaultRule = (data?['default_rule'] ?? '').toString();
        _sections = _parseSections(data?['editable_sections']);
        _currentProducts = _parseProducts(data?['products']);
        _loading = false;
      });

      _preselectProducts();

      if (mounted) {
        setState(() {});
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _loading = false;
        _error = 'Error cargando selección mensual: $e';
      });
    }
  }

  List<String> get _selectedProductNames {
    return _selectedProductsBySection.values
        .where((value) => value != null && value.trim().isNotEmpty)
        .map((value) => value!.trim())
        .toList();
  }

  Future<void> _saveSelection() async {
    if (_selectionId == null) {
      setState(() {
        _error = 'No se encontró la selección mensual';
      });
      return;
    }

    if (_selectedProductNames.isEmpty) {
      setState(() {
        _error = 'Selecciona al menos un producto';
      });
      return;
    }

    if (_selectedProductNames.toSet().length != _selectedProductNames.length) {
      setState(() {
        _error = 'No puedes seleccionar el mismo producto dos veces.';
      });
      return;
    }

    setState(() {
      _saving = true;
      _error = null;
    });

    try {
      final result = await _monthlySelectionService.saveSelections(
        selectionId: _selectionId!,
        productNames: _selectedProductNames,
      );

      if (!mounted) return;

      if (result['statusCode'] != 200 && result['statusCode'] != 201) {
        setState(() {
          _saving = false;
          _error = _extractErrorMessage(
            result['data'],
            'No se pudo guardar la selección',
          );
        });
        return;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Selección mensual guardada correctamente'),
        ),
      );

      setState(() {
        _saving = false;
      });

      await _loadSelection();
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _saving = false;
        _error = 'Error guardando selección: $e';
      });
    }
  }

  Widget _buildCurrentProductsCard() {
    if (_currentProducts.isEmpty) {
      return const SizedBox.shrink();
    }

    return _card(
      title: 'Productos actuales',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: _currentProducts.map((product) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text(
              '• ${product['name'] ?? 'Producto'}',
              style: const TextStyle(fontSize: 16),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildSectionDropdowns() {
    if (_sections.isEmpty) {
      return _card(
        title: 'Productos disponibles',
        child: const Text('No hay productos configurados para este plan.'),
      );
    }

    return _card(
      title: 'Editar selección mensual',
      child: Column(
        children: _sections.map((section) {
          final key = section['section_key']?.toString() ?? '';
          final title = section['section_name']?.toString() ?? 'Producto';
          final productsRaw = section['products'];

          final products = productsRaw is List
              ? productsRaw
                  .whereType<Map>()
                  .map((p) => Map<String, dynamic>.from(p))
                  .toList()
              : <Map<String, dynamic>>[];

          final options = products
              .map((p) => p['name']?.toString() ?? '')
              .where((name) => name.trim().isNotEmpty)
              .toList();

          final selectedValue = _selectedProductsBySection[key];
          final validValue =
              options.contains(selectedValue) ? selectedValue : null;

          return Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: DropdownButtonFormField<String>(
              initialValue: validValue,
              decoration: InputDecoration(
                labelText: title,
                border: const OutlineInputBorder(),
              ),
              items: options.map((name) {
                return DropdownMenuItem<String>(
                  value: name,
                  child: Text(name),
                );
              }).toList(),
              onChanged: !_editable || _orderLocked || _saving
                  ? null
                  : (value) {
                      setState(() {
                        _selectedProductsBySection[key] = value;
                      });
                    },
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _card({
    required String title,
    required Widget child,
  }) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 19,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MayuScaffold(
      appBar: AppBar(
        title: const Text('Mi selección mensual'),
        centerTitle: true,
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : RefreshIndicator(
                    onRefresh: _loadSelection,
                    child: SingleChildScrollView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _card(
                            title: 'Ciclo activo',
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _monthLabel.isEmpty
                                      ? 'Mes no disponible'
                                      : _monthLabel,
                                  style: const TextStyle(fontSize: 18),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  _planName.isEmpty
                                      ? 'Plan no disponible'
                                      : _planName,
                                  style: const TextStyle(fontSize: 16),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  _cycleStatusLabel,
                                  style: const TextStyle(
                                    fontSize: 15,
                                    color: Colors.black54,
                                  ),
                                ),
                                if (_movedToNextCycle) ...[
                                  const SizedBox(height: 8),
                                  const Text(
                                    'Tu orden anterior ya fue liberada a logística. Esta selección corresponde al siguiente ciclo.',
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.blueGrey,
                                    ),
                                  ),
                                ],
                                if (_orderLocked) ...[
                                  const SizedBox(height: 8),
                                  const Text(
                                    'La orden ya fue liberada a logística. Esta selección ya no puede modificarse.',
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.red,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                                if (_adminReviewWindow.isNotEmpty) ...[
                                  const SizedBox(height: 8),
                                  Text(
                                    'Revisión administrativa: $_adminReviewWindow',
                                    style: const TextStyle(
                                      fontSize: 14,
                                      color: Colors.black54,
                                    ),
                                  ),
                                ],
                                if (_shippingWindow.isNotEmpty) ...[
                                  const SizedBox(height: 4),
                                  Text(
                                    'Día de despacho: $_shippingWindow',
                                    style: const TextStyle(
                                      fontSize: 14,
                                      color: Colors.black54,
                                    ),
                                  ),
                                ],
                                if (_defaultRule.isNotEmpty) ...[
                                  const SizedBox(height: 8),
                                  Text(
                                    _defaultRule,
                                    style: const TextStyle(
                                      fontSize: 14,
                                      color: Colors.black54,
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),
                          _buildCurrentProductsCard(),
                          _buildSectionDropdowns(),
                          if (_error != null)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 12),
                              child: Text(
                                _error!,
                                style: const TextStyle(color: Colors.red),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ElevatedButton.icon(
                            onPressed: !_editable || _orderLocked || _saving
                                ? null
                                : _saveSelection,
                            icon: const Icon(Icons.save),
                            label: _saving
                                ? const SizedBox(
                                    height: 20,
                                    width: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                    ),
                                  )
                                : const Text('Guardar selección'),
                          ),
                          const SizedBox(height: 12),
                          OutlinedButton.icon(
                            onPressed: _saving ? null : _loadSelection,
                            icon: const Icon(Icons.refresh),
                            label: const Text('Actualizar'),
                          ),
                        ],
                      ),
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}