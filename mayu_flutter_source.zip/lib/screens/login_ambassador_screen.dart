import 'package:flutter/material.dart';

import '../services/ambassador_service.dart';
import '../widgets/mayu_logo.dart';
import '../widgets/mayu_scaffold.dart';

import 'ambassador_dashboard_screen.dart';

class LoginAmbassadorScreen extends StatefulWidget {
  const LoginAmbassadorScreen({super.key});

  @override
  State<LoginAmbassadorScreen> createState() => _LoginAmbassadorScreenState();
}

class _LoginAmbassadorScreenState extends State<LoginAmbassadorScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  final FocusNode _emailFocus = FocusNode();
  final FocusNode _passwordFocus = FocusNode();

  bool _loading = false;
  bool _showPassword = false;
  String? _error;

  bool _isValidEmail(String email) {
    return RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(email);
  }

  Future<void> _login() async {
    final email = _emailController.text.trim().toLowerCase();
    final password = _passwordController.text.trim();

    FocusScope.of(context).unfocus();

    if (email.isEmpty || password.isEmpty) {
      setState(() => _error = 'Email y contraseña son obligatorios');
      return;
    }

    if (!_isValidEmail(email)) {
      setState(() => _error = 'Ingresa un email válido');
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final result = await AmbassadorService.loginAmbassador(
        email: email,
        password: password,
      );

      if (!mounted) return;

      if (result['statusCode'] == 200 && result['data'] is Map) {
        final data = Map<String, dynamic>.from(result['data']);
        final ambassadorRaw = data['ambassador'];

        if (ambassadorRaw is! Map) {
          setState(() {
            _loading = false;
            _error = 'Error al obtener datos del embajador';
          });
          return;
        }

        final ambassador = Map<String, dynamic>.from(ambassadorRaw);

        final int ambassadorId = int.tryParse(
              (ambassador['id'] ?? 0).toString(),
            ) ??
            0;

        if (ambassadorId == 0) {
          setState(() {
            _loading = false;
            _error = 'ID de embajador inválido';
          });
          return;
        }

        setState(() {
          _loading = false;
        });

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => AmbassadorDashboardScreen(
              ambassadorId: ambassadorId,
            ),
          ),
        );
      } else {
        setState(() {
          _loading = false;
          _error = result['data']?['detail'] ?? 'Credenciales incorrectas';
        });
      }
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _loading = false;
        _error = 'Error de conexión con el servidor';
      });
    }
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _emailFocus.dispose();
    _passwordFocus.dispose();
    super.dispose();
  }

  InputDecoration _input(String label, {Widget? suffixIcon}) {
    return InputDecoration(
      labelText: label,
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
      ),
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 14,
      ),
      suffixIcon: suffixIcon,
    );
  }

  @override
  Widget build(BuildContext context) {
    return MayuScaffold(
      appBar: AppBar(
        title: const Text('Embajadores Mayu'),
        centerTitle: true,
      ),
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const MayuLogo(height: 95),
                    const SizedBox(height: 16),
                    const Text(
                      'Acceso Embajador',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Ingresa con tu cuenta para revisar afiliados, entregas y comisiones.',
                      style: TextStyle(color: Colors.black54),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 24),
                    TextField(
                      controller: _emailController,
                      focusNode: _emailFocus,
                      keyboardType: TextInputType.emailAddress,
                      textInputAction: TextInputAction.next,
                      decoration: _input('Email'),
                      onSubmitted: (_) {
                        FocusScope.of(context).requestFocus(_passwordFocus);
                      },
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _passwordController,
                      focusNode: _passwordFocus,
                      obscureText: !_showPassword,
                      textInputAction: TextInputAction.done,
                      decoration: _input(
                        'Contraseña',
                        suffixIcon: IconButton(
                          icon: Icon(
                            _showPassword
                                ? Icons.visibility_off
                                : Icons.visibility,
                          ),
                          onPressed: () {
                            setState(() {
                              _showPassword = !_showPassword;
                            });
                          },
                        ),
                      ),
                      onSubmitted: (_) {
                        if (!_loading) _login();
                      },
                    ),
                    const SizedBox(height: 16),
                    if (_error != null)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Text(
                          _error!,
                          style: const TextStyle(
                            color: Colors.red,
                            fontWeight: FontWeight.w500,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _loading ? null : _login,
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                        child: _loading
                            ? const SizedBox(
                                width: 22,
                                height: 22,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Text('Ingresar como Embajador'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}