import 'package:flutter/material.dart';

import '../core/api_config.dart';
import '../services/education_service.dart';
import '../widgets/mayu_scaffold.dart';
import 'education_reader_screen.dart';

class EducationAccessScreen extends StatefulWidget {
  const EducationAccessScreen({super.key});

  @override
  State<EducationAccessScreen> createState() =>
      _EducationAccessScreenState();
}

class _EducationAccessScreenState extends State<EducationAccessScreen> {
  final EducationService _service = EducationService();

  final TextEditingController _codeController = TextEditingController();

  bool _loading = false;

  @override
  void dispose() {
    _codeController.dispose();
    super.dispose();
  }

  Future<void> _openReader() async {
    final code = _codeController.text.trim();

    if (code.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Ingresa el código de acceso'),
        ),
      );
      return;
    }

    setState(() {
      _loading = true;
    });

    final result = await _service.validateAccessCode(
      accessCode: code,
    );

    if (!mounted) return;

    setState(() {
      _loading = false;
    });

    if (result['statusCode'] != 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'Código inválido o caducado',
          ),
        ),
      );
      return;
    }

    final data = result['data'];

    final viewUrl = data?['view_url']?.toString() ?? '';

    final title =
        data?['title']?.toString() ?? 'Contenido Mayu Educación';

    if (viewUrl.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No se pudo abrir el contenido'),
        ),
      );
      return;
    }

    final fullUrl = viewUrl.startsWith('http')
        ? viewUrl
        : '${ApiConfig.baseUrl}$viewUrl';

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => EducationReaderScreen(
          title: title,
          viewUrl: fullUrl,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MayuScaffold(
      appBar: AppBar(
        title: const Text('Acceso Mayu Educación'),
        centerTitle: true,
      ),
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text(
            'Ingresar con código',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 27,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Coloca el código recibido después de tu compra para abrir el material protegido. El código permite hasta 30 ingresos.',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),

          TextField(
            controller: _codeController,
            textCapitalization: TextCapitalization.characters,
            decoration: const InputDecoration(
              labelText: 'Código de acceso',
              hintText: 'MAYU-EDU-XXXXXXXXXX',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.lock_open),
            ),
          ),

          const SizedBox(height: 22),

          SizedBox(
            height: 54,
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _loading ? null : _openReader,
              icon: _loading
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                      ),
                    )
                  : const Icon(Icons.menu_book),
              label: Text(
                _loading
                    ? 'Validando código...'
                    : 'Abrir contenido',
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                foregroundColor: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }
}