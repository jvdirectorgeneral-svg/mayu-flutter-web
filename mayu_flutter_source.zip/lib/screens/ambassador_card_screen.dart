import 'package:flutter/material.dart';
import '../services/ambassador_service.dart';
import '../widgets/ambassador_card.dart';

class AmbassadorCardScreen extends StatefulWidget {
  final int ambassadorId;

  const AmbassadorCardScreen({
    super.key,
    required this.ambassadorId,
  });

  @override
  State<AmbassadorCardScreen> createState() => _AmbassadorCardScreenState();
}

class _AmbassadorCardScreenState extends State<AmbassadorCardScreen> {
  Map<String, dynamic>? cardData;
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    loadCard();
  }

  Future<void> loadCard() async {
    setState(() {
      loading = true;
      error = null;
    });

    try {
      final result = await AmbassadorService.getCard(widget.ambassadorId);

      if (!mounted) return;

      if (result['statusCode'] == 200 && result['data'] != null) {
        setState(() {
          cardData = Map<String, dynamic>.from(result['data']);
          loading = false;
        });
      } else {
        setState(() {
          error = result['data']?['detail'] ??
              'No se pudo cargar la tarjeta del embajador';
          loading = false;
        });
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        error = 'Error de conexión con el servidor';
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final String name = (cardData?['name'] ?? '').toString();
    final String code = (cardData?['code'] ??
            cardData?['ambassador_code'] ??
            '')
        .toString();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Tarjeta de Embajador'),
        actions: [
          IconButton(
            onPressed: loadCard,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(18),
        child: loading
            ? const Center(child: CircularProgressIndicator())
            : error != null
                ? Center(
                    child: Text(
                      error!,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.red),
                    ),
                  )
                : AmbassadorCard(
                    name: name,
                    ambassadorCode: code,
                  ),
      ),
    );
  }
}