import 'package:flutter/material.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tratamiento de datos'),
      ),
      body: const SingleChildScrollView(
        padding: EdgeInsets.all(22),
        child: Text(
          '''
POLÍTICA DE TRATAMIENTO DE DATOS PERSONALES — MAYU WELLNESS CLUB

Al registrarte en Mayu Wellness Club autorizas el tratamiento de tus datos personales para fines operativos, administrativos, comerciales, logísticos y de comunicación relacionados con tu membresía.

1. Datos recolectados

Mayu Wellness Club podrá registrar datos como nombre, cédula, correo electrónico, teléfono, ciudad, dirección, referencia de entrega, datos de facturación, estado de membresía, historial de pagos, historial de entregas, plan seleccionado y productos elegidos.

2. Finalidad

Tus datos serán utilizados para:

• Crear y administrar tu cuenta.
• Gestionar pagos y membresías.
• Procesar entregas.
• Emitir comprobantes o registros internos.
• Contactarte por temas operativos.
• Enviar información relacionada con beneficios, productos, promociones y servicios.
• Dar seguimiento postventa.

3. Seguridad

Mayu Wellness Club aplicará medidas razonables de seguridad para proteger la información del usuario y limitar su acceso únicamente a personal autorizado.

4. Compartición de datos

Tus datos podrán compartirse únicamente cuando sea necesario para cumplir con procesos operativos, como logística, pasarelas de pago, sistemas de mensajería, facturación, soporte o servicios relacionados con la membresía.

5. Derechos del usuario

El usuario puede solicitar actualización, corrección o revisión de sus datos personales mediante los canales oficiales de Mayu Wellness Club.

6. Conservación

Los datos podrán conservarse mientras exista relación con la plataforma, obligación administrativa, historial comercial o necesidad operativa.

Al continuar con el registro, declaras que autorizas el tratamiento de tus datos personales.
''',
          style: TextStyle(fontSize: 16, height: 1.45),
        ),
      ),
    );
  }
}