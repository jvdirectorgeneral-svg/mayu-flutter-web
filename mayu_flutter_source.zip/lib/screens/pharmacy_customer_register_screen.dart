import 'package:flutter/material.dart';

import '../services/pharmacy_loyalty_service.dart';

class PharmacyCustomerRegisterScreen extends StatefulWidget {
  const PharmacyCustomerRegisterScreen({super.key});

  @override
  State<PharmacyCustomerRegisterScreen> createState() =>
      _PharmacyCustomerRegisterScreenState();
}

class _PharmacyCustomerRegisterScreenState
    extends State<PharmacyCustomerRegisterScreen> {
  final PharmacyLoyaltyService _service = PharmacyLoyaltyService();
  final _nameController = TextEditingController();
  final _birthDateController = TextEditingController();
  final _cityController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();

  bool _acceptedPolicies = false;
  bool _saving = false;

  @override
  void dispose() {
    _nameController.dispose();
    _birthDateController.dispose();
    _cityController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    super.dispose();
  }

  Future<void> _pickBirthDate() async {
    final now = DateTime.now();
    final selected = await showDatePicker(
      context: context,
      initialDate: DateTime(now.year - 25, now.month, now.day),
      firstDate: DateTime(1920),
      lastDate: now,
    );

    if (selected == null) return;

    final month = selected.month.toString().padLeft(2, '0');
    final day = selected.day.toString().padLeft(2, '0');
    _birthDateController.text = '${selected.year}-$month-$day';
  }

  Future<void> _register() async {
    if (_nameController.text.trim().isEmpty ||
        _birthDateController.text.trim().isEmpty ||
        _cityController.text.trim().isEmpty ||
        _phoneController.text.trim().isEmpty ||
        _emailController.text.trim().isEmpty) {
      _showMessage(
        'Completa nombre, fecha de nacimiento, ciudad, teléfono y correo',
      );
      return;
    }

    if (!_acceptedPolicies) {
      _showMessage('Debes aceptar términos y políticas Farmacia Mayu');
      return;
    }

    setState(() => _saving = true);
    final result = await _service.register(
      name: _nameController.text,
      birthDate: _birthDateController.text,
      city: _cityController.text,
      phone: _phoneController.text,
      email: _emailController.text,
      acceptedPolicies: _acceptedPolicies,
    );
    if (!mounted) return;
    setState(() => _saving = false);

    if (result['statusCode'] == 200) {
      Navigator.pop(context, true);
    } else {
      final detail = result['data']?['detail']?.toString();
      _showMessage(
        detail == 'El correo ya está registrado'
            ? 'Ese correo ya tiene una Tarjeta Farmacia registrada.'
            : detail ?? 'No se pudo activar tu Tarjeta Farmacia',
      );
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      appBar: AppBar(title: const Text('Activar Tarjeta Farmacia')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Datos del socio farmacia',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Estos datos activan la tarjeta de puntos y permiten enviar notificaciones de cumpleaños y compras.',
                ),
                const SizedBox(height: 22),
                _field(_nameController, 'Nombre completo'),
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: TextField(
                    controller: _birthDateController,
                    readOnly: true,
                    onTap: _pickBirthDate,
                    decoration: const InputDecoration(
                      labelText: 'Fecha de nacimiento',
                      suffixIcon: Icon(Icons.calendar_month),
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                _field(_cityController, 'Ciudad'),
                _field(
                  _phoneController,
                  'Teléfono',
                  keyboardType: TextInputType.phone,
                ),
                _field(
                  _emailController,
                  'Correo',
                  keyboardType: TextInputType.emailAddress,
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: _acceptedPolicies,
                  title: const Text(
                    'Acepto términos, privacidad y notificaciones Farmacia Mayu',
                  ),
                  onChanged: (value) {
                    setState(() => _acceptedPolicies = value);
                  },
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _saving ? null : _register,
                    icon: const Icon(Icons.card_membership),
                    label: Text(
                      _saving ? 'Activando...' : 'Activar Tarjeta Farmacia',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _field(
    TextEditingController controller,
    String label, {
    TextInputType? keyboardType,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }
}
