import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../widgets/mayu_logo.dart';

import 'home_screen.dart';
import 'register_screen.dart';
import 'register_ambassador_screen.dart';
import 'login_mayu_team_screen.dart';
import 'forgot_password_screen.dart';
import 'marketplace_screen.dart';
import 'education_marketplace_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  final AuthService _authService = AuthService();

  bool _loading = false;
  String? _error;
  bool _obscurePassword = true;

  Future<void> _login() async {
    FocusScope.of(context).unfocus();

    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      setState(() {
        _error = 'Debes ingresar email y contraseña';
      });
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final success = await _authService.login(
        email: email,
        password: password,
      );

      if (!mounted) return;

      setState(() {
        _loading = false;
      });

      if (success) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => const HomeScreen(),
          ),
        );
      } else {
        setState(() {
          _error = 'Email o contraseña incorrectos';
        });
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _loading = false;
        _error = 'No se pudo iniciar sesión';
      });
    }
  }

  void _openMayuTeamLogin() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const LoginMayuTeamScreen(),
      ),
    );
  }

  InputDecoration _input({
    required String label,
    IconData? icon,
    Widget? suffixIcon,
  }) {
    return InputDecoration(
      labelText: label,
      prefixIcon: icon == null ? null : Icon(icon),
      suffixIcon: suffixIcon,
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: BorderSide.none,
      ),
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 18,
        vertical: 18,
      ),
    );
  }

  Widget _margenImage() {
    return Image.asset(
      'assets/images/margen1.png',
      width: double.infinity,
      fit: BoxFit.cover,
      errorBuilder: (context, error, stackTrace) {
        return const SizedBox.shrink();
      },
    );
  }

  Widget _mainButton({
    required String text,
    required VoidCallback? onPressed,
    IconData? icon,
    bool outlined = false,
  }) {
    if (outlined) {
      return SizedBox(
        width: double.infinity,
        height: 54,
        child: OutlinedButton.icon(
          onPressed: _loading ? null : onPressed,
          icon: Icon(icon ?? Icons.arrow_forward),
          label: Text(
            text,
            style: const TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w500,
            ),
          ),
          style: OutlinedButton.styleFrom(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18),
            ),
          ),
        ),
      );
    }

    return SizedBox(
      width: double.infinity,
      height: 54,
      child: ElevatedButton.icon(
        onPressed: _loading ? null : onPressed,
        icon: Icon(icon ?? Icons.arrow_forward),
        label: Text(
          text,
          style: const TextStyle(
            fontSize: 17,
            fontWeight: FontWeight.w600,
          ),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF38B6B4),
          foregroundColor: Colors.white,
          elevation: 3,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
        ),
      ),
    );
  }

  Widget _loginButton() {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: _loading ? null : _login,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF38B6B4),
          foregroundColor: Colors.white,
          elevation: 4,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
        ),
        child: _loading
            ? const SizedBox(
                height: 22,
                width: 22,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: Colors.white,
                ),
              )
            : const Text(
                'Iniciar sesión',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
      ),
    );
  }

  Widget _forgotPasswordButton() {
    return Align(
      alignment: Alignment.centerRight,
      child: TextButton.icon(
        onPressed: _loading
            ? null
            : () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const ForgotPasswordScreen(),
                  ),
                );
              },
        icon: const Icon(
          Icons.lock_reset,
          size: 18,
          color: Color(0xFF38B6B4),
        ),
        label: const Text(
          '¿Olvidaste tu contraseña?',
          style: TextStyle(
            color: Color(0xFF38B6B4),
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  Widget _errorMessage() {
    if (_error == null) {
      return const SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Text(
        _error!,
        style: const TextStyle(
          color: Colors.red,
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
        textAlign: TextAlign.center,
      ),
    );
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      body: SafeArea(
        child: Column(
          children: [
            _margenImage(),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 18,
                ),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 460),
                    child: SingleChildScrollView(
                      child: AutofillGroup(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const SizedBox(height: 10),

                            GestureDetector(
                              onTap: _openMayuTeamLogin,
                              child: const MayuLogo(height: 95),
                            ),

                            const SizedBox(height: 22),

                            const Text(
                              'Bienvenido a Mayu Wellness Club',
                              style: TextStyle(
                                fontSize: 27,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF1E1E1E),
                              ),
                              textAlign: TextAlign.center,
                            ),

                            const SizedBox(height: 10),

                            const Text(
                              'Ingresa con tu correo y contraseña para acceder a tu membresía y beneficios Mayu.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 15,
                                color: Colors.black87,
                                height: 1.4,
                              ),
                            ),

                            const SizedBox(height: 34),

                            TextField(
                              controller: _emailController,
                              keyboardType: TextInputType.emailAddress,
                              textInputAction: TextInputAction.next,
                              autofillHints: const [
                                AutofillHints.username,
                                AutofillHints.email,
                              ],
                              decoration: _input(
                                label: 'Email',
                                icon: Icons.email_outlined,
                              ),
                              onChanged: (_) {
                                if (_error != null) {
                                  setState(() {
                                    _error = null;
                                  });
                                }
                              },
                            ),

                            const SizedBox(height: 18),

                            TextField(
                              controller: _passwordController,
                              obscureText: _obscurePassword,
                              textInputAction: TextInputAction.done,
                              autofillHints: const [
                                AutofillHints.password,
                              ],
                              decoration: _input(
                                label: 'Contraseña',
                                icon: Icons.lock_outline,
                                suffixIcon: IconButton(
                                  onPressed: () {
                                    setState(() {
                                      _obscurePassword = !_obscurePassword;
                                    });
                                  },
                                  icon: Icon(
                                    _obscurePassword
                                        ? Icons.visibility_off
                                        : Icons.visibility,
                                  ),
                                ),
                              ),
                              onSubmitted: (_) {
                                if (!_loading) {
                                  _login();
                                }
                              },
                              onChanged: (_) {
                                if (_error != null) {
                                  setState(() {
                                    _error = null;
                                  });
                                }
                              },
                            ),

                            const SizedBox(height: 8),

                            _forgotPasswordButton(),

                            _errorMessage(),

                            _loginButton(),

                            const SizedBox(height: 14),

                            _mainButton(
                              text: 'Crear cuenta',
                              icon: Icons.person_add_alt_1,
                              outlined: true,
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => const RegisterScreen(),
                                  ),
                                );
                              },
                            ),

                            const SizedBox(height: 14),

                            _mainButton(
                              text: 'Registro de Embajador',
                              icon: Icons.groups,
                              outlined: true,
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const RegisterAmbassadorScreen(),
                                  ),
                                );
                              },
                            ),

                            const SizedBox(height: 14),

                            _mainButton(
                              text: 'Marketplace Farmacia Magistral Mayu',
                              icon: Icons.storefront,
                              outlined: true,
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const MarketplaceScreen(),
                                  ),
                                );
                              },
                            ),

                            const SizedBox(height: 14),

                            _mainButton(
                              text: 'Mayu Educación Marketplace',
                              icon: Icons.menu_book,
                              outlined: true,
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const EducationMarketplaceScreen(),
                                  ),
                                );
                              },
                            ),

                            const SizedBox(height: 24),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            _margenImage(),
          ],
        ),
      ),
    );
  }
}