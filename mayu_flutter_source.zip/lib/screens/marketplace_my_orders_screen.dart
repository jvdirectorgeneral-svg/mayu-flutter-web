import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/marketplace_service.dart';
import '../widgets/marketplace_order_timeline.dart';

class MarketplaceMyOrdersScreen extends StatefulWidget {
  const MarketplaceMyOrdersScreen({super.key});

  @override
  State<MarketplaceMyOrdersScreen> createState() =>
      _MarketplaceMyOrdersScreenState();
}

class _MarketplaceMyOrdersScreenState extends State<MarketplaceMyOrdersScreen> {
  final MarketplaceService _service = MarketplaceService();

  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _orders = [];

  @override
  void initState() {
    super.initState();
    _loadOrders();
  }

  Future<void> _loadOrders() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final result = await _service.getMyMarketplaceOrders();
    if (!mounted) return;

    if (result['statusCode'] == 200) {
      final rawItems =
          result['data']?['items'] is List ? result['data']['items'] : [];
      setState(() {
        _orders = List<Map<String, dynamic>>.from(
          rawItems.map((item) => Map<String, dynamic>.from(item)),
        );
        _loading = false;
      });
    } else {
      setState(() {
        _loading = false;
        _error = result['data']?['detail']?.toString() ??
            'No se pudieron cargar tus compras';
      });
    }
  }

  Future<void> _openTracking(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null ||
        !await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No se pudo abrir el seguimiento')),
      );
    }
  }

  Widget _orderCard(Map<String, dynamic> order) {
    final items = order['items'] is List ? order['items'] as List : [];
    final status = (order['status'] ?? '').toString();
    final trackingUrl = (order['tracking_url'] ?? '').toString().trim();

    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: ExpansionTile(
        leading: Icon(
          Icons.local_pharmacy,
          color: MarketplaceOrderTimeline.color(status),
        ),
        title: Text(
          order['order_code']?.toString() ?? 'Pedido Farmacia',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          '${MarketplaceOrderTimeline.label(status)} · \$${order['total'] ?? 0} USD',
        ),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        children: [
          const Divider(),
          ...items.map((raw) {
            final item = Map<String, dynamic>.from(raw);
            return ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              title: Text(item['product_name']?.toString() ?? 'Producto'),
              trailing: Text('x${item['quantity'] ?? 1}'),
              subtitle: Text('\$${item['total'] ?? 0} USD'),
            );
          }),
          const Divider(),
          MarketplaceOrderTimeline(order: order),
          if (trackingUrl.isNotEmpty) ...[
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => _openTracking(trackingUrl),
                icon: const Icon(Icons.local_shipping),
                label: const Text('Abrir seguimiento'),
              ),
            ),
          ],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      appBar: AppBar(
        title: const Text('Mis compras de Farmacia'),
        actions: [
          IconButton(
            onPressed: _loadOrders,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(
                      _error!,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.red),
                    ),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadOrders,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      const Text(
                        'Seguimiento de pedidos',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Aquí puedes revisar cada etapa y abrir la guía de envío.',
                      ),
                      const SizedBox(height: 18),
                      if (_orders.isEmpty)
                        const Padding(
                          padding: EdgeInsets.all(40),
                          child: Center(
                            child: Text('Aún no tienes compras en Farmacia'),
                          ),
                        )
                      else
                        ..._orders.map(_orderCard),
                    ],
                  ),
                ),
    );
  }
}
