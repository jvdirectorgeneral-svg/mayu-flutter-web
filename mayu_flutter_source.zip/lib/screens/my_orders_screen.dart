import 'package:flutter/material.dart';

import '../services/auth_service.dart';
import '../services/order_service.dart';
import '../widgets/mayu_scaffold.dart';

class MyOrdersScreen extends StatefulWidget {
  final int? userId;

  const MyOrdersScreen({
    super.key,
    this.userId,
  });

  @override
  State<MyOrdersScreen> createState() => _MyOrdersScreenState();
}

class _MyOrdersScreenState extends State<MyOrdersScreen> {
  final AuthService _authService = AuthService();
  final OrderService _orderService = OrderService();

  bool _loading = true;
  String? _error;
  int? _userId;

  List<Map<String, dynamic>> _orders = [];

  @override
  void initState() {
    super.initState();
    _loadOrders();
  }

  Future<int?> _resolveUserId() async {
    if (widget.userId != null) return widget.userId;

    final user = await _authService.getUser();
    final rawId = user?['id'];

    if (rawId == null) return null;

    return int.tryParse(rawId.toString());
  }

  String _extractErrorMessage(dynamic data, String fallback) {
    if (data == null) return fallback;

    if (data is String && data.trim().isNotEmpty) return data;

    if (data is Map<String, dynamic>) {
      final detail = data['detail'];

      if (detail is String && detail.trim().isNotEmpty) return detail;

      final message = data['message'];
      if (message is String && message.trim().isNotEmpty) return message;
    }

    return fallback;
  }

  List<Map<String, dynamic>> _parseOrders(dynamic data) {
    if (data is Map && data['items'] is List) {
      return (data['items'] as List)
          .whereType<Map>()
          .map((item) => Map<String, dynamic>.from(item))
          .toList();
    }

    if (data is List) {
      return data
          .whereType<Map>()
          .map((item) => Map<String, dynamic>.from(item))
          .toList();
    }

    return [];
  }

  Future<void> _loadOrders() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final userId = await _resolveUserId();

      if (userId == null) {
        setState(() {
          _loading = false;
          _error = 'No se pudo identificar el usuario';
        });
        return;
      }

      final result = await _orderService.getUserOrders(userId: userId);

      if (!mounted) return;

      if (result['statusCode'] != 200 && result['statusCode'] != 201) {
        setState(() {
          _loading = false;
          _error = _extractErrorMessage(
            result['data'],
            'No se pudieron cargar tus pedidos',
          );
        });
        return;
      }

      setState(() {
        _userId = userId;
        _orders = _parseOrders(result['data']);
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _loading = false;
        _error = 'Error cargando pedidos: $e';
      });
    }
  }

  String _statusLabel(String? status) {
    switch (status) {
      case 'pending_payment_review':
        return 'Pendiente de revisión';
      case 'approved_for_logistics':
        return 'Liberado a logística';
      case 'preparing':
        return 'En preparación';
      case 'shipped':
        return 'Despachado';
      case 'delivered':
        return 'Entregado';
      case 'cancelled':
        return 'Cancelado';
      default:
        return status ?? 'Sin estado';
    }
  }

  Color _statusColor(String? status) {
    switch (status) {
      case 'pending_payment_review':
        return Colors.orange;
      case 'approved_for_logistics':
        return Colors.blue;
      case 'preparing':
        return Colors.purple;
      case 'shipped':
        return Colors.teal;
      case 'delivered':
        return Colors.green;
      case 'cancelled':
        return Colors.red;
      default:
        return Colors.blueGrey;
    }
  }

  String _text(dynamic value, String fallback) {
    final text = value?.toString().trim();
    return text == null || text.isEmpty ? fallback : text;
  }

  Widget _buildOrderCard(Map<String, dynamic> order) {
    final int? orderId = int.tryParse(order['id']?.toString() ?? '');
    final status = order['status']?.toString();
    final items = order['items'];

    final List<Map<String, dynamic>> orderItems = items is List
        ? items
            .whereType<Map>()
            .map((item) => Map<String, dynamic>.from(item))
            .toList()
        : [];

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: InkWell(
        onTap: orderId == null
            ? null
            : () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => OrderDetailScreenStub(
                      orderId: orderId,
                    ),
                  ),
                );
              },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _text(order['order_code'], 'Pedido sin código'),
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              _text(order['month_label'] ?? order['monthLabel'], 'Sin ciclo'),
              style: const TextStyle(fontSize: 15),
            ),
            const SizedBox(height: 10),
            Chip(
              label: Text(
                _statusLabel(status),
                style: const TextStyle(color: Colors.white),
              ),
              backgroundColor: _statusColor(status),
            ),
            const SizedBox(height: 10),
            if (orderItems.isNotEmpty) ...[
              const Text(
                'Productos:',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 6),
              ...orderItems.take(4).map(
                    (item) => Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Text(
                        '• ${_text(item['name'] ?? item['product_name_snapshot'], 'Producto')}',
                      ),
                    ),
                  ),
              if (orderItems.length > 4)
                Text('+ ${orderItems.length - 4} productos más'),
            ],
            const SizedBox(height: 10),
            if (order['carrier'] != null ||
                order['tracking_number'] != null) ...[
              const Divider(),
              Text(
                'Transportista: ${_text(order['carrier'], 'Pendiente')}',
              ),
              Text(
                'Guía: ${_text(order['tracking_number'], 'Pendiente')}',
              ),
            ],
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: orderId == null
                    ? null
                    : () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => OrderDetailScreenStub(
                              orderId: orderId,
                            ),
                          ),
                        );
                      },
                icon: const Icon(Icons.chevron_right),
                label: const Text('Ver detalle'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _emptyState() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
      ),
      child: const Column(
        children: [
          Icon(Icons.inventory_2_outlined, size: 48, color: Colors.black45),
          SizedBox(height: 12),
          Text(
            'Todavía no tienes pedidos.',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 6),
          Text(
            'Cuando tu selección mensual sea aprobada y liberada a logística, aparecerá aquí.',
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MayuScaffold(
      appBar: AppBar(
        title: const Text('Mis pedidos'),
        centerTitle: true,
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 620),
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : RefreshIndicator(
                    onRefresh: _loadOrders,
                    child: SingleChildScrollView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          const Text(
                            'Historial de pedidos',
                            style: TextStyle(
                              fontSize: 26,
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            _userId == null
                                ? ''
                                : 'Pedidos asociados a tu membresía Mayu',
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.black54),
                          ),
                          const SizedBox(height: 22),
                          if (_error != null)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 12),
                              child: Text(
                                _error!,
                                style: const TextStyle(color: Colors.red),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          if (_orders.isEmpty)
                            _emptyState()
                          else
                            ..._orders.map(_buildOrderCard),
                          const SizedBox(height: 12),
                          OutlinedButton.icon(
                            onPressed: _loadOrders,
                            icon: const Icon(Icons.refresh),
                            label: const Text('Actualizar pedidos'),
                          ),
                        ],
                      ),
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}

class OrderDetailScreenStub extends StatelessWidget {
  final int orderId;

  const OrderDetailScreenStub({
    super.key,
    required this.orderId,
  });

  @override
  Widget build(BuildContext context) {
    return MayuScaffold(
      appBar: AppBar(
        title: const Text('Detalle del pedido'),
        centerTitle: true,
      ),
      child: Center(
        child: Text(
          'Detalle del pedido #$orderId\n\nSiguiente pantalla por construir.',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}