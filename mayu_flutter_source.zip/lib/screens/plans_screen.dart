import 'package:flutter/material.dart';

class PlansScreen extends StatelessWidget {
  const PlansScreen({super.key});

  Widget _priceBox({
    required String title,
    required String value,
    required String note,
    required Color color,
  }) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 2),
          Text(note, style: const TextStyle(fontSize: 13)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final plans = [
      {
        'name': 'Nivel 1 - Cobre',
        'firstPayment': '\$45 USD',
        'monthly': '\$40 USD / mes',
        'items': [
          '1 coloide a libre elección',
          '1 producto de línea CBD a elección',
          '1 producto de línea bienestar a elección',
        ],
      },
      {
        'name': 'Nivel 2 - Plata',
        'firstPayment': '\$55 USD',
        'monthly': '\$50 USD / mes',
        'items': [
          '1 coloide a libre elección',
          '1 producto de hongos medicinales a elección',
          '1 producto de línea CBD a elección',
          '1 producto de línea bienestar a elección',
        ],
      },
      {
        'name': 'Nivel 3 - Oro',
        'firstPayment': '\$65 USD',
        'monthly': '\$60 USD / mes',
        'items': [
          '1 coloide a libre elección',
          '1 producto de línea CBD a elección',
          '1 producto de línea bienestar CBD a elección',
          '1 producto de soporte funcional a elección',
          '1 producto extra de bienestar a elección',
        ],
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Planes Mayu'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: ListView.builder(
          itemCount: plans.length,
          itemBuilder: (context, index) {
            final plan = plans[index];

            return Container(
              margin: const EdgeInsets.only(bottom: 18),
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.65),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.black12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    plan['name'] as String,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  _priceBox(
                    title: 'Primer pago',
                    value: plan['firstPayment'] as String,
                    note:
                        'Incluye inscripción inicial única de \$5 + primera mensualidad.',
                    color: Colors.teal,
                  ),
                  _priceBox(
                    title: 'Pago mensual recurrente',
                    value: plan['monthly'] as String,
                    note: 'Cobro recurrente para mantener activo el plan.',
                    color: Colors.deepPurple,
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Incluye:',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 8),
                  ...(plan['items'] as List<String>).map(
                    (item) => Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('• ', style: TextStyle(fontSize: 18)),
                          Expanded(
                            child: Text(
                              item,
                              style: const TextStyle(fontSize: 17),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}