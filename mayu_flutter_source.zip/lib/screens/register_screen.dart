import 'package:flutter/material.dart';
import '../core/membership_rules.dart';
import '../services/auth_service.dart';
import '../services/register_service.dart';
import '../widgets/mayu_logo.dart';
import '../widgets/mayu_scaffold.dart';

import 'payment_screen.dart';
import 'terms_screen.dart';
import 'privacy_policy_screen.dart';
import 'digital_policy_screen.dart';

class ProductSection {
  final String key;
  final String title;
  final List<String> options;

  ProductSection({
    required this.key,
    required this.title,
    required this.options,
  });
}

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final AuthService _authService = AuthService();
  final RegisterService _registerService = RegisterService();

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _cedulaController = TextEditingController();
  final TextEditingController _birthDateController = TextEditingController();
  final TextEditingController _cityController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _referenceController = TextEditingController();
  final TextEditingController _deliveryNotesController =
      TextEditingController();
  final TextEditingController _ambassadorCodeController =
      TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();

  bool _loading = false;
  bool _loadingProducts = false;
  String? _error;

  bool _acceptTerms = false;
  bool _acceptDataPolicy = false;
  bool _acceptDigitalPolicy = false;

  int? _selectedLevel = 1;

  final Map<int, String> _plans = {
    1: 'Nivel 1 - Cobre',
    2: 'Nivel 2 - Plata',
    3: 'Nivel 3 - Oro',
  };

  int selectedPlanLevel = 1;
  String selectedPlanName = 'Nivel 1 - Cobre';
  double selectedMonthlyPrice = MembershipRules.monthlyPrice(1);

  List<ProductSection> _productSections = [];
  final Map<String, String?> selectedProductsBySection = {};

  final List<String> clubBenefits = [
    '15% de descuento en consultas',
    '15% de descuento en terapias',
    '10% de descuento en compras de Farmacia Mayu',
    'Ingreso gratuito a Mayu Educación',
  ];

  @override
  void initState() {
    super.initState();
    updateSelectedPlan(1);
  }

  Future<void> _pickBirthDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime(1990, 1, 1),
      firstDate: DateTime(1900, 1, 1),
      lastDate: DateTime.now(),
    );

    if (picked != null) {
      final year = picked.year.toString().padLeft(4, '0');
      final month = picked.month.toString().padLeft(2, '0');
      final day = picked.day.toString().padLeft(2, '0');

      setState(() {
        _birthDateController.text = '$year-$month-$day';
      });
    }
  }

  List<ProductSection> _buildSectionsFromBackendSections(dynamic data) {
    if (data is! Map || data['sections'] is! List) {
      return [];
    }

    final List rawSections = data['sections'] as List;

    return rawSections
        .map((section) {
          if (section is! Map) {
            return ProductSection(key: '', title: '', options: []);
          }

          final map = Map<String, dynamic>.from(section);

          final String key =
              (map['section_key'] ?? map['key'] ?? '').toString().trim();

          final String title =
              (map['section_name'] ?? map['title'] ?? '').toString().trim();

          final List<String> options = map['options'] is List
              ? List<String>.from(
                  (map['options'] as List).map((e) => e.toString().trim()),
                ).where((e) => e.isNotEmpty).toList()
              : <String>[];

          return ProductSection(
            key: key,
            title: title,
            options: options,
          );
        })
        .where(
          (section) =>
              section.key.isNotEmpty &&
              section.title.isNotEmpty &&
              section.options.isNotEmpty,
        )
        .toList();
  }

  Future<void> updateSelectedPlan(int level) async {
    setState(() {
      selectedPlanLevel = level;
      _selectedLevel = level;
      _loadingProducts = true;
      _error = null;

      if (level == 1) {
        selectedPlanName = 'Nivel 1 - Cobre';
        selectedMonthlyPrice = MembershipRules.monthlyPrice(1);
      } else if (level == 2) {
        selectedPlanName = 'Nivel 2 - Plata';
        selectedMonthlyPrice = MembershipRules.monthlyPrice(2);
      } else {
        selectedPlanName = 'Nivel 3 - Oro';
        selectedMonthlyPrice = MembershipRules.monthlyPrice(3);
      }

      selectedProductsBySection.clear();
      _productSections = [];
    });

    try {
      final result = await _registerService.getPlanOptions(planId: level);

      if (!mounted) return;

      if (result['statusCode'] != 200) {
        setState(() {
          _loadingProducts = false;
          _error = 'No se pudieron cargar los productos del plan';
        });
        return;
      }

      final data = result['data'];
      final sections = _buildSectionsFromBackendSections(data);

      setState(() {
        _productSections = sections;
        selectedProductsBySection.clear();

        for (final section in sections) {
          selectedProductsBySection[section.key] = section.options.first;
        }

        _loadingProducts = false;
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _loadingProducts = false;
        _error = 'Error cargando productos del plan';
      });
    }
  }

  List<ProductSection> getProductSectionsByLevel(int level) {
    return _productSections;
  }

  List<String> get selectedInitialProducts {
    return _productSections
        .map((section) => selectedProductsBySection[section.key])
        .where((value) => value != null && value.trim().isNotEmpty)
        .map((value) => value!.trim())
        .toList();
  }

  String _formatMoney(double value) {
    return value == value.roundToDouble()
        ? value.toStringAsFixed(0)
        : value.toStringAsFixed(2);
  }

  bool get _legalAccepted =>
      _acceptTerms && _acceptDataPolicy && _acceptDigitalPolicy;

  void _openLegalScreen(Widget screen) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => screen),
    );
  }

  Widget buildPlanSummaryCard() {
    final String monthlyText = _formatMoney(selectedMonthlyPrice);

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 16),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            selectedPlanName,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Text(
            'Primer cobro: \$$monthlyText USD',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 6),
          Text(
            'Sin cuota de inscripción. IVA 0%.',
            style: const TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 8),
          Text(
            'Pago mensual recurrente: \$$monthlyText USD',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 14),
          const Text(
            MembershipRules.recurringDebitDisclosure,
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 14),
          const Text(
            'Incluye selección inicial:',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 10),
          if (_loadingProducts)
            const Text('Cargando productos del plan...')
          else if (_productSections.isEmpty)
            const Text('No hay productos configurados para este plan.')
          else
            ..._productSections.map(
              (section) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('• ', style: TextStyle(fontSize: 18)),
                    Expanded(
                      child: Text(
                        section.title,
                        style: const TextStyle(fontSize: 17),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget buildInitialProductsDropdowns() {
    final sections = getProductSectionsByLevel(selectedPlanLevel);

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 16),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Elige tus productos iniciales',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          if (_loadingProducts)
            const Center(child: CircularProgressIndicator())
          else if (sections.isEmpty)
            const Text('No hay productos disponibles para este plan.')
          else
            ...sections.map((section) {
              final selectedValue = selectedProductsBySection[section.key];
              final validValue = section.options.contains(selectedValue)
                  ? selectedValue
                  : null;

              return Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: DropdownButtonFormField<String>(
                  initialValue: validValue,
                  decoration: InputDecoration(
                    labelText: section.title,
                    border: const OutlineInputBorder(),
                  ),
                  items: section.options.map((String option) {
                    return DropdownMenuItem<String>(
                      value: option,
                      child: Text(option),
                    );
                  }).toList(),
                  onChanged: (String? value) {
                    setState(() {
                      selectedProductsBySection[section.key] = value;
                    });
                  },
                ),
              );
            }),
        ],
      ),
    );
  }

  Widget buildBenefitsCard() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 16),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Beneficios del Club Mayu',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          ...clubBenefits.map(
            (String benefit) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('• ', style: TextStyle(fontSize: 18)),
                  Expanded(
                    child: Text(benefit, style: const TextStyle(fontSize: 17)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildLegalCheckboxes() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 16),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Aceptaciones obligatorias',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          CheckboxListTile(
            value: _acceptTerms,
            controlAffinity: ListTileControlAffinity.leading,
            contentPadding: EdgeInsets.zero,
            title: const Text('Acepto los términos y condiciones'),
            subtitle: TextButton(
              onPressed: () => _openLegalScreen(const TermsScreen()),
              child: const Align(
                alignment: Alignment.centerLeft,
                child: Text('Leer términos y condiciones'),
              ),
            ),
            onChanged: (value) {
              setState(() {
                _acceptTerms = value ?? false;
              });
            },
          ),
          CheckboxListTile(
            value: _acceptDataPolicy,
            controlAffinity: ListTileControlAffinity.leading,
            contentPadding: EdgeInsets.zero,
            title: const Text('Acepto el tratamiento de datos personales'),
            subtitle: TextButton(
              onPressed: () => _openLegalScreen(const PrivacyPolicyScreen()),
              child: const Align(
                alignment: Alignment.centerLeft,
                child: Text('Leer política de datos personales'),
              ),
            ),
            onChanged: (value) {
              setState(() {
                _acceptDataPolicy = value ?? false;
              });
            },
          ),
          CheckboxListTile(
            value: _acceptDigitalPolicy,
            controlAffinity: ListTileControlAffinity.leading,
            contentPadding: EdgeInsets.zero,
            title:
                const Text('Acepto las políticas digitales y notificaciones'),
            subtitle: TextButton(
              onPressed: () => _openLegalScreen(const DigitalPolicyScreen()),
              child: const Align(
                alignment: Alignment.centerLeft,
                child: Text('Leer política digital'),
              ),
            ),
            onChanged: (value) {
              setState(() {
                _acceptDigitalPolicy = value ?? false;
              });
            },
          ),
        ],
      ),
    );
  }

  Future<void> _register() async {
    final String name = _nameController.text.trim();
    final String email = _emailController.text.trim();
    final String phone = _phoneController.text.trim();
    final String cedula = _cedulaController.text.trim();
    final String birthDate = _birthDateController.text.trim();
    final String city = _cityController.text.trim();
    final String address = _addressController.text.trim();
    final String reference = _referenceController.text.trim();
    final String deliveryNotes = _deliveryNotesController.text.trim();
    final String ambassadorCode = _ambassadorCodeController.text.trim();
    final String password = _passwordController.text.trim();
    final String confirmPassword = _confirmPasswordController.text.trim();

    FocusScope.of(context).unfocus();

    if (name.isEmpty ||
        email.isEmpty ||
        phone.isEmpty ||
        cedula.isEmpty ||
        city.isEmpty ||
        address.isEmpty ||
        reference.isEmpty ||
        deliveryNotes.isEmpty ||
        password.isEmpty) {
      setState(() {
        _error = 'Todos los campos obligatorios deben completarse';
      });
      return;
    }

    if (_selectedLevel == null) {
      setState(() {
        _error = 'Selecciona un plan';
      });
      return;
    }

    if (_loadingProducts || _productSections.isEmpty) {
      setState(() {
        _error = 'Espera a que carguen los productos del plan';
      });
      return;
    }

    if (selectedInitialProducts.length != _productSections.length) {
      setState(() {
        _error = 'Selecciona todos tus productos iniciales';
      });
      return;
    }

    if (password != confirmPassword) {
      setState(() {
        _error = 'Las contraseñas no coinciden';
      });
      return;
    }

    if (!_legalAccepted) {
      setState(() {
        _error =
            'Debes aceptar términos, tratamiento de datos y políticas digitales para continuar';
      });
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final registerResult = await _registerService.registerUser(
        name: name,
        email: email,
        phone: phone,
        cedula: cedula,
        birthDate: birthDate.isEmpty ? null : birthDate,
        city: city,
        address: address,
        reference: reference,
        deliveryNotes: deliveryNotes,
        phoneSecondary: null,
        password: password,
        ambassadorCode: ambassadorCode.isEmpty ? null : ambassadorCode,
        acceptedTerms: _acceptTerms,
        acceptedPrivacyPolicy: _acceptDataPolicy,
        acceptedDigitalPolicy: _acceptDigitalPolicy,
      );

      if (registerResult['statusCode'] != 200 &&
          registerResult['statusCode'] != 201) {
        setState(() {
          _loading = false;
          _error = registerResult['data']?['detail'] ??
              'No se pudo registrar el usuario';
        });
        return;
      }

      final dynamic userData = registerResult['data'];
      final dynamic userIdRaw = userData['id'];
      final int userId = int.tryParse(userIdRaw.toString()) ?? 0;

      if (userId == 0) {
        setState(() {
          _loading = false;
          _error = 'Usuario creado, pero no se pudo continuar';
        });
        return;
      }

      await _authService.logout();
      await _authService.login(email: email, password: password);

      if (!mounted) return;

      setState(() {
        _loading = false;
      });

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => PaymentScreen(
            userId: userId,
            name: name,
            email: email,
            planLevel: selectedPlanLevel,
            planName: selectedPlanName,
            price: selectedMonthlyPrice,
            initialProducts: selectedInitialProducts,
            ambassadorCode: ambassadorCode.isEmpty ? null : ambassadorCode,
            loginPassword: password,
          ),
        ),
      );
    } catch (_) {
      setState(() {
        _loading = false;
        _error = 'Error durante el registro';
      });
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _cedulaController.dispose();
    _birthDateController.dispose();
    _cityController.dispose();
    _addressController.dispose();
    _referenceController.dispose();
    _deliveryNotesController.dispose();
    _ambassadorCodeController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool canContinue = !_loading && !_loadingProducts && _legalAccepted;

    return MayuScaffold(
      appBar: AppBar(
        title: const Text('Registro Mayu Wellness Club'),
        centerTitle: true,
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 550),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const MayuLogo(height: 95),
                  const SizedBox(height: 16),
                  const Text(
                    'Crear cuenta y elegir plan',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),
                  TextField(
                    controller: _nameController,
                    decoration: const InputDecoration(
                      labelText: 'Nombre completo',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _emailController,
                    decoration: const InputDecoration(
                      labelText: 'Email',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _phoneController,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(
                      labelText: 'Número de celular',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _cedulaController,
                    decoration: const InputDecoration(
                      labelText: 'Número de cédula',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _birthDateController,
                    readOnly: true,
                    decoration: const InputDecoration(
                      labelText: 'Fecha de nacimiento (opcional)',
                      hintText: 'YYYY-MM-DD',
                      border: OutlineInputBorder(),
                    ),
                    onTap: _pickBirthDate,
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _cityController,
                    decoration: const InputDecoration(
                      labelText: 'Ciudad',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _addressController,
                    maxLines: 2,
                    decoration: const InputDecoration(
                      labelText: 'Dirección completa',
                      hintText:
                          'Ejemplo: Calle, número, edificio, casa o departamento',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _referenceController,
                    decoration: const InputDecoration(
                      labelText: 'Referencia',
                      hintText: 'Ejemplo: Frente al parque, junto a farmacia',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Datos de facturación',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Nombre / Razón social, cédula o RUC, ciudad, teléfono y correo electrónico',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.black54,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _deliveryNotesController,
                    maxLines: 3,
                    decoration: const InputDecoration(
                      labelText: 'Escribe tus datos de facturación',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _ambassadorCodeController,
                    decoration: const InputDecoration(
                      labelText: 'Código o PIN de embajador (opcional)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _passwordController,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Contraseña',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _confirmPasswordController,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Confirmar contraseña',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<int>(
                    initialValue: _selectedLevel,
                    decoration: const InputDecoration(
                      labelText: 'Selecciona tu plan',
                      border: OutlineInputBorder(),
                    ),
                    items: _plans.entries.map((MapEntry<int, String> entry) {
                      return DropdownMenuItem<int>(
                        value: entry.key,
                        child: Text(entry.value),
                      );
                    }).toList(),
                    onChanged: (int? value) {
                      if (value != null) updateSelectedPlan(value);
                    },
                  ),
                  buildPlanSummaryCard(),
                  buildInitialProductsDropdowns(),
                  buildBenefitsCard(),
                  buildLegalCheckboxes(),
                  const SizedBox(height: 16),
                  if (_error != null)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Text(
                        _error!,
                        style: const TextStyle(color: Colors.red),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: canContinue ? _register : null,
                      child: _loading
                          ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Text('Continuar al pago PayPal'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
