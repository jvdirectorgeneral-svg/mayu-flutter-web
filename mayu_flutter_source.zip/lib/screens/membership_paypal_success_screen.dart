import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../services/auth_service.dart';
import '../services/monthly_selection_service.dart';
import '../services/subscription_service.dart';
import '../widgets/mayu_scaffold.dart';
import 'digital_card_screen.dart';

class MembershipPaypalSuccessScreen extends StatefulWidget {
  const MembershipPaypalSuccessScreen({
    super.key,
    this.userId,
    this.subscriptionId,
    this.paymentStatus,
    this.planLevel,
  });

  final int? userId;
  final String? subscriptionId;
  final String? paymentStatus;
  final int? planLevel;

  @override
  State<MembershipPaypalSuccessScreen> createState() =>
      _MembershipPaypalSuccessScreenState();
}

class _MembershipPaypalSuccessScreenState
    extends State<MembershipPaypalSuccessScreen> {
  static const String _pendingKey = 'mayu_pending_subscription';

  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  final AuthService _authService = AuthService();
  final SubscriptionService _subscriptionService = SubscriptionService();
  final MonthlySelectionService _monthlySelectionService =
      MonthlySelectionService();

  bool _loading = true;
  bool _success = false;
  String? _error;
  Map<String, dynamic> _pending = {};
  Map<String, dynamic>? _activationData;

  @override
  void initState() {
    super.initState();
    _confirmMembership();
  }

  int? _intFrom(dynamic value) {
    if (value == null) return null;
    if (value is int) return value;
    return int.tryParse(value.toString());
  }

  String _stringFrom(dynamic value) {
    return value == null ? '' : value.toString().trim();
  }

  List<String> _pendingProducts() {
    final raw = _pending['initial_products'];
    if (raw is List) {
      return raw
          .map((item) => item.toString().trim())
          .where((item) => item.isNotEmpty)
          .toList();
    }
    return <String>[];
  }

  String _pendingName() {
    final value = _stringFrom(_pending['name']);
    return value.isNotEmpty ? value : 'Socio Mayu';
  }

  String _pendingPlanName() {
    final value = _stringFrom(_pending['plan_name']);
    return value.isNotEmpty ? value : 'Mayu Wellness Club';
  }

  String _extractErrorMessage(dynamic data, String fallback) {
    if (data == null) return fallback;
    if (data is String && data.trim().isNotEmpty) return data;

    if (data is Map<String, dynamic>) {
      final detail = data['detail'];
      if (detail is String && detail.trim().isNotEmpty) return detail;
      if (detail is Map && detail['message'] != null) {
        return detail['message'].toString();
      }
      final message = data['message'];
      if (message is String && message.trim().isNotEmpty) return message;
    }

    return fallback;
  }

  Future<void> _loadPending() async {
    final raw = await _storage.read(key: _pendingKey);
    if (raw == null || raw.trim().isEmpty) return;

    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map) {
        _pending = Map<String, dynamic>.from(decoded);
      }
    } catch (_) {
      _pending = {};
    }
  }

  Future<Map<String, dynamic>> _activateWithRetry({
    required int userId,
    required String subscriptionId,
  }) async {
    Map<String, dynamic> result = {};

    for (int i = 0; i < 5; i++) {
      result = await _subscriptionService.activateLevel1Subscription(
        userId: userId,
        subscriptionId: subscriptionId,
      );

      if (result['statusCode'] == 200 || result['statusCode'] == 201) {
        return result;
      }

      await Future.delayed(const Duration(seconds: 2));
    }

    return result;
  }

  Future<void> _confirmMembership() async {
    final status = (widget.paymentStatus ?? 'approved').toLowerCase();

    if (status == 'cancelled' || status == 'cancel') {
      setState(() {
        _loading = false;
        _success = false;
        _error = 'PayPal canceló el proceso. La membresía no se activó.';
      });
      return;
    }

    await _loadPending();

    final userId = widget.userId ?? _intFrom(_pending['user_id']);
    final subscriptionId = _stringFrom(widget.subscriptionId).isNotEmpty
        ? _stringFrom(widget.subscriptionId)
        : _stringFrom(_pending['subscription_id']);

    if (userId == null || userId == 0 || subscriptionId.isEmpty) {
      setState(() {
        _loading = false;
        _success = false;
        _error =
            'No se encontró la información del pago. Regresa a la app y toca confirmar otra vez.';
      });
      return;
    }

    final activateResult = await _activateWithRetry(
      userId: userId,
      subscriptionId: subscriptionId,
    );

    if (!mounted) return;

    if (activateResult['statusCode'] != 200 &&
        activateResult['statusCode'] != 201) {
      setState(() {
        _loading = false;
        _success = false;
        _error = _extractErrorMessage(
          activateResult['data'],
          'PayPal aprobó el pago, pero aún no confirma la suscripción. Espera unos segundos y vuelve a confirmar.',
        );
      });
      return;
    }

    final activationData =
        Map<String, dynamic>.from(activateResult['data'] as Map);
    final selectionId = _intFrom(
      activationData['selection_id'] ?? activationData['id'],
    );
    final products = _pendingProducts();

    if (selectionId != null && selectionId > 0 && products.isNotEmpty) {
      final saveResult =
          await _monthlySelectionService.saveInitialSelectionsAfterPayment(
        selectionId: selectionId,
        productNames: products,
      );

      if (!mounted) return;

      if (saveResult['statusCode'] != 200 && saveResult['statusCode'] != 201) {
        setState(() {
          _loading = false;
          _success = false;
          _error = _extractErrorMessage(
            saveResult['data'],
            'La membresía se activó, pero no se pudieron guardar los productos iniciales.',
          );
        });
        return;
      }
    }

    final pendingEmail = _stringFrom(_pending['email']);
    final pendingPassword = _stringFrom(_pending['login_password']);
    if (pendingEmail.isNotEmpty && pendingPassword.isNotEmpty) {
      await _authService.logout();
      await _authService.login(email: pendingEmail, password: pendingPassword);
    }

    await _storage.delete(key: _pendingKey);

    if (!mounted) return;

    setState(() {
      _loading = false;
      _success = true;
      _activationData = activationData;
      _error = null;
    });
  }

  void _openDigitalCard() {
    final userId = widget.userId ?? _intFrom(_pending['user_id']);
    final name = _pendingName();
    final planName = _pendingPlanName();

    if (userId == null || userId == 0) return;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (_) => DigitalCardScreen(
          userId: userId,
          name: name,
          planName: planName,
        ),
      ),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return MayuScaffold(
      appBar: AppBar(
        title: const Text('Mayu Wellness Club'),
        centerTitle: true,
      ),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 520),
          child: Card(
            margin: const EdgeInsets.all(24),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Icon(
                    _loading
                        ? Icons.hourglass_top
                        : _success
                            ? Icons.check_circle
                            : Icons.info,
                    color: _success ? const Color(0xFF006450) : Colors.orange,
                    size: 72,
                  ),
                  const SizedBox(height: 18),
                  Text(
                    _loading
                        ? 'Confirmando tu membresía'
                        : _success
                            ? 'Bienvenido a Mayu Wellness Club'
                            : 'Revisar confirmación',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    _loading
                        ? 'Estamos validando el pago aprobado por PayPal.'
                        : _success
                            ? 'Tu membresía quedó activa. La salud nace de nuestros hábitos de todos los días.'
                            : (_error ?? 'No se pudo confirmar el pago.'),
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 16, height: 1.35),
                  ),
                  if (_activationData?['member_code'] != null) ...[
                    const SizedBox(height: 14),
                    Text(
                      'Tarjeta: ${_activationData!['member_code']}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ],
                  const SizedBox(height: 24),
                  if (_loading)
                    const Center(child: CircularProgressIndicator())
                  else if (_success)
                    ElevatedButton.icon(
                      onPressed: _openDigitalCard,
                      icon: const Icon(Icons.card_membership),
                      label: const Text('Ver mi tarjeta Mayu'),
                    )
                  else
                    ElevatedButton.icon(
                      onPressed: () {
                        setState(() {
                          _loading = true;
                          _error = null;
                        });
                        _confirmMembership();
                      },
                      icon: const Icon(Icons.verified),
                      label: const Text('Confirmar otra vez'),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
