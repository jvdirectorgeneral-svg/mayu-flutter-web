import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class PharmacyQrScannerScreen extends StatefulWidget {
  final String title;
  final String helperText;

  const PharmacyQrScannerScreen({
    super.key,
    this.title = 'Escanear QR Mayu Magistral',
    this.helperText =
        'Enfoca el QR de la Tarjeta Mayu Magistral para cargar el socio.',
  });

  @override
  State<PharmacyQrScannerScreen> createState() =>
      _PharmacyQrScannerScreenState();
}

class _PharmacyQrScannerScreenState extends State<PharmacyQrScannerScreen> {
  bool _handled = false;

  String _extractIdentifier(String rawValue) {
    final clean = rawValue.trim();
    final uri = Uri.tryParse(clean);
    final segments = uri?.pathSegments ?? const <String>[];
    final qrIndex = segments.indexOf('qr');
    if (qrIndex >= 0 && qrIndex + 1 < segments.length) {
      return segments[qrIndex + 1];
    }
    return clean;
  }

  void _handleCode(String? rawValue) {
    if (_handled) return;
    final value = rawValue?.trim();
    if (value == null || value.isEmpty) return;
    _handled = true;
    Navigator.pop(context, _extractIdentifier(value));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Stack(
        children: [
          MobileScanner(
            onDetect: (capture) {
              final barcodes = capture.barcodes;
              if (barcodes.isNotEmpty) {
                _handleCode(barcodes.first.rawValue);
              }
            },
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              width: double.infinity,
              margin: const EdgeInsets.all(18),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.70),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Text(
                widget.helperText,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
