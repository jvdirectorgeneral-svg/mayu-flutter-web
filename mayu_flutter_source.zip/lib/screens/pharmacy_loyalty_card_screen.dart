import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/pharmacy_location_reminder_service.dart';
import '../services/pharmacy_loyalty_service.dart';
import 'pharmacy_customer_register_screen.dart';
import 'pharmacy_customer_recover_screen.dart';

class PharmacyLoyaltyCardScreen extends StatefulWidget {
  const PharmacyLoyaltyCardScreen({super.key});

  @override
  State<PharmacyLoyaltyCardScreen> createState() =>
      _PharmacyLoyaltyCardScreenState();
}

class _PharmacyLoyaltyCardScreenState extends State<PharmacyLoyaltyCardScreen> {
  final PharmacyLoyaltyService _service = PharmacyLoyaltyService();
  bool _loading = true;
  bool _needsAuth = false;
  String? _error;
  Map<String, dynamic>? _card;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _needsAuth = false;
      _error = null;
    });

    final hasSession = await _service.hasPharmacySession();
    if (!mounted) return;

    if (!hasSession) {
      setState(() {
        _loading = false;
        _needsAuth = true;
      });
      return;
    }

    final result = await _service.getMyCard();
    if (!mounted) return;

    if (result['statusCode'] == 200) {
      setState(() {
        _card = Map<String, dynamic>.from(result['data']);
        _loading = false;
      });
      await PharmacyLocationReminderService.instance.startLocationReminders();
    } else if (result['statusCode'] == 401 || result['statusCode'] == 403) {
      await _service.logoutPharmacyCustomer();
      if (!mounted) return;
      setState(() {
        _loading = false;
        _needsAuth = true;
      });
    } else {
      setState(() {
        _loading = false;
        _error = result['data']?['detail']?.toString() ??
            'No se pudo cargar tu Tarjeta Farmacia';
      });
    }
  }

  Future<void> _openRegister() async {
    final ok = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => const PharmacyCustomerRegisterScreen()),
    );
    if (ok == true) await _load();
  }

  Future<void> _openRecover() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const PharmacyCustomerRecoverScreen()),
    );
  }

  Future<void> _logout() async {
    await _service.logoutPharmacyCustomer();
    if (!mounted) return;
    setState(() {
      _card = null;
      _needsAuth = true;
      _error = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final card = _card;
    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      appBar: AppBar(
        title: const Text('Tarjeta Mayu Magistral'),
        actions: [
          if (card != null)
            IconButton(
              tooltip: 'Cerrar sesión farmacia',
              onPressed: _logout,
              icon: const Icon(Icons.logout),
            ),
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _needsAuth
              ? _AuthGate(onRegister: _openRegister, onRecover: _openRecover)
              : _error != null
                  ? Center(child: Text(_error!))
                  : _CardContent(card: card ?? {}),
    );
  }
}

class _AuthGate extends StatelessWidget {
  const _AuthGate({required this.onRegister, required this.onRecover});

  final VoidCallback onRegister;
  final VoidCallback onRecover;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(22),
        child: Container(
          constraints: const BoxConstraints(maxWidth: 520),
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(22),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.08),
                blurRadius: 16,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.local_pharmacy,
                color: Color(0xFF00695C),
                size: 64,
              ),
              const SizedBox(height: 14),
              const Text(
                'Activa tu Tarjeta Mayu Magistral',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text(
                'Afíliate y acumula 1 punto por cada \$10 en compras pagadas.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 22),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: onRegister,
                  icon: const Icon(Icons.card_membership),
                  label: const Text('Activar Tarjeta Mayu Magistral'),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: onRecover,
                  icon: const Icon(Icons.restore),
                  label: const Text('Recuperar tarjeta'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CardContent extends StatelessWidget {
  const _CardContent({required this.card});

  final Map<String, dynamic> card;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF00695C), Color(0xFF26A69A)],
            ),
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'TARJETA MAYU MAGISTRAL',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
              const SizedBox(height: 20),
              Text(
                card['customer_name']?.toString() ?? '',
                style: const TextStyle(color: Colors.white, fontSize: 19),
              ),
              Text(
                card['card_code']?.toString() ?? '',
                style: const TextStyle(color: Colors.white70),
              ),
              const SizedBox(height: 20),
              Text(
                '${card['points_balance'] ?? 0} puntos',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 34,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                '1 punto por cada \$10 acumulados',
                style: TextStyle(color: Colors.white70),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        if ((card['qr_image_url'] ?? '').toString().isNotEmpty)
          Center(
            child: Image.network(
              card['qr_image_url'].toString(),
              width: 220,
              height: 220,
            ),
          ),
        const SizedBox(height: 10),
        Text(
          'Acumulado para el próximo punto: '
          '\$${_money(card['accumulated_cents'])}',
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 18),
        _WalletButtons(card: card),
      ],
    );
  }

  String _money(dynamic cents) {
    final value =
        cents is num ? cents : num.tryParse(cents?.toString() ?? '0') ?? 0;
    return (value / 100).toStringAsFixed(2);
  }
}

class _WalletButtons extends StatelessWidget {
  const _WalletButtons({required this.card});

  final Map<String, dynamic> card;

  Future<void> _open(
    BuildContext context,
    String? url,
    String unavailableMessage,
  ) async {
    final cleanUrl = url?.trim();
    if (cleanUrl == null || cleanUrl.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(unavailableMessage)));
      return;
    }

    final opened = await launchUrl(
      Uri.parse(cleanUrl),
      mode: LaunchMode.externalApplication,
    );

    if (!opened && context.mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(unavailableMessage)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final appleUrl = card['apple_wallet_url']?.toString();
    final googleUrl = card['google_wallet_url']?.toString();

    return Column(
      children: [
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: () => _open(
              context,
              appleUrl,
              'Apple Wallet estará disponible cuando se configure el certificado.',
            ),
            icon: const Icon(Icons.wallet),
            label: const Text('Descargar tarjeta Wallet iOS'),
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: () => _open(
              context,
              googleUrl,
              'Android Wallet estará disponible cuando se configure Google Wallet.',
            ),
            icon: const Icon(Icons.account_balance_wallet),
            label: const Text('Descargar tarjeta Wallet Android'),
          ),
        ),
      ],
    );
  }
}
