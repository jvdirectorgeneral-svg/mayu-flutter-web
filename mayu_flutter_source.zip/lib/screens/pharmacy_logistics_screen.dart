import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/marketplace_service.dart';
import '../widgets/marketplace_order_timeline.dart';

class PharmacyLogisticsScreen extends StatefulWidget {
  const PharmacyLogisticsScreen({super.key});

  @override
  State<PharmacyLogisticsScreen> createState() =>
      _PharmacyLogisticsScreenState();
}

class _PharmacyLogisticsScreenState extends State<PharmacyLogisticsScreen> {
  final MarketplaceService _service = MarketplaceService();

  bool _loading = true;
  String? _error;

  List<dynamic> _orders = [];

  @override
  void initState() {
    super.initState();
    _loadOrders();
  }

  String _textOrPending(dynamic value) {
    final text = (value ?? '').toString().trim();
    return text.isEmpty ? 'Pendiente' : text;
  }

  String _cleanPhoneForWhatsApp(String value) {
    var phone = value.replaceAll(RegExp(r'[^0-9+]'), '');

    if (phone.startsWith('+')) {
      phone = phone.substring(1);
    }

    if (phone.startsWith('0')) {
      phone = '593${phone.substring(1)}';
    }

    if (!phone.startsWith('593')) {
      phone = '593$phone';
    }

    return phone;
  }

  Future<void> _openExternalUrl(Uri uri) async {
    final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);

    if (!opened && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No se pudo abrir el enlace')),
      );
    }
  }

  Future<void> _loadOrders() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final result = await _service.getAdminOrders();

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      final allOrders =
          result['data']?['items'] is List ? result['data']['items'] : [];

      setState(() {
        _orders = allOrders.where((order) {
          final map = Map<String, dynamic>.from(order);
          return map['admin_verified'] == true ||
              map['status'] == 'admin_approved' ||
              map['status'] == 'prepared' ||
              map['status'] == 'shipped' ||
              map['status'] == 'delivered';
        }).toList();

        _loading = false;
      });
    } else {
      setState(() {
        _loading = false;
        _error = result['data']?['detail']?.toString() ??
            'No se pudieron cargar los pedidos';
      });
    }
  }

  Future<void> _openWhatsApp(Map<String, dynamic> order) async {
    final rawPhone = (order['customer_phone'] ?? '').toString();

    if (rawPhone.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('El cliente no tiene teléfono registrado')),
      );
      return;
    }

    final phone = _cleanPhoneForWhatsApp(rawPhone);
    final items = order['items'] is List ? order['items'] as List : [];

    final productsText = items.map((item) {
      final p = Map<String, dynamic>.from(item);
      return '• ${p['product_name']} x${p['quantity']}';
    }).join('\n');

    final message = '''
Hola ${order['customer_name'] ?? ''}, le escribimos de Mayu Farmacia sobre su pedido ${order['order_code'] ?? ''}.

Su pedido fue enviado.

Productos:
$productsText

Datos de entrega:
Ciudad: ${order['city'] ?? ''}
Dirección: ${order['address'] ?? ''}

Transportadora: ${_textOrPending(order['carrier'])}
Guía: ${_textOrPending(order['tracking_number'])}
Tracking: ${_textOrPending(order['tracking_url'])}

Total: \$${order['total'] ?? 0} USD

Gracias por comprar en Mayu Farmacia.
''';

    final uri = Uri.parse(
      'https://wa.me/$phone?text=${Uri.encodeComponent(message)}',
    );

    await _openExternalUrl(uri);
  }

  Future<void> _openEmail(Map<String, dynamic> order) async {
    final email = (order['customer_email'] ?? '').toString();

    if (email.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('El cliente no tiene email registrado')),
      );
      return;
    }

    final subject = Uri.encodeComponent(
      'Pedido Mayu ${order['order_code'] ?? ''}',
    );

    final body = Uri.encodeComponent('''
Hola ${order['customer_name'] ?? ''},

Le escribimos de Mayu Farmacia sobre su pedido ${order['order_code'] ?? ''}.

Su pedido fue enviado.

Ciudad: ${order['city'] ?? ''}
Dirección: ${order['address'] ?? ''}
Transportadora: ${_textOrPending(order['carrier'])}
Guía: ${_textOrPending(order['tracking_number'])}
Tracking: ${_textOrPending(order['tracking_url'])}
Total: \$${order['total'] ?? 0} USD

Equipo Mayu
''');

    final uri = Uri.parse('mailto:$email?subject=$subject&body=$body');

    await _openExternalUrl(uri);
  }

  Future<void> _downloadInvoice(Map<String, dynamic> order) async {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('PDF de factura pendiente de conectar al backend'),
      ),
    );
  }

  Future<void> _markPrepared(Map<String, dynamic> order) async {
    final result = await _service.updateMarketplaceOrderByLogistics(
      orderId: order['id'],
      status: 'prepared',
      shippingNotes: 'Pedido preparado por logística',
    );

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      await _loadOrders();
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pedido marcado como preparado')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No se pudo preparar el pedido',
          ),
        ),
      );
    }
  }

  Future<void> _markShipped(Map<String, dynamic> order) async {
    final carrierController = TextEditingController(
      text: (order['carrier'] ?? '').toString(),
    );

    final trackingController = TextEditingController(
      text: (order['tracking_number'] ?? '').toString(),
    );

    final trackingUrlController = TextEditingController(
      text: (order['tracking_url'] ?? '').toString(),
    );

    final notesController = TextEditingController(
      text: (order['shipping_notes'] ?? '').toString(),
    );

    final confirm = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Agregar guía / tracking'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: carrierController,
                  decoration: const InputDecoration(
                    labelText: 'Transportadora',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: trackingController,
                  decoration: const InputDecoration(
                    labelText: 'Número de guía',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: trackingUrlController,
                  decoration: const InputDecoration(
                    labelText: 'Link de tracking',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: notesController,
                  minLines: 2,
                  maxLines: 4,
                  decoration: const InputDecoration(
                    labelText: 'Notas de envío',
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Guardar y enviar WhatsApp'),
            ),
          ],
        );
      },
    );

    if (confirm != true) return;
    if (!mounted) return;

    final carrier = carrierController.text.trim();
    final trackingNumber = trackingController.text.trim();
    final trackingUrl = trackingUrlController.text.trim();
    final shippingNotes = notesController.text.trim().isEmpty
        ? 'Despachado por logística'
        : notesController.text.trim();

    if (carrier.isEmpty || trackingNumber.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Transportadora y número de guía son obligatorios'),
        ),
      );
      return;
    }

    final result = await _service.updateMarketplaceOrderByLogistics(
      orderId: order['id'],
      status: 'shipped',
      carrier: carrier,
      trackingNumber: trackingNumber,
      trackingUrl: trackingUrl,
      shippingNotes: shippingNotes,
    );

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      final updatedOrder = Map<String, dynamic>.from(order);
      updatedOrder['status'] = 'shipped';
      updatedOrder['carrier'] = carrier;
      updatedOrder['tracking_number'] = trackingNumber;
      updatedOrder['tracking_url'] = trackingUrl;
      updatedOrder['shipping_notes'] = shippingNotes;

      await _openWhatsApp(updatedOrder);
      await _loadOrders();

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pedido enviado y tracking registrado')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No se pudo guardar el tracking',
          ),
        ),
      );
    }
  }

  Future<void> _markDelivered(Map<String, dynamic> order) async {
    final result = await _service.updateMarketplaceOrderByLogistics(
      orderId: order['id'],
      status: 'delivered',
      shippingNotes: 'Pedido entregado',
    );

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      await _loadOrders();
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pedido marcado como entregado')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No se pudo marcar el pedido como entregado',
          ),
        ),
      );
    }
  }

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(top: 10, bottom: 4),
      child: Text(
        title,
        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
      ),
    );
  }

  Widget _orderCard(Map<String, dynamic> order) {
    final items = order['items'] is List ? order['items'] as List : [];
    final status = (order['status'] ?? '').toString();

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              order['order_code'] ?? 'Pedido',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            _sectionTitle('Cliente / entrega'),
            Text('Cliente: ${order['customer_name'] ?? ''}'),
            Text('Teléfono: ${order['customer_phone'] ?? ''}'),
            Text('Email: ${order['customer_email'] ?? ''}'),
            Text('Ciudad: ${order['city'] ?? ''}'),
            Text('Dirección: ${order['address'] ?? ''}'),
            Text('Notas: ${order['delivery_notes'] ?? 'Sin notas'}'),
            _sectionTitle('Datos de facturación'),
            Text(
                'Razón social / Nombre: ${order['billing_name'] ?? order['customer_name'] ?? ''}'),
            Text('Cédula / RUC: ${order['billing_identification'] ?? ''}'),
            Text(
                'Email factura: ${order['billing_email'] ?? order['customer_email'] ?? ''}'),
            Text(
                'Teléfono factura: ${order['billing_phone'] ?? order['customer_phone'] ?? ''}'),
            Text(
                'Dirección factura: ${order['billing_address'] ?? order['address'] ?? ''}'),
            const Divider(),
            _sectionTitle('Productos'),
            ...items.map((item) {
              final p = Map<String, dynamic>.from(item);
              return Text(
                '• ${p['product_name']} x${p['quantity']} - \$${p['total']}',
              );
            }),
            const Divider(),
            Text('Pago: ${order['payment_status'] ?? ''}'),
            Text('Total: \$${order['total'] ?? 0} USD'),
            Chip(
              avatar: Icon(
                Icons.circle,
                size: 12,
                color: MarketplaceOrderTimeline.color(status),
              ),
              label: Text(MarketplaceOrderTimeline.label(status)),
            ),
            Text('Transportadora: ${_textOrPending(order['carrier'])}'),
            Text('Guía: ${_textOrPending(order['tracking_number'])}'),
            Text('Tracking: ${_textOrPending(order['tracking_url'])}'),
            Text('Notas envío: ${order['shipping_notes'] ?? ''}'),
            const Divider(),
            MarketplaceOrderTimeline(order: order),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ElevatedButton.icon(
                  icon: const Icon(Icons.chat),
                  label: const Text('WhatsApp'),
                  onPressed: () => _openWhatsApp(order),
                ),
                OutlinedButton.icon(
                  icon: const Icon(Icons.email),
                  label: const Text('Email'),
                  onPressed: () => _openEmail(order),
                ),
                OutlinedButton.icon(
                  icon: const Icon(Icons.picture_as_pdf),
                  label: const Text('Factura PDF'),
                  onPressed: () => _downloadInvoice(order),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.inventory),
                    label: const Text('Preparado'),
                    onPressed: status == 'prepared' ||
                            status == 'shipped' ||
                            status == 'delivered'
                        ? null
                        : () => _markPrepared(order),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.local_shipping),
                    label: const Text('Enviado / Tracking'),
                    onPressed:
                        status != 'prepared' ? null : () => _markShipped(order),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.check_circle),
                label: const Text('Entregado'),
                onPressed:
                    status != 'shipped' ? null : () => _markDelivered(order),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      appBar: AppBar(
        title: const Text('Logística Farmacia'),
        actions: [
          IconButton(onPressed: _loadOrders, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!))
              : RefreshIndicator(
                  onRefresh: _loadOrders,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      const Text(
                        'Gestión de Envíos',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Aquí logística revisa pedidos aprobados, datos de entrega, facturación, contacto, tracking y estado de envío.',
                      ),
                      const SizedBox(height: 16),
                      if (_orders.isEmpty)
                        const Center(
                          child: Padding(
                            padding: EdgeInsets.all(40),
                            child: Text('No existen pedidos aprobados'),
                          ),
                        )
                      else
                        ..._orders.map(
                          (e) => _orderCard(Map<String, dynamic>.from(e)),
                        ),
                    ],
                  ),
                ),
    );
  }
}
