import 'package:flutter/material.dart';
import '../services/ambassador_service.dart';
import '../widgets/mayu_logo.dart';
import '../widgets/mayu_scaffold.dart';

import 'ambassador_dashboard_screen.dart';

class RegisterAmbassadorScreen extends StatefulWidget {
  const RegisterAmbassadorScreen({super.key});

  @override
  State<RegisterAmbassadorScreen> createState() =>
      _RegisterAmbassadorScreenState();
}

class _RegisterAmbassadorScreenState extends State<RegisterAmbassadorScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _birthDateController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();
  final TextEditingController _nationalIdController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _bankNameController = TextEditingController();
  final TextEditingController _accountTypeController = TextEditingController();
  final TextEditingController _bankAccountNumberController =
      TextEditingController();
  final TextEditingController _confirmBankAccountNumberController =
      TextEditingController();

  bool _loading = false;
  String? _error;

  bool _isValidEmail(String email) {
    return RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(email);
  }

  Future<void> _selectBirthDate() async {
    final now = DateTime.now();
    final selected = await showDatePicker(
      context: context,
      initialDate: DateTime(now.year - 25, now.month, now.day),
      firstDate: DateTime(1930),
      lastDate: now,
    );

    if (selected == null) return;

    final month = selected.month.toString().padLeft(2, '0');
    final day = selected.day.toString().padLeft(2, '0');
    _birthDateController.text = '${selected.year}-$month-$day';
  }

  Future<void> _register() async {
    final name = _nameController.text.trim();
    final email = _emailController.text.trim().toLowerCase();
    final phone = _phoneController.text.trim();
    final birthDate = _birthDateController.text.trim();
    final password = _passwordController.text.trim();
    final confirmPassword = _confirmPasswordController.text.trim();
    final nationalId = _nationalIdController.text.trim();
    final address = _addressController.text.trim();
    final bankName = _bankNameController.text.trim();
    final accountType = _accountTypeController.text.trim();
    final bankAccountNumber = _bankAccountNumberController.text.trim();
    final confirmBankAccountNumber =
        _confirmBankAccountNumberController.text.trim();

    FocusScope.of(context).unfocus();

    if (name.isEmpty ||
        email.isEmpty ||
        phone.isEmpty ||
        birthDate.isEmpty ||
        password.isEmpty ||
        confirmPassword.isEmpty ||
        nationalId.isEmpty ||
        address.isEmpty ||
        bankName.isEmpty ||
        accountType.isEmpty ||
        bankAccountNumber.isEmpty ||
        confirmBankAccountNumber.isEmpty) {
      setState(() {
        _error = 'Todos los campos son obligatorios';
      });
      return;
    }

    if (!_isValidEmail(email)) {
      setState(() {
        _error = 'Ingresa un email válido';
      });
      return;
    }

    if (password.length < 6) {
      setState(() {
        _error = 'La contraseña debe tener al menos 6 caracteres';
      });
      return;
    }

    if (password != confirmPassword) {
      setState(() {
        _error = 'Las contraseñas no coinciden';
      });
      return;
    }

    if (bankAccountNumber != confirmBankAccountNumber) {
      setState(() {
        _error = 'Los números de cuenta bancaria no coinciden';
      });
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final result = await AmbassadorService.registerAmbassador(
        name: name,
        email: email,
        phone: phone,
        birthDate: birthDate,
        password: password,
        nationalId: nationalId,
        address: address,
        bankName: bankName,
        accountType: accountType,
        bankAccountNumber: bankAccountNumber,
      );

      if (!mounted) return;

      if (result['statusCode'] == 200 || result['statusCode'] == 201) {
        final data = result['data'];
        final ambassador = data?['ambassador'];

        if (ambassador == null || ambassador['id'] == null) {
          setState(() {
            _loading = false;
            _error = 'No se pudo obtener el perfil del embajador';
          });
          return;
        }

        final int ambassadorId = ambassador['id'] is int
            ? ambassador['id']
            : int.tryParse(ambassador['id'].toString()) ?? 0;

        if (ambassadorId == 0) {
          setState(() {
            _loading = false;
            _error = 'ID de embajador inválido';
          });
          return;
        }

        final loginResult = await AmbassadorService.loginAmbassador(
          email: email,
          password: password,
        );

        if (!mounted) return;

        if (loginResult['statusCode'] != 200) {
          setState(() {
            _loading = false;
            _error =
                'Embajador creado, pero no se pudo iniciar sesión automáticamente. Ingresa desde login.';
          });
          return;
        }

        setState(() {
          _loading = false;
        });

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => AmbassadorDashboardScreen(
              ambassadorId: ambassadorId,
            ),
          ),
        );
      } else {
        setState(() {
          _loading = false;
          _error = result['data']?['detail'] ?? 'No se pudo registrar';
        });
      }
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _loading = false;
        _error = 'Error al registrar embajador';
      });
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _birthDateController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    _nationalIdController.dispose();
    _addressController.dispose();
    _bankNameController.dispose();
    _accountTypeController.dispose();
    _bankAccountNumberController.dispose();
    _confirmBankAccountNumberController.dispose();
    super.dispose();
  }

  InputDecoration _input(String label) {
    return InputDecoration(
      labelText: label,
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
      ),
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 14,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MayuScaffold(
      appBar: AppBar(
        title: const Text('Registro de Embajador'),
        centerTitle: true,
      ),
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 500),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    const MayuLogo(height: 95),
                    const SizedBox(height: 16),
                    const Text(
                      'Crear cuenta de Embajador Mayu',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 24),
                    TextField(
                      controller: _nameController,
                      decoration: _input('Nombre completo'),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _emailController,
                      keyboardType: TextInputType.emailAddress,
                      decoration: _input('Email'),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _phoneController,
                      keyboardType: TextInputType.phone,
                      decoration: _input('Número de celular'),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _birthDateController,
                      readOnly: true,
                      onTap: _selectBirthDate,
                      decoration: _input('Fecha de nacimiento'),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _passwordController,
                      obscureText: true,
                      decoration: _input('Contraseña'),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _confirmPasswordController,
                      obscureText: true,
                      decoration: _input('Confirmar contraseña'),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _nationalIdController,
                      keyboardType: TextInputType.number,
                      decoration: _input('Número de cédula'),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _addressController,
                      decoration: _input('Dirección'),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _bankNameController,
                      decoration: _input('Nombre del banco'),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _accountTypeController,
                      decoration: _input('Tipo de cuenta'),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _bankAccountNumberController,
                      keyboardType: TextInputType.number,
                      decoration: _input('Número de cuenta bancaria'),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _confirmBankAccountNumberController,
                      keyboardType: TextInputType.number,
                      decoration: _input('Confirmar número de cuenta bancaria'),
                    ),
                    const SizedBox(height: 16),
                    if (_error != null)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Text(
                          _error!,
                          style: const TextStyle(color: Colors.red),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _loading ? null : _register,
                        child: _loading
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child:
                                    CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Text('Crear cuenta de embajador'),
                      ),
                    ),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
