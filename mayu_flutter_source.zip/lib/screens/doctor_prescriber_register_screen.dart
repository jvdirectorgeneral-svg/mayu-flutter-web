import 'package:flutter/material.dart';

import '../services/doctor_prescriber_service.dart';

class DoctorPrescriberRegisterScreen extends StatefulWidget {
  const DoctorPrescriberRegisterScreen({super.key});

  @override
  State<DoctorPrescriberRegisterScreen> createState() =>
      _DoctorPrescriberRegisterScreenState();
}

class _DoctorPrescriberRegisterScreenState
    extends State<DoctorPrescriberRegisterScreen> {
  final DoctorPrescriberService _service = DoctorPrescriberService();
  final _nameController = TextEditingController();
  final _birthDateController = TextEditingController();
  final _cityController = TextEditingController();
  final _phoneController = TextEditingController();
  final _phoneConfirmController = TextEditingController();
  final _emailController = TextEditingController();
  final _emailConfirmController = TextEditingController();
  final _bankNameController = TextEditingController();
  final _bankAccountController = TextEditingController();
  final _bankAccountConfirmController = TextEditingController();
  String _accountType = 'Ahorros';
  bool _acceptedPolicies = false;
  bool _saving = false;

  @override
  void dispose() {
    _nameController.dispose();
    _birthDateController.dispose();
    _cityController.dispose();
    _phoneController.dispose();
    _phoneConfirmController.dispose();
    _emailController.dispose();
    _emailConfirmController.dispose();
    _bankNameController.dispose();
    _bankAccountController.dispose();
    _bankAccountConfirmController.dispose();
    super.dispose();
  }

  Future<void> _pickBirthDate() async {
    final now = DateTime.now();
    final selected = await showDatePicker(
      context: context,
      initialDate: DateTime(now.year - 35, now.month, now.day),
      firstDate: DateTime(1920),
      lastDate: now,
    );
    if (selected == null) return;
    _birthDateController.text =
        '${selected.year}-${selected.month.toString().padLeft(2, '0')}-${selected.day.toString().padLeft(2, '0')}';
  }

  Future<void> _register() async {
    final email = _emailController.text.trim().toLowerCase();
    final emailConfirm = _emailConfirmController.text.trim().toLowerCase();
    final phone = _phoneController.text.trim();
    final phoneConfirm = _phoneConfirmController.text.trim();

    if (_nameController.text.trim().isEmpty ||
        _birthDateController.text.trim().isEmpty ||
        _cityController.text.trim().isEmpty ||
        phone.isEmpty ||
        phoneConfirm.isEmpty ||
        email.isEmpty ||
        emailConfirm.isEmpty ||
        _bankAccountController.text.trim().isEmpty ||
        _bankAccountConfirmController.text.trim().isEmpty) {
      _showMessage(
          'Completa datos personales, confirmaciones y cuenta bancaria');
      return;
    }
    if (phone != phoneConfirm) {
      _showMessage('El teléfono no coincide');
      return;
    }
    if (email != emailConfirm) {
      _showMessage('El correo no coincide');
      return;
    }
    if (_bankAccountController.text.trim() !=
        _bankAccountConfirmController.text.trim()) {
      _showMessage('El número de cuenta bancaria no coincide');
      return;
    }
    if (!_acceptedPolicies) {
      _showMessage(
          'Debes aceptar términos y políticas Doctor Prescriptor Mayu');
      return;
    }

    setState(() => _saving = true);
    final result = await _service.register(
      name: _nameController.text,
      birthDate: _birthDateController.text,
      city: _cityController.text,
      phone: phone,
      email: email,
      bankName: _bankNameController.text,
      bankAccountType: _accountType,
      bankAccountNumber: _bankAccountController.text,
      bankAccountNumberConfirm: _bankAccountConfirmController.text,
      acceptedPolicies: _acceptedPolicies,
    );
    if (!mounted) return;
    setState(() => _saving = false);

    if (result['statusCode'] == 200) {
      Navigator.pop(context, true);
    } else {
      _showMessage(
        result['data']?['detail']?.toString() ??
            'No se pudo activar Doctor Prescriptor Mayu',
      );
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      appBar: AppBar(title: const Text('Doctor Prescriptor Mayu')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Afiliación Doctor Prescriptor Mayu',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Comisiona el 30% como médico prescriptor. Farmacia carga las ventas y tu tarjeta muestra el avance de ganancias.',
                ),
                const SizedBox(height: 22),
                _field(_nameController, 'Nombre completo'),
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: TextField(
                    controller: _birthDateController,
                    readOnly: true,
                    onTap: _pickBirthDate,
                    decoration: const InputDecoration(
                      labelText: 'Fecha de nacimiento',
                      suffixIcon: Icon(Icons.calendar_month),
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                _field(_cityController, 'Ciudad'),
                _field(_phoneController, 'Teléfono',
                    keyboardType: TextInputType.phone),
                _field(_phoneConfirmController, 'Confirmar teléfono',
                    keyboardType: TextInputType.phone),
                _field(_emailController, 'Correo',
                    keyboardType: TextInputType.emailAddress),
                _field(_emailConfirmController, 'Confirmar correo',
                    keyboardType: TextInputType.emailAddress),
                const Divider(height: 28),
                const Text(
                  'Datos bancarios para comisiones',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                _field(_bankNameController, 'Banco'),
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: DropdownButtonFormField<String>(
                    initialValue: _accountType,
                    decoration: const InputDecoration(
                      labelText: 'Tipo de cuenta',
                      border: OutlineInputBorder(),
                    ),
                    items: const [
                      DropdownMenuItem(
                          value: 'Ahorros', child: Text('Ahorros')),
                      DropdownMenuItem(
                          value: 'Corriente', child: Text('Corriente')),
                    ],
                    onChanged: (value) {
                      if (value != null) setState(() => _accountType = value);
                    },
                  ),
                ),
                _field(
                  _bankAccountController,
                  'Número de cuenta',
                  keyboardType: TextInputType.number,
                ),
                _field(
                  _bankAccountConfirmController,
                  'Confirmar número de cuenta',
                  keyboardType: TextInputType.number,
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: _acceptedPolicies,
                  title: const Text(
                    'Acepto términos, privacidad y política digital Doctor Prescriptor Mayu',
                  ),
                  onChanged: (value) =>
                      setState(() => _acceptedPolicies = value),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _saving ? null : _register,
                    icon: const Icon(Icons.badge),
                    label: Text(_saving
                        ? 'Activando...'
                        : 'Activar Doctor Prescriptor'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _field(TextEditingController controller, String label,
      {TextInputType? keyboardType}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
            labelText: label, border: const OutlineInputBorder()),
      ),
    );
  }
}
