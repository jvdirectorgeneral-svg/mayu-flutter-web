import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/marketplace_service.dart';
import 'marketplace_my_orders_screen.dart';
import 'pharmacy_loyalty_card_screen.dart';
import 'pharmacy_qr_scanner_screen.dart';

class MarketplaceScreen extends StatefulWidget {
  const MarketplaceScreen({super.key});

  @override
  State<MarketplaceScreen> createState() => _MarketplaceScreenState();
}

class _MarketplaceScreenState extends State<MarketplaceScreen> {
  final MarketplaceService _service = MarketplaceService();

  bool _loading = true;
  bool _creatingOrder = false;
  bool _paypalLoading = false;
  bool _payPhoneLoading = false;
  bool _needsBilling = false;
  String? _error;
  String? _pendingPayPalOrderId;
  String? _pendingPayPhoneClientTransactionId;

  List<dynamic> _products = [];
  List<dynamic> _categories = [];

  final Map<int, Map<String, dynamic>> _cart = {};

  String _searchQuery = '';
  int _selectedCategoryId = 0;

  final TextEditingController _discountCodeController = TextEditingController();
  final TextEditingController _pharmacyLoyaltyController =
      TextEditingController();
  final TextEditingController _doctorPrescriberController =
      TextEditingController();

  final TextEditingController _customerNameController = TextEditingController();
  final TextEditingController _customerPhoneController =
      TextEditingController();
  final TextEditingController _confirmPhoneController = TextEditingController();
  final TextEditingController _customerEmailController =
      TextEditingController();
  final TextEditingController _confirmEmailController = TextEditingController();
  final TextEditingController _cityController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();

  final TextEditingController _billingNameController = TextEditingController();
  final TextEditingController _billingIdentificationController =
      TextEditingController();
  final TextEditingController _billingEmailController = TextEditingController();
  final TextEditingController _billingPhoneController = TextEditingController();
  final TextEditingController _billingAddressController =
      TextEditingController();

  final String _whatsAppNumber = '593962320665';

  static const double _memberDiscountPercent = 10;

  // Temporal: luego lo conectamos al usuario real logueado.
  final int _userId = 1;

  @override
  void initState() {
    super.initState();
    _loadMarketplace();
  }

  @override
  void dispose() {
    _discountCodeController.dispose();
    _pharmacyLoyaltyController.dispose();
    _doctorPrescriberController.dispose();
    _customerNameController.dispose();
    _customerPhoneController.dispose();
    _confirmPhoneController.dispose();
    _customerEmailController.dispose();
    _confirmEmailController.dispose();
    _cityController.dispose();
    _addressController.dispose();

    _billingNameController.dispose();
    _billingIdentificationController.dispose();
    _billingEmailController.dispose();
    _billingPhoneController.dispose();
    _billingAddressController.dispose();

    super.dispose();
  }

  Future<void> _loadMarketplace() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final categoriesResult = await _service.getPublicCategories();
    final productsResult = await _service.getPublicProducts();

    if (!mounted) return;

    if (categoriesResult['statusCode'] == 200 &&
        productsResult['statusCode'] == 200) {
      final categoriesData = categoriesResult['data'];
      final productsData = productsResult['data'];

      setState(() {
        _categories = categoriesData is Map && categoriesData['items'] is List
            ? categoriesData['items']
            : [];

        _products = productsData is Map && productsData['items'] is List
            ? productsData['items']
            : [];

        _loading = false;
      });
    } else {
      setState(() {
        _loading = false;
        _error = categoriesResult['data']?['detail']?.toString() ??
            productsResult['data']?['detail']?.toString() ??
            'No se pudo cargar el marketplace';
      });
    }
  }

  List<dynamic> get _filteredProducts {
    return _products.where((item) {
      final product = Map<String, dynamic>.from(item);

      final active = product['active'] == true;
      final name = (product['name'] ?? '').toString().toLowerCase();
      final description =
          (product['description'] ?? '').toString().toLowerCase();
      final shortDescription =
          (product['short_description'] ?? '').toString().toLowerCase();
      final categoryId =
          int.tryParse((product['category_id'] ?? 0).toString()) ?? 0;

      final search = _searchQuery.toLowerCase();

      final matchesSearch = name.contains(search) ||
          description.contains(search) ||
          shortDescription.contains(search);

      final matchesCategory =
          _selectedCategoryId == 0 || categoryId == _selectedCategoryId;

      return active && matchesSearch && matchesCategory;
    }).toList();
  }

  double _price(dynamic value) {
    return double.tryParse((value ?? 0).toString()) ?? 0;
  }

  double get _subtotal {
    double total = 0;

    for (final item in _cart.values) {
      final product = Map<String, dynamic>.from(item['product']);
      final quantity = item['quantity'] as int;
      total += _price(product['price']) * quantity;
    }

    return total;
  }

  bool get _hasMemberCode => _discountCodeController.text.trim().isNotEmpty;

  bool get _hasDoctorPrescriber =>
      _doctorPrescriberController.text.trim().isNotEmpty;

  double get _discountAmount {
    if (!_hasMemberCode) return 0;
    return _subtotal * (_memberDiscountPercent / 100);
  }

  double get _total => _subtotal - _discountAmount;

  double get _doctorCommissionEstimate {
    if (!_hasDoctorPrescriber) return 0;
    return _total * 0.30;
  }

  bool _isValidEmail(String value) {
    final email = value.trim();
    final regex = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');
    return regex.hasMatch(email);
  }

  String _normalizePhoneForMatch(String value) {
    final digits = value.replaceAll(RegExp(r'\D'), '');
    if (digits.startsWith('593') && digits.length == 12) {
      return '0${digits.substring(3)}';
    }
    return digits;
  }

  void _showCheckoutMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 4),
      ),
    );
  }

  Future<bool> _openUrlWithFallback(Uri uri) async {
    final openedExternal = await launchUrl(
      uri,
      mode: LaunchMode.externalApplication,
    );
    if (openedExternal) return true;

    final openedDefault = await launchUrl(uri);
    if (openedDefault) return true;

    return await launchUrl(uri, mode: LaunchMode.inAppBrowserView);
  }

  Uri _buildWhatsAppUri(String message) {
    return Uri.parse(
      'https://wa.me/$_whatsAppNumber?text=${Uri.encodeComponent(message)}',
    );
  }

  String? _checkoutBlockingMessage() {
    final name = _customerNameController.text.trim();
    final phone = _customerPhoneController.text.trim();
    final confirmPhone = _confirmPhoneController.text.trim();
    final email = _customerEmailController.text.trim();
    final confirmEmail = _confirmEmailController.text.trim();
    final city = _cityController.text.trim();
    final address = _addressController.text.trim();
    final billingName = _billingNameController.text.trim();
    final billingIdentification = _billingIdentificationController.text.trim();
    final billingEmail = _billingEmailController.text.trim();

    if (_cart.isEmpty || _subtotal <= 0) {
      return 'Tu carrito está vacío. Regresa y agrega productos antes de pagar.';
    }

    if (name.isEmpty ||
        phone.isEmpty ||
        confirmPhone.isEmpty ||
        email.isEmpty ||
        confirmEmail.isEmpty ||
        city.isEmpty ||
        address.isEmpty) {
      return 'Completa nombre, teléfono, confirmar teléfono, email, confirmar email, ciudad y dirección.';
    }

    if (_normalizePhoneForMatch(phone) != _normalizePhoneForMatch(confirmPhone)) {
      return 'El teléfono y su confirmación no coinciden.';
    }

    if (!_isValidEmail(email)) {
      return 'Ingresa un email válido.';
    }

    if (email.toLowerCase() != confirmEmail.toLowerCase()) {
      return 'El email y su confirmación no coinciden.';
    }

    if (_needsBilling) {
      if (billingName.isEmpty || billingIdentification.isEmpty) {
        return 'Completa nombre o razón social y cédula/RUC para facturación.';
      }

      if (billingEmail.isNotEmpty && !_isValidEmail(billingEmail)) {
        return 'El email de facturación no es válido.';
      }
    }

    return null;
  }

  bool _validateOrderData() {
    final blockingMessage = _checkoutBlockingMessage();
    if (blockingMessage != null) {
      _showCheckoutMessage(blockingMessage);
      return false;
    }
    return true;
  }

  Future<void> _openVideoUrl(String url) async {
    final cleanUrl = url.trim();

    if (cleanUrl.isEmpty) return;

    final uri = Uri.parse(cleanUrl);

    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No se pudo abrir el video')),
      );
    }
  }

  void _addToCart(Map<String, dynamic> product) {
    final id = int.tryParse((product['id'] ?? 0).toString()) ?? 0;
    if (id == 0) return;

    setState(() {
      if (_cart.containsKey(id)) {
        _cart[id]!['quantity'] = (_cart[id]!['quantity'] as int) + 1;
      } else {
        _cart[id] = {
          'product': product,
          'quantity': 1,
        };
      }
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${product['name']} agregado al carrito')),
    );
  }

  void _removeFromCart(int productId) {
    setState(() {
      _cart.remove(productId);
    });
  }

  void _changeQuantity(int productId, int quantity) {
    if (quantity <= 0) {
      _removeFromCart(productId);
      return;
    }

    setState(() {
      if (_cart.containsKey(productId)) {
        _cart[productId]!['quantity'] = quantity;
      }
    });
  }

  List<Map<String, dynamic>> _orderItems() {
    return _cart.entries.map((entry) {
      return {
        'product_id': entry.key,
        'quantity': entry.value['quantity'],
      };
    }).toList();
  }

  Future<void> _scanCodeIntoController(
    TextEditingController controller,
    StateSetter setModalState,
  ) async {
    FocusScope.of(context).unfocus();
    final result = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => const PharmacyQrScannerScreen()),
    );

    if (!mounted) return;
    final value = result?.trim();
    if (value == null || value.isEmpty) return;

    setState(() {
      controller.text = value;
    });
    setModalState(() {});
  }

  Future<void> _scanPharmacyLoyaltyQr(StateSetter setModalState) async {
    await _scanCodeIntoController(_pharmacyLoyaltyController, setModalState);
  }

  Future<void> _scanWellnessClubQr(StateSetter setModalState) async {
    await _scanCodeIntoController(_discountCodeController, setModalState);
  }

  Future<void> _scanDoctorPrescriberQr(StateSetter setModalState) async {
    FocusScope.of(context).unfocus();
    final result = await Navigator.push<String>(
      context,
      MaterialPageRoute(
        builder: (_) => const PharmacyQrScannerScreen(
          title: 'Escanear QR Doctor Prescriptor',
          helperText:
              'Enfoca el QR del Doctor Prescriptor Mayu para registrar su ganancia.',
        ),
      ),
    );

    if (!mounted) return;
    final value = result?.trim();
    if (value == null || value.isEmpty) return;

    setState(() {
      _doctorPrescriberController.text = value;
    });
    setModalState(() {});
  }

  String _extractPayPhoneLink(dynamic data) {
    if (data is! Map) return '';

    final direct = data['payment_url'] ??
        data['approval_url'] ??
        data['link'] ??
        data['url'];
    if (direct != null && direct.toString().trim().isNotEmpty) {
      return direct.toString();
    }

    final payphone = data['payphone'];
    if (payphone is Map) {
      final nested = payphone['link'] ??
          payphone['url'] ??
          payphone['paymentUrl'] ??
          payphone['payment_url'] ??
          payphone['shortUrl'] ??
          payphone['short_url'];
      if (nested != null && nested.toString().trim().isNotEmpty) {
        return nested.toString();
      }
    }

    return '';
  }

  Future<void> _verifyPendingPayPhonePayment() async {
    final clientTransactionId = _pendingPayPhoneClientTransactionId;
    if (clientTransactionId == null || clientTransactionId.isEmpty) {
      _showCheckoutMessage('No hay pago PayPhone pendiente para verificar.');
      return;
    }

    setState(() {
      _payPhoneLoading = true;
    });

    final result = await _service.confirmMarketplacePayPhoneOrder(
      clientTransactionId: clientTransactionId,
    );

    if (!mounted) return;

    setState(() {
      _payPhoneLoading = false;
    });

    if (result['statusCode'] == 200 || result['statusCode'] == 201) {
      final fulfillment = result['data']?['pharmacy_fulfillment'];
      final loyalty = fulfillment is Map ? fulfillment['loyalty'] : null;
      final pointsEarned =
          loyalty is Map ? (loyalty['points_earned']?.toString() ?? '0') : '0';
      final pointsBalance =
          loyalty is Map ? (loyalty['points_balance']?.toString() ?? '') : '';

      setState(() {
        _pendingPayPhoneClientTransactionId = null;
        _cart.clear();
      });

      final balanceText = pointsBalance.isNotEmpty
          ? ' Saldo actual: $pointsBalance punto(s).'
          : '';

      _showCheckoutMessage(
        'Pago PayPhone confirmado. Puntos sumados: $pointsEarned.$balanceText',
      );

      if (Navigator.canPop(context)) {
        Navigator.pop(context);
      }
    } else {
      _showCheckoutMessage(
        result['data']?['detail']?.toString() ??
            'PayPhone aún no confirma el pago. Espera unos segundos y vuelve a verificar.',
      );
    }
  }

  Future<void> _handlePayPhoneTap() async {
    if (_payPhoneLoading) return;
    await _payWithPayPhone();
  }

  Future<void> _handlePayPalTap() async {
    if (_paypalLoading) return;
    await _payWithPayPal();
  }

  Future<void> _handleWhatsAppOrderTap() async {
    if (_creatingOrder) return;
    await _createOrderAndOpenWhatsApp();
  }

  Future<void> _payWithPayPhone() async {
    FocusScope.of(context).unfocus();
    if (!_validateOrderData()) return;

    setState(() {
      _payPhoneLoading = true;
    });

    try {
      final result = await _service.createMarketplacePayPhoneCartOrder(
        userId: _userId,
        buyerName: _customerNameController.text.trim(),
        buyerPhone: _customerPhoneController.text.trim(),
        buyerEmail: _customerEmailController.text.trim(),
        city: _cityController.text.trim(),
        address: _addressController.text.trim(),
        deliveryNotes: '',
        billingName: _needsBilling ? _billingNameController.text.trim() : null,
        billingIdentification:
            _needsBilling ? _billingIdentificationController.text.trim() : null,
        billingEmail:
            _needsBilling ? _billingEmailController.text.trim() : null,
        billingPhone:
            _needsBilling ? _billingPhoneController.text.trim() : null,
        billingAddress:
            _needsBilling ? _billingAddressController.text.trim() : null,
        discountCode: _discountCodeController.text.trim(),
        pharmacyLoyaltyIdentifier: _pharmacyLoyaltyController.text.trim(),
        doctorPrescriberIdentifier: _doctorPrescriberController.text.trim(),
        items: _orderItems(),
      );

      if (!mounted) return;

      if (result['statusCode'] == 200 || result['statusCode'] == 201) {
        final data = result['data'];
        final paymentUrl = _extractPayPhoneLink(data);

        if (paymentUrl.isEmpty) {
          _showCheckoutMessage('PayPhone no devolvió enlace de pago');
          return;
        }

        final clientTransactionId =
            data?['clientTransactionId']?.toString() ?? '';
        setState(() {
          _pendingPayPhoneClientTransactionId =
              clientTransactionId.isEmpty ? null : clientTransactionId;
        });

        final uri = Uri.tryParse(paymentUrl);
        if (uri == null) {
          _showCheckoutMessage('PayPhone devolvió un enlace inválido');
          return;
        }

        _showCheckoutMessage('Abriendo PayPhone...');
        final opened = await _openUrlWithFallback(uri);

        if (!opened && mounted) {
          _showCheckoutMessage(
            'No se pudo abrir PayPhone. Intenta nuevamente o revisa Safari.',
          );
          return;
        }

        if (!mounted) return;

        await showDialog<void>(
          context: context,
          builder: (dialogContext) {
            return AlertDialog(
              title: const Text('Pago PayPhone'),
              content: const Text(
                'Cuando termines el pago en PayPhone y vuelvas a Mayu, toca “Verificar pago” para confirmar la orden y acreditar puntos.',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Luego'),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(dialogContext);
                    _verifyPendingPayPhonePayment();
                  },
                  child: const Text('Verificar pago'),
                ),
              ],
            );
          },
        );
      } else {
        _showCheckoutMessage(
          result['data']?['detail']?.toString() ??
              'No se pudo crear pago PayPhone',
        );
      }
    } catch (e) {
      if (mounted) {
        _showCheckoutMessage('Error abriendo PayPhone: $e');
      }
    } finally {
      if (mounted) {
        setState(() {
          _payPhoneLoading = false;
        });
      }
    }
  }

  Future<void> _verifyPendingPayPalPayment() async {
    final paypalOrderId = _pendingPayPalOrderId;
    if (paypalOrderId == null || paypalOrderId.isEmpty) {
      _showCheckoutMessage('No hay pago PayPal pendiente para verificar.');
      return;
    }

    setState(() {
      _paypalLoading = true;
    });

    final result = await _service.captureMarketplacePayPalOrder(
      paypalOrderId: paypalOrderId,
    );

    if (!mounted) return;

    setState(() {
      _paypalLoading = false;
    });

    if (result['statusCode'] == 200 || result['statusCode'] == 201) {
      final fulfillment = result['data']?['pharmacy_fulfillment'];
      final loyalty = fulfillment is Map ? fulfillment['loyalty'] : null;
      final pointsEarned =
          loyalty is Map ? (loyalty['points_earned']?.toString() ?? '0') : '0';
      final pointsBalance =
          loyalty is Map ? (loyalty['points_balance']?.toString() ?? '') : '';

      setState(() {
        _pendingPayPalOrderId = null;
        _cart.clear();
      });

      final balanceText = pointsBalance.isNotEmpty
          ? ' Saldo actual: $pointsBalance punto(s).'
          : '';

      _showCheckoutMessage(
        'Pago confirmado. Puntos sumados: $pointsEarned.$balanceText',
      );

      if (Navigator.canPop(context)) {
        Navigator.pop(context);
      }
    } else {
      _showCheckoutMessage(
        result['data']?['detail']?.toString() ??
            'PayPal aún no confirma el pago. Espera unos segundos y vuelve a verificar.',
      );
    }
  }

  Future<void> _payWithPayPal() async {
    FocusScope.of(context).unfocus();
    if (!_validateOrderData()) return;

    setState(() {
      _paypalLoading = true;
    });

    try {
      final result = await _service.createMarketplacePayPalCartOrder(
        userId: _userId,
        buyerName: _customerNameController.text.trim(),
        buyerPhone: _customerPhoneController.text.trim(),
        buyerEmail: _customerEmailController.text.trim(),
        city: _cityController.text.trim(),
        address: _addressController.text.trim(),
        deliveryNotes: '',
        billingName: _needsBilling ? _billingNameController.text.trim() : null,
        billingIdentification:
            _needsBilling ? _billingIdentificationController.text.trim() : null,
        billingEmail:
            _needsBilling ? _billingEmailController.text.trim() : null,
        billingPhone:
            _needsBilling ? _billingPhoneController.text.trim() : null,
        billingAddress:
            _needsBilling ? _billingAddressController.text.trim() : null,
        discountCode: _discountCodeController.text.trim(),
        pharmacyLoyaltyIdentifier: _pharmacyLoyaltyController.text.trim(),
        doctorPrescriberIdentifier: _doctorPrescriberController.text.trim(),
        items: _orderItems(),
      );

      if (!mounted) return;

      if (result['statusCode'] == 200 || result['statusCode'] == 201) {
        final approvalUrl = result['data']?['approval_url']?.toString() ?? '';

        if (approvalUrl.isEmpty) {
          _showCheckoutMessage('PayPal no devolvió enlace de pago');
          return;
        }

        final paypalOrderId =
            result['data']?['paypal_order_id']?.toString() ?? '';
        setState(() {
          _pendingPayPalOrderId = paypalOrderId.isEmpty ? null : paypalOrderId;
        });

        final uri = Uri.tryParse(approvalUrl);
        if (uri == null) {
          _showCheckoutMessage('PayPal devolvió un enlace inválido');
          return;
        }

        _showCheckoutMessage('Abriendo PayPal...');
        final opened = await _openUrlWithFallback(uri);

        if (!opened && mounted) {
          _showCheckoutMessage(
            'No se pudo abrir PayPal. Intenta nuevamente o revisa Safari.',
          );
          return;
        }

        if (!mounted) return;

        await showDialog<void>(
          context: context,
          builder: (dialogContext) {
            return AlertDialog(
              title: const Text('Pago PayPal'),
              content: const Text(
                'Cuando termines el pago en PayPal y vuelvas a Mayu, toca “Verificar pago” para confirmar la orden y acreditar puntos.',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Luego'),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(dialogContext);
                    _verifyPendingPayPalPayment();
                  },
                  child: const Text('Verificar pago'),
                ),
              ],
            );
          },
        );
      } else {
        _showCheckoutMessage(
          result['data']?['detail']?.toString() ??
              'No se pudo crear pago PayPal',
        );
      }
    } catch (e) {
      if (mounted) {
        _showCheckoutMessage('Error abriendo PayPal: $e');
      }
    } finally {
      if (mounted) {
        setState(() {
          _paypalLoading = false;
        });
      }
    }
  }

  Future<void> _createOrderAndOpenWhatsApp() async {
    FocusScope.of(context).unfocus();
    if (!_validateOrderData()) return;

    setState(() {
      _creatingOrder = true;
    });

    try {
      final result = await _service.createOrder(
        customerName: _customerNameController.text.trim(),
        customerPhone: _customerPhoneController.text.trim(),
        customerEmail: _customerEmailController.text.trim(),
        city: _cityController.text.trim(),
        address: _addressController.text.trim(),
        deliveryNotes: '',
        billingName: _needsBilling ? _billingNameController.text.trim() : null,
        billingIdentification:
            _needsBilling ? _billingIdentificationController.text.trim() : null,
        billingEmail:
            _needsBilling ? _billingEmailController.text.trim() : null,
        billingPhone:
            _needsBilling ? _billingPhoneController.text.trim() : null,
        billingAddress:
            _needsBilling ? _billingAddressController.text.trim() : null,
        discountCode: _discountCodeController.text.trim(),
        pharmacyLoyaltyIdentifier: _pharmacyLoyaltyController.text.trim(),
        doctorPrescriberIdentifier: _doctorPrescriberController.text.trim(),
        items: _orderItems(),
      );

      if (!mounted) return;

      if (result['statusCode'] == 200 || result['statusCode'] == 201) {
        final order = result['data']?['order'];
        final message = order?['whatsapp_message']?.toString() ??
            'Hola Mayu, deseo confirmar mi pedido.';

        final uri = _buildWhatsAppUri(message);

        _showCheckoutMessage('Abriendo WhatsApp...');
        final opened = await _openUrlWithFallback(uri);

        if (!opened && mounted) {
          _showCheckoutMessage(
            'La orden se creó, pero no se pudo abrir WhatsApp. Intenta nuevamente o revisa Safari.',
          );
          return;
        }

        if (!mounted) return;

        _cart.clear();
        Navigator.pop(context);
        setState(() {});
      } else {
        _showCheckoutMessage(
          result['data']?['detail']?.toString() ?? 'No se pudo crear la orden',
        );
      }
    } catch (e) {
      if (mounted) {
        _showCheckoutMessage('Error abriendo WhatsApp: $e');
      }
    } finally {
      if (mounted) {
        setState(() {
          _creatingOrder = false;
        });
      }
    }
  }

  Widget _pharmacyHeader() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 14,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            width: 104,
            height: 104,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.teal.withValues(alpha: 0.08),
              shape: BoxShape.circle,
            ),
            child: Image.asset(
              'assets/images/logo_mayu_farmacia.png',
              fit: BoxFit.contain,
            ),
          ),
          const SizedBox(height: 14),
          const Text(
            'Marketplace Farmacia Magistral Mayu',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Farmacia magistral fitoterapéutica especializada en fórmulas naturales, cannabinoides, fitoterapia clínica, aceites esenciales, hongos medicinales, coloides y productos de bienestar integrativo.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 15, height: 1.4),
          ),
          const SizedBox(height: 8),
          const Text(
            'Explora productos, revisa sus usos, agrega al carrito y confirma tu pedido directamente por WhatsApp o PayPhone.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: Colors.teal,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _imagePlaceholder({double height = 180}) {
    return Container(
      height: height,
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.teal.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(18),
      ),
      child: const Center(
        child: Icon(
          Icons.local_pharmacy,
          size: 64,
          color: Colors.teal,
        ),
      ),
    );
  }

  Widget _infoSection(String title, dynamic value) {
    final text = (value ?? '').toString().trim();

    if (text.isEmpty) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.only(top: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
          ),
          const SizedBox(height: 4),
          Text(text, style: const TextStyle(fontSize: 15, height: 1.45)),
        ],
      ),
    );
  }

  void _openProductDetail(Map<String, dynamic> product) {
    final imageUrl = (product['image_url'] ?? '').toString();
    final videoUrl = (product['video_url'] ?? '').toString().trim();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) {
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.78,
          maxChildSize: 0.94,
          minChildSize: 0.45,
          builder: (context, scrollController) {
            return SingleChildScrollView(
              controller: scrollController,
              padding: const EdgeInsets.all(22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    product['name']?.toString() ?? 'Producto Mayu',
                    style: const TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    product['category_name']?.toString() ?? 'Sin categoría',
                    style: const TextStyle(color: Colors.teal),
                  ),
                  if ((product['presentation'] ?? '').toString().isNotEmpty)
                    Text(
                      'Presentación: ${product['presentation']}',
                      style: const TextStyle(color: Colors.black54),
                    ),
                  const SizedBox(height: 14),
                  imageUrl.isNotEmpty
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(18),
                          child: Image.network(
                            imageUrl,
                            height: 220,
                            width: double.infinity,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                                _imagePlaceholder(height: 220),
                          ),
                        )
                      : _imagePlaceholder(height: 220),
                  const SizedBox(height: 18),
                  Text(
                    '\$${_price(product['price']).toStringAsFixed(2)}',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.teal,
                    ),
                  ),
                  if ((product['stock'] ?? 0) != 0)
                    Text('Stock disponible: ${product['stock']}'),
                  if (videoUrl.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: OutlinedButton.icon(
                        onPressed: () => _openVideoUrl(videoUrl),
                        icon: const Icon(Icons.play_circle_outline),
                        label: const Text('Ver video de usos'),
                      ),
                    ),
                  ],
                  _infoSection(
                    'Descripción',
                    product['description'] ??
                        product['short_description'] ??
                        'Producto de la Farmacia Magistral Mayu.',
                  ),
                  _infoSection('Beneficios', product['benefits']),
                  _infoSection('Ingredientes', product['ingredients']),
                  _infoSection('Dosis sugerida', product['suggested_dose']),
                  _infoSection('Modo de uso', product['usage_instructions']),
                  _infoSection('Advertencias', product['warnings']),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: ElevatedButton.icon(
                      onPressed: () {
                        Navigator.pop(context);
                        _addToCart(product);
                      },
                      icon: const Icon(Icons.shopping_cart),
                      label: const Text('Agregar al carrito'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal,
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _openCart() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            final blockingMessage = _checkoutBlockingMessage();
            final canSubmitCheckout = blockingMessage == null;

            return SafeArea(
              bottom: false,
              child: SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(
                  22,
                  22,
                  22,
                  32 +
                      MediaQuery.of(context).viewInsets.bottom +
                      MediaQuery.of(context).padding.bottom,
                ),
                keyboardDismissBehavior:
                    ScrollViewKeyboardDismissBehavior.onDrag,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Carrito Mayu',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.arrow_back),
                        label: const Text('Regresar y agregar productos'),
                      ),
                    ),
                    const SizedBox(height: 14),
                    if (_cart.isEmpty)
                      const Padding(
                        padding: EdgeInsets.all(24),
                        child: Center(child: Text('Tu carrito está vacío')),
                      )
                    else
                      ..._cart.entries.map((entry) {
                        final product =
                            Map<String, dynamic>.from(entry.value['product']);
                        final quantity = entry.value['quantity'] as int;
                        final productId = entry.key;
                        final unitPrice = _price(product['price']);

                        return Card(
                          child: ListTile(
                            title: Text(product['name'] ?? 'Producto'),
                            subtitle: Text(
                              '\$${unitPrice.toStringAsFixed(2)} x $quantity',
                            ),
                            trailing: Wrap(
                              crossAxisAlignment: WrapCrossAlignment.center,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.remove),
                                  onPressed: () {
                                    _changeQuantity(productId, quantity - 1);
                                    setModalState(() {});
                                  },
                                ),
                                Text(quantity.toString()),
                                IconButton(
                                  icon: const Icon(Icons.add),
                                  onPressed: () {
                                    _changeQuantity(productId, quantity + 1);
                                    setModalState(() {});
                                  },
                                ),
                                IconButton(
                                  icon: const Icon(
                                    Icons.delete,
                                    color: Colors.red,
                                  ),
                                  onPressed: () {
                                    _removeFromCart(productId);
                                    setModalState(() {});
                                  },
                                ),
                              ],
                            ),
                          ),
                        );
                      }),
                    const SizedBox(height: 16),
                    const Text(
                      'Datos para confirmar pedido',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _customerNameController,
                      onChanged: (_) => setModalState(() {}),
                      decoration: const InputDecoration(
                        labelText: 'Nombre completo *',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _customerPhoneController,
                      keyboardType: TextInputType.phone,
                      onChanged: (_) => setModalState(() {}),
                      decoration: const InputDecoration(
                        labelText: 'Teléfono / WhatsApp *',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _confirmPhoneController,
                      keyboardType: TextInputType.phone,
                      onChanged: (_) => setModalState(() {}),
                      decoration: const InputDecoration(
                        labelText: 'Confirmar teléfono / WhatsApp *',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _customerEmailController,
                      keyboardType: TextInputType.emailAddress,
                      onChanged: (_) => setModalState(() {}),
                      decoration: const InputDecoration(
                        labelText: 'Email *',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _confirmEmailController,
                      keyboardType: TextInputType.emailAddress,
                      onChanged: (_) => setModalState(() {}),
                      decoration: const InputDecoration(
                        labelText: 'Confirmar email *',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _cityController,
                      onChanged: (_) => setModalState(() {}),
                      decoration: const InputDecoration(
                        labelText: 'Ciudad *',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _addressController,
                      onChanged: (_) => setModalState(() {}),
                      decoration: const InputDecoration(
                        labelText: 'Dirección de entrega *',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 18),
                    const Text(
                      'Puntos Farmacia Magistral',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _pharmacyLoyaltyController,
                      textCapitalization: TextCapitalization.characters,
                      decoration: InputDecoration(
                        labelText: 'Código de tarjeta Farmacia',
                        hintText: 'Ej: FAR-MAYU-000001',
                        border: const OutlineInputBorder(),
                        prefixIcon: const Icon(Icons.card_membership),
                        suffixIcon: IconButton(
                          tooltip: 'Escanear QR de Farmacia',
                          icon: const Icon(Icons.qr_code_scanner),
                          onPressed: () =>
                              _scanPharmacyLoyaltyQr(setModalState),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: () => _scanPharmacyLoyaltyQr(setModalState),
                        icon: const Icon(Icons.qr_code_scanner),
                        label: const Text('Escanear QR de Farmacia'),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Doctor Afiliado',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _doctorPrescriberController,
                      textCapitalization: TextCapitalization.characters,
                      decoration: InputDecoration(
                        labelText: 'Código o QR Doctor Prescriptor',
                        hintText: 'Ej: DOC-MAYU-000001',
                        border: const OutlineInputBorder(),
                        prefixIcon: const Icon(Icons.medical_services_outlined),
                        suffixIcon: IconButton(
                          tooltip: 'Escanear QR Doctor Prescriptor',
                          icon: const Icon(Icons.qr_code_scanner),
                          onPressed: () =>
                              _scanDoctorPrescriberQr(setModalState),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: () => _scanDoctorPrescriberQr(setModalState),
                        icon: const Icon(Icons.qr_code_scanner),
                        label: const Text('Escanear QR Doctor Prescriptor'),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Mayu Wellness Club',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _discountCodeController,
                      textCapitalization: TextCapitalization.characters,
                      decoration: InputDecoration(
                        labelText: 'Código Mayu Wellness Club',
                        hintText: 'Ej: MAYU-ORO-15',
                        border: const OutlineInputBorder(),
                        prefixIcon: const Icon(Icons.local_offer_outlined),
                        suffixIcon: IconButton(
                          tooltip: 'Escanear QR Mayu Wellness Club',
                          icon: const Icon(Icons.qr_code_scanner),
                          onPressed: () => _scanWellnessClubQr(setModalState),
                        ),
                      ),
                      onChanged: (_) {
                        setState(() {});
                        setModalState(() {});
                      },
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: () => _scanWellnessClubQr(setModalState),
                        icon: const Icon(Icons.qr_code_scanner),
                        label: const Text('Escanear QR Mayu Wellness Club'),
                      ),
                    ),
                    const SizedBox(height: 18),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text(
                        'Necesito datos de facturación',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      subtitle: const Text(
                        'Actívalo solo si quieres factura con cédula/RUC.',
                      ),
                      value: _needsBilling,
                      onChanged: (value) {
                        setState(() {
                          _needsBilling = value;
                        });
                        setModalState(() {});
                      },
                    ),
                    if (_needsBilling) ...[
                      const SizedBox(height: 8),
                      TextField(
                        controller: _billingNameController,
                        decoration: const InputDecoration(
                          labelText: 'Nombre o razón social *',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _billingIdentificationController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'Cédula / RUC *',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _billingEmailController,
                        keyboardType: TextInputType.emailAddress,
                        decoration: const InputDecoration(
                          labelText: 'Email de facturación',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _billingPhoneController,
                        keyboardType: TextInputType.phone,
                        decoration: const InputDecoration(
                          labelText: 'Teléfono de facturación',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _billingAddressController,
                        decoration: const InputDecoration(
                          labelText: 'Dirección de facturación',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ],
                    const SizedBox(height: 16),
                    _summaryRow('Subtotal', _subtotal),
                    if (_hasMemberCode)
                      _summaryRow('Descuento socio 10%', -_discountAmount),
                    if (_hasDoctorPrescriber)
                      _summaryRow(
                        'Comisión doctor 30% estimada',
                        _doctorCommissionEstimate,
                      ),
                    const Divider(),
                    _summaryRow('Total cliente', _total, bold: true),
                    if (blockingMessage != null) ...[
                      const SizedBox(height: 14),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFF3F0),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: const Color(0xFFE58A7A)),
                        ),
                        child: Text(
                          blockingMessage,
                          style: const TextStyle(
                            color: Color(0xFF9F3A2A),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: ElevatedButton.icon(
                        onPressed: canSubmitCheckout ? _handlePayPhoneTap : null,
                        icon: const Icon(Icons.phone_iphone),
                        label: Text(
                          _payPhoneLoading
                              ? 'Conectando con PayPhone...'
                              : 'Pagar carrito con PayPhone',
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF00AFA3),
                          foregroundColor: Colors.white,
                        ),
                      ),
                    ),
                    if (_pendingPayPhoneClientTransactionId != null) ...[
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: OutlinedButton.icon(
                          onPressed: () {
                            if (_payPhoneLoading) return;
                            _verifyPendingPayPhonePayment();
                          },
                          icon: const Icon(Icons.verified),
                          label: const Text('Verificar pago PayPhone y puntos'),
                        ),
                      ),
                    ],
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: ElevatedButton.icon(
                        onPressed: canSubmitCheckout ? _handlePayPalTap : null,
                        icon: const Icon(Icons.payment),
                        label: Text(
                          _paypalLoading
                              ? 'Conectando con PayPal...'
                              : 'Pagar carrito con PayPal',
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          foregroundColor: Colors.white,
                        ),
                      ),
                    ),
                    if (_pendingPayPalOrderId != null) ...[
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: OutlinedButton.icon(
                          onPressed: () {
                            if (_paypalLoading) return;
                            _verifyPendingPayPalPayment();
                          },
                          icon: const Icon(Icons.verified),
                          label: const Text('Verificar pago PayPal y puntos'),
                        ),
                      ),
                    ],
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: ElevatedButton.icon(
                        onPressed:
                            canSubmitCheckout ? _handleWhatsAppOrderTap : null,
                        icon: const Icon(Icons.check_circle),
                        label: Text(
                          _creatingOrder
                              ? 'Creando orden...'
                              : 'Crear orden y enviar por WhatsApp',
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF25D366),
                          foregroundColor: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _summaryRow(String label, double amount, {bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontWeight: bold ? FontWeight.bold : FontWeight.normal,
              fontSize: bold ? 18 : 15,
            ),
          ),
          Text(
            '\$${amount.toStringAsFixed(2)} USD',
            style: TextStyle(
              fontWeight: bold ? FontWeight.bold : FontWeight.normal,
              fontSize: bold ? 18 : 15,
              color: amount < 0 ? Colors.green : Colors.black,
            ),
          ),
        ],
      ),
    );
  }

  Widget _productCard(Map<String, dynamic> product) {
    final imageUrl = (product['image_url'] ?? '').toString();
    final videoUrl = (product['video_url'] ?? '').toString().trim();

    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () => _openProductDetail(product),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.black12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            imageUrl.isNotEmpty
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: Image.network(
                      imageUrl,
                      height: 76,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) =>
                          _imagePlaceholder(height: 76),
                    ),
                  )
                : _imagePlaceholder(height: 76),
            const SizedBox(height: 8),
            Text(
              product['name']?.toString() ?? 'Producto Mayu',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
            ),
            const SizedBox(height: 4),
            Text(
              product['category_name']?.toString() ?? 'Sin categoría',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.teal, fontSize: 13),
            ),
            if ((product['presentation'] ?? '').toString().isNotEmpty)
              Text(
                product['presentation'].toString(),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 13),
              ),
            if (videoUrl.isNotEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 4),
                child: Row(
                  children: [
                    Icon(Icons.play_circle_outline,
                        size: 16, color: Colors.red),
                    SizedBox(width: 4),
                    Text(
                      'Video disponible',
                      style: TextStyle(fontSize: 12, color: Colors.red),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 6),
            Text(
              '\$${_price(product['price']).toStringAsFixed(2)}',
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            const SizedBox(height: 6),
            SizedBox(
              width: double.infinity,
              height: 30,
              child: OutlinedButton.icon(
                onPressed: () => _openProductDetail(product),
                icon: const Icon(Icons.visibility, size: 18),
                label: const Text('Ver ficha'),
                style: OutlinedButton.styleFrom(
                  visualDensity: VisualDensity.compact,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                ),
              ),
            ),
            const SizedBox(height: 4),
            SizedBox(
              width: double.infinity,
              height: 30,
              child: ElevatedButton.icon(
                onPressed: () => _addToCart(product),
                icon: const Icon(Icons.add_shopping_cart, size: 18),
                label: const Text('Agregar'),
                style: ElevatedButton.styleFrom(
                  visualDensity: VisualDensity.compact,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final products = _filteredProducts;

    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      appBar: AppBar(
        title: const Text('Marketplace Farmacia Magistral Mayu'),
        centerTitle: true,
        actions: [
          IconButton(
            tooltip: 'Tarjeta Farmacia',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const PharmacyLoyaltyCardScreen(),
                ),
              );
            },
            icon: const Icon(Icons.stars),
          ),
          IconButton(
            tooltip: 'Mis compras',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const MarketplaceMyOrdersScreen(),
                ),
              );
            },
            icon: const Icon(Icons.receipt_long),
          ),
          Stack(
            children: [
              IconButton(
                onPressed: _openCart,
                icon: const Icon(Icons.shopping_cart),
              ),
              if (_cart.isNotEmpty)
                Positioned(
                  right: 8,
                  top: 8,
                  child: CircleAvatar(
                    radius: 9,
                    backgroundColor: Colors.red,
                    child: Text(
                      _cart.length.toString(),
                      style: const TextStyle(fontSize: 11, color: Colors.white),
                    ),
                  ),
                ),
            ],
          ),
          IconButton(
            onPressed: _loadMarketplace,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Text(
                    _error!,
                    style: const TextStyle(color: Colors.red),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadMarketplace,
                  child: ListView(
                    padding: const EdgeInsets.all(18),
                    children: [
                      _pharmacyHeader(),
                      const SizedBox(height: 22),
                      TextField(
                        decoration: InputDecoration(
                          hintText: 'Buscar producto',
                          prefixIcon: const Icon(Icons.search),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(18),
                            borderSide: BorderSide.none,
                          ),
                        ),
                        onChanged: (value) {
                          setState(() {
                            _searchQuery = value;
                          });
                        },
                      ),
                      const SizedBox(height: 14),
                      SizedBox(
                        height: 44,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: _categories.length + 1,
                          separatorBuilder: (_, __) => const SizedBox(width: 8),
                          itemBuilder: (context, index) {
                            if (index == 0) {
                              return ChoiceChip(
                                label: const Text('Todas'),
                                selected: _selectedCategoryId == 0,
                                onSelected: (_) {
                                  setState(() {
                                    _selectedCategoryId = 0;
                                  });
                                },
                              );
                            }

                            final category = Map<String, dynamic>.from(
                              _categories[index - 1],
                            );

                            final id =
                                int.tryParse(category['id'].toString()) ?? 0;

                            return ChoiceChip(
                              label: Text(category['name'] ?? 'Categoría'),
                              selected: _selectedCategoryId == id,
                              onSelected: (_) {
                                setState(() {
                                  _selectedCategoryId = id;
                                });
                              },
                            );
                          },
                        ),
                      ),
                      const SizedBox(height: 22),
                      if (products.isEmpty)
                        const Center(
                          child: Padding(
                            padding: EdgeInsets.all(30),
                            child: Text('No hay productos disponibles.'),
                          ),
                        )
                      else
                        GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: products.length,
                          gridDelegate:
                              const SliverGridDelegateWithMaxCrossAxisExtent(
                            maxCrossAxisExtent: 260,
                            childAspectRatio: 0.44,
                            crossAxisSpacing: 12,
                            mainAxisSpacing: 12,
                          ),
                          itemBuilder: (context, index) {
                            return _productCard(
                              Map<String, dynamic>.from(products[index]),
                            );
                          },
                        ),
                    ],
                  ),
                ),
    );
  }
}
