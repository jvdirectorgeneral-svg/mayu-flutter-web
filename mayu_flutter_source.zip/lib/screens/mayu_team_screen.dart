import 'package:flutter/material.dart';

import 'doctor_prescriber_card_screen.dart';
import 'login_mayu_team_screen.dart';

class MayuTeamScreen extends StatelessWidget {
  const MayuTeamScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mayu Team'),
        centerTitle: true,
        actions: [
          IconButton(
            tooltip: 'Doctor Prescriptor Mayu',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const DoctorPrescriberCardScreen(),
                ),
              );
            },
            icon: const Icon(Icons.stars),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 500),
            child: ListView(
              shrinkWrap: true,
              children: [
                const Icon(
                  Icons.admin_panel_settings,
                  size: 60,
                ),
                const SizedBox(height: 16),
                const Text(
                  'Mayu Team',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 12),
                const Text(
                  'Acceso interno para el equipo Mayu:\nSuperadmin, Administradores, Supervisores, Logística, Marketing, Farmacia Magistral y Educación.',
                  style: TextStyle(fontSize: 16),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 28),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              const LoginMayuTeamScreen(),
                        ),
                      );
                    },
                    icon: const Icon(Icons.login),
                    label: const Text(
                      'Ingresar a Mayu Team',
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.black12),
                  ),
                  child: const Text(
                    'Acceso restringido únicamente para personal autorizado de Mayu.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 13),
                  ),
                ),
                const SizedBox(height: 18),
                const _DoctorPrescriberAccessCard(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _DoctorPrescriberAccessCard extends StatelessWidget {
  const _DoctorPrescriberAccessCard();

  void _openDoctor(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const DoctorPrescriberCardScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFFF3FAF9),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0x2230B7AD)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.medical_services,
            color: Color(0xFF00695C),
            size: 54,
          ),
          const SizedBox(height: 12),
          const Text(
            'Afiliación Doctor Prescriptor Mayu',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          const Text(
            'Comisiona el 30% de ventas prescritas. Farmacia registra la venta y aquí ves tu avance.',
            textAlign: TextAlign.center,
            style: TextStyle(height: 1.35),
          ),
          const SizedBox(height: 18),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => _openDoctor(context),
              icon: const Icon(Icons.badge),
              label: const Text('Activar Doctor Prescriptor Mayu'),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () => _openDoctor(context),
              icon: const Icon(Icons.restore),
              label: const Text('Recuperar tarjeta Doctor'),
            ),
          ),
        ],
      ),
    );
  }
}
