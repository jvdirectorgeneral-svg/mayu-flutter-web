import 'package:flutter/material.dart';

import '../services/pharmacy_loyalty_service.dart';
import 'pharmacy_magistral_affiliates_screen.dart';
import 'pharmacy_qr_scanner_screen.dart';

class PharmacyPointsAdminScreen extends StatefulWidget {
  const PharmacyPointsAdminScreen({super.key});

  @override
  State<PharmacyPointsAdminScreen> createState() =>
      _PharmacyPointsAdminScreenState();
}

class _PharmacyPointsAdminScreenState extends State<PharmacyPointsAdminScreen> {
  final PharmacyLoyaltyService _service = PharmacyLoyaltyService();
  final _cardController = TextEditingController();
  final _amountController = TextEditingController();
  final _referenceController = TextEditingController();
  final _noteController = TextEditingController();
  bool _saving = false;
  bool _checkingCard = false;
  Map<String, dynamic>? _resolvedCard;

  @override
  void dispose() {
    _cardController.dispose();
    _amountController.dispose();
    _referenceController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _scanQr() async {
    final identifier = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => const PharmacyQrScannerScreen()),
    );
    if (!mounted || identifier == null || identifier.trim().isEmpty) return;
    _cardController.text = identifier.trim();
    await _resolveCard();
  }

  Future<void> _openAffiliates() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const PharmacyMagistralAffiliatesScreen(),
      ),
    );
  }

  Future<void> _resolveCard() async {
    final identifier = _cardController.text.trim();
    if (identifier.isEmpty) return;
    setState(() {
      _checkingCard = true;
      _resolvedCard = null;
    });
    final result = await _service.resolveCard(identifier);
    if (!mounted) return;
    setState(() => _checkingCard = false);
    if (result['statusCode'] == 200) {
      final data = Map<String, dynamic>.from(result['data']);
      setState(() {
        _resolvedCard = Map<String, dynamic>.from(data['card'] as Map);
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No se pudo validar la tarjeta',
          ),
        ),
      );
    }
  }

  Future<void> _credit() async {
    final identifier = _cardController.text.trim();
    final amount = double.tryParse(
      _amountController.text.replaceAll(',', '.').trim(),
    );
    final reference = _referenceController.text.trim();
    if (identifier.isEmpty ||
        amount == null ||
        amount <= 0 ||
        reference.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Completa tarjeta, monto y número de factura'),
        ),
      );
      return;
    }
    setState(() => _saving = true);
    final result = await _service.creditPurchase(
      identifier: identifier,
      amount: amount,
      reference: reference,
      note: _noteController.text,
    );
    if (!mounted) return;
    setState(() => _saving = false);
    if (result['statusCode'] == 200) {
      final earned = result['data']?['points_earned'] ?? 0;
      final card = result['data']?['card'];
      final balance = card is Map ? card['points_balance'] ?? 0 : 0;
      if (card is Map) {
        setState(() {
          _resolvedCard = Map<String, dynamic>.from(card);
        });
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Se acreditaron $earned punto(s). Saldo: $balance'),
        ),
      );
      await _showWalletSyncResult(result['data']);
      _amountController.clear();
      _referenceController.clear();
      _noteController.clear();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No se pudieron acreditar los puntos',
          ),
        ),
      );
    }
  }

  Future<void> _showWalletSyncResult(dynamic data) async {
    if (!mounted || data is! Map) return;

    final walletSync = data['wallet_sync'];
    if (walletSync is! Map) return;

    final apple = walletSync['apple'];
    final google = walletSync['google'];
    final push = data['push'];

    final lines = <String>[];
    if (apple is Map) {
      final registered = apple['registered'] ?? apple['registered_devices'] ?? 0;
      final sent = apple['sent'];
      final errors = apple['errors'];
      lines.add('Apple Wallet registrado: $registered dispositivo(s)');
      if (sent != null) lines.add('Avisos enviados a Apple Wallet: $sent');
      if (errors is List && errors.isNotEmpty) {
        lines.add('Errores Apple: ${errors.take(2).join(' | ')}');
      }
    }

    if (google is Map) {
      final updated = google['updated'];
      final detail = google['detail'];
      if (updated != null) lines.add('Google Wallet actualizado: $updated');
      if (detail != null) lines.add('Google Wallet: $detail');
    }

    if (push is Map) {
      lines.add('Push app enviados: ${push['sent'] ?? 0}');
      final errors = push['errors'];
      if (errors is List && errors.isNotEmpty) {
        lines.add('Errores push app: ${errors.take(2).join(' | ')}');
      }
    }

    if (lines.isEmpty) return;

    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sincronización de tarjeta'),
        content: Text(lines.join('\n')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final card = _resolvedCard;
    return Scaffold(
      appBar: AppBar(title: const Text('Acreditar puntos Mayu Magistral')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text(
            'Por cada \$10 acumulados se acredita 1 punto.',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _openAffiliates,
            icon: const Icon(Icons.people),
            label: const Text('Ver afiliados Mayu Magistral'),
          ),
          const SizedBox(height: 18),
          TextField(
            controller: _cardController,
            onSubmitted: (_) => _resolveCard(),
            decoration: InputDecoration(
              labelText: 'Código o token de Tarjeta Mayu Magistral',
              prefixIcon: IconButton(
                tooltip: 'Escanear QR',
                onPressed: _scanQr,
                icon: const Icon(Icons.qr_code_scanner),
              ),
              suffixIcon: _checkingCard
                  ? const Padding(
                      padding: EdgeInsets.all(12),
                      child: SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                    )
                  : IconButton(
                      tooltip: 'Validar tarjeta',
                      onPressed: _resolveCard,
                      icon: const Icon(Icons.search),
                    ),
              border: const OutlineInputBorder(),
            ),
          ),
          if (card != null) ...[
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                leading: const Icon(Icons.card_membership),
                title: Text(card['customer_name']?.toString() ?? ''),
                subtitle: Text(card['card_code']?.toString() ?? ''),
                trailing: Text('${card['points_balance'] ?? 0} pts'),
              ),
            ),
          ],
          const SizedBox(height: 12),
          TextField(
            controller: _amountController,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'Dólares comprados',
              prefixText: '\$ ',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _referenceController,
            decoration: const InputDecoration(
              labelText: 'Número de factura',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _noteController,
            decoration: const InputDecoration(
              labelText: 'Nota opcional',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 18),
          ElevatedButton.icon(
            onPressed: _saving ? null : _credit,
            icon: const Icon(Icons.add_card),
            label: Text(_saving ? 'Guardando...' : 'Acreditar puntos'),
          ),
        ],
      ),
    );
  }
}
