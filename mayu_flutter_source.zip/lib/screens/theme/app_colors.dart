import 'package:flutter/material.dart';

class AppColors {
  static const Color background = Color(0xFFE6E6E6);
  static const Color primary = Color(0xFF30AFA8);
  static const Color secondary = Color(0xFF015850);
  static const Color black = Color(0xFF1A1A1A);
  static const Color gold = Color(0xFFD79B2D);
  static const Color orange = Color(0xFFFFAC28);

  static const Color white = Colors.white;
  static const Color error = Colors.redAccent;
}