import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/user_service.dart';
import '../services/membership_history_service.dart';
import '../widgets/mayu_scaffold.dart';

class MembershipHistoryScreen extends StatefulWidget {
  const MembershipHistoryScreen({super.key});

  @override
  State<MembershipHistoryScreen> createState() =>
      _MembershipHistoryScreenState();
}

class _MembershipHistoryScreenState extends State<MembershipHistoryScreen> {
  final UserService _userService = UserService();
  final MembershipHistoryService _membershipHistoryService =
      MembershipHistoryService();

  bool loading = true;
  String? error;

  List<dynamic> deliveredHistory = [];
  Map<String, dynamic>? upcomingDelivery;

  String searchQuery = '';

  static const double margen1 = 16;

  @override
  void initState() {
    super.initState();
    loadHistory();
  }

  Future<void> loadHistory() async {
    setState(() {
      loading = true;
      error = null;
    });

    try {
      final Map<String, dynamic>? me = await _userService.getMe();

      if (me == null || me["id"] == null) {
        setState(() {
          error = "No se pudo obtener el usuario actual";
          loading = false;
        });
        return;
      }

      final int userId = int.tryParse(me["id"].toString()) ?? 0;

      if (userId == 0) {
        setState(() {
          error = "Usuario inválido";
          loading = false;
        });
        return;
      }

      final result = await _membershipHistoryService.getMembershipHistory(
        userId,
      );

      if (!mounted) return;

      if (result["statusCode"] == 200 && result["data"] != null) {
        final data = result["data"];

        setState(() {
          deliveredHistory = data["history"] is List ? data["history"] : [];

          upcomingDelivery = data["upcoming"] is Map
              ? Map<String, dynamic>.from(data["upcoming"])
              : null;

          loading = false;
        });
      } else {
        setState(() {
          error = result["data"]?["detail"] ?? "Aún no hay historial disponible";
          loading = false;
        });
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        error = "Error cargando historial: $e";
        loading = false;
      });
    }
  }

  String safeLabel(dynamic value, String fallback) {
    if (value == null) return fallback;
    final text = value.toString().trim();
    return text.isEmpty ? fallback : text;
  }

  String _statusLabel(dynamic status) {
    final value = safeLabel(status, "");

    switch (value) {
      case "pending_payment_review":
        return "Revisión de pago";
      case "approved_for_logistics":
        return "Listo para despacho";
      case "preparing":
        return "Preparando";
      case "shipped":
        return "Enviado";
      case "delivered":
        return "Entregado";
      case "cancelled":
        return "Cancelado";
      case "Pendiente para próximo despacho semanal":
        return "Pendiente para próximo despacho";
      case "Procesado":
        return "Procesado";
      default:
        return value.isEmpty ? "Sin estado" : value;
    }
  }

  Color _statusColor(dynamic status) {
    final value = safeLabel(status, "");

    switch (value) {
      case "approved_for_logistics":
      case "delivered":
        return Colors.green;
      case "preparing":
        return Colors.blue;
      case "shipped":
        return Colors.purple;
      case "cancelled":
        return Colors.red;
      case "pending_payment_review":
        return Colors.orange;
      case "Pendiente para próximo despacho semanal":
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  String _formatDate(dynamic value) {
    if (value == null || value.toString().trim().isEmpty) return "-";

    try {
      final date = DateTime.parse(value.toString()).toLocal();
      final day = date.day.toString().padLeft(2, "0");
      final month = date.month.toString().padLeft(2, "0");
      final year = date.year.toString();
      final hour = date.hour.toString().padLeft(2, "0");
      final minute = date.minute.toString().padLeft(2, "0");

      return "$day/$month/$year $hour:$minute";
    } catch (_) {
      return value.toString();
    }
  }

  List<dynamic> _productsFromItem(Map<String, dynamic> item) {
    final rawProducts = item["products"];
    final deliveryProducts = item["delivery_products"];
    final editableProducts = item["editableProducts"];
    final fixedProducts = item["fixedProducts"];

    final List<dynamic> products = [];

    if (rawProducts is List && rawProducts.isNotEmpty) {
      for (final p in rawProducts) {
        if (p is Map) {
          products.add(
            p["name"] ?? p["product_name_snapshot"] ?? "Producto sin nombre",
          );
        } else {
          products.add(p);
        }
      }
      return products;
    }

    if (deliveryProducts is List && deliveryProducts.isNotEmpty) {
      for (final p in deliveryProducts) {
        if (p is Map) {
          products.add(
            p["name"] ?? p["product_name_snapshot"] ?? "Producto sin nombre",
          );
        } else {
          products.add(p);
        }
      }
      return products;
    }

    if (fixedProducts is List) {
      products.addAll(fixedProducts);
    }

    if (editableProducts is List) {
      products.addAll(editableProducts);
    } else if (item["editableProduct"] != null) {
      products.add(item["editableProduct"]);
    }

    return products;
  }

  bool _matchesSearch(Map<String, dynamic> item) {
    if (searchQuery.trim().isEmpty) return true;

    final q = searchQuery.toLowerCase();

    final values = [
      item["monthLabel"],
      item["month_label"],
      item["planName"],
      item["status"],
      item["order_status"],
      item["shippingWindow"],
      item["editableProduct"],
      item["order_code"],
      item["tracking_number"],
      item["tracking_url"],
      item["carrier"],
      item["shipping_notes"],
      item["logistics_notes"],
    ];

    for (final value in values) {
      if (value != null && value.toString().toLowerCase().contains(q)) {
        return true;
      }
    }

    for (final product in _productsFromItem(item)) {
      if (product.toString().toLowerCase().contains(q)) return true;
    }

    return false;
  }

  Future<void> _openTrackingUrl(String url) async {
    final cleanUrl = url.trim();

    if (cleanUrl.isEmpty || cleanUrl == "-") {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("No hay link de tracking disponible")),
      );
      return;
    }

    final uri = Uri.tryParse(cleanUrl);

    if (uri == null || !uri.hasScheme) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Link de tracking inválido")),
      );
      return;
    }

    final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);

    if (!opened && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("No se pudo abrir el tracking")),
      );
    }
  }

  Widget sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12, top: 24),
      child: Text(
        title,
        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget card({required Widget child}) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.82),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12, width: 1.5),
      ),
      child: child,
    );
  }

  Widget _badge(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: TextStyle(color: color, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget productList(List<dynamic> products) {
    if (products.isEmpty) {
      return const Text(
        "Sin productos registrados",
        style: TextStyle(fontSize: 15),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: products.map((product) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 6),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("• "),
              Expanded(
                child: Text(
                  product.toString(),
                  style: const TextStyle(fontSize: 15),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _trackingHistoryWidget(Map<String, dynamic> item) {
    final raw = item["tracking_history"];

    if (raw is! List || raw.isEmpty) {
      return const SizedBox.shrink();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 14),
        const Text(
          "Historial de logística:",
          style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        ...raw.map((h) {
          final history = Map<String, dynamic>.from(h as Map);

          return Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text(
              "• ${_statusLabel(history["status"])} — ${safeLabel(history["note"], "Sin nota")} (${_formatDate(history["created_at"])})",
              style: const TextStyle(fontSize: 14),
            ),
          );
        }),
      ],
    );
  }

  Widget _cycleNotice(Map<String, dynamic> item, {required bool upcoming}) {
    final movedToNext = item["moved_to_next_cycle"] == true;
    final orderLocked = item["order_locked"] == true;

    if (movedToNext && upcoming) {
      return Container(
        width: double.infinity,
        margin: const EdgeInsets.only(top: 10, bottom: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.orange.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.orange.withValues(alpha: 0.35)),
        ),
        child: const Text(
          "La orden actual ya fue liberada a logística. Esta selección corresponde al próximo ciclo.",
          style: TextStyle(fontSize: 14),
        ),
      );
    }

    if (orderLocked && !upcoming) {
      return Container(
        width: double.infinity,
        margin: const EdgeInsets.only(top: 10, bottom: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.blueGrey.withValues(alpha: 0.10),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.blueGrey.withValues(alpha: 0.30)),
        ),
        child: const Text(
          "Esta orden ya fue liberada a logística y no puede modificarse.",
          style: TextStyle(fontSize: 14),
        ),
      );
    }

    return const SizedBox.shrink();
  }

  Widget _deliveryCard(Map<String, dynamic> item, {required bool upcoming}) {
    final products = _productsFromItem(item);

    final orderStatus = item["order_status"] ?? item["status"];
    final trackingNumber = safeLabel(item["tracking_number"], "");
    final trackingUrl = safeLabel(item["tracking_url"], "");
    final carrier = safeLabel(item["carrier"], "");
    final shippingNotes = safeLabel(item["shipping_notes"], "");
    final logisticsNotes = safeLabel(item["logistics_notes"], "");

    final monthLabel = safeLabel(
      item["monthLabel"] ?? item["month_label"],
      upcoming ? "Próximo ciclo operativo" : "Ciclo anterior",
    );

    return card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            monthLabel,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          _cycleNotice(item, upcoming: upcoming),
          const SizedBox(height: 8),
          Text(
            "Plan: ${safeLabel(item["planName"], "Sin plan")}",
            style: const TextStyle(fontSize: 17),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _badge(
                _statusLabel(orderStatus),
                _statusColor(orderStatus),
              ),
              if (trackingNumber.isNotEmpty && trackingNumber != "-")
                _badge("Guía: $trackingNumber", Colors.blueGrey),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            "Orden: ${safeLabel(item["order_code"], "Aún no generada")}",
            style: const TextStyle(fontSize: 16),
          ),
          Text(
            "Despacho semanal: ${safeLabel(item["shippingWindow"], "viernes")}",
            style: const TextStyle(fontSize: 16),
          ),
          if (carrier.isNotEmpty && carrier != "-")
            Text(
              "Transportadora: $carrier",
              style: const TextStyle(fontSize: 16),
            ),
          if (shippingNotes.isNotEmpty && shippingNotes != "-")
            Text(
              "Notas de envío: $shippingNotes",
              style: const TextStyle(fontSize: 16),
            ),
          if (logisticsNotes.isNotEmpty && logisticsNotes != "-")
            Text(
              "Notas logística: $logisticsNotes",
              style: const TextStyle(fontSize: 16),
            ),
          if (item["prepared_at"] != null)
            Text("Preparado: ${_formatDate(item["prepared_at"])}"),
          if (item["shipped_at"] != null)
            Text("Enviado: ${_formatDate(item["shipped_at"])}"),
          if (item["delivered_at"] != null)
            Text("Entregado: ${_formatDate(item["delivered_at"])}"),
          if (trackingUrl.isNotEmpty && trackingUrl != "-") ...[
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: () => _openTrackingUrl(trackingUrl),
              icon: const Icon(Icons.local_shipping),
              label: const Text("Ver tracking"),
            ),
          ],
          const SizedBox(height: 14),
          const Text(
            "Productos:",
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          productList(products),
          _trackingHistoryWidget(item),
          const SizedBox(height: 12),
          const Text(
            "Administración revisa pagos y suscripciones de lunes a jueves. Logística despacha los viernes las órdenes aprobadas.",
            style: TextStyle(fontSize: 14),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filteredHistory = deliveredHistory
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .where(_matchesSearch)
        .toList();

    return MayuScaffold(
      appBar: AppBar(
        title: const Text("Historial de entregas"),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: loadHistory,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: margen1, bottom: margen1),
          child: loading
              ? const Center(child: CircularProgressIndicator())
              : error != null
                  ? Center(child: Text(error!))
                  : RefreshIndicator(
                      onRefresh: loadHistory,
                      child: ListView(
                        padding: const EdgeInsets.symmetric(horizontal: 18),
                        children: [
                          TextField(
                            decoration: const InputDecoration(
                              hintText:
                                  "Buscar por mes, plan, producto, estado, orden o guía",
                              prefixIcon: Icon(Icons.search),
                              border: OutlineInputBorder(),
                            ),
                            onChanged: (value) {
                              setState(() {
                                searchQuery = value;
                              });
                            },
                          ),
                          sectionTitle("Próximo ciclo / despacho"),
                          if (upcomingDelivery == null)
                            card(
                              child: const Text(
                                "No hay próximo ciclo registrado todavía.",
                                style: TextStyle(fontSize: 16),
                              ),
                            )
                          else
                            _deliveryCard(
                              Map<String, dynamic>.from(upcomingDelivery!),
                              upcoming: true,
                            ),
                          sectionTitle("Historial de despachos"),
                          if (filteredHistory.isEmpty)
                            card(
                              child: const Text(
                                "No hay despachos registrados todavía.",
                                style: TextStyle(fontSize: 16),
                              ),
                            )
                          else
                            ...filteredHistory.map(
                              (item) => _deliveryCard(
                                item,
                                upcoming: false,
                              ),
                            ),
                        ],
                      ),
                    ),
        ),
      ),
    );
  }
}