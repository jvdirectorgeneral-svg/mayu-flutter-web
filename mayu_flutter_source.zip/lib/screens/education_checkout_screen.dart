import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/education_service.dart';

class EducationCheckoutScreen extends StatefulWidget {
  final List<Map<String, dynamic>> cartItems;

  const EducationCheckoutScreen({
    super.key,
    required this.cartItems,
  });

  @override
  State<EducationCheckoutScreen> createState() =>
      _EducationCheckoutScreenState();
}

class _EducationCheckoutScreenState extends State<EducationCheckoutScreen> {
  final EducationService _service = EducationService();

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _confirmEmailController = TextEditingController();

  bool _paypalLoading = false;
  bool _payPhoneLoading = false;
  String? _pendingPayPhoneClientTransactionId;

  final int _userId = 1;

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _confirmEmailController.dispose();
    super.dispose();
  }

  double _price(dynamic value) {
    return double.tryParse((value ?? 0).toString()) ?? 0;
  }

  double get _subtotal {
    double total = 0;

    for (final item in widget.cartItems) {
      final resource = Map<String, dynamic>.from(item['resource']);
      final quantity = int.tryParse((item['quantity'] ?? 1).toString()) ?? 1;
      total += _price(resource['price']) * quantity;
    }

    return total;
  }

  bool _isValidEmail(String value) {
    final email = value.trim();
    final regex = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');
    return regex.hasMatch(email);
  }

  List<Map<String, dynamic>> _educationOrderItems() {
    return widget.cartItems.map((item) {
      final resource = Map<String, dynamic>.from(item['resource']);
      final resourceId = int.tryParse((resource['id'] ?? 0).toString()) ?? 0;
      final quantity = int.tryParse((item['quantity'] ?? 1).toString()) ?? 1;

      return {
        'product_id': resourceId,
        'quantity': quantity,
      };
    }).toList();
  }

  String _extractPayPhoneLink(dynamic data) {
    if (data is! Map) return '';

    final direct = data['payment_url'] ??
        data['approval_url'] ??
        data['link'] ??
        data['url'];
    if (direct != null && direct.toString().trim().isNotEmpty) {
      return direct.toString();
    }

    final payphone = data['payphone'];
    if (payphone is Map) {
      final nested = payphone['link'] ??
          payphone['url'] ??
          payphone['paymentUrl'] ??
          payphone['payment_url'] ??
          payphone['shortUrl'] ??
          payphone['short_url'];
      if (nested != null && nested.toString().trim().isNotEmpty) {
        return nested.toString();
      }
    }

    return '';
  }

  bool _validateBuyerData() {
    final name = _nameController.text.trim();
    final phone = _phoneController.text.trim();
    final email = _emailController.text.trim();
    final confirmEmail = _confirmEmailController.text.trim();

    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('El nombre completo es obligatorio')),
      );
      return false;
    }

    if (phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('El teléfono / WhatsApp es obligatorio')),
      );
      return false;
    }

    if (email.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('El email es obligatorio')),
      );
      return false;
    }

    if (!_isValidEmail(email)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Ingresa un email válido')),
      );
      return false;
    }

    if (confirmEmail.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Confirma tu email')),
      );
      return false;
    }

    if (email.toLowerCase() != confirmEmail.toLowerCase()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Los emails no coinciden')),
      );
      return false;
    }

    return true;
  }

  Future<void> _verifyPendingPayPhonePayment() async {
    final clientTransactionId = _pendingPayPhoneClientTransactionId;
    if (clientTransactionId == null || clientTransactionId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No hay pago PayPhone pendiente')),
      );
      return;
    }

    setState(() {
      _payPhoneLoading = true;
    });

    final result = await _service.confirmMarketplacePayPhoneOrder(
      clientTransactionId: clientTransactionId,
    );

    if (!mounted) return;

    setState(() {
      _payPhoneLoading = false;
    });

    if (result['statusCode'] == 200 || result['statusCode'] == 201) {
      setState(() {
        _pendingPayPhoneClientTransactionId = null;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
              'Pago PayPhone confirmado. Revisa tu email con los códigos.'),
        ),
      );

      if (Navigator.canPop(context)) {
        Navigator.pop(context, true);
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'PayPhone aun no confirma el pago',
          ),
        ),
      );
    }
  }

  Future<void> _payWithPayPhone() async {
    if (widget.cartItems.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('El carrito está vacío')),
      );
      return;
    }

    if (!_validateBuyerData()) return;

    final items = _educationOrderItems();
    if (items.any((item) => (item['product_id'] as int) <= 0)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Hay un contenido inválido en el carrito')),
      );
      return;
    }

    setState(() {
      _payPhoneLoading = true;
    });

    try {
      final result = await _service.createMarketplacePayPhoneCartOrder(
        userId: _userId,
        buyerName: _nameController.text.trim(),
        buyerPhone: _phoneController.text.trim(),
        buyerEmail: _emailController.text.trim(),
        items: items,
      );

      if (!mounted) return;

      if (result['statusCode'] == 200 || result['statusCode'] == 201) {
        final data = result['data'];
        final paymentUrl = _extractPayPhoneLink(data);

        if (paymentUrl.isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text('PayPhone no devolvió enlace de pago')),
          );
          return;
        }

        final clientTransactionId =
            data?['clientTransactionId']?.toString() ?? '';
        setState(() {
          _pendingPayPhoneClientTransactionId =
              clientTransactionId.isEmpty ? null : clientTransactionId;
        });

        final uri = Uri.tryParse(paymentUrl);
        if (uri == null) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text('PayPhone devolvió un enlace inválido')),
          );
          return;
        }

        await launchUrl(uri, mode: LaunchMode.externalApplication);

        if (!mounted) return;
        await showDialog<void>(
          context: context,
          builder: (dialogContext) {
            return AlertDialog(
              title: const Text('Pago PayPhone'),
              content: const Text(
                'Cuando termines el pago, vuelve a Mayu y toca “Verificar pago” para enviar tus códigos por email.',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Luego'),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(dialogContext);
                    _verifyPendingPayPhonePayment();
                  },
                  child: const Text('Verificar pago'),
                ),
              ],
            );
          },
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              result['data']?['detail']?.toString() ??
                  'No se pudo crear pago PayPhone',
            ),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _payPhoneLoading = false;
        });
      }
    }
  }

  Future<void> _payWithPayPal() async {
    if (widget.cartItems.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('El carrito está vacío')),
      );
      return;
    }

    if (!_validateBuyerData()) return;

    final items = _educationOrderItems();
    if (items.any((item) => (item['product_id'] as int) <= 0)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Hay un contenido inválido en el carrito')),
      );
      return;
    }

    setState(() {
      _paypalLoading = true;
    });

    final result = await _service.createMarketplacePayPalCartOrder(
      userId: _userId,
      buyerName: _nameController.text.trim(),
      buyerPhone: _phoneController.text.trim(),
      buyerEmail: _emailController.text.trim(),
      items: items,
    );

    if (!mounted) return;

    setState(() {
      _paypalLoading = false;
    });

    if (result['statusCode'] == 200 || result['statusCode'] == 201) {
      final approvalUrl = result['data']?['approval_url']?.toString() ?? '';

      if (approvalUrl.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('PayPal no devolvió enlace de pago')),
        );
        return;
      }

      final uri = Uri.parse(approvalUrl);
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No se pudo crear pago PayPal',
          ),
        ),
      );
    }
  }

  Widget _summaryRow(String label, double amount, {bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: bold ? 18 : 15,
              fontWeight: bold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          Text(
            '\$${amount.toStringAsFixed(2)} USD',
            style: TextStyle(
              fontSize: bold ? 18 : 15,
              fontWeight: bold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }

  Widget _itemCard(Map<String, dynamic> item) {
    final resource = Map<String, dynamic>.from(item['resource']);
    final quantity = int.tryParse((item['quantity'] ?? 1).toString()) ?? 1;
    final unitPrice = _price(resource['price']);
    final total = unitPrice * quantity;

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: const Icon(Icons.school, color: Colors.teal),
        title: Text(resource['title']?.toString() ?? 'Contenido educativo'),
        subtitle: Text(
          'Cantidad: $quantity\nPrecio: \$${unitPrice.toStringAsFixed(2)} USD',
        ),
        isThreeLine: true,
        trailing: Text(
          '\$${total.toStringAsFixed(2)}',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      appBar: AppBar(
        title: const Text('Checkout Mayu Educación'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Resumen de compra',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 14),
          if (widget.cartItems.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Center(child: Text('No hay contenidos en el carrito')),
              ),
            )
          else
            ...widget.cartItems.map(_itemCard),
          const SizedBox(height: 12),
          _summaryRow('Subtotal', _subtotal),
          const Divider(),
          _summaryRow('Total', _subtotal, bold: true),
          const SizedBox(height: 24),
          const Text(
            'Datos del comprador',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _nameController,
            textCapitalization: TextCapitalization.words,
            decoration: const InputDecoration(
              labelText: 'Nombre completo *',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _phoneController,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
              labelText: 'Teléfono / WhatsApp *',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _emailController,
            keyboardType: TextInputType.emailAddress,
            textCapitalization: TextCapitalization.none,
            decoration: const InputDecoration(
              labelText: 'Email obligatorio *',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _confirmEmailController,
            keyboardType: TextInputType.emailAddress,
            textCapitalization: TextCapitalization.none,
            decoration: const InputDecoration(
              labelText: 'Confirmar email *',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'El código de acceso será enviado a este email después de confirmar el pago.',
            style: TextStyle(
              color: Colors.black54,
              fontSize: 13,
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            height: 54,
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: (_payPhoneLoading || _paypalLoading)
                  ? null
                  : _payWithPayPhone,
              icon: const Icon(Icons.phone_iphone),
              label: Text(
                _payPhoneLoading
                    ? 'Conectando con PayPhone...'
                    : 'Pagar con PayPhone',
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                foregroundColor: Colors.white,
              ),
            ),
          ),
          if (_pendingPayPhoneClientTransactionId != null) ...[
            const SizedBox(height: 10),
            SizedBox(
              height: 50,
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed:
                    _payPhoneLoading ? null : _verifyPendingPayPhonePayment,
                icon: const Icon(Icons.verified),
                label: const Text('Verificar pago PayPhone'),
              ),
            ),
          ],
          const SizedBox(height: 10),
          SizedBox(
            height: 54,
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed:
                  (_paypalLoading || _payPhoneLoading) ? null : _payWithPayPal,
              icon: const Icon(Icons.payment),
              label: Text(
                _paypalLoading
                    ? 'Conectando con PayPal...'
                    : 'Pagar con PayPal',
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
