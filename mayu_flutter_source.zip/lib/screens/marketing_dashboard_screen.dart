import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/marketing_service.dart';
import '../services/auth_service.dart';
import 'login_mayu_team_screen.dart';

class MarketingDashboardScreen extends StatefulWidget {
  const MarketingDashboardScreen({super.key});

  @override
  State<MarketingDashboardScreen> createState() =>
      _MarketingDashboardScreenState();
}

class _MarketingDashboardScreenState extends State<MarketingDashboardScreen> {
  final MarketingService _service = MarketingService();
  final AuthService _authService = AuthService();
  final ImagePicker _picker = ImagePicker();

  bool _loading = true;
  bool _creating = false;
  bool _loadingContacts = false;
  bool _uploadingImage = false;
  bool _runningScheduled = false;
  String? _error;

  Map<String, dynamic> _dashboard = {};
  List<dynamic> _campaigns = [];
  List<dynamic> _contacts = [];

  String _selectedChannel = 'push';
  String _selectedTargetGroup = 'members';
  String _filterChannel = 'all';

  DateTime? _scheduledAt;
  XFile? _selectedImage;

  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _subjectController = TextEditingController();
  final TextEditingController _messageController = TextEditingController();
  final TextEditingController _imageUrlController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadData();
    _loadContacts();
  }

  String _channelLabel(String channel) {
    switch (channel) {
      case 'push':
        return 'Push';
      case 'email':
        return 'Mailing';
      case 'whatsapp':
        return 'WhatsApp';
      default:
        return channel;
    }
  }

  String _targetLabel(String target) {
    switch (target) {
      case 'members':
        return 'Socios';
      case 'active_members':
        return 'Socios activos';
      case 'inactive_members':
        return 'Socios inactivos';
      case 'ambassadors':
        return 'Embajadores';
      case 'pharmacy_marketplace':
        return 'Farmacia Mayu';
      case 'education_marketplace':
        return 'Educación Mayu';
      default:
        return target;
    }
  }

  IconData _channelIcon(String channel) {
    if (channel == 'email') return Icons.email;
    if (channel == 'whatsapp') return Icons.chat;
    return Icons.notifications_active;
  }


  Future<void> _openWhatsAppContact(String? url) async {
    if (url == null || url.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Este contacto no tiene WhatsApp válido')),
      );
      return;
    }

    final uri = Uri.parse(url);
    final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);

    if (!opened && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No se pudo abrir WhatsApp')),
      );
    }
  }

  String _formatDateTime(DateTime date) {
    final day = date.day.toString().padLeft(2, '0');
    final month = date.month.toString().padLeft(2, '0');
    final year = date.year.toString();
    final hour = date.hour.toString().padLeft(2, '0');
    final minute = date.minute.toString().padLeft(2, '0');
    return '$day/$month/$year $hour:$minute';
  }

  String _formatScheduledFromApi(dynamic value) {
    if (value == null) return '';

    final raw = value.toString().trim();

    if (raw.isEmpty || raw == 'null') return '';

    try {
      final parsed = DateTime.parse(raw);

      final hasTimezone =
          raw.endsWith('Z') || RegExp(r'([+-]\d{2}:\d{2})$').hasMatch(raw);

      final utcDate = hasTimezone
          ? parsed.toUtc()
          : DateTime.utc(
              parsed.year,
              parsed.month,
              parsed.day,
              parsed.hour,
              parsed.minute,
              parsed.second,
              parsed.millisecond,
              parsed.microsecond,
            );

      final localDate = utcDate.toLocal();

      return _formatDateTime(localDate);
    } catch (_) {
      return raw;
    }
  }

  Future<void> _pickScheduleDateTime() async {
    final now = DateTime.now();

    final selectedDate = await showDatePicker(
      context: context,
      initialDate: _scheduledAt ?? now,
      firstDate: now,
      lastDate: DateTime(now.year + 3),
    );

    if (selectedDate == null) return;
    if (!mounted) return;

    final selectedTime = await showTimePicker(
      context: context,
      initialTime: _scheduledAt != null
          ? TimeOfDay.fromDateTime(_scheduledAt!)
          : TimeOfDay.now(),
    );

    if (selectedTime == null) return;

    setState(() {
      _scheduledAt = DateTime(
        selectedDate.year,
        selectedDate.month,
        selectedDate.day,
        selectedTime.hour,
        selectedTime.minute,
      );
    });
  }

  void _clearSchedule() {
    setState(() {
      _scheduledAt = null;
    });
  }

  Future<void> _pickImage() async {
    final XFile? image = await _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 85,
    );

    if (image == null) return;

    setState(() {
      _selectedImage = image;
    });
  }

  Future<void> _uploadImage() async {
    if (_selectedImage == null) return;

    setState(() {
      _uploadingImage = true;
    });

    final result = await _service.uploadMarketingImage(file: _selectedImage!);

    if (!mounted) return;

    setState(() {
      _uploadingImage = false;
    });

    if (result['statusCode'] == 200 || result['statusCode'] == 201) {
      final imageUrl = result['data']?['image_url']?.toString();

      if (imageUrl != null && imageUrl.isNotEmpty) {
        _imageUrlController.text = imageUrl;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Flyer subido correctamente')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail'] ?? 'No se pudo subir el flyer',
          ),
        ),
      );
    }
  }

  Future<void> _loadData() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final dashboardResult = await _service.getDashboard();
    final campaignsResult = await _service.getCampaigns(
      channel: _filterChannel == 'all' ? null : _filterChannel,
    );

    if (!mounted) return;

    if (dashboardResult['statusCode'] == 200 &&
        campaignsResult['statusCode'] == 200) {
      setState(() {
        _dashboard = Map<String, dynamic>.from(dashboardResult['data'] ?? {});
        _campaigns = campaignsResult['data']?['items'] is List
            ? campaignsResult['data']['items']
            : [];
        _loading = false;
      });
    } else {
      setState(() {
        _loading = false;
        _error = dashboardResult['data']?['detail'] ??
            campaignsResult['data']?['detail'] ??
            'No se pudo cargar marketing';
      });
    }
  }

  Future<void> _loadContacts() async {
    setState(() {
      _loadingContacts = true;
    });

    final result = await _service.getAudiencePreview(
      channel: _selectedChannel,
      targetGroup: _selectedTargetGroup,
    );

    if (!mounted) return;

    setState(() {
      _loadingContacts = false;
      _contacts =
          result['statusCode'] == 200 && result['data']?['items'] is List
              ? result['data']['items']
              : [];
    });
  }

  Future<void> _createCampaign() async {
    if (_titleController.text.trim().isEmpty ||
        _messageController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Completa título y mensaje')),
      );
      return;
    }

    final bool wasScheduled = _scheduledAt != null;

    setState(() {
      _creating = true;
    });

    final result = await _service.createCampaign(
      title: _titleController.text,
      subject: _subjectController.text.trim().isEmpty
          ? null
          : _subjectController.text,
      message: _messageController.text,
      imageUrl: _imageUrlController.text.trim().isEmpty
          ? null
          : _imageUrlController.text,
      scheduledAt: _scheduledAt?.toUtc().toIso8601String(),
      channel: _selectedChannel,
      targetGroup: _selectedTargetGroup,
    );

    if (!mounted) return;

    setState(() {
      _creating = false;
    });

    if (result['statusCode'] == 200 || result['statusCode'] == 201) {
      _titleController.clear();
      _subjectController.clear();
      _messageController.clear();
      _imageUrlController.clear();

      setState(() {
        _selectedImage = null;
        _scheduledAt = null;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            wasScheduled
                ? 'Campaña programada correctamente'
                : 'Campaña creada correctamente',
          ),
        ),
      );

      await _loadData();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail'] ?? 'No se pudo crear la campaña',
          ),
        ),
      );
    }
  }

  Future<void> _sendCampaign(Map<String, dynamic> campaign) async {
    final int campaignId = int.tryParse((campaign['id'] ?? 0).toString()) ?? 0;
    if (campaignId == 0) return;

    final status = campaign['status']?.toString() ?? '';

    if (status == 'scheduled') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Esta campaña está programada y se enviará automáticamente.',
          ),
        ),
      );
      return;
    }

    final confirm = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Enviar campaña'),
          content: Text(
            '¿Seguro que deseas enviar "${campaign['title']}" a ${_targetLabel((campaign['target_group'] ?? '').toString())}?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Enviar'),
            ),
          ],
        );
      },
    );

    if (confirm != true) return;

    final result = await _service.sendCampaign(campaignId: campaignId);

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Campaña enviada a ${result['data']?['total_recipients'] ?? 0} usuarios',
          ),
        ),
      );

      await _loadData();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail'] ?? 'No se pudo enviar la campaña',
          ),
        ),
      );
    }
  }

  Future<void> _runScheduledCampaigns() async {
    setState(() {
      _runningScheduled = true;
    });

    final result = await _service.runScheduledCampaigns();

    if (!mounted) return;

    setState(() {
      _runningScheduled = false;
    });

    if (result['statusCode'] == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Campañas procesadas: ${result['data']?['processed'] ?? 0}',
          ),
        ),
      );

      await _loadData();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail'] ??
                'No se pudieron procesar campañas programadas',
          ),
        ),
      );
    }
  }

  Widget _metricCard(String title, dynamic value, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.96),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.black12),
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.teal),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    value?.toString() ?? '0',
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(title, style: const TextStyle(color: Colors.black54)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _box({required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.96),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
      ),
      child: child,
    );
  }

  Widget _buildDashboardMetrics() {
    return Column(
      children: [
        Row(
          children: [
            _metricCard(
              'Campañas',
              _dashboard['total_campaigns'],
              Icons.campaign,
            ),
            const SizedBox(width: 10),
            _metricCard(
              'Programadas',
              _dashboard['total_scheduled'],
              Icons.schedule,
            ),
            const SizedBox(width: 10),
            _metricCard('Enviados', _dashboard['total_sent'], Icons.send),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            _metricCard(
              'Push',
              _dashboard['total_push'],
              Icons.notifications_active,
            ),
            const SizedBox(width: 10),
            _metricCard('Mailing', _dashboard['total_email'], Icons.email),
            const SizedBox(width: 10),
            _metricCard('WhatsApp', _dashboard['total_whatsapp'], Icons.chat),
          ],
        ),
      ],
    );
  }

  Widget _buildContactsPreview() {
    return _box(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Contactos encontrados (${_contacts.length})',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            '${_channelLabel(_selectedChannel)} para ${_targetLabel(_selectedTargetGroup)}',
            style: const TextStyle(color: Colors.black54),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 210,
            child: _loadingContacts
                ? const Center(child: CircularProgressIndicator())
                : _contacts.isEmpty
                    ? const Center(
                        child: Text('No hay contactos para esta audiencia'),
                      )
                    : ListView.builder(
                        itemCount: _contacts.length,
                        itemBuilder: (context, index) {
                          final c = Map<String, dynamic>.from(_contacts[index]);

                          final contact = _selectedChannel == 'email'
                              ? c['email']
                              : _selectedChannel == 'whatsapp'
                                  ? c['phone']
                                  : '${c['email'] ?? '-'} | ${c['phone'] ?? '-'}';

                          final whatsappUrl = c['whatsapp_url']?.toString();

                          return ListTile(
                            dense: true,
                            leading: Icon(
                              _channelIcon(_selectedChannel),
                              color: Colors.teal,
                            ),
                            title: Text(c['name']?.toString() ?? '-'),
                            subtitle: Text(contact?.toString() ?? '-'),
                            trailing: _selectedChannel == 'whatsapp'
                                ? IconButton(
                                    tooltip: 'Abrir WhatsApp',
                                    icon: const Icon(Icons.open_in_new),
                                    color: Colors.teal,
                                    onPressed: () =>
                                        _openWhatsAppContact(whatsappUrl),
                                  )
                                : null,
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildImageSection() {
    return _box(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Flyer de campaña',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              ElevatedButton.icon(
                onPressed: _pickImage,
                icon: const Icon(Icons.image),
                label: const Text('Seleccionar flyer'),
              ),
              ElevatedButton.icon(
                onPressed: _selectedImage == null || _uploadingImage
                    ? null
                    : _uploadImage,
                icon: const Icon(Icons.cloud_upload),
                label: Text(_uploadingImage ? 'Subiendo...' : 'Subir flyer'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (_selectedImage != null)
            FutureBuilder<List<int>>(
              future: _selectedImage!.readAsBytes(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Padding(
                    padding: EdgeInsets.all(12),
                    child: CircularProgressIndicator(),
                  );
                }

                return ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Image.memory(
                    snapshot.data! as dynamic,
                    height: 220,
                    fit: BoxFit.cover,
                  ),
                );
              },
            ),
          const SizedBox(height: 12),
          TextField(
            controller: _imageUrlController,
            decoration: const InputDecoration(
              labelText: 'URL flyer subida',
              border: OutlineInputBorder(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScheduleSection() {
    return _box(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Programar campaña',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            _scheduledAt == null
                ? 'Sin fecha programada. Si no seleccionas fecha, quedará como borrador.'
                : 'Fecha programada: ${_formatDateTime(_scheduledAt!)}',
            style: const TextStyle(color: Colors.black54),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              ElevatedButton.icon(
                onPressed: _pickScheduleDateTime,
                icon: const Icon(Icons.calendar_month),
                label: const Text('Elegir fecha y hora'),
              ),
              if (_scheduledAt != null)
                OutlinedButton.icon(
                  onPressed: _clearSchedule,
                  icon: const Icon(Icons.close),
                  label: const Text('Quitar programación'),
                ),
              ElevatedButton.icon(
                onPressed: _runningScheduled ? null : _runScheduledCampaigns,
                icon: const Icon(Icons.play_arrow),
                label: Text(
                  _runningScheduled ? 'Procesando...' : 'Procesar programadas',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCreateCampaignBox() {
    return _box(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Crear campaña',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              SizedBox(
                width: 260,
                child: DropdownButtonFormField<String>(
                  value: _selectedChannel,
                  decoration: const InputDecoration(
                    labelText: 'Canal',
                    border: OutlineInputBorder(),
                  ),
                  items: const [
                    DropdownMenuItem(value: 'push', child: Text('Push')),
                    DropdownMenuItem(value: 'email', child: Text('Mailing')),
                    DropdownMenuItem(value: 'whatsapp', child: Text('WhatsApp')),
                  ],
                  onChanged: (value) async {
                    if (value == null) return;
                    setState(() {
                      _selectedChannel = value;
                    });
                    await _loadContacts();
                  },
                ),
              ),
              SizedBox(
                width: 260,
                child: DropdownButtonFormField<String>(
                  value: _selectedTargetGroup,
                  decoration: const InputDecoration(
                    labelText: 'Audiencia',
                    border: OutlineInputBorder(),
                  ),
                  items: const [
                    DropdownMenuItem(value: 'members', child: Text('Socios')),
                    DropdownMenuItem(
                      value: 'active_members',
                      child: Text('Socios activos'),
                    ),
                    DropdownMenuItem(
                      value: 'inactive_members',
                      child: Text('Socios inactivos'),
                    ),
                    DropdownMenuItem(
                      value: 'ambassadors',
                      child: Text('Embajadores'),
                    ),
                    DropdownMenuItem(
                      value: 'pharmacy_marketplace',
                      child: Text('Farmacia Mayu'),
                    ),
                    DropdownMenuItem(
                      value: 'education_marketplace',
                      child: Text('Educación Mayu'),
                    ),
                  ],
                  onChanged: (value) async {
                    if (value == null) return;
                    setState(() {
                      _selectedTargetGroup = value;
                    });
                    await _loadContacts();
                  },
                ),
              ),
              SizedBox(
                width: 360,
                child: TextField(
                  controller: _titleController,
                  decoration: const InputDecoration(
                    labelText: 'Título',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              SizedBox(
                width: 360,
                child: TextField(
                  controller: _subjectController,
                  decoration: const InputDecoration(
                    labelText: 'Asunto opcional para mailing',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _messageController,
            minLines: 4,
            maxLines: 8,
            decoration: const InputDecoration(
              labelText: 'Mensaje',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          _buildScheduleSection(),
          _buildImageSection(),
          _buildContactsPreview(),
          Align(
            alignment: Alignment.centerRight,
            child: ElevatedButton.icon(
              onPressed: _creating ? null : _createCampaign,
              icon: Icon(_scheduledAt == null ? Icons.add : Icons.schedule),
              label: Text(
                _creating
                    ? 'Guardando...'
                    : _scheduledAt == null
                        ? 'Crear campaña'
                        : 'Programar campaña',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCampaignTrailing(
    String status,
    Map<String, dynamic> campaign,
  ) {
    if (status == 'sent') {
      return const Chip(label: Text('Enviada'));
    }

    if (status == 'scheduled') {
      return const Chip(label: Text('Programada'));
    }

    return IconButton(
      onPressed: () => _sendCampaign(campaign),
      icon: const Icon(Icons.send),
      tooltip: 'Enviar ahora',
    );
  }

  Widget _buildCampaignsBox() {
    return _box(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Historial de campañas',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: 240,
            child: DropdownButtonFormField<String>(
              value: _filterChannel,
              decoration: const InputDecoration(
                labelText: 'Filtrar canal',
                border: OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(value: 'all', child: Text('Todos')),
                DropdownMenuItem(value: 'push', child: Text('Push')),
                DropdownMenuItem(value: 'email', child: Text('Mailing')),
                DropdownMenuItem(value: 'whatsapp', child: Text('WhatsApp')),
              ],
              onChanged: (value) async {
                if (value == null) return;
                setState(() {
                  _filterChannel = value;
                });
                await _loadData();
              },
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 420,
            child: _campaigns.isEmpty
                ? const Center(child: Text('No hay campañas todavía'))
                : ListView.builder(
                    itemCount: _campaigns.length,
                    itemBuilder: (context, index) {
                      final campaign =
                          Map<String, dynamic>.from(_campaigns[index]);
                      final status = campaign['status']?.toString() ?? '-';
                      final imageUrl = campaign['image_url']?.toString();
                      final scheduledAtText =
                          _formatScheduledFromApi(campaign['scheduled_at']);

                      return Card(
                        margin: const EdgeInsets.only(bottom: 10),
                        child: ListTile(
                          leading: imageUrl != null && imageUrl.isNotEmpty
                              ? ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Image.network(
                                    imageUrl,
                                    width: 48,
                                    height: 48,
                                    fit: BoxFit.cover,
                                  ),
                                )
                              : Icon(
                                  _channelIcon(
                                    (campaign['channel'] ?? '').toString(),
                                  ),
                                  color: Colors.teal,
                                ),
                          title: Text(
                            campaign['title']?.toString() ?? 'Sin título',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(
                            '${_channelLabel((campaign['channel'] ?? '').toString())} | ${_targetLabel((campaign['target_group'] ?? '').toString())} | $status'
                            '${scheduledAtText.isNotEmpty ? ' | Programada: $scheduledAtText' : ''}',
                          ),
                          trailing: _buildCampaignTrailing(status, campaign),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Future<void> _logout() async {
    await _authService.logout();

    if (!mounted) return;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginMayuTeamScreen()),
      (route) => false,
    );
  }

  @override
  void dispose() {
    _titleController.dispose();
    _subjectController.dispose();
    _messageController.dispose();
    _imageUrlController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7F6),
      appBar: AppBar(
        title: const Text('Marketing Mayu'),
        actions: [
          IconButton(onPressed: _loadData, icon: const Icon(Icons.refresh)),
          IconButton(onPressed: _logout, icon: const Icon(Icons.logout)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Text(
                    _error!,
                    style: const TextStyle(color: Colors.red),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadData,
                  child: SingleChildScrollView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _buildDashboardMetrics(),
                        const SizedBox(height: 14),
                        _buildCreateCampaignBox(),
                        _buildCampaignsBox(),
                      ],
                    ),
                  ),
                ),
    );
  }
}