import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/marketing_service.dart';
import '../services/auth_service.dart';
import 'login_mayu_team_screen.dart';

class MarketingDashboardScreen extends StatefulWidget {
  const MarketingDashboardScreen({super.key});

  @override
  State<MarketingDashboardScreen> createState() =>
      _MarketingDashboardScreenState();
}

class _MarketingDashboardScreenState extends State<MarketingDashboardScreen> {
  final MarketingService _service = MarketingService();
  final AuthService _authService = AuthService();
  final ImagePicker _picker = ImagePicker();
  final GlobalKey _crmSectionKey = GlobalKey();

  bool _loading = true;
  bool _creating = false;
  bool _loadingContacts = false;
  bool _uploadingImage = false;
  bool _runningScheduled = false;
  String? _error;

  Map<String, dynamic> _dashboard = {};
  List<dynamic> _campaigns = [];
  List<dynamic> _contacts = [];
  List<dynamic> _directoryContacts = [];
  int _directoryDoctors = 0;
  List<dynamic> _directoryTags = [];
  String? _openDirectoryTitle;
  String? _selectedDirectory;

  String _selectedChannel = 'push';
  String _selectedTargetGroup = 'members';
  String _selectedAudienceOption = 'members';
  String _filterChannel = 'all';

  DateTime? _scheduledAt;
  XFile? _selectedImage;

  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _subjectController = TextEditingController();
  final TextEditingController _messageController = TextEditingController();
  final TextEditingController _imageUrlController = TextEditingController();
  final TextEditingController _audienceTagController = TextEditingController();
  final TextEditingController _directorySearchController =
      TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadData();
    _loadContacts();
    _loadDirectory();
  }

  String _channelLabel(String channel) {
    switch (channel) {
      case 'push':
        return 'Push';
      case 'email':
        return 'Mailing';
      case 'whatsapp':
        return 'WhatsApp';
      default:
        return channel;
    }
  }

  String _targetLabel(String target) {
    switch (target) {
      case 'members':
        return 'Socios';
      case 'active_members':
        return 'Socios activos';
      case 'inactive_members':
        return 'Socios inactivos';
      case 'ambassadors':
        return 'Embajadores';
      case 'pharmacy_marketplace':
        return 'Farmacia Mayu';
      case 'education_marketplace':
        return 'Educación Mayu';
      case 'mayu_contacts':
        return 'CRM · Todas las bases';
      case 'doctor_contacts':
        return 'Doctores afiliados';
      case 'external_contacts':
        return 'Contactos externos';
      default:
        return target;
    }
  }

  Future<void> _loadDirectory(
      {String? search, String? source, String? tag, String? title}) async {
    final results = await Future.wait([
      _service.getDirectoryContacts(search: search, source: source, tag: tag),
      _service.getDirectoryTags(),
    ]);
    final result = results[0];
    if (!mounted) return;
    if (result['statusCode'] == 200) {
      setState(() {
        _directoryContacts = result['data']?['items'] ?? [];
        _directoryTags = results[1]['data']?['items'] ?? [];
        _openDirectoryTitle = title;
        _directoryDoctors = result['data']?['total_doctors'] ?? 0;
      });
    }
  }

  Future<void> _selectDirectory(String? value) async {
    if (value == null) return;
    setState(() => _selectedDirectory = value);
    if (value == 'all') {
      await _loadDirectory(title: 'Todas las bases');
    } else if (value.startsWith('source:')) {
      final source = value.substring(7);
      final titles = {
        'doctor_prescriber': 'Doctores afiliados',
        'marketplace': 'Compradores Marketplace',
        'education_marketplace': 'Compradores Educación',
      };
      await _loadDirectory(source: source, title: titles[source]);
    } else if (value.startsWith('tag:')) {
      final tag = value.substring(4);
      await _loadDirectory(tag: tag, title: tag);
    }
  }

  Future<void> _selectCrmAudience(String tag) async {
    final cleanTag = tag.trim();
    if (cleanTag.isEmpty) return;
    await _loadDirectory(tag: cleanTag, title: cleanTag);
    if (!mounted) return;
    setState(() {
      _selectedDirectory = 'tag:$cleanTag';
      _selectedTargetGroup = 'mayu_contacts';
      _selectedAudienceOption = 'crm_tag:$cleanTag';
      _audienceTagController.text = cleanTag;
    });
    await _loadContacts();
  }

  Future<void> _deleteDirectoryContact(Map<String, dynamic> contact) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Eliminar contacto del CRM'),
        content: Text(
            '¿Eliminar a ${contact['name'] ?? 'este contacto'} de todas las campañas? No se borrará su cuenta original de Mayu.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancelar')),
          FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Eliminar')),
        ],
      ),
    );
    if (confirmed != true) return;
    final id = int.tryParse('${contact['id']}');
    if (id == null) return;
    final result = await _service.deleteDirectoryContact(id);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(result['statusCode'] == 200
            ? 'Contacto eliminado del CRM'
            : (result['data']?['detail'] ?? 'No se pudo eliminar'))));
    if (result['statusCode'] == 200) {
      setState(() =>
          _directoryContacts.removeWhere((item) => '${item['id']}' == '$id'));
      final tags = await _service.getDirectoryTags();
      if (mounted && tags['statusCode'] == 200) {
        setState(() => _directoryTags = tags['data']?['items'] ?? []);
      }
      await _loadContacts();
    }
  }

  Future<void> _syncDirectory() async {
    final result = await _service.syncDirectoryContacts();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(result['statusCode'] == 200
            ? 'Contactos Mayu sincronizados'
            : (result['data']?['detail'] ?? 'No se pudo sincronizar'))));
    if (result['statusCode'] == 200) {
      await _loadDirectory();
      await _loadData();
    }
  }

  Future<void> _addDirectoryContact({String? presetCategory}) async {
    final name = TextEditingController();
    final email = TextEditingController();
    final phone = TextEditingController();
    final city = TextEditingController();
    final birthday = TextEditingController();
    final tags = TextEditingController();
    tags.text = presetCategory ?? '';
    bool consent = false;
    final save = await showDialog<bool>(
        context: context,
        builder: (context) => StatefulBuilder(
            builder: (context, setLocal) => AlertDialog(
                  title: const Text('Nuevo contacto externo'),
                  content: SizedBox(
                      width: 440,
                      child: SingleChildScrollView(
                          child:
                              Column(mainAxisSize: MainAxisSize.min, children: [
                        TextField(
                            controller: name,
                            decoration:
                                const InputDecoration(labelText: 'Nombre *')),
                        TextField(
                            controller: email,
                            decoration:
                                const InputDecoration(labelText: 'Correo')),
                        TextField(
                            controller: phone,
                            decoration:
                                const InputDecoration(labelText: 'Celular')),
                        TextField(
                            controller: city,
                            decoration:
                                const InputDecoration(labelText: 'Ciudad')),
                        TextField(
                            controller: birthday,
                            decoration: const InputDecoration(
                                labelText: 'Cumpleaños (AAAA-MM-DD)')),
                        TextField(
                            controller: tags,
                            decoration: const InputDecoration(
                                labelText: 'Categoría o base *',
                                hintText: 'Ej.: Pacientes, Taller Quito',
                                helperText:
                                    'La categoría aparecerá automáticamente como audiencia.')),
                        CheckboxListTile(
                            value: consent,
                            onChanged: (v) =>
                                setLocal(() => consent = v ?? false),
                            title: const Text('Autorizó recibir campañas'),
                            subtitle: const Text(
                                'Actívalo solo si tienes consentimiento verificable.')),
                      ]))),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: const Text('Cancelar')),
                    FilledButton(
                        onPressed: () => Navigator.pop(context, true),
                        child: const Text('Guardar'))
                  ],
                )));
    if (save != true || name.text.trim().isEmpty) return;
    if (tags.text.trim().isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Escribe una categoría o base para el contacto')));
      }
      return;
    }
    final result = await _service.createDirectoryContact(
        name: name.text,
        email: email.text,
        phone: phone.text,
        city: city.text,
        birthDate: birthday.text.trim().isEmpty ? null : birthday.text,
        tags: tags.text,
        marketingConsent: consent);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(result['statusCode'] == 200
            ? 'Contacto guardado'
            : (result['data']?['detail'] ?? 'Error'))));
    if (result['statusCode'] == 200) {
      final category = tags.text
          .split(',')
          .map((item) => item.trim())
          .firstWhere((item) => item.isNotEmpty, orElse: () => '');
      await _selectCrmAudience(category);
    }
  }

  Future<void> _importDirectory() async {
    final tagController = TextEditingController();
    final importTag = await showDialog<String>(
        context: context,
        builder: (context) => AlertDialog(
              title: const Text('Etiqueta de esta base'),
              content: TextField(
                  controller: tagController,
                  autofocus: true,
                  decoration: const InputDecoration(
                      labelText: 'Ej.: Webinar Guayaquil 2026')),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancelar')),
                FilledButton(
                    onPressed: () =>
                        Navigator.pop(context, tagController.text.trim()),
                    child: const Text('Continuar'))
              ],
            ));
    if (importTag == null || importTag.isEmpty) return;
    final selected = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['xlsx', 'xls', 'csv'],
        withData: true);
    if (selected == null || selected.files.single.bytes == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Selecciona un archivo Excel o CSV')));
      }
      return;
    }
    final selectedFile = selected.files.single;
    final extension = selectedFile.extension?.toLowerCase();
    final mimeType = extension == 'csv'
        ? 'text/csv'
        : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    final file = XFile.fromData(selectedFile.bytes!,
        name: selectedFile.name, mimeType: mimeType);
    final result = await _service.importDirectoryCsv(file, importTag);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(result['statusCode'] == 200
            ? '${result['data']?['imported'] ?? 0} contactos importados'
            : (result['data']?['detail'] ?? 'Error al importar'))));
    if (result['statusCode'] == 200) {
      await _selectCrmAudience(importTag);
    }
  }

  IconData _channelIcon(String channel) {
    if (channel == 'email') return Icons.email;
    if (channel == 'whatsapp') return Icons.chat;
    return Icons.notifications_active;
  }

  Future<void> _openWhatsAppContact(String? url) async {
    if (url == null || url.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Este contacto no tiene WhatsApp válido')),
      );
      return;
    }

    final uri = Uri.parse(url);
    final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);

    if (!opened && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No se pudo abrir WhatsApp')),
      );
    }
  }

  String _formatDateTime(DateTime date) {
    final day = date.day.toString().padLeft(2, '0');
    final month = date.month.toString().padLeft(2, '0');
    final year = date.year.toString();
    final hour = date.hour.toString().padLeft(2, '0');
    final minute = date.minute.toString().padLeft(2, '0');
    return '$day/$month/$year $hour:$minute';
  }

  String _formatScheduledFromApi(dynamic value) {
    if (value == null) return '';

    final raw = value.toString().trim();

    if (raw.isEmpty || raw == 'null') return '';

    try {
      final parsed = DateTime.parse(raw);

      final hasTimezone =
          raw.endsWith('Z') || RegExp(r'([+-]\d{2}:\d{2})$').hasMatch(raw);

      final utcDate = hasTimezone
          ? parsed.toUtc()
          : DateTime.utc(
              parsed.year,
              parsed.month,
              parsed.day,
              parsed.hour,
              parsed.minute,
              parsed.second,
              parsed.millisecond,
              parsed.microsecond,
            );

      final localDate = utcDate.toLocal();

      return _formatDateTime(localDate);
    } catch (_) {
      return raw;
    }
  }

  Future<void> _pickScheduleDateTime() async {
    final now = DateTime.now();

    final selectedDate = await showDatePicker(
      context: context,
      initialDate: _scheduledAt ?? now,
      firstDate: now,
      lastDate: DateTime(now.year + 3),
    );

    if (selectedDate == null) return;
    if (!mounted) return;

    final selectedTime = await showTimePicker(
      context: context,
      initialTime: _scheduledAt != null
          ? TimeOfDay.fromDateTime(_scheduledAt!)
          : TimeOfDay.now(),
    );

    if (selectedTime == null) return;

    setState(() {
      _scheduledAt = DateTime(
        selectedDate.year,
        selectedDate.month,
        selectedDate.day,
        selectedTime.hour,
        selectedTime.minute,
      );
    });
  }

  void _clearSchedule() {
    setState(() {
      _scheduledAt = null;
    });
  }

  Future<void> _pickImage() async {
    final XFile? image = await _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 85,
    );

    if (image == null) return;

    setState(() {
      _selectedImage = image;
    });
  }

  Future<void> _uploadImage() async {
    if (_selectedImage == null) return;

    setState(() {
      _uploadingImage = true;
    });

    final result = await _service.uploadMarketingImage(file: _selectedImage!);

    if (!mounted) return;

    setState(() {
      _uploadingImage = false;
    });

    if (result['statusCode'] == 200 || result['statusCode'] == 201) {
      final imageUrl = result['data']?['image_url']?.toString();

      if (imageUrl != null && imageUrl.isNotEmpty) {
        _imageUrlController.text = imageUrl;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Flyer subido correctamente')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail'] ?? 'No se pudo subir el flyer',
          ),
        ),
      );
    }
  }

  Future<void> _loadData() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final dashboardResult = await _service.getDashboard();
    final campaignsResult = await _service.getCampaigns(
      channel: _filterChannel == 'all' ? null : _filterChannel,
    );

    if (!mounted) return;

    if (dashboardResult['statusCode'] == 200 &&
        campaignsResult['statusCode'] == 200) {
      setState(() {
        _dashboard = Map<String, dynamic>.from(dashboardResult['data'] ?? {});
        _campaigns = campaignsResult['data']?['items'] is List
            ? campaignsResult['data']['items']
            : [];
        _loading = false;
      });
    } else {
      setState(() {
        _loading = false;
        _error = dashboardResult['data']?['detail'] ??
            campaignsResult['data']?['detail'] ??
            'No se pudo cargar marketing';
      });
    }
  }

  Future<void> _loadContacts() async {
    setState(() {
      _loadingContacts = true;
    });

    final result = await _service.getAudiencePreview(
      channel: _selectedChannel,
      targetGroup: _selectedTargetGroup,
      audienceTag: _audienceTagController.text,
    );

    if (!mounted) return;

    setState(() {
      _loadingContacts = false;
      _contacts =
          result['statusCode'] == 200 && result['data']?['items'] is List
              ? result['data']['items']
              : [];
    });
  }

  Future<void> _createCampaign() async {
    if (_titleController.text.trim().isEmpty ||
        _messageController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Completa título y mensaje')),
      );
      return;
    }

    final bool wasScheduled = _scheduledAt != null;

    setState(() {
      _creating = true;
    });

    final result = await _service.createCampaign(
      title: _titleController.text,
      subject: _subjectController.text.trim().isEmpty
          ? null
          : _subjectController.text,
      message: _messageController.text,
      imageUrl: _imageUrlController.text.trim().isEmpty
          ? null
          : _imageUrlController.text,
      scheduledAt: _scheduledAt?.toUtc().toIso8601String(),
      channel: _selectedChannel,
      targetGroup: _selectedTargetGroup,
      audienceTag: _audienceTagController.text,
    );

    if (!mounted) return;

    setState(() {
      _creating = false;
    });

    if (result['statusCode'] == 200 || result['statusCode'] == 201) {
      _titleController.clear();
      _subjectController.clear();
      _messageController.clear();
      _imageUrlController.clear();
      _audienceTagController.clear();

      setState(() {
        _selectedImage = null;
        _scheduledAt = null;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            wasScheduled
                ? 'Campaña programada correctamente'
                : 'Campaña creada correctamente',
          ),
        ),
      );

      await _loadData();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail'] ?? 'No se pudo crear la campaña',
          ),
        ),
      );
    }
  }

  Future<void> _sendCampaign(Map<String, dynamic> campaign) async {
    final int campaignId = int.tryParse((campaign['id'] ?? 0).toString()) ?? 0;
    if (campaignId == 0) return;

    final status = campaign['status']?.toString() ?? '';

    if (status == 'scheduled') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Esta campaña está programada y se enviará automáticamente.',
          ),
        ),
      );
      return;
    }

    final confirm = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Enviar campaña'),
          content: Text(
            '¿Seguro que deseas enviar "${campaign['title']}" a ${_targetLabel((campaign['target_group'] ?? '').toString())}?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Enviar'),
            ),
          ],
        );
      },
    );

    if (confirm != true) return;

    final result = await _service.sendCampaign(campaignId: campaignId);

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Campaña enviada a ${result['data']?['total_recipients'] ?? 0} usuarios',
          ),
        ),
      );

      await _loadData();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail'] ?? 'No se pudo enviar la campaña',
          ),
        ),
      );
    }
  }

  Future<void> _runScheduledCampaigns() async {
    setState(() {
      _runningScheduled = true;
    });

    final result = await _service.runScheduledCampaigns();

    if (!mounted) return;

    setState(() {
      _runningScheduled = false;
    });

    if (result['statusCode'] == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Campañas procesadas: ${result['data']?['processed'] ?? 0}',
          ),
        ),
      );

      await _loadData();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail'] ??
                'No se pudieron procesar campañas programadas',
          ),
        ),
      );
    }
  }

  Future<void> _deleteCampaign(Map<String, dynamic> campaign) async {
    final campaignId = int.tryParse((campaign['id'] ?? '').toString()) ?? 0;
    if (campaignId == 0) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Eliminar campaña'),
        content: Text(
          '¿Deseas eliminar "${campaign['title'] ?? 'Sin título'}"? Esta acción no se puede deshacer.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton.icon(
            onPressed: () => Navigator.pop(dialogContext, true),
            icon: const Icon(Icons.delete_outline),
            label: const Text('Eliminar'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    final result = await _service.deleteCampaign(campaignId: campaignId);
    if (!mounted) return;
    if (result['statusCode'] == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Campaña eliminada')),
      );
      await _loadData();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(result['data']?['detail'] ?? 'No se pudo eliminar'),
        ),
      );
    }
  }

  Future<void> _deleteAllSentCampaigns() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Eliminar historial enviado'),
        content: const Text(
          'Se eliminarán únicamente todas las campañas enviadas. Las programadas y pendientes se conservarán.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton.icon(
            onPressed: () => Navigator.pop(dialogContext, true),
            icon: const Icon(Icons.delete_sweep_outlined),
            label: const Text('Eliminar enviadas'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    final result = await _service.deleteAllSentCampaigns();
    if (!mounted) return;
    if (result['statusCode'] == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Campañas enviadas eliminadas: ${result['data']?['deleted'] ?? 0}',
          ),
        ),
      );
      await _loadData();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail'] ?? 'No se pudo limpiar el historial',
          ),
        ),
      );
    }
  }

  Widget _metricCard(String title, dynamic value, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.96),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.black12),
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.teal),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    value?.toString() ?? '0',
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(title, style: const TextStyle(color: Colors.black54)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _box({required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.96),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
      ),
      child: child,
    );
  }

  Widget _buildDashboardMetrics() {
    return Column(
      children: [
        Row(
          children: [
            _metricCard(
              'Campañas',
              _dashboard['total_campaigns'],
              Icons.campaign,
            ),
            const SizedBox(width: 10),
            _metricCard(
              'Programadas',
              _dashboard['total_scheduled'],
              Icons.schedule,
            ),
            const SizedBox(width: 10),
            _metricCard('Enviados', _dashboard['total_sent'], Icons.send),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            _metricCard(
              'Push',
              _dashboard['total_push'],
              Icons.notifications_active,
            ),
            const SizedBox(width: 10),
            _metricCard('Mailing', _dashboard['total_email'], Icons.email),
            const SizedBox(width: 10),
            _metricCard('WhatsApp', _dashboard['total_whatsapp'], Icons.chat),
          ],
        ),
      ],
    );
  }

  Widget _buildDirectoryBox() {
    return KeyedSubtree(
      key: _crmSectionKey,
      child: _box(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
          Expanded(
              child: Text('${_directoryContacts.length} contactos',
                  style: const TextStyle(
                      fontSize: 26, fontWeight: FontWeight.bold))),
          const Icon(Icons.people_alt_outlined, color: Color(0xFF00A39A))
        ]),
        const SizedBox(height: 6),
        const Text(
            'CRM Mayu · contactos, categorías y campañas en un solo lugar.',
            style: TextStyle(color: Colors.black54)),
        const SizedBox(height: 12),
        Wrap(spacing: 10, runSpacing: 10, children: [
          FilledButton.icon(
              onPressed: _syncDirectory,
              icon: const Icon(Icons.sync),
              label: const Text('Actualizar desde Mayu')),
          OutlinedButton.icon(
              onPressed: _addDirectoryContact,
              icon: const Icon(Icons.person_add),
              label: const Text('Nuevo contacto')),
          OutlinedButton.icon(
              onPressed: _importDirectory,
              icon: const Icon(Icons.upload_file),
              label: const Text('Importar Excel/CSV')),
          OutlinedButton.icon(
              onPressed: () {
                _selectedTargetGroup = 'mayu_contacts';
                _selectedAudienceOption = 'crm_tag:Pacientes';
                _audienceTagController.text = 'Pacientes';
                _addDirectoryContact(presetCategory: 'Pacientes');
              },
              icon: const Icon(Icons.medical_information_outlined),
              label: const Text('Agregar paciente')),
        ]),
        const SizedBox(height: 10),
        TextField(
          controller: _directorySearchController,
          textInputAction: TextInputAction.search,
          onSubmitted: (value) => _loadDirectory(
              search: value, title: 'Resultados en todas las bases'),
          decoration: InputDecoration(
            hintText: 'Buscar en todas las bases por nombre, correo o celular',
            prefixIcon: const Icon(Icons.search),
            suffixIcon: IconButton(
              tooltip: 'Buscar',
              onPressed: () => _loadDirectory(
                  search: _directorySearchController.text,
                  title: 'Resultados en todas las bases'),
              icon: const Icon(Icons.arrow_forward),
            ),
            border: const OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(
          value: _selectedDirectory,
          decoration: const InputDecoration(
            labelText: 'Base de contactos',
            prefixIcon: Icon(Icons.folder_open),
            border: OutlineInputBorder(),
          ),
          hint: const Text('Selecciona una base'),
          items: [
            const DropdownMenuItem(
                value: 'all', child: Text('Todas las bases')),
            DropdownMenuItem(
                value: 'source:doctor_prescriber',
                child: Text('Doctores afiliados ($_directoryDoctors)')),
            const DropdownMenuItem(
                value: 'source:marketplace',
                child: Text('Compradores Marketplace')),
            const DropdownMenuItem(
                value: 'source:education_marketplace',
                child: Text('Compradores Educación')),
            ..._directoryTags.map((item) {
              final tag = Map<String, dynamic>.from(item);
              return DropdownMenuItem(
                  value: 'tag:${tag['name']}',
                  child: Text('${tag['name']} (${tag['contacts']})'));
            }),
          ],
          onChanged: _selectDirectory,
        ),
        const SizedBox(height: 12),
        if (_openDirectoryTitle != null)
          Row(children: [
            Expanded(
                child: Text(_openDirectoryTitle!,
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.bold))),
            TextButton(
                onPressed: () => setState(() {
                      _openDirectoryTitle = null;
                      _directoryContacts = [];
                    }),
                child: const Text('Cerrar carpeta')),
          ]),
        if (_openDirectoryTitle != null) _buildCrmContactsTable(),
      ])),
    );
  }

  String _crmDate(dynamic value) {
    final date = DateTime.tryParse('${value ?? ''}')?.toLocal();
    if (date == null) return '-';
    final day = date.day.toString().padLeft(2, '0');
    final month = date.month.toString().padLeft(2, '0');
    return '$day/$month/${date.year}';
  }

  Widget _crmCell(double width, Widget child) => SizedBox(
      width: width,
      child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
          child: child));

  Widget _buildCrmContactsTable() {
    if (_directoryContacts.isEmpty) {
      return const Padding(
          padding: EdgeInsets.symmetric(vertical: 28),
          child: Center(child: Text('No hay contactos en esta base')));
    }
    const headerStyle = TextStyle(fontWeight: FontWeight.bold);
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: SizedBox(
          width: 1180,
          child: Column(children: [
            Container(
              color: const Color(0xFFF1F5F8),
              child: Row(children: [
                _crmCell(135, const Text('Registro', style: headerStyle)),
                _crmCell(300, const Text('Contacto', style: headerStyle)),
                _crmCell(
                    205, const Text('Teléfono / ciudad', style: headerStyle)),
                _crmCell(300, const Text('Etiquetas', style: headerStyle)),
                _crmCell(165, const Text('Canales', style: headerStyle)),
                _crmCell(70, const Text('Acción', style: headerStyle)),
              ]),
            ),
            ..._directoryContacts.asMap().entries.map((entry) {
              final contact = Map<String, dynamic>.from(entry.value);
              final tags = (contact['tags'] as List?)
                      ?.map((e) => '$e')
                      .toList() ??
                  (contact['sources'] as List?)?.map((e) => '$e').toList() ??
                  <String>[];
              final consent = contact['marketing_consent'] == true;
              final pushChannels = (contact['push_channels'] as List?)
                      ?.map((e) => '$e')
                      .toList() ??
                  <String>[];
              return Container(
                decoration: BoxDecoration(
                    color: entry.key.isEven
                        ? Colors.white
                        : const Color(0xFFFAFBFC),
                    border: const Border(
                        top: BorderSide(color: Color(0xFFE4E9ED)))),
                child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      _crmCell(135, Text(_crmDate(contact['created_at']))),
                      _crmCell(
                          300,
                          Row(children: [
                            const CircleAvatar(
                                radius: 18,
                                backgroundColor: Color(0xFFE1F4F2),
                                child: Icon(Icons.person_outline,
                                    color: Color(0xFF00A39A))),
                            const SizedBox(width: 10),
                            Expanded(
                                child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                  Text('${contact['name'] ?? 'Contacto Mayu'}',
                                      style: const TextStyle(
                                          fontWeight: FontWeight.w600)),
                                  Text('${contact['email'] ?? '-'}',
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                          color: Colors.black54))
                                ]))
                          ])),
                      _crmCell(
                          205,
                          Text(
                              '${contact['phone'] ?? '-'}\n${contact['city'] ?? '-'}')),
                      _crmCell(
                          300,
                          Wrap(
                              spacing: 5,
                              runSpacing: 5,
                              children: tags
                                  .take(4)
                                  .map((tag) => Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8, vertical: 4),
                                      decoration: BoxDecoration(
                                          color: const Color(0xFFEAF4F8),
                                          borderRadius:
                                              BorderRadius.circular(12)),
                                      child: Text(tag,
                                          style:
                                              const TextStyle(fontSize: 12))))
                                  .toList())),
                      _crmCell(
                          165,
                          Row(children: [
                            Icon(consent ? Icons.mark_email_read : Icons.block,
                                size: 19,
                                color: consent ? Colors.green : Colors.orange),
                            const SizedBox(width: 6),
                            Expanded(
                                child: Text(consent
                                    ? (pushChannels.isEmpty
                                        ? 'Email / WhatsApp'
                                        : 'Push: ${pushChannels.join(' + ')}')
                                    : 'Sin autorización'))
                          ])),
                      _crmCell(
                          70,
                          IconButton(
                              tooltip: 'Eliminar del CRM',
                              onPressed: () => _deleteDirectoryContact(contact),
                              icon: const Icon(Icons.delete_outline,
                                  color: Colors.red))),
                    ]),
              );
            }),
          ]),
        ),
      ),
    );
  }

  Widget _buildContactsPreview() {
    return _box(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Contactos encontrados (${_contacts.length})',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            '${_channelLabel(_selectedChannel)} para ${_targetLabel(_selectedTargetGroup)}',
            style: const TextStyle(color: Colors.black54),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 210,
            child: _loadingContacts
                ? const Center(child: CircularProgressIndicator())
                : _contacts.isEmpty
                    ? const Center(
                        child: Text('No hay contactos para esta audiencia'),
                      )
                    : ListView.builder(
                        itemCount: _contacts.length,
                        itemBuilder: (context, index) {
                          final c = Map<String, dynamic>.from(_contacts[index]);

                          final contact = _selectedChannel == 'email'
                              ? c['email']
                              : _selectedChannel == 'whatsapp'
                                  ? c['phone']
                                  : '${c['email'] ?? '-'} | ${c['phone'] ?? '-'}';

                          final whatsappUrl = c['whatsapp_url']?.toString();

                          return ListTile(
                            dense: true,
                            leading: Icon(
                              _channelIcon(_selectedChannel),
                              color: Colors.teal,
                            ),
                            title: Text(c['name']?.toString() ?? '-'),
                            subtitle: Text(contact?.toString() ?? '-'),
                            trailing: _selectedChannel == 'whatsapp'
                                ? IconButton(
                                    tooltip: 'Abrir WhatsApp',
                                    icon: const Icon(Icons.open_in_new),
                                    color: Colors.teal,
                                    onPressed: () =>
                                        _openWhatsAppContact(whatsappUrl),
                                  )
                                : null,
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildImageSection() {
    return _box(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Flyer de campaña',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              ElevatedButton.icon(
                onPressed: _pickImage,
                icon: const Icon(Icons.image),
                label: const Text('Seleccionar flyer'),
              ),
              ElevatedButton.icon(
                onPressed: _selectedImage == null || _uploadingImage
                    ? null
                    : _uploadImage,
                icon: const Icon(Icons.cloud_upload),
                label: Text(_uploadingImage ? 'Subiendo...' : 'Subir flyer'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (_selectedImage != null)
            FutureBuilder<List<int>>(
              future: _selectedImage!.readAsBytes(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Padding(
                    padding: EdgeInsets.all(12),
                    child: CircularProgressIndicator(),
                  );
                }

                return ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Image.memory(
                    snapshot.data! as dynamic,
                    height: 220,
                    fit: BoxFit.cover,
                  ),
                );
              },
            ),
          const SizedBox(height: 12),
          TextField(
            controller: _imageUrlController,
            decoration: const InputDecoration(
              labelText: 'URL flyer subida',
              border: OutlineInputBorder(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScheduleSection() {
    return _box(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Programar campaña',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            _scheduledAt == null
                ? 'Sin fecha programada. Si no seleccionas fecha, quedará como borrador.'
                : 'Fecha programada: ${_formatDateTime(_scheduledAt!)}',
            style: const TextStyle(color: Colors.black54),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              ElevatedButton.icon(
                onPressed: _pickScheduleDateTime,
                icon: const Icon(Icons.calendar_month),
                label: const Text('Elegir fecha y hora'),
              ),
              if (_scheduledAt != null)
                OutlinedButton.icon(
                  onPressed: _clearSchedule,
                  icon: const Icon(Icons.close),
                  label: const Text('Quitar programación'),
                ),
              ElevatedButton.icon(
                onPressed: _runningScheduled ? null : _runScheduledCampaigns,
                icon: const Icon(Icons.play_arrow),
                label: Text(
                  _runningScheduled ? 'Procesando...' : 'Procesar programadas',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCreateCampaignBox() {
    return _box(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Crear campaña',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              SizedBox(
                width: 260,
                child: DropdownButtonFormField<String>(
                  value: _selectedChannel,
                  decoration: const InputDecoration(
                    labelText: 'Canal',
                    border: OutlineInputBorder(),
                  ),
                  items: const [
                    DropdownMenuItem(value: 'push', child: Text('Push')),
                    DropdownMenuItem(value: 'email', child: Text('Mailing')),
                    DropdownMenuItem(
                        value: 'whatsapp', child: Text('WhatsApp')),
                  ],
                  onChanged: (value) async {
                    if (value == null) return;
                    setState(() {
                      _selectedChannel = value;
                    });
                    await _loadContacts();
                  },
                ),
              ),
              SizedBox(
                width: 260,
                child: DropdownButtonFormField<String>(
                  value: _selectedAudienceOption,
                  decoration: const InputDecoration(
                    labelText: 'Audiencia',
                    border: OutlineInputBorder(),
                  ),
                  items: [
                    const DropdownMenuItem(
                        value: 'members', child: Text('Socios')),
                    const DropdownMenuItem(
                      value: 'active_members',
                      child: Text('Socios activos'),
                    ),
                    const DropdownMenuItem(
                      value: 'inactive_members',
                      child: Text('Socios inactivos'),
                    ),
                    const DropdownMenuItem(
                      value: 'ambassadors',
                      child: Text('Embajadores'),
                    ),
                    const DropdownMenuItem(
                      value: 'pharmacy_marketplace',
                      child: Text('Farmacia Mayu'),
                    ),
                    const DropdownMenuItem(
                      value: 'education_marketplace',
                      child: Text('Educación Mayu'),
                    ),
                    const DropdownMenuItem(
                      value: 'mayu_contacts',
                      child: Text('CRM · Todas las bases'),
                    ),
                    const DropdownMenuItem(
                      value: 'doctor_contacts',
                      child: Text('CRM · Doctores afiliados'),
                    ),
                    ..._directoryTags.map((item) {
                      final tag = Map<String, dynamic>.from(item);
                      final name = '${tag['name'] ?? ''}';
                      return DropdownMenuItem(
                        value: 'crm_tag:$name',
                        child: Text('CRM · $name (${tag['contacts'] ?? 0})'),
                      );
                    }),
                  ],
                  onChanged: (value) async {
                    if (value == null) return;
                    setState(() {
                      _selectedAudienceOption = value;
                      if (value.startsWith('crm_tag:')) {
                        _selectedTargetGroup = 'mayu_contacts';
                        _audienceTagController.text = value.substring(8);
                      } else {
                        _selectedTargetGroup = value;
                        _audienceTagController.clear();
                      }
                    });
                    await _loadContacts();
                  },
                ),
              ),
              SizedBox(
                width: 360,
                child: TextField(
                  controller: _titleController,
                  decoration: const InputDecoration(
                    labelText: 'Título',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              OutlinedButton.icon(
                onPressed: () {
                  final crmContext = _crmSectionKey.currentContext;
                  if (crmContext != null) {
                    Scrollable.ensureVisible(crmContext,
                        duration: const Duration(milliseconds: 450),
                        curve: Curves.easeInOut);
                  }
                },
                icon: const Icon(Icons.contacts),
                label: const Text('Administrar CRM'),
              ),
              SizedBox(
                width: 360,
                child: TextField(
                  controller: _audienceTagController,
                  decoration: const InputDecoration(
                    labelText: 'Filtrar por etiqueta (opcional)',
                    helperText: 'Ej.: Webinar Guayaquil 2026',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              SizedBox(
                width: 360,
                child: TextField(
                  controller: _subjectController,
                  decoration: const InputDecoration(
                    labelText: 'Asunto opcional para mailing',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _messageController,
            minLines: 4,
            maxLines: 8,
            decoration: const InputDecoration(
              labelText: 'Mensaje',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          _buildScheduleSection(),
          _buildImageSection(),
          _buildContactsPreview(),
          Align(
            alignment: Alignment.centerRight,
            child: ElevatedButton.icon(
              onPressed: _creating ? null : _createCampaign,
              icon: Icon(_scheduledAt == null ? Icons.add : Icons.schedule),
              label: Text(
                _creating
                    ? 'Guardando...'
                    : _scheduledAt == null
                        ? 'Crear campaña'
                        : 'Programar campaña',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCampaignTrailing(
    String status,
    Map<String, dynamic> campaign,
  ) {
    if (status == 'sent') {
      return const Chip(label: Text('Enviada'));
    }

    if (status == 'scheduled') {
      return const Chip(label: Text('Programada'));
    }

    return IconButton(
      onPressed: () => _sendCampaign(campaign),
      icon: const Icon(Icons.send),
      tooltip: 'Enviar ahora',
    );
  }

  Widget _campaignTile(Map<String, dynamic> campaign) {
    final status = campaign['status']?.toString() ?? '-';
    final imageUrl = campaign['image_url']?.toString();
    final scheduledAtText = _formatScheduledFromApi(campaign['scheduled_at']);

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: imageUrl != null && imageUrl.isNotEmpty
            ? ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(imageUrl,
                    width: 48, height: 48, fit: BoxFit.cover),
              )
            : Icon(
                _channelIcon((campaign['channel'] ?? '').toString()),
                color: Colors.teal,
              ),
        title: Text(
          campaign['title']?.toString() ?? 'Sin título',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          '${_channelLabel((campaign['channel'] ?? '').toString())} | ${_targetLabel((campaign['target_group'] ?? '').toString())}'
          '${scheduledAtText.isNotEmpty ? ' | $scheduledAtText' : ''}',
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildCampaignTrailing(status, campaign),
            IconButton(
              onPressed: () => _deleteCampaign(campaign),
              icon: const Icon(Icons.delete_outline, color: Colors.red),
              tooltip: 'Eliminar campaña',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCampaignsBox() {
    return _box(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Campañas',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ),
              OutlinedButton.icon(
                onPressed: _campaigns.any((item) => item['status'] == 'sent')
                    ? _deleteAllSentCampaigns
                    : null,
                icon: const Icon(Icons.delete_sweep_outlined),
                label: const Text('Eliminar todas las enviadas'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: 240,
            child: DropdownButtonFormField<String>(
              value: _filterChannel,
              decoration: const InputDecoration(
                labelText: 'Filtrar canal',
                border: OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(value: 'all', child: Text('Todos')),
                DropdownMenuItem(value: 'push', child: Text('Push')),
                DropdownMenuItem(value: 'email', child: Text('Mailing')),
                DropdownMenuItem(value: 'whatsapp', child: Text('WhatsApp')),
              ],
              onChanged: (value) async {
                if (value == null) return;
                setState(() {
                  _filterChannel = value;
                });
                await _loadData();
              },
            ),
          ),
          const SizedBox(height: 12),
          Builder(builder: (context) {
            final sent = _campaigns
                .where((item) => item['status'] == 'sent')
                .map((item) => Map<String, dynamic>.from(item))
                .toList();
            final pending = _campaigns
                .where((item) => item['status'] != 'sent')
                .map((item) => Map<String, dynamic>.from(item))
                .toList();
            if (_campaigns.isEmpty) {
              return const Padding(
                padding: EdgeInsets.all(24),
                child: Center(child: Text('No hay campañas todavía')),
              );
            }
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Programadas y pendientes (${pending.length})',
                  style: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                if (pending.isEmpty)
                  const Padding(
                    padding: EdgeInsets.only(bottom: 16),
                    child: Text('No hay campañas programadas o pendientes.'),
                  )
                else
                  ...pending.map(_campaignTile),
                const Divider(height: 28),
                Text(
                  'Enviadas (${sent.length})',
                  style: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                if (sent.isEmpty)
                  const Text('No hay campañas enviadas.')
                else
                  ...sent.map(_campaignTile),
              ],
            );
          }),
        ],
      ),
    );
  }

  Future<void> _logout() async {
    await _authService.logout();

    if (!mounted) return;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginMayuTeamScreen()),
      (route) => false,
    );
  }

  @override
  void dispose() {
    _titleController.dispose();
    _subjectController.dispose();
    _messageController.dispose();
    _imageUrlController.dispose();
    _audienceTagController.dispose();
    _directorySearchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7F6),
      appBar: AppBar(
        title: const Text('Marketing Mayu'),
        actions: [
          IconButton(onPressed: _loadData, icon: const Icon(Icons.refresh)),
          IconButton(onPressed: _logout, icon: const Icon(Icons.logout)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Text(
                    _error!,
                    style: const TextStyle(color: Colors.red),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadData,
                  child: SingleChildScrollView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _buildDashboardMetrics(),
                        const SizedBox(height: 14),
                        _buildDirectoryBox(),
                        _buildCreateCampaignBox(),
                        _buildCampaignsBox(),
                      ],
                    ),
                  ),
                ),
    );
  }
}
