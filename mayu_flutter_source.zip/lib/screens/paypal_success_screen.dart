import 'package:flutter/material.dart';

import '../services/cart_service.dart';
import 'marketplace_screen.dart';

class PayPalSuccessScreen extends StatefulWidget {
  const PayPalSuccessScreen({
    super.key,
    this.paypalOrderId,
    this.paymentId,
    this.paymentStatus,
  });

  final String? paypalOrderId;
  final String? paymentId;
  final String? paymentStatus;

  @override
  State<PayPalSuccessScreen> createState() => _PayPalSuccessScreenState();
}

class _PayPalSuccessScreenState extends State<PayPalSuccessScreen> {
  @override
  void initState() {
    super.initState();

    final status = (widget.paymentStatus ?? '').toLowerCase();
    if (status == 'success' || status == 'paid' || status == 'approved') {
      CartService().clear();
    }
  }

  void _openMarketplace() {
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const MarketplaceScreen()),
      (route) => route.isFirst,
    );
  }

  @override
  Widget build(BuildContext context) {
    final status = (widget.paymentStatus ?? 'success').toLowerCase();
    final isSuccess =
        status == 'success' || status == 'paid' || status == 'approved';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Pago PayPal'),
        backgroundColor: const Color(0xFF006450),
        foregroundColor: Colors.white,
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      isSuccess ? Icons.check_circle : Icons.info,
                      color:
                          isSuccess ? const Color(0xFF006450) : Colors.orange,
                      size: 72,
                    ),
                    const SizedBox(height: 18),
                    Text(
                      isSuccess ? 'Pago confirmado' : 'Revisión de pago',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      isSuccess
                          ? 'Tu compra de Farmacia Mayu fue registrada. Si ingresaste tu Tarjeta Mayu Magistral, los puntos se acreditan automáticamente.'
                          : 'Volviste desde PayPal. Si el pago fue aprobado, la orden se actualizará en unos segundos.',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 16, height: 1.35),
                    ),
                    if ((widget.paypalOrderId ?? '').isNotEmpty) ...[
                      const SizedBox(height: 16),
                      Text(
                        'PayPal: ${widget.paypalOrderId}',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey.shade700),
                      ),
                    ],
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: _openMarketplace,
                        icon: const Icon(Icons.storefront),
                        label: const Text('Volver al Marketplace'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF2FB5AC),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
