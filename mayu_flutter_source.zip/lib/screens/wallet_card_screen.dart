import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/member_card_service.dart';
import '../widgets/mayu_scaffold.dart';

class WalletCardScreen extends StatefulWidget {
  final int userId;
  final String userName;

  const WalletCardScreen({
    super.key,
    required this.userId,
    this.userName = '',
  });

  @override
  State<WalletCardScreen> createState() => _WalletCardScreenState();
}

class _WalletCardScreenState extends State<WalletCardScreen> {
  final MemberCardService _service = MemberCardService();

  bool loading = true;
  bool googleWalletLoading = false;

  String? error;
  Map<String, dynamic>? card;

  static const String adminWhatsapp = '593989683645';

  bool get _isIOS => !kIsWeb && defaultTargetPlatform == TargetPlatform.iOS;
  bool get _isAndroid =>
      !kIsWeb && defaultTargetPlatform == TargetPlatform.android;

  String get _displayName {
    if (widget.userName.trim().isNotEmpty) return widget.userName.trim();

    final fromCard = card?['name'] ??
        card?['user_name'] ??
        card?['customer_name'] ??
        card?['display_name'];

    if (fromCard != null && fromCard.toString().trim().isNotEmpty) {
      return fromCard.toString().trim();
    }

    return 'Socio Mayu';
  }

  @override
  void initState() {
    super.initState();
    loadCard();
  }

  Future<void> loadCard() async {
    setState(() {
      loading = true;
      error = null;
    });

    try {
      final result = await _service.getMemberCardByUser(widget.userId);

      if (!mounted) return;

      if (result['statusCode'] == 200 && result['data'] != null) {
        setState(() {
          card = Map<String, dynamic>.from(result['data']);
          loading = false;
        });
        return;
      }

      final generated = await _service.generateMemberCard(widget.userId);

      if (!mounted) return;

      if ((generated['statusCode'] == 200 || generated['statusCode'] == 201) &&
          generated['data'] != null) {
        final data = generated['data'];

        setState(() {
          if (data is Map && data['card'] != null) {
            card = Map<String, dynamic>.from(data['card']);
          } else {
            card = Map<String, dynamic>.from(data);
          }
          loading = false;
        });
      } else {
        setState(() {
          error =
              generated['data']?['detail'] ?? 'No se pudo generar la tarjeta';
          loading = false;
        });
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        error = 'Error cargando tarjeta: $e';
        loading = false;
      });
    }
  }

  Future<void> _openUrl(String url, String errorMessage) async {
    try {
      final uri = Uri.parse(url);

      final opened = await launchUrl(
        uri,
        mode: LaunchMode.externalApplication,
      );

      if (!opened && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(errorMessage)),
        );
      }
    } catch (_) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(errorMessage)),
      );
    }
  }

  String _getFromCardOrFallback(String key, String fallback) {
    final value = card?[key];

    if (value == null || value.toString().trim().isEmpty) {
      return fallback;
    }

    return value.toString();
  }

  bool get _isAmbassadorWallet {
    final type =
        (card?['card_type'] ?? card?['type'] ?? '').toString().toLowerCase();
    return type.contains('ambassador') || type.contains('embajador');
  }

  String _money(dynamic value) {
    final parsed = double.tryParse((value ?? 0).toString()) ?? 0;
    return parsed.toStringAsFixed(2);
  }

  Widget _ambassadorWalletBox() {
    if (!_isAmbassadorWallet) return const SizedBox.shrink();

    final pendingAmount = _money(
      card?['wallet_pending_amount'] ?? card?['wallet_projected_amount'],
    );
    final paidAmount = _money(card?['wallet_paid_amount']);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.only(top: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Próxima comisión: \$$pendingAmount',
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Pago realizado: \$$paidAmount',
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }

  Future<void> sendWhatsAppCard() async {
    final message = _service.buildSocioWhatsAppMessage(
      name: _displayName,
      userId: widget.userId,
    );

    final uri = Uri.https(
      'api.whatsapp.com',
      '/send',
      {
        'phone': adminWhatsapp,
        'text': message,
      },
    );

    await _openUrl(uri.toString(), 'No se pudo abrir WhatsApp');
  }

  Future<void> recoverCard() async {
    final message = _service.buildRecoverCardMessage(
      name: _displayName,
      userId: widget.userId,
    );

    final uri = Uri.https(
      'api.whatsapp.com',
      '/send',
      {
        'phone': adminWhatsapp,
        'text': message,
      },
    );

    await _openUrl(uri.toString(), 'No se pudo abrir WhatsApp');
  }

  Future<void> openCardImage() async {
    final url = _getFromCardOrFallback(
      'image_url',
      _service.getCardImageUrl(widget.userId),
    );

    await _openUrl(url, 'No se pudo abrir la tarjeta');
  }

  Future<void> openCardWeb() async {
    final url = _getFromCardOrFallback(
      'web_url',
      _service.getCardWebUrl(widget.userId),
    );

    await _openUrl(url, 'No se pudo abrir la tarjeta web');
  }

  Future<void> openAppleWallet() async {
    final url = _getFromCardOrFallback(
      'apple_wallet_url',
      _service.getAppleWalletUrl(widget.userId),
    );

    await _openUrl(
      url,
      'No se pudo abrir Apple Wallet.',
    );
  }

  Future<void> openGoogleWallet() async {
    setState(() {
      googleWalletLoading = true;
      error = null;
    });

    try {
      final result = await _service.getGoogleWalletPass(widget.userId);

      if (!mounted) return;

      String url = '';

      if (result['statusCode'] == 200 && result['data'] != null) {
        final data = result['data'];

        if (data is Map) {
          url = (data['save_url'] ??
                  data['google_wallet_url'] ??
                  data['url'] ??
                  '')
              .toString();
        }
      }

      if (url.trim().isEmpty) {
        url = _getFromCardOrFallback(
          'google_wallet_url',
          _service.getGoogleWalletUrl(widget.userId),
        );
      }

      setState(() {
        googleWalletLoading = false;
      });

      await _openUrl(
        url,
        'No se pudo abrir Google Wallet.',
      );
    } catch (e) {
      if (!mounted) return;

      setState(() {
        googleWalletLoading = false;
        error = 'Error generando Google Wallet: $e';
      });
    }
  }

  Widget _actionButton({
    required String text,
    required IconData icon,
    required VoidCallback? onPressed,
    bool outlined = false,
    bool isLoading = false,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: outlined
          ? OutlinedButton.icon(
              onPressed: isLoading ? null : onPressed,
              icon: isLoading
                  ? const SizedBox(
                      height: 18,
                      width: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : Icon(icon),
              label: Text(text, style: const TextStyle(fontSize: 16)),
            )
          : ElevatedButton.icon(
              onPressed: isLoading ? null : onPressed,
              icon: isLoading
                  ? const SizedBox(
                      height: 18,
                      width: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : Icon(icon),
              label: Text(text, style: const TextStyle(fontSize: 16)),
            ),
    );
  }

  Widget _statusBadge() {
    final String status = (card?['status'] ?? '').toString();
    final bool active = status == 'active';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: active ? Colors.green.shade100 : Colors.red.shade100,
        borderRadius: BorderRadius.circular(30),
      ),
      child: Text(
        active ? 'Tarjeta activa' : 'Tarjeta inactiva',
        style: TextStyle(
          color: active ? Colors.green.shade800 : Colors.red.shade800,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _cardPreview() {
    final imageUrl =
        '${_service.getCardImageUrl(widget.userId)}?v=${DateTime.now().millisecondsSinceEpoch}';

    final String code = (card?['member_code'] ?? '').toString();
    final String type = (card?['card_type'] ?? '').toString();

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Image.network(
              imageUrl,
              height: 230,
              width: double.infinity,
              fit: BoxFit.contain,
              errorBuilder: (_, __, ___) {
                return Container(
                  width: double.infinity,
                  height: 210,
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: Colors.black12),
                    color: Colors.grey.shade100,
                  ),
                  child: const Center(
                    child: Text(
                      'No se pudo cargar la imagen de la tarjeta.',
                      textAlign: TextAlign.center,
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 14),
          Text(
            _displayName,
            style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
          ),
          if (code.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text('Código: $code'),
          ],
          if (type.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(
              type == 'ambassador'
                  ? 'Embajador Mayu'
                  : 'Socio Mayu Wellness Club',
            ),
          ],
          const SizedBox(height: 10),
          _statusBadge(),
          _ambassadorWalletBox(),
        ],
      ),
    );
  }

  Widget _walletInfoBox() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.only(bottom: 18),
      decoration: BoxDecoration(
        color: Colors.teal.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.teal.withValues(alpha: 0.35)),
      ),
      child: Text(
        _isAmbassadorWallet
            ? 'Tu Wallet Mayu muestra tu tarjeta digital, código QR, próxima comisión y pago realizado.'
            : 'Tu Wallet Mayu contiene tu tarjeta digital, código QR y acceso rápido para validación.',
        style: const TextStyle(
          fontSize: 15,
          height: 1.35,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _platformWalletButtons() {
    return Column(
      children: [
        if (_isIOS || kIsWeb) ...[
          _actionButton(
            text: 'Agregar a Apple Wallet',
            icon: Icons.phone_iphone,
            onPressed: openAppleWallet,
          ),
          const SizedBox(height: 10),
        ],
        if (_isAndroid || kIsWeb) ...[
          _actionButton(
            text: googleWalletLoading
                ? 'Generando Google Wallet...'
                : 'Agregar a Google Wallet',
            icon: Icons.account_balance_wallet,
            outlined: true,
            isLoading: googleWalletLoading,
            onPressed: openGoogleWallet,
          ),
          const SizedBox(height: 10),
        ],
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return MayuScaffold(
      appBar: AppBar(
        title: const Text('Wallet Mayu'),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: loadCard,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      child: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Padding(
                  padding: const EdgeInsets.all(24),
                  child: Center(
                    child: Text(
                      error!,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.red),
                    ),
                  ),
                )
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 620),
                      child: Column(
                        children: [
                          _walletInfoBox(),
                          _cardPreview(),
                          const SizedBox(height: 24),
                          _actionButton(
                            text: 'Ver tarjeta completa',
                            icon: Icons.visibility,
                            onPressed: openCardImage,
                          ),
                          const SizedBox(height: 10),
                          _actionButton(
                            text: 'Abrir tarjeta web',
                            icon: Icons.open_in_browser,
                            outlined: true,
                            onPressed: openCardWeb,
                          ),
                          const SizedBox(height: 10),
                          _actionButton(
                            text: 'Enviar tarjeta por WhatsApp',
                            icon: Icons.chat,
                            onPressed: sendWhatsAppCard,
                          ),
                          const SizedBox(height: 10),
                          _actionButton(
                            text: 'Recuperar tarjeta',
                            icon: Icons.refresh,
                            outlined: true,
                            onPressed: recoverCard,
                          ),
                          const SizedBox(height: 10),
                          _platformWalletButtons(),
                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
                  ),
                ),
    );
  }
}
