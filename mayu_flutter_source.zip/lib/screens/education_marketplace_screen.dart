import 'package:flutter/material.dart';

import '../services/education_service.dart';
import '../widgets/mayu_scaffold.dart';
import 'education_access_screen.dart';
import 'education_checkout_screen.dart';
import 'education_product_screen.dart';

class EducationMarketplaceScreen extends StatefulWidget {
  const EducationMarketplaceScreen({super.key});

  @override
  State<EducationMarketplaceScreen> createState() =>
      _EducationMarketplaceScreenState();
}

class _EducationMarketplaceScreenState
    extends State<EducationMarketplaceScreen> {
  final EducationService _service = EducationService();

  bool _loading = true;
  String? _error;

  List<dynamic> _resources = [];
  String _search = '';
  String _language = 'es';

  final Map<int, Map<String, dynamic>> _cart = {};

  @override
  void initState() {
    super.initState();
    _loadMarketplace();
  }

  Future<void> _loadMarketplace() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final result = await _service.getStoreResources(
      search: _search,
      language: _language,
    );

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      final data = result['data'];

      setState(() {
        _resources =
            data is Map && data['items'] is List ? data['items'] : [];
        _loading = false;
      });
    } else {
      setState(() {
        _loading = false;
        _error = result['data']?['detail']?.toString() ??
            'No se pudo cargar el marketplace educativo';
      });
    }
  }

  String _t(String es, String en) {
    return _language == 'en' ? en : es;
  }

  String _typeLabel(String type) {
    switch (type) {
      case 'pdf':
        return 'PDF';
      case 'video':
        return _t('Video', 'Video');
      case 'image':
        return _t('Imagen', 'Image');
      case 'plant_card':
        return _t('Ficha de planta', 'Plant sheet');
      case 'plant_registry':
        return _t('Registro de planta', 'Plant registry');
      default:
        return _t('Contenido', 'Content');
    }
  }

  IconData _typeIcon(String type) {
    switch (type) {
      case 'video':
        return Icons.play_circle;
      case 'image':
        return Icons.image;
      case 'plant_card':
      case 'plant_registry':
        return Icons.eco;
      case 'pdf':
      default:
        return Icons.menu_book;
    }
  }

  double _priceOf(Map<String, dynamic> resource) {
    final raw = resource['price'];
    if (raw is num) return raw.toDouble();
    return double.tryParse((raw ?? '0').toString()) ?? 0;
  }

  void _addToCart(Map<String, dynamic> resource) {
    final id = int.tryParse((resource['id'] ?? 0).toString()) ?? 0;

    if (id == 0) return;

    setState(() {
      if (_cart.containsKey(id)) {
        _cart[id]!['quantity'] = (_cart[id]!['quantity'] as int) + 1;
      } else {
        _cart[id] = {
          'resource': resource,
          'quantity': 1,
        };
      }
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          _t(
            '${resource['title']} agregado al carrito',
            '${resource['title']} added to cart',
          ),
        ),
      ),
    );
  }

  Future<void> _openProduct(Map<String, dynamic> resource) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => EducationProductScreen(
          resource: resource,
          onAddToCart: () {
            _addToCart(resource);
          },
        ),
      ),
    );
  }

  Future<void> _openCheckout() async {
    if (_cart.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            _t(
              'No hay contenidos en el carrito',
              'There are no items in the cart',
            ),
          ),
        ),
      );
      return;
    }

    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => EducationCheckoutScreen(
          cartItems: _cart.values.toList(),
        ),
      ),
    );
  }

  Widget _languageSelector() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ChoiceChip(
          label: const Text('Español'),
          selected: _language == 'es',
          onSelected: (_) {
            setState(() {
              _language = 'es';
              _cart.clear();
            });
            _loadMarketplace();
          },
        ),
        const SizedBox(width: 10),
        ChoiceChip(
          label: const Text('English'),
          selected: _language == 'en',
          onSelected: (_) {
            setState(() {
              _language = 'en';
              _cart.clear();
            });
            _loadMarketplace();
          },
        ),
      ],
    );
  }

  Widget _educationHeader() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 14,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          Image.asset(
            'assets/images/logo_mayu_educacion.png',
            height: 95,
            fit: BoxFit.contain,
          ),
          const SizedBox(height: 14),
          Text(
            _t(
              'Marketplace Educativo Mayu',
              'Mayu Educational Marketplace',
            ),
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 27,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _t(
              'Espacio educativo de Mayu para acceder a libros, cursos, videos, PDFs, fichas botánicas y material formativo sobre fitoterapia, medicina natural, plantas ancestrales y bienestar integrativo.',
              'Mayu educational space to access books, courses, videos, PDFs, botanical sheets and training material about phytotherapy, natural medicine, ancestral plants and integrative wellness.',
            ),
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 15, height: 1.4),
          ),
          const SizedBox(height: 8),
          Text(
            _t(
              'Cada contenido adquirido se abre mediante un código de acceso protegido válido para 30 ingresos.',
              'Each purchased content is opened with a protected access code valid for 30 entries.',
            ),
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 14,
              color: Colors.teal,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 14),
          _languageSelector(),
        ],
      ),
    );
  }

  Widget _accessCodeCard() {
    return Card(
      color: const Color(0xFFE8F5E9),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(
              _t(
                '¿Ya compraste un contenido?',
                'Already purchased content?',
              ),
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              _t(
                'Ingresa tu código de acceso para abrir tus cursos, PDFs, libros o videos educativos.',
                'Enter your access code to open your courses, PDFs, books or educational videos.',
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.vpn_key),
                label: Text(
                  _t(
                    'Ingresar código de acceso',
                    'Enter access code',
                  ),
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const EducationAccessScreen(),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _resourceCard(Map<String, dynamic> resource) {
    final type = (resource['resource_type'] ?? '').toString();
    final coverUrl = (resource['cover_image_url'] ?? '').toString();
    final price = _priceOf(resource);

    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => _openProduct(resource),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: coverUrl.isNotEmpty
                    ? Image.network(
                        coverUrl,
                        width: 86,
                        height: 86,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => _placeholder(type),
                      )
                    : _placeholder(type),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      resource['title']?.toString() ?? 'Contenido Mayu',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 17,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${resource['category_name'] ?? _t('Sin categoría', 'No category')} • ${_typeLabel(type)}',
                      style: const TextStyle(color: Colors.teal, fontSize: 13),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '${_t('Marketplace', 'Marketplace')}: \$${price.toStringAsFixed(2)} USD',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    if ((resource['description'] ?? '').toString().isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(
                          resource['description'].toString(),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                  ],
                ),
              ),
              const Icon(Icons.visibility, color: Colors.teal),
            ],
          ),
        ),
      ),
    );
  }

  Widget _placeholder(String type) {
    return Container(
      width: 86,
      height: 86,
      color: Colors.teal.withOpacity(0.10),
      child: Icon(_typeIcon(type), color: Colors.teal, size: 34),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MayuScaffold(
      appBar: AppBar(
        title: Text(
          _t(
            'Mayu Educación Marketplace',
            'Mayu Education Marketplace',
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: _loadMarketplace,
            icon: const Icon(Icons.refresh),
          ),
          Stack(
            children: [
              IconButton(
                onPressed: _openCheckout,
                icon: const Icon(Icons.shopping_cart),
              ),
              if (_cart.isNotEmpty)
                Positioned(
                  right: 8,
                  top: 8,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(
                      color: Colors.red,
                      shape: BoxShape.circle,
                    ),
                    child: Text(
                      '${_cart.length}',
                      style: const TextStyle(color: Colors.white, fontSize: 10),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
      child: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child:
                      Text(_error!, style: const TextStyle(color: Colors.red)),
                )
              : RefreshIndicator(
                  onRefresh: _loadMarketplace,
                  child: ListView(
                    padding: const EdgeInsets.all(18),
                    children: [
                      _educationHeader(),
                      const SizedBox(height: 18),
                      _accessCodeCard(),
                      const SizedBox(height: 20),
                      TextField(
                        decoration: InputDecoration(
                          hintText: _t(
                            'Buscar contenido educativo',
                            'Search educational content',
                          ),
                          prefixIcon: const Icon(Icons.search),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(18),
                            borderSide: BorderSide.none,
                          ),
                        ),
                        onChanged: (value) {
                          _search = value;
                        },
                        onSubmitted: (_) => _loadMarketplace(),
                      ),
                      const SizedBox(height: 18),
                      if (_resources.isEmpty)
                        Padding(
                          padding: const EdgeInsets.all(30),
                          child: Center(
                            child: Text(
                              _t(
                                'No hay contenidos disponibles.',
                                'No content available.',
                              ),
                            ),
                          ),
                        )
                      else
                        ..._resources.map(
                          (item) => _resourceCard(
                            Map<String, dynamic>.from(item),
                          ),
                        ),
                      if (_cart.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 20),
                          child: SizedBox(
                            height: 55,
                            child: ElevatedButton.icon(
                              onPressed: _openCheckout,
                              icon: const Icon(Icons.shopping_cart),
                              label: Text(
                                _t(
                                  'Ir al carrito (${_cart.length})',
                                  'Go to cart (${_cart.length})',
                                ),
                              ),
                            ),
                          ),
                        ),
                      const SizedBox(height: 80),
                    ],
                  ),
                ),
    );
  }
}