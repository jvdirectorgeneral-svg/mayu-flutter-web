import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/user_service.dart';
import '../services/auth_service.dart';
import '../services/membership_history_service.dart';

import '../widgets/mayu_scaffold.dart';

import 'plans_screen.dart';
import 'my_membership_screen.dart';
import 'benefits_screen.dart';
import 'wallet_card_screen.dart';
import 'membership_history_screen.dart';
import 'login_screen.dart';
import 'mayu_education_screen.dart';
import 'monthly_selection_screen.dart';
import 'my_orders_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final UserService _userService = UserService();
  final AuthService _authService = AuthService();
  final MembershipHistoryService _membershipHistoryService =
      MembershipHistoryService();

  Map<String, dynamic>? user;
  Map<String, dynamic>? upcomingDelivery;
  List<dynamic> deliveryHistory = [];

  bool loading = true;

  @override
  void initState() {
    super.initState();
    loadUser();
  }

  Future<void> loadUser() async {
    setState(() => loading = true);

    final data = await _userService.getMe();

    if (!mounted) return;

    if (data == null) {
      setState(() {
        user = null;
        upcomingDelivery = null;
        deliveryHistory = [];
        loading = false;
      });
      return;
    }

    final int userId = int.tryParse((data['id'] ?? 0).toString()) ?? 0;

    Map<String, dynamic>? upcoming;
    List<dynamic> history = [];

    if (userId != 0) {
      final historyResult =
          await _membershipHistoryService.getMembershipHistory(userId);

      if (historyResult['statusCode'] == 200) {
        final historyData = historyResult['data'] ?? {};

        if (historyData is Map && historyData['upcoming'] is Map) {
          upcoming = Map<String, dynamic>.from(historyData['upcoming']);
        }

        if (historyData is Map && historyData['history'] is List) {
          history = List<dynamic>.from(historyData['history']);
        }
      }
    }

    if (!mounted) return;

    setState(() {
      user = Map<String, dynamic>.from(data);
      upcomingDelivery = upcoming;
      deliveryHistory = history;
      loading = false;
    });
  }

  bool _isMembershipActive(Map<String, dynamic>? data) {
    if (data == null) return false;

    final membershipActive = data['membership_active'] == true;
    final status = (data['status'] ?? '').toString().toLowerCase();
    final subscriptionStatus =
        (data['subscription_status'] ?? data['local_payment_status'] ?? '')
            .toString()
            .toLowerCase();

    return membershipActive ||
        status == 'active' ||
        subscriptionStatus == 'active' ||
        subscriptionStatus == 'subscription_active' ||
        subscriptionStatus == 'verified';
  }

  String _membershipLabel(dynamic level) {
    final int parsedLevel = int.tryParse((level ?? 0).toString()) ?? 0;

    switch (parsedLevel) {
      case 1:
        return 'Nivel 1 - Cobre';
      case 2:
        return 'Nivel 2 - Plata';
      case 3:
        return 'Nivel 3 - Oro';
      default:
        return 'Sin nivel';
    }
  }

  double _monthlyPrice(dynamic level) {
    final int parsedLevel = int.tryParse((level ?? 0).toString()) ?? 0;

    switch (parsedLevel) {
      case 1:
        return 40;
      case 2:
        return 50;
      case 3:
        return 60;
      default:
        return 0;
    }
  }

  String _money(double value) {
    return value == value.roundToDouble()
        ? value.toStringAsFixed(0)
        : value.toStringAsFixed(2);
  }

  String _safeText(dynamic value) {
    if (value == null) return '-';
    final text = value.toString().trim();
    return text.isEmpty ? '-' : text;
  }

  String _productsText(dynamic products) {
    if (products is! List || products.isEmpty) {
      return 'Sin productos registrados';
    }

    return products.map((p) {
      if (p is Map) {
        final map = Map<String, dynamic>.from(p);
        return '• ${map['name'] ?? map['product_name_snapshot'] ?? 'Producto'}';
      }

      return '• ${p.toString()}';
    }).join('\n');
  }

  Future<void> _openTrackingUrl(String url) async {
    final cleanUrl = url.trim();

    if (cleanUrl.isEmpty || cleanUrl == '-') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No hay link de seguimiento disponible.')),
      );
      return;
    }

    final uri = Uri.tryParse(cleanUrl);

    if (uri == null || !uri.hasScheme) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Link de seguimiento inválido.')),
      );
      return;
    }

    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Future<void> _logout() async {
    await _authService.logout();

    if (!mounted) return;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  void _openWalletScreen({
    required int userId,
    required String userName,
  }) {
    if (userId == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No se pudo identificar el usuario para abrir Wallet.'),
        ),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => WalletCardScreen(
          userId: userId,
          userName: userName,
        ),
      ),
    );
  }

  Widget _mainButton({
    required String text,
    required IconData icon,
    required VoidCallback onPressed,
    bool outlined = false,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: outlined
          ? OutlinedButton.icon(
              onPressed: onPressed,
              icon: Icon(icon),
              label: Text(text, style: const TextStyle(fontSize: 16)),
            )
          : ElevatedButton.icon(
              onPressed: onPressed,
              icon: Icon(icon),
              label: Text(text, style: const TextStyle(fontSize: 16)),
            ),
    );
  }

  Widget _dashboardCard({
    required Widget child,
    Color? borderColor,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: borderColor ?? Colors.black12),
      ),
      child: child,
    );
  }

  Widget _membershipStatusCard({
    required bool isActive,
    required String membershipName,
    required double monthlyPrice,
  }) {
    return _dashboardCard(
      borderColor: isActive ? Colors.green.shade200 : Colors.red.shade200,
      child: Column(
        children: [
          Icon(
            isActive ? Icons.verified : Icons.cancel,
            color: isActive ? Colors.green : Colors.red,
            size: 44,
          ),
          const SizedBox(height: 12),
          Text(
            isActive ? 'Membresía activa' : 'Membresía inactiva',
            style: TextStyle(
              fontSize: 21,
              fontWeight: FontWeight.bold,
              color: isActive ? Colors.green : Colors.red,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            membershipName,
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
            textAlign: TextAlign.center,
          ),
          if (monthlyPrice > 0) ...[
            const SizedBox(height: 6),
            Text(
              'Mensualidad: \$${_money(monthlyPrice)} USD',
              style: const TextStyle(fontSize: 15),
            ),
          ],
        ],
      ),
    );
  }

  Widget _deliveryDashboardCard() {
    final data = upcomingDelivery;

    if (data == null) {
      return _dashboardCard(
        child: const Text(
          'Aún no tienes una entrega próxima registrada.',
          style: TextStyle(fontSize: 15),
        ),
      );
    }

    final products = data['products'] ??
        data['items'] ??
        data['monthly_selection_products'] ??
        data['editableProducts'] ??
        data['delivery_products'] ??
        [];

    final carrier = data['carrier'] ?? data['shipping_provider'];
    final trackingNumber = data['tracking_number'] ?? data['trackingNumber'];
    final trackingUrl = data['tracking_url'] ?? data['trackingUrl'];

    final trackingUrlText = _safeText(trackingUrl);

    return _dashboardCard(
      borderColor: Colors.teal.shade200,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Próxima entrega',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Text('Ciclo: ${_safeText(data['monthLabel'] ?? data['month_label'])}'),
          Text('Plan: ${_safeText(data['planName'] ?? data['plan_name'])}'),
          Text('Estado: ${_safeText(data['status'])}'),
          Text('Despacho: ${_safeText(data['shippingWindow'] ?? 'viernes')}'),
          const SizedBox(height: 10),
          const Text(
            'Productos:',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          Text(_productsText(products)),
          const SizedBox(height: 10),
          Text('Transportadora: ${_safeText(carrier)}'),
          Text('Guía: ${_safeText(trackingNumber)}'),
          Text('Tracking: $trackingUrlText'),
          if (trackingUrlText != '-') ...[
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => _openTrackingUrl(trackingUrlText),
                icon: const Icon(Icons.open_in_new),
                label: const Text('Abrir seguimiento'),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _recentHistoryCard() {
    return _dashboardCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Historial reciente',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          if (deliveryHistory.isEmpty)
            const Text('No hay entregas anteriores registradas.')
          else
            ...deliveryHistory.take(3).map((item) {
              final map = Map<String, dynamic>.from(item as Map);
              final tracking =
                  map['tracking_number'] ?? map['trackingNumber'] ?? '-';

              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Text(
                  '${_safeText(map['monthLabel'] ?? map['month_label'])} — ${_safeText(map['status'])} — Guía: ${_safeText(tracking)}',
                  style: const TextStyle(fontSize: 15),
                ),
              );
            }),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const MembershipHistoryScreen(),
                  ),
                );
              },
              icon: const Icon(Icons.history),
              label: const Text('Ver historial completo'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _welcomeHeader({
    required String userName,
    required String email,
  }) {
    return Column(
      children: [
        const Text(
          'Mayu Wellness Club',
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 18),
        Text(
          'Bienvenido $userName 👋',
          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w500),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 8),
        Text(
          email,
          style: const TextStyle(fontSize: 15, color: Colors.grey),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _levelChip(String membershipName) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.teal.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(40),
      ),
      child: Text(
        membershipName,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _quickAccessButtons({
    required int userId,
    required String userName,
  }) {
    return Column(
      children: [
        _mainButton(
          text: 'Wallet / Tarjeta digital',
          icon: Icons.account_balance_wallet,
          onPressed: () => _openWalletScreen(userId: userId, userName: userName),
        ),
        const SizedBox(height: 14),
        _mainButton(
          text: 'Mi membresía',
          icon: Icons.workspace_premium,
          outlined: true,
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const MyMembershipScreen()),
            );
          },
        ),
        const SizedBox(height: 14),
        _mainButton(
          text: 'Mi selección mensual',
          icon: Icons.checklist,
          outlined: true,
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MonthlySelectionScreen(userId: userId),
              ),
            );
          },
        ),
        const SizedBox(height: 14),
        _mainButton(
          text: 'Mis pedidos',
          icon: Icons.inventory_2,
          outlined: true,
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MyOrdersScreen(userId: userId),
              ),
            );
          },
        ),
        const SizedBox(height: 14),
        _mainButton(
          text: 'Historial de entregas',
          icon: Icons.local_shipping,
          outlined: true,
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const MembershipHistoryScreen()),
            );
          },
        ),
        const SizedBox(height: 14),
        _mainButton(
          text: 'Beneficios del socio',
          icon: Icons.card_giftcard,
          outlined: true,
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const BenefitsScreen()),
            );
          },
        ),
        const SizedBox(height: 14),
        _mainButton(
          text: 'Mayu Educación',
          icon: Icons.school,
          outlined: true,
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const MayuEducationScreen()),
            );
          },
        ),
        const SizedBox(height: 14),
        _mainButton(
          text: 'Ver planes',
          icon: Icons.layers,
          outlined: true,
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const PlansScreen()),
            );
          },
        ),
        const SizedBox(height: 14),
        _mainButton(
          text: 'Cerrar sesión',
          icon: Icons.logout,
          outlined: true,
          onPressed: _logout,
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool isActive = _isMembershipActive(user);
    final int userId = int.tryParse((user?['id'] ?? 0).toString()) ?? 0;
    final String userName = (user?['name'] ?? 'Usuario').toString();
    final String email = (user?['email'] ?? '').toString();

    final dynamic level = user?['membership_level'];
    final String membershipName = _membershipLabel(level);
    final double monthlyPrice = _monthlyPrice(level);

    return MayuScaffold(
      appBar: AppBar(
        title: const Text('Mayu Wellness Club'),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: loadUser,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      child: Center(
        child: loading
            ? const CircularProgressIndicator()
            : user == null
                ? const Text('No se pudo cargar el usuario')
                : Padding(
                    padding: const EdgeInsets.all(20),
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 520),
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            _welcomeHeader(userName: userName, email: email),
                            const SizedBox(height: 16),
                            _levelChip(membershipName),
                            const SizedBox(height: 22),
                            _membershipStatusCard(
                              isActive: isActive,
                              membershipName: membershipName,
                              monthlyPrice: monthlyPrice,
                            ),
                            _deliveryDashboardCard(),
                            _recentHistoryCard(),
                            const SizedBox(height: 12),
                            _quickAccessButtons(
                              userId: userId,
                              userName: userName,
                            ),
                            const SizedBox(height: 30),
                          ],
                        ),
                      ),
                    ),
                  ),
      ),
    );
  }
}