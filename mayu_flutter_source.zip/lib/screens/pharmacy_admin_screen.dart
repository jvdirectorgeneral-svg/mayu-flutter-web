import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/marketplace_service.dart';
import '../widgets/marketplace_order_timeline.dart';

class PharmacyAdminScreen extends StatefulWidget {
  const PharmacyAdminScreen({super.key});

  @override
  State<PharmacyAdminScreen> createState() => _PharmacyAdminScreenState();
}

class _PharmacyAdminScreenState extends State<PharmacyAdminScreen> {
  final MarketplaceService _service = MarketplaceService();

  bool _loading = true;
  String? _error;
  List<dynamic> _orders = [];
  List<dynamic> _pendingPayPhone = [];
  String _pendingSearch = '';
  String _ordersSearch = '';
  final Set<int> _expandedPending = <int>{};
  final Set<int> _expandedOrders = <int>{};

  List<dynamic> get _visiblePendingPayPhone {
    final query = _pendingSearch.trim().toLowerCase();
    if (query.isEmpty) return _pendingPayPhone;
    return _pendingPayPhone.where((item) {
      final payment = Map<String, dynamic>.from(item);
      return [
        payment['buyer_name'],
        payment['buyer_phone'],
        payment['buyer_email'],
        payment['client_transaction_id'],
        payment['doctor_prescriber_identifier'],
      ].any((value) => (value ?? '').toString().toLowerCase().contains(query));
    }).toList();
  }

  List<dynamic> get _visibleOrders {
    final query = _ordersSearch.trim().toLowerCase();
    if (query.isEmpty) return _orders;
    return _orders.where((item) {
      final order = Map<String, dynamic>.from(item);
      return [
        order['order_code'],
        order['customer_name'],
        order['customer_phone'],
        order['customer_email'],
      ].any((value) => (value ?? '').toString().toLowerCase().contains(query));
    }).toList();
  }

  @override
  void initState() {
    super.initState();
    _loadOrders();
  }

  Future<void> _loadOrders() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final results = await Future.wait([
      _service.getAdminOrders(),
      _service.getPendingPayPhonePharmacyPayments(),
    ]);
    final result = results[0];
    final pendingResult = results[1];

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      setState(() {
        _orders =
            result['data']?['items'] is List ? result['data']['items'] : [];
        _pendingPayPhone = pendingResult['statusCode'] == 200 &&
                pendingResult['data']?['items'] is List
            ? pendingResult['data']['items']
            : [];
        _loading = false;
      });
    } else {
      setState(() {
        _loading = false;
        _error = result['data']?['detail']?.toString() ??
            'No se pudieron cargar los pedidos';
      });
    }
  }

  Future<void> _deleteTestOrders() async {
    final controller = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Limpiar pedidos de prueba'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Se eliminarán todos los pedidos de Marketplace Farmacia de Administrador y Logística, además de los avisos PayPhone de Farmacia. No se modificarán usuarios, tarjetas, puntos, comisiones ni productos.',
            ),
            const SizedBox(height: 14),
            const Text('Escribe: ELIMINAR PEDIDOS FARMACIA'),
            const SizedBox(height: 8),
            TextField(controller: controller),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(
              dialogContext,
              controller.text.trim().toUpperCase() ==
                  'ELIMINAR PEDIDOS FARMACIA',
            ),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Eliminar definitivamente'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (confirmed != true) return;

    setState(() => _loading = true);
    final result = await _service.deletePharmacyTestOrders();
    if (!mounted) return;
    if (result['statusCode'] == 200) {
      await _loadOrders();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Administrador y Logística Farmacia quedaron en cero.',
          ),
        ),
      );
    } else {
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No se pudieron limpiar los pedidos',
          ),
        ),
      );
    }
  }

  Future<void> _confirmPendingPayPhone(Map<String, dynamic> payment) async {
    final paymentId = int.tryParse('${payment['payment_id'] ?? 0}') ?? 0;
    if (paymentId == 0) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Confirmar pago PayPhone'),
        content: Text(
          'Confirma únicamente después de verificar en PayPhone Business el cobro de '
          '\$${payment['amount'] ?? 0} USD con referencia '
          '${payment['client_transaction_id'] ?? ''}.\n\n'
          'Al confirmar se creará el pedido, se acreditará el 22% al doctor y se actualizará su Wallet.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Pago verificado'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    final result = await _service.confirmPayPhonePharmacyPayment(
      paymentId: paymentId,
    );
    if (!mounted) return;
    if (result['statusCode'] == 200 || result['statusCode'] == 201) {
      await _loadOrders();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Pago confirmado: pedido creado, doctor acreditado y logística notificada.',
          ),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(result['data']?['detail']?.toString() ??
              'No se pudo confirmar el pago'),
        ),
      );
    }
  }

  Widget _pendingPayPhoneBox() {
    return Card(
      color: const Color(0xFFFFF7E0),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Pagos PayPhone por verificar (${_pendingPayPhone.length})',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            const Text(
              'Verifica cada referencia en PayPhone Business antes de marcarla como pagada.',
            ),
            const SizedBox(height: 12),
            TextField(
              onChanged: (value) => setState(() => _pendingSearch = value),
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: 'Buscar referencia, cliente, teléfono o doctor',
                border: OutlineInputBorder(),
              ),
            ),
            if (_pendingPayPhone.isEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 12),
                child: Text('No hay avisos pendientes.'),
              )
            else
              ..._visiblePendingPayPhone.map((item) {
                final payment = Map<String, dynamic>.from(item);
                final paymentId =
                    int.tryParse('${payment['payment_id'] ?? 0}') ?? 0;
                final expanded = _expandedPending.contains(paymentId);
                return Card(
                  color: Colors.white.withValues(alpha: .75),
                  margin: const EdgeInsets.only(top: 10),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: () => setState(() {
                      expanded
                          ? _expandedPending.remove(paymentId)
                          : _expandedPending.add(paymentId);
                    }),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.phone_iphone,
                                  color: Colors.orange),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  '${payment['client_transaction_id'] ?? 'Sin referencia'} · ${payment['buyer_name'] ?? 'Cliente'}',
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Icon(expanded
                                  ? Icons.expand_less
                                  : Icons.expand_more),
                            ],
                          ),
                          if (expanded) ...[
                            const SizedBox(height: 10),
                            Text('Total: \$${payment['amount'] ?? 0} USD'),
                            Text('Teléfono: ${payment['buyer_phone'] ?? ''}'),
                            Text('Correo: ${payment['buyer_email'] ?? ''}'),
                            Text(
                                'Doctor: ${payment['doctor_prescriber_identifier'] ?? 'No vinculado'}'),
                            const SizedBox(height: 10),
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton.icon(
                                onPressed: () =>
                                    _confirmPendingPayPhone(payment),
                                icon: const Icon(Icons.verified),
                                label: const Text('Confirmar pago verificado'),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }

  Future<void> _approveOrder(Map<String, dynamic> order) async {
    final int id = int.tryParse((order['id'] ?? 0).toString()) ?? 0;
    if (id == 0) return;

    final result = await _service.updateMarketplaceOrderByAdmin(
      orderId: id,
      paymentStatus: 'paid',
      status: 'admin_approved',
      shippingNotes: 'Pedido aprobado por farmacia',
    );

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      await _loadOrders();

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Pedido aprobado y enviado a logística'),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No se pudo aprobar el pedido',
          ),
        ),
      );
    }
  }

  Future<void> _cancelOrder(Map<String, dynamic> order) async {
    final int id = int.tryParse((order['id'] ?? 0).toString()) ?? 0;
    if (id == 0) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Cancelar pedido'),
        content: Text(
          '¿Seguro que deseas cancelar ${order['order_code'] ?? 'este pedido'}?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Volver'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Cancelar pedido'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    final result = await _service.updateMarketplaceOrderByAdmin(
      orderId: id,
      status: 'cancelled',
      shippingNotes: 'Pedido cancelado por farmacia',
    );

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      await _loadOrders();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No se pudo cancelar el pedido',
          ),
        ),
      );
    }
  }

  Future<void> _openWhatsApp(Map<String, dynamic> order) async {
    final phone =
        (order['customer_phone'] ?? '').toString().replaceAll(' ', '');

    if (phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('El cliente no tiene teléfono registrado')),
      );
      return;
    }

    final message = '''
Hola ${order['customer_name'] ?? ''}, le escribimos de Mayu Farmacia sobre su pedido ${order['order_code'] ?? ''}.

Estado pago: ${order['payment_status'] ?? ''}
Total: \$${order['total'] ?? 0} USD
''';

    final uri = Uri.parse(
      'https://wa.me/$phone?text=${Uri.encodeComponent(message)}',
    );

    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Future<void> _openEmail(Map<String, dynamic> order) async {
    final email = (order['customer_email'] ?? '').toString();

    if (email.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('El cliente no tiene email registrado')),
      );
      return;
    }

    final subject = Uri.encodeComponent(
      'Pedido Mayu ${order['order_code'] ?? ''}',
    );

    final body = Uri.encodeComponent('''
Hola ${order['customer_name'] ?? ''},

Le escribimos de Mayu Farmacia sobre su pedido ${order['order_code'] ?? ''}.

Estado pago: ${order['payment_status'] ?? ''}
Total: \$${order['total'] ?? 0} USD

Equipo Mayu
''');

    final uri = Uri.parse('mailto:$email?subject=$subject&body=$body');

    await launchUrl(uri);
  }

  Future<void> _downloadInvoice(Map<String, dynamic> order) async {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('PDF de factura pendiente de conectar al backend'),
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(top: 10, bottom: 4),
      child: Text(
        title,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 15,
        ),
      ),
    );
  }

  Widget _benefitSummary(Map<String, dynamic> order) {
    final raw = order['affiliation_summary'];
    if (raw is! Map) return const SizedBox.shrink();
    final summary = Map<String, dynamic>.from(raw);
    final direct = summary['purchase_type'] == 'direct';
    final entries = [
      ['Tarjeta/Puntos Farmacia', summary['pharmacy_loyalty']],
      ['Doctor Prescriptor', summary['doctor_prescriber']],
      ['Mayu Wellness Club', summary['mayu_wellness']],
      ['Facturación', summary['billing']],
    ];
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color:
            direct ? Colors.grey.shade100 : Colors.teal.withValues(alpha: .06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: direct ? Colors.grey : Colors.teal),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            direct
                ? 'Compra directa sin afiliaciones'
                : 'Beneficios y afiliaciones del pedido',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          ...entries.map((entry) {
            final value = entry[1];
            final map = value is Map
                ? Map<String, dynamic>.from(value)
                : <String, dynamic>{};
            return Padding(
              padding: const EdgeInsets.only(bottom: 5),
              child: Text(
                '${map['applies'] == true || map['requested'] == true ? '✓' : '—'} ${entry[0]}: ${map['description'] ?? 'No aplica'}',
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _orderCard(Map<String, dynamic> order) {
    final items = order['items'] is List ? order['items'] as List : [];
    final status = (order['status'] ?? '').toString();
    final paymentStatus = (order['payment_status'] ?? '').toString();
    final bool adminVerified = order['admin_verified'] == true;
    final orderId = int.tryParse('${order['id'] ?? 0}') ?? 0;
    final expanded = _expandedOrders.contains(orderId);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => setState(() {
          expanded
              ? _expandedOrders.remove(orderId)
              : _expandedOrders.add(orderId);
        }),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.receipt_long, color: Colors.teal),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          order['order_code']?.toString() ??
                              'Pedido Marketplace',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        Text(
                          '${order['customer_name'] ?? ''} · ${MarketplaceOrderTimeline.label(status)}',
                        ),
                      ],
                    ),
                  ),
                  Icon(expanded ? Icons.expand_less : Icons.expand_more),
                ],
              ),
              if (expanded) ...[
                _sectionTitle('Cliente / entrega'),
                Text('Cliente: ${order['customer_name'] ?? ''}'),
                Text('Teléfono: ${order['customer_phone'] ?? ''}'),
                Text('Email: ${order['customer_email'] ?? ''}'),
                Text('Ciudad: ${order['city'] ?? 'No registrada'}'),
                Text('Dirección: ${order['address'] ?? 'No registrada'}'),
                Text(
                    'Notas entrega: ${order['delivery_notes'] ?? 'Sin notas'}'),
                if (order['billing_requested'] == true) ...[
                  _sectionTitle('Datos de facturación'),
                  Text(
                    'Razón social / Nombre: ${order['billing_name'] ?? order['customer_name'] ?? ''}',
                  ),
                  Text(
                      'Cédula / RUC: ${order['billing_identification'] ?? ''}'),
                  Text(
                    'Email factura: ${order['billing_email'] ?? order['customer_email'] ?? ''}',
                  ),
                  Text(
                    'Teléfono factura: ${order['billing_phone'] ?? order['customer_phone'] ?? ''}',
                  ),
                  Text(
                    'Dirección factura: ${order['billing_address'] ?? order['address'] ?? ''}',
                  ),
                ] else
                  const Text('Facturación: no solicitada'),
                const Divider(),
                _sectionTitle('Pago y estado'),
                Text('Método pago: ${order['payment_method'] ?? ''}'),
                Text('Estado pago: $paymentStatus'),
                Chip(
                  avatar: Icon(
                    Icons.circle,
                    size: 12,
                    color: MarketplaceOrderTimeline.color(status),
                  ),
                  label: Text(MarketplaceOrderTimeline.label(status)),
                ),
                Text('Total: \$${order['total'] ?? 0} USD'),
                _benefitSummary(order),
                Text(
                  adminVerified
                      ? 'Aprobado por farmacia'
                      : 'Pendiente de aprobación farmacia',
                  style: TextStyle(
                    color: adminVerified ? Colors.green : Colors.orange,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Divider(),
                const Text(
                  'Productos:',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                ...items.map((item) {
                  final map = Map<String, dynamic>.from(item);
                  return Text(
                    '• ${map['product_name']} x${map['quantity']} - \$${map['total']}',
                  );
                }),
                const Divider(),
                MarketplaceOrderTimeline(order: order),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    OutlinedButton.icon(
                      onPressed: () => _openWhatsApp(order),
                      icon: const Icon(Icons.chat),
                      label: const Text('WhatsApp'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () => _openEmail(order),
                      icon: const Icon(Icons.email),
                      label: const Text('Email'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () => _downloadInvoice(order),
                      icon: const Icon(Icons.picture_as_pdf),
                      label: const Text('Factura PDF'),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed:
                            adminVerified ? null : () => _approveOrder(order),
                        icon: const Icon(Icons.check_circle),
                        label: const Text('Aprobar'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.teal,
                          foregroundColor: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: status == 'cancelled'
                            ? null
                            : () => _cancelOrder(order),
                        icon: const Icon(Icons.cancel),
                        label: const Text('Cancelar'),
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      appBar: AppBar(
        title: const Text('Administrador Farmacia'),
        actions: [
          IconButton(
            onPressed: _loadOrders,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Text(
                    _error!,
                    style: const TextStyle(color: Colors.red),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadOrders,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      const Text(
                        'Pedidos Marketplace Farmacia',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Revisa pagos, datos de facturación y aprueba pedidos para logística.',
                      ),
                      const SizedBox(height: 10),
                      Align(
                        alignment: Alignment.centerRight,
                        child: OutlinedButton.icon(
                          onPressed: _deleteTestOrders,
                          icon: const Icon(Icons.delete_sweep),
                          label: const Text('Limpiar pedidos de prueba'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.red,
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),
                      _pendingPayPhoneBox(),
                      const SizedBox(height: 18),
                      TextField(
                        onChanged: (value) =>
                            setState(() => _ordersSearch = value),
                        decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.search),
                          hintText: 'Buscar orden, cliente, teléfono o correo',
                          border: OutlineInputBorder(),
                          filled: true,
                          fillColor: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 14),
                      if (_orders.isEmpty)
                        const Padding(
                          padding: EdgeInsets.all(30),
                          child: Center(
                            child: Text('No hay pedidos registrados'),
                          ),
                        )
                      else
                        ..._visibleOrders.map(
                          (item) => _orderCard(
                            Map<String, dynamic>.from(item),
                          ),
                        ),
                      const SizedBox(height: 80),
                    ],
                  ),
                ),
    );
  }
}
