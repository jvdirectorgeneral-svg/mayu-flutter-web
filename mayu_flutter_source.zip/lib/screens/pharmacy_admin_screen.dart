import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/marketplace_service.dart';
import '../widgets/marketplace_order_timeline.dart';

class PharmacyAdminScreen extends StatefulWidget {
  const PharmacyAdminScreen({super.key});

  @override
  State<PharmacyAdminScreen> createState() => _PharmacyAdminScreenState();
}

class _PharmacyAdminScreenState extends State<PharmacyAdminScreen> {
  final MarketplaceService _service = MarketplaceService();

  bool _loading = true;
  String? _error;
  List<dynamic> _orders = [];

  @override
  void initState() {
    super.initState();
    _loadOrders();
  }

  Future<void> _loadOrders() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final result = await _service.getAdminOrders();

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      setState(() {
        _orders =
            result['data']?['items'] is List ? result['data']['items'] : [];
        _loading = false;
      });
    } else {
      setState(() {
        _loading = false;
        _error = result['data']?['detail']?.toString() ??
            'No se pudieron cargar los pedidos';
      });
    }
  }

  Future<void> _approveOrder(Map<String, dynamic> order) async {
    final int id = int.tryParse((order['id'] ?? 0).toString()) ?? 0;
    if (id == 0) return;

    final result = await _service.updateMarketplaceOrderByAdmin(
      orderId: id,
      paymentStatus: 'paid',
      status: 'admin_approved',
      shippingNotes: 'Pedido aprobado por farmacia',
    );

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      await _loadOrders();

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Pedido aprobado y enviado a logística'),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No se pudo aprobar el pedido',
          ),
        ),
      );
    }
  }

  Future<void> _cancelOrder(Map<String, dynamic> order) async {
    final int id = int.tryParse((order['id'] ?? 0).toString()) ?? 0;
    if (id == 0) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Cancelar pedido'),
        content: Text(
          '¿Seguro que deseas cancelar ${order['order_code'] ?? 'este pedido'}?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Volver'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Cancelar pedido'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    final result = await _service.updateMarketplaceOrderByAdmin(
      orderId: id,
      status: 'cancelled',
      shippingNotes: 'Pedido cancelado por farmacia',
    );

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      await _loadOrders();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No se pudo cancelar el pedido',
          ),
        ),
      );
    }
  }

  Future<void> _openWhatsApp(Map<String, dynamic> order) async {
    final phone =
        (order['customer_phone'] ?? '').toString().replaceAll(' ', '');

    if (phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('El cliente no tiene teléfono registrado')),
      );
      return;
    }

    final message = '''
Hola ${order['customer_name'] ?? ''}, le escribimos de Mayu Farmacia sobre su pedido ${order['order_code'] ?? ''}.

Estado pago: ${order['payment_status'] ?? ''}
Total: \$${order['total'] ?? 0} USD
''';

    final uri = Uri.parse(
      'https://wa.me/$phone?text=${Uri.encodeComponent(message)}',
    );

    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Future<void> _openEmail(Map<String, dynamic> order) async {
    final email = (order['customer_email'] ?? '').toString();

    if (email.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('El cliente no tiene email registrado')),
      );
      return;
    }

    final subject = Uri.encodeComponent(
      'Pedido Mayu ${order['order_code'] ?? ''}',
    );

    final body = Uri.encodeComponent('''
Hola ${order['customer_name'] ?? ''},

Le escribimos de Mayu Farmacia sobre su pedido ${order['order_code'] ?? ''}.

Estado pago: ${order['payment_status'] ?? ''}
Total: \$${order['total'] ?? 0} USD

Equipo Mayu
''');

    final uri = Uri.parse('mailto:$email?subject=$subject&body=$body');

    await launchUrl(uri);
  }

  Future<void> _downloadInvoice(Map<String, dynamic> order) async {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('PDF de factura pendiente de conectar al backend'),
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(top: 10, bottom: 4),
      child: Text(
        title,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 15,
        ),
      ),
    );
  }

  Widget _orderCard(Map<String, dynamic> order) {
    final items = order['items'] is List ? order['items'] as List : [];
    final status = (order['status'] ?? '').toString();
    final paymentStatus = (order['payment_status'] ?? '').toString();
    final bool adminVerified = order['admin_verified'] == true;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              order['order_code']?.toString() ?? 'Pedido Marketplace',
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            _sectionTitle('Cliente / entrega'),
            Text('Cliente: ${order['customer_name'] ?? ''}'),
            Text('Teléfono: ${order['customer_phone'] ?? ''}'),
            Text('Email: ${order['customer_email'] ?? ''}'),
            Text('Ciudad: ${order['city'] ?? 'No registrada'}'),
            Text('Dirección: ${order['address'] ?? 'No registrada'}'),
            Text('Notas entrega: ${order['delivery_notes'] ?? 'Sin notas'}'),
            _sectionTitle('Datos de facturación'),
            Text(
              'Razón social / Nombre: ${order['billing_name'] ?? order['customer_name'] ?? ''}',
            ),
            Text('Cédula / RUC: ${order['billing_identification'] ?? ''}'),
            Text(
              'Email factura: ${order['billing_email'] ?? order['customer_email'] ?? ''}',
            ),
            Text(
              'Teléfono factura: ${order['billing_phone'] ?? order['customer_phone'] ?? ''}',
            ),
            Text(
              'Dirección factura: ${order['billing_address'] ?? order['address'] ?? ''}',
            ),
            const Divider(),
            _sectionTitle('Pago y estado'),
            Text('Método pago: ${order['payment_method'] ?? ''}'),
            Text('Estado pago: $paymentStatus'),
            Chip(
              avatar: Icon(
                Icons.circle,
                size: 12,
                color: MarketplaceOrderTimeline.color(status),
              ),
              label: Text(MarketplaceOrderTimeline.label(status)),
            ),
            Text('Total: \$${order['total'] ?? 0} USD'),
            Text(
              adminVerified
                  ? 'Aprobado por farmacia'
                  : 'Pendiente de aprobación farmacia',
              style: TextStyle(
                color: adminVerified ? Colors.green : Colors.orange,
                fontWeight: FontWeight.bold,
              ),
            ),
            const Divider(),
            const Text(
              'Productos:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            ...items.map((item) {
              final map = Map<String, dynamic>.from(item);
              return Text(
                '• ${map['product_name']} x${map['quantity']} - \$${map['total']}',
              );
            }),
            const Divider(),
            MarketplaceOrderTimeline(order: order),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                OutlinedButton.icon(
                  onPressed: () => _openWhatsApp(order),
                  icon: const Icon(Icons.chat),
                  label: const Text('WhatsApp'),
                ),
                OutlinedButton.icon(
                  onPressed: () => _openEmail(order),
                  icon: const Icon(Icons.email),
                  label: const Text('Email'),
                ),
                OutlinedButton.icon(
                  onPressed: () => _downloadInvoice(order),
                  icon: const Icon(Icons.picture_as_pdf),
                  label: const Text('Factura PDF'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed:
                        adminVerified ? null : () => _approveOrder(order),
                    icon: const Icon(Icons.check_circle),
                    label: const Text('Aprobar'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: status == 'cancelled'
                        ? null
                        : () => _cancelOrder(order),
                    icon: const Icon(Icons.cancel),
                    label: const Text('Cancelar'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      appBar: AppBar(
        title: const Text('Administrador Farmacia'),
        actions: [
          IconButton(
            onPressed: _loadOrders,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Text(
                    _error!,
                    style: const TextStyle(color: Colors.red),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadOrders,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      const Text(
                        'Pedidos Marketplace Farmacia',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Revisa pagos, datos de facturación y aprueba pedidos para logística.',
                      ),
                      const SizedBox(height: 18),
                      if (_orders.isEmpty)
                        const Padding(
                          padding: EdgeInsets.all(30),
                          child: Center(
                            child: Text('No hay pedidos registrados'),
                          ),
                        )
                      else
                        ..._orders.map(
                          (item) => _orderCard(
                            Map<String, dynamic>.from(item),
                          ),
                        ),
                      const SizedBox(height: 80),
                    ],
                  ),
                ),
    );
  }
}
