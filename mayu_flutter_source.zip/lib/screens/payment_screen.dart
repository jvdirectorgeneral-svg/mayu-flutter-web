import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/monthly_selection_service.dart';
import '../services/subscription_service.dart';

import '../widgets/mayu_scaffold.dart';
import 'digital_card_screen.dart';

class PaymentScreen extends StatefulWidget {
  final int userId;
  final String name;
  final String email;
  final int planLevel;
  final String planName;
  final double price;
  final List<String> initialProducts;
  final String? ambassadorCode;
  final String? loginPassword;

  const PaymentScreen({
    super.key,
    required this.userId,
    required this.name,
    required this.email,
    required this.planLevel,
    required this.planName,
    required this.price,
    required this.initialProducts,
    this.ambassadorCode,
    this.loginPassword,
  });

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  final MonthlySelectionService _monthlySelectionService =
      MonthlySelectionService();
  final SubscriptionService _subscriptionService = SubscriptionService();
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  bool _loading = false;
  bool _subscriptionCreated = false;
  String? _error;
  String? _subscriptionId;
  String? _approvalUrl;

  final double _ivaRate = 0.12;

  double get _baseMonthlyPrice {
    switch (widget.planLevel) {
      case 1:
        return 40.00;
      case 2:
        return 50.00;
      case 3:
        return 60.00;
      default:
        return 0.00;
    }
  }

  double get _baseSignupFee => 5.00;

  double get _monthlyPrice => _baseMonthlyPrice * (1 + _ivaRate);
  double get _signupFee => _baseSignupFee * (1 + _ivaRate);
  double get _firstPayment => _monthlyPrice + _signupFee;

  String get _affiliateSourceText {
    final code = widget.ambassadorCode?.trim();
    if (code != null && code.isNotEmpty) {
      return 'Afiliado por embajador: $code';
    }
    return 'Registro directo';
  }

  String _money(double value) {
    return value == value.roundToDouble()
        ? value.toStringAsFixed(0)
        : value.toStringAsFixed(2);
  }

  String _extractErrorMessage(dynamic data, String fallback) {
    if (data == null) return fallback;
    if (data is String && data.trim().isNotEmpty) return data;

    if (data is Map<String, dynamic>) {
      final detail = data['detail'];

      if (detail is String && detail.trim().isNotEmpty) return detail;

      if (detail is Map && detail['message'] != null) {
        return detail['message'].toString();
      }

      if (detail is List && detail.isNotEmpty) {
        return detail.map((e) => e.toString()).join(' | ');
      }

      final message = data['message'];
      if (message is String && message.trim().isNotEmpty) return message;
    }

    return fallback;
  }

  Future<bool> _openUrl(String url, String errorMessage) async {
    final uri = Uri.tryParse(url);

    if (uri == null) {
      if (!mounted) return false;
      setState(() {
        _loading = false;
        _error = errorMessage;
      });
      return false;
    }

    final opened = await launchUrl(
      uri,
      mode: LaunchMode.externalApplication,
    );

    if (opened) return true;

    if (!mounted) return false;

    setState(() {
      _loading = false;
      _error = errorMessage;
    });

    return false;
  }

  Future<void> _savePendingSubscriptionContext(String subscriptionId) async {
    await _storage.write(
      key: 'mayu_pending_subscription',
      value: jsonEncode({
        'user_id': widget.userId,
        'name': widget.name,
        'email': widget.email,
        'plan_level': widget.planLevel,
        'plan_name': widget.planName,
        'subscription_id': subscriptionId,
        'initial_products': widget.initialProducts,
        'ambassador_code': widget.ambassadorCode,
        'login_password': widget.loginPassword,
      }),
    );
  }

  Future<void> _createSubscriptionAndOpenPayPal() async {
    if (widget.initialProducts.isEmpty) {
      setState(() {
        _error = 'No hay productos iniciales seleccionados para guardar';
      });
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final result = await _subscriptionService.createSubscription(
        userId: widget.userId,
        planLevel: widget.planLevel,
      );

      if (!mounted) return;

      if (result['statusCode'] != 200 && result['statusCode'] != 201) {
        setState(() {
          _loading = false;
          _error = _extractErrorMessage(
            result['data'],
            'No se pudo crear la suscripción PayPal',
          );
        });
        return;
      }

      final data = result['data'];
      final approveUrl = _subscriptionService.getApproveUrl(data);
      final subscriptionId =
          (data?['paypal_subscription_id'] ?? data?['id'] ?? '').toString();

      if (approveUrl == null || approveUrl.isEmpty) {
        setState(() {
          _loading = false;
          _error = 'PayPal no devolvió el enlace de aprobación';
        });
        return;
      }

      if (subscriptionId.isNotEmpty) {
        await _savePendingSubscriptionContext(subscriptionId);
      }

      setState(() {
        _subscriptionCreated = true;
        _subscriptionId = subscriptionId.isNotEmpty ? subscriptionId : null;
        _approvalUrl = approveUrl;
        _loading = false;
      });

      await _openUrl(
        approveUrl,
        'No se pudo abrir PayPal para aprobar la membresía',
      );
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _loading = false;
        _error = 'Error creando suscripción PayPal: $e';
      });
    }
  }

  Future<void> _verifySubscriptionAndContinue() async {
    if (!_subscriptionCreated) {
      setState(() {
        _error = 'Primero debes aprobar la membresía en PayPal';
      });
      return;
    }

    if (_subscriptionId == null || _subscriptionId!.isEmpty) {
      setState(() {
        _error = 'No se encontró el ID de la suscripción PayPal';
      });
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final statusResult = await _subscriptionService.getSubscriptionStatus(
        userId: widget.userId,
      );

      if (!mounted) return;

      if (statusResult['statusCode'] != 200 &&
          statusResult['statusCode'] != 201) {
        setState(() {
          _loading = false;
          _error = _extractErrorMessage(
            statusResult['data'],
            'PayPal aún no confirma la suscripción',
          );
        });
        return;
      }

      final statusData = statusResult['data'];
      final bool active = statusData?['membership_active'] == true;
      final status = (statusData?['subscription_status'] ?? '').toString();
      final localStatus =
          (statusData?['local_payment_status'] ?? '').toString();

      if (!active &&
          status != 'ACTIVE' &&
          localStatus != 'subscription_active' &&
          localStatus != 'subscription_paid') {
        setState(() {
          _loading = false;
          _error =
              'PayPal todavía no reporta la suscripción activa. Espera unos segundos y vuelve a verificar.';
        });
        return;
      }

      final activateResult =
          await _subscriptionService.activateLevel1Subscription(
        userId: widget.userId,
        subscriptionId: _subscriptionId!,
      );

      if (!mounted) return;

      if (activateResult['statusCode'] != 200 &&
          activateResult['statusCode'] != 201) {
        setState(() {
          _loading = false;
          _error = _extractErrorMessage(
            activateResult['data'],
            'PayPal aprobó la membresía, pero falló la activación final',
          );
        });
        return;
      }

      await _saveInitialProductsFromActivatedSelection(activateResult['data']);
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _loading = false;
        _error = 'Error verificando suscripción PayPal: $e';
      });
    }
  }

  Future<void> _saveInitialProductsFromActivatedSelection(dynamic data) async {
    final dynamic selectionId = data?['selection_id'] ?? data?['id'];

    if (selectionId == null) {
      setState(() {
        _loading = false;
        _error =
            'La membresía se activó, pero no se obtuvo la selección mensual';
      });
      return;
    }

    final saveProductsResult =
        await _monthlySelectionService.saveInitialSelectionsAfterPayment(
      selectionId: int.parse(selectionId.toString()),
      productNames: widget.initialProducts,
    );

    if (!mounted) return;

    if (saveProductsResult['statusCode'] != 200 &&
        saveProductsResult['statusCode'] != 201) {
      setState(() {
        _loading = false;
        _error = _extractErrorMessage(
          saveProductsResult['data'],
          'La membresía se activó, pero falló guardar los productos iniciales',
        );
      });
      return;
    }

    _goToDigitalCard();
  }

  void _goToDigitalCard() {
    if (!mounted) return;

    setState(() {
      _loading = false;
    });

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (context) => DigitalCardScreen(
          userId: widget.userId,
          name: widget.name,
          planName: widget.planName,
        ),
      ),
      (route) => false,
    );
  }

  Widget _statusBox() {
    if (!_subscriptionCreated) {
      return const SizedBox.shrink();
    }

    return Container(
      margin: const EdgeInsets.only(top: 14),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.blueGrey.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Estado del proceso',
              style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text('Suscripción PayPal: ${_subscriptionId ?? "-"}'),
          const SizedBox(height: 4),
          const Text(
            'Cuando PayPal termine, volverás automáticamente a Mayu para confirmar tu membresía.',
          ),
          if (_approvalUrl != null) ...[
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: _loading
                  ? null
                  : () => _openUrl(_approvalUrl!, 'No se pudo abrir PayPal'),
              icon: const Icon(Icons.open_in_new),
              label: const Text('Abrir PayPal nuevamente'),
            ),
          ],
        ],
      ),
    );
  }

  Widget _selectedProductsBox() {
    if (widget.initialProducts.isEmpty) {
      return const Text(
        'No hay productos iniciales seleccionados.',
        style: TextStyle(fontSize: 16, color: Colors.red),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Productos iniciales:',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 8),
        ...widget.initialProducts.map(
          (product) => Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('- ', style: TextStyle(fontSize: 17)),
                Expanded(
                  child: Text(product, style: const TextStyle(fontSize: 16)),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final String baseFirstPaymentText =
        _money(_baseMonthlyPrice + _baseSignupFee);
    final String firstPaymentText = _money(_firstPayment);
    final String baseMonthlyText = _money(_baseMonthlyPrice);
    final String monthlyText = _money(_monthlyPrice);
    final String signupFeeText = _money(_signupFee);

    return MayuScaffold(
      appBar: AppBar(
        title: const Text('Pago de afiliación'),
        centerTitle: true,
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text(
                    'Resumen de tu afiliación',
                    style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.88),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Colors.black12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Nombre: ${widget.name}',
                            style: const TextStyle(fontSize: 18)),
                        const SizedBox(height: 8),
                        Text('Email: ${widget.email}',
                            style: const TextStyle(fontSize: 18)),
                        const SizedBox(height: 8),
                        Text('Plan: ${widget.planName}',
                            style: const TextStyle(fontSize: 18)),
                        const SizedBox(height: 8),
                        Text(
                          _affiliateSourceText,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 16),
                        _selectedProductsBox(),
                        const SizedBox(height: 16),
                        Text(
                          'Primer cobro PayPal: \$$firstPaymentText USD',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Subtotal sin IVA: \$$baseFirstPaymentText USD',
                          style: const TextStyle(fontSize: 15),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Incluye inscripción inicial única de \$$signupFeeText con IVA + mensualidad de \$$monthlyText con IVA.',
                          style: const TextStyle(fontSize: 15),
                        ),
                        const SizedBox(height: 4),
                        const Text(
                          'IVA Ecuador 12% incluido.',
                          style: TextStyle(fontSize: 15),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Mensualidad recurrente: \$$monthlyText USD',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Mensualidad base: \$$baseMonthlyText + IVA 12%.',
                          style: const TextStyle(fontSize: 15),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'PayPal será la única pasarela para activar y mantener la membresía.',
                          style: TextStyle(fontSize: 15),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  _statusBox(),
                  const SizedBox(height: 20),
                  if (_error != null)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Text(
                        _error!,
                        style: const TextStyle(color: Colors.red),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ElevatedButton.icon(
                    onPressed:
                        _loading ? null : _createSubscriptionAndOpenPayPal,
                    icon: const Icon(Icons.payment),
                    label: _loading
                        ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Text('Aprobar membresía mensual con PayPal'),
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: _loading || !_subscriptionCreated
                        ? null
                        : _verifySubscriptionAndContinue,
                    icon: const Icon(Icons.verified),
                    label: const Text('Confirmar membresía en Mayu'),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
