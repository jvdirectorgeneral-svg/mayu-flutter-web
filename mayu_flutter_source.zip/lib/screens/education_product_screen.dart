import 'package:flutter/material.dart';

import '../widgets/mayu_scaffold.dart';
import 'education_checkout_screen.dart';

class EducationProductScreen extends StatelessWidget {
  final Map<String, dynamic> resource;
  final VoidCallback? onAddToCart;

  const EducationProductScreen({
    super.key,
    required this.resource,
    this.onAddToCart,
  });

  double _priceOf() {
    final raw = resource['price'];
    if (raw is num) return raw.toDouble();
    return double.tryParse((raw ?? '0').toString()) ?? 0;
  }

  String _typeLabel(String type) {
    switch (type) {
      case 'pdf':
        return 'PDF';
      case 'video':
        return 'Video';
      case 'image':
        return 'Imagen';
      case 'plant_card':
        return 'Ficha de planta';
      case 'plant_registry':
        return 'Registro de planta';
      default:
        return 'Contenido';
    }
  }

  String _languageLabel() {
    final language = (resource['language'] ?? 'es').toString();
    return language == 'en' ? 'Inglés' : 'Español';
  }

  String _contentTypeLabel() {
    final type = (resource['content_type'] ?? 'general').toString();

    switch (type) {
      case 'course':
        return 'Curso';
      case 'ebook':
        return 'Ebook';
      case 'video':
        return 'Video';
      case 'masterclass':
        return 'Masterclass';
      case 'conference':
        return 'Conferencia';
      case 'protocol':
        return 'Protocolo';
      case 'botanical_sheet':
        return 'Ficha botánica';
      case 'clinical_guide':
        return 'Guía clínica';
      default:
        return 'General';
    }
  }

  Widget _infoSection(String title, dynamic value) {
    final text = (value ?? '').toString().trim();

    if (text.isEmpty) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.only(top: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
          ),
          const SizedBox(height: 5),
          Text(text, style: const TextStyle(fontSize: 15, height: 1.45)),
        ],
      ),
    );
  }

  Widget _urlTile({
    required IconData icon,
    required String title,
    required String url,
  }) {
    if (url.trim().isEmpty) return const SizedBox.shrink();

    return Card(
      child: ListTile(
        leading: Icon(icon, color: Colors.teal),
        title: Text(title),
        subtitle: const Text(
          'Contenido protegido Mayu. Se habilita dentro del acceso educativo.',
        ),
        trailing: const Icon(
          Icons.lock_outline,
          color: Colors.teal,
        ),
      ),
    );
  }

  Widget _extraContentSection() {
    final videoUrls = resource['video_urls'] is List
        ? List<dynamic>.from(resource['video_urls'])
        : [];

    final onlineFiles = resource['online_files'] is List
        ? List<dynamic>.from(resource['online_files'])
        : [];

    final downloadPdfUrl =
        (resource['download_pdf_url'] ?? '').toString().trim();

    if (videoUrls.isEmpty && onlineFiles.isEmpty && downloadPdfUrl.isEmpty) {
      return const SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.only(top: 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Contenido incluido',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
          ),
          const SizedBox(height: 10),
          ...videoUrls.map(
            (url) => _urlTile(
              icon: Icons.play_circle,
              title: 'Video online',
              url: url.toString(),
            ),
          ),
          ...onlineFiles.map((file) {
            if (file is Map) {
              return _urlTile(
                icon: Icons.insert_drive_file,
                title: file['name']?.toString() ?? 'Archivo online',
                url: file['url']?.toString() ?? '',
              );
            }

            return _urlTile(
              icon: Icons.insert_drive_file,
              title: 'Archivo online',
              url: file.toString(),
            );
          }),
          _urlTile(
            icon: Icons.download,
            title: 'PDF descargable',
            url: downloadPdfUrl,
          ),
        ],
      ),
    );
  }

  Widget _placeholder(String type) {
    IconData icon = Icons.menu_book;

    if (type == 'video') icon = Icons.play_circle;
    if (type == 'image') icon = Icons.image;
    if (type == 'plant_card' || type == 'plant_registry') icon = Icons.eco;

    return Container(
      height: 220,
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.teal.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Icon(icon, color: Colors.teal, size: 70),
    );
  }

  @override
  Widget build(BuildContext context) {
    final title = resource['title']?.toString() ?? 'Contenido Mayu';
    final type = (resource['resource_type'] ?? '').toString();
    final coverUrl = (resource['cover_image_url'] ?? '').toString();
    final price = _priceOf();

    return MayuScaffold(
      appBar: AppBar(
        title: const Text('Mayu Educación'),
        centerTitle: true,
      ),
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(
            title,
            style: const TextStyle(fontSize: 27, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            '${resource['category_name'] ?? 'Sin categoría'} • ${_typeLabel(type)} • ${_languageLabel()} • ${_contentTypeLabel()}',
            style: const TextStyle(
              color: Colors.teal,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 16),
          coverUrl.isNotEmpty
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: Image.network(
                    coverUrl,
                    height: 220,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => _placeholder(type),
                  ),
                )
              : _placeholder(type),
          const SizedBox(height: 18),
          Text(
            '\$${price.toStringAsFixed(2)} USD',
            style: const TextStyle(
              fontSize: 25,
              fontWeight: FontWeight.bold,
              color: Colors.teal,
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Incluye código de acceso válido para 30 ingresos.',
            style: TextStyle(fontSize: 14),
          ),
          _infoSection('Descripción', resource['description']),
          _infoSection('Resumen educativo', resource['content_text']),
          _infoSection('Nombre común', resource['plant_common_name']),
          _infoSection('Nombre científico', resource['plant_scientific_name']),
          _infoSection('Familia', resource['plant_family']),
          _infoSection('Origen', resource['plant_origin']),
          _infoSection('Usos', resource['plant_uses']),
          _infoSection('Partes usadas', resource['plant_parts_used']),
          _infoSection('Preparación', resource['plant_preparation']),
          _infoSection('Advertencias', resource['plant_warnings']),
          _extraContentSection(),
          const SizedBox(height: 28),
          if (onAddToCart != null)
            SizedBox(
              height: 54,
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.add_shopping_cart),
                label: const Text('Agregar al carrito'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  foregroundColor: Colors.white,
                ),
                onPressed: () {
                  onAddToCart!();
                  Navigator.pop(context);
                },
              ),
            )
          else
            SizedBox(
              height: 54,
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.shopping_cart),
                label: const Text('Comprar acceso'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  foregroundColor: Colors.white,
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => EducationCheckoutScreen(
                        cartItems: [
                          {
                            'resource': resource,
                            'quantity': 1,
                          },
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          const SizedBox(height: 80),
        ],
      ),
    );
  }
}