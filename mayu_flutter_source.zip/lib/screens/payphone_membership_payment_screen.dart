import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/payphone_service.dart';
import 'wallet_card_screen.dart';

class PayphoneMembershipPaymentScreen extends StatefulWidget {
  final int userId;
  final int planLevel;
  final String userName;

  const PayphoneMembershipPaymentScreen({
    super.key,
    required this.userId,
    required this.planLevel,
    this.userName = 'Socio Mayu',
  });

  @override
  State<PayphoneMembershipPaymentScreen> createState() =>
      _PayphoneMembershipPaymentScreenState();
}

class _PayphoneMembershipPaymentScreenState
    extends State<PayphoneMembershipPaymentScreen> {
  final PayphoneService _service = PayphoneService();

  bool _creating = false;
  bool _confirming = false;

  String? _error;
  String? _paymentUrl;
  String? _clientTransactionId;

  double get _monthlyAmount {
    if (widget.planLevel == 1) return 40.00;
    if (widget.planLevel == 2) return 50.00;
    return 60.00;
  }

  double get _firstPaymentAmount => _monthlyAmount + 5.00;

  String get _planName {
    if (widget.planLevel == 1) return 'Nivel 1 - Cobre';
    if (widget.planLevel == 2) return 'Nivel 2 - Plata';
    return 'Nivel 3 - Oro';
  }

  String _money(double value) {
    return value == value.roundToDouble()
        ? value.toStringAsFixed(0)
        : value.toStringAsFixed(2);
  }

  String _extractError(dynamic data, String fallback) {
    if (data == null) return fallback;

    if (data is Map) {
      final detail = data['detail'];
      if (detail is String && detail.trim().isNotEmpty) return detail;

      final message = data['message'];
      if (message is String && message.trim().isNotEmpty) return message;
    }

    return fallback;
  }

  String _extractPayphoneUrl(dynamic data) {
    if (data == null) return '';

    final payphone = data['payphone'];

    if (payphone is String) return payphone;

    if (payphone is Map) {
      return payphone['link']?.toString() ??
          payphone['paymentUrl']?.toString() ??
          payphone['payment_url']?.toString() ??
          payphone['url']?.toString() ??
          '';
    }

    return data['link']?.toString() ??
        data['paymentUrl']?.toString() ??
        data['payment_url']?.toString() ??
        data['url']?.toString() ??
        '';
  }

  Future<void> _openPaymentUrl(String url) async {
    if (url.trim().isEmpty) return;

    await launchUrl(
      Uri.parse(url),
      mode: LaunchMode.externalApplication,
    );
  }

  Future<void> _createPayment() async {
    setState(() {
      _creating = true;
      _error = null;
    });

    final result = await _service.createInitialMembershipPayment(
      userId: widget.userId,
      planLevel: widget.planLevel,
      acceptedRecurringDebit: true,
    );

    if (!mounted) return;

    setState(() {
      _creating = false;
    });

    if (result['statusCode'] == 200 || result['statusCode'] == 201) {
      final data = result['data'];
      final url = _extractPayphoneUrl(data);

      setState(() {
        _paymentUrl = url;
        _clientTransactionId = data['clientTransactionId']?.toString();
      });

      if (url.isNotEmpty) {
        await _openPaymentUrl(url);
      }
    } else {
      setState(() {
        _error = _extractError(
          result['data'],
          'No se pudo crear el link PayPhone',
        );
      });
    }
  }

  Future<void> _confirmPayment() async {
    if (_clientTransactionId == null || _clientTransactionId!.isEmpty) {
      setState(() {
        _error = 'Primero crea el link de pago';
      });
      return;
    }

    setState(() {
      _confirming = true;
      _error = null;
    });

    final result = await _service.confirmInitialMembershipPayment(
      clientTransactionId: _clientTransactionId!,
    );

    if (!mounted) return;

    setState(() {
      _confirming = false;
    });

    if (result['statusCode'] == 200 || result['statusCode'] == 201) {
      final data = result['data'];

      if (data['success'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Pago confirmado. Membresía activada.'),
          ),
        );

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => WalletCardScreen(
              userId: widget.userId,
              userName: widget.userName,
            ),
          ),
        );
      } else {
        setState(() {
          _error = data['message']?.toString() ??
              'PayPhone todavía no confirma el pago';
        });
      }
    } else {
      setState(() {
        _error = _extractError(
          result['data'],
          'No se pudo confirmar el pago',
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final monthlyText = _money(_monthlyAmount);
    final firstPaymentText = _money(_firstPaymentAmount);

    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      appBar: AppBar(
        title: const Text('Pago PayPhone'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(22),
        children: [
          Text(
            _planName,
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            'Primer pago: \$$firstPaymentText USD',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          Text(
            'Incluye inscripción única de \$5 + mensualidad de \$$monthlyText.',
          ),
          const SizedBox(height: 10),
          Text(
            'Luego aceptas el débito mensual recurrente de \$$monthlyText según tu nivel.',
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: _creating ? null : _createPayment,
            icon: const Icon(Icons.payment),
            label: Text(
              _creating ? 'Creando link...' : 'Pagar con PayPhone',
            ),
          ),
          if (_paymentUrl != null && _paymentUrl!.isNotEmpty) ...[
            const SizedBox(height: 14),
            OutlinedButton.icon(
              onPressed: () => _openPaymentUrl(_paymentUrl!),
              icon: const Icon(Icons.open_in_new),
              label: const Text('Abrir link PayPhone nuevamente'),
            ),
          ],
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: _confirming ? null : _confirmPayment,
            icon: const Icon(Icons.check_circle),
            label: Text(
              _confirming ? 'Confirmando...' : 'Ya pagué, confirmar pago',
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.teal,
              foregroundColor: Colors.white,
            ),
          ),
          if (_clientTransactionId != null) ...[
            const SizedBox(height: 14),
            Text(
              'Transacción: $_clientTransactionId',
              style: const TextStyle(color: Colors.black54),
            ),
          ],
          if (_error != null) ...[
            const SizedBox(height: 18),
            Text(
              _error!,
              style: const TextStyle(color: Colors.red),
            ),
          ],
        ],
      ),
    );
  }
}