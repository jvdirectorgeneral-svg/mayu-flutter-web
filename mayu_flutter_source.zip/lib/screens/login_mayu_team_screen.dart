import 'package:flutter/material.dart';

import '../services/auth_service.dart';
import '../services/ambassador_service.dart';
import '../widgets/mayu_logo.dart';

import 'ambassador_dashboard_screen.dart';
import 'admin_dashboard_screen.dart';
import 'doctor_prescriber_card_screen.dart';
import 'supervisor_dashboard_screen.dart';
import 'superadmin_dashboard_screen.dart';
import 'logistics_dashboard_screen.dart';
import 'marketing_dashboard_screen.dart';
import 'pharmacy_dashboard_screen.dart';
import 'education_dashboard_screen.dart';

class LoginMayuTeamScreen extends StatefulWidget {
  const LoginMayuTeamScreen({super.key});

  @override
  State<LoginMayuTeamScreen> createState() => _LoginMayuTeamScreenState();
}

class _LoginMayuTeamScreenState extends State<LoginMayuTeamScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  final AuthService _authService = AuthService();

  bool _loading = false;
  String? _error;

  Future<void> _login() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    FocusScope.of(context).unfocus();

    if (email.isEmpty || password.isEmpty) {
      setState(() {
        _error = 'Ingresa email y contraseña';
      });
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final success = await _authService.login(
        email: email,
        password: password,
      );

      if (!mounted) return;

      if (!success) {
        setState(() {
          _error = 'Email o contraseña incorrectos';
          _loading = false;
        });
        return;
      }

      final user = await _authService.getUser();
      final String role = (user?['role'] ?? '').toString();

      Widget? nextScreen;

      switch (role) {
        case 'superadmin':
          nextScreen = const SuperAdminDashboardScreen();
          break;
        case 'admin':
          nextScreen = const AdminDashboardScreen();
          break;
        case 'supervisor':
          nextScreen = const SupervisorDashboardScreen();
          break;
        case 'logistics':
          nextScreen = const LogisticsDashboardScreen();
          break;
        case 'marketing':
          nextScreen = const MarketingDashboardScreen();
          break;
        case 'pharmacy_admin':
          nextScreen = const PharmacyDashboardScreen();
          break;
        case 'education_admin':
          nextScreen = const EducationDashboardScreen();
          break;
        case 'ambassador':
          final result = await AmbassadorService.loginAmbassador(
            email: email,
            password: password,
          );

          if (result['statusCode'] == 200 && result['data'] != null) {
            final data = result['data'];
            final ambassador = data['ambassador'];

            if (ambassador == null || ambassador['id'] == null) {
              setState(() {
                _error = 'No se pudo obtener el perfil del embajador';
                _loading = false;
              });
              return;
            }

            final int ambassadorId = ambassador['id'] is int
                ? ambassador['id']
                : int.tryParse(ambassador['id'].toString()) ?? 0;

            if (ambassadorId == 0) {
              setState(() {
                _error = 'ID de embajador inválido';
                _loading = false;
              });
              return;
            }

            nextScreen = AmbassadorDashboardScreen(
              ambassadorId: ambassadorId,
            );
          } else {
            setState(() {
              _error = result['data']?['detail'] ??
                  'No se pudo cargar el perfil del embajador';
              _loading = false;
            });
            return;
          }
          break;
        default:
          setState(() {
            _error = 'Rol no reconocido';
            _loading = false;
          });
          return;
      }

      if (!mounted) return;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => nextScreen!),
      );
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _error = 'Error al iniciar sesión';
        _loading = false;
      });
      return;
    }

    if (mounted) {
      setState(() {
        _loading = false;
      });
    }
  }

  InputDecoration _input(String label) {
    return InputDecoration(
      labelText: label,
      border: const OutlineInputBorder(),
    );
  }

  void _openDoctor() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const DoctorPrescriberCardScreen()),
    );
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mayu Team'),
        actions: [
          IconButton(
            tooltip: 'Doctor Prescriptor Mayu',
            onPressed: _openDoctor,
            icon: const Icon(Icons.stars),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 500),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  const MayuLogo(height: 90),
                  const SizedBox(height: 16),
                  const Text(
                    'Ingreso equipo Mayu',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _emailController,
                    keyboardType: TextInputType.emailAddress,
                    textInputAction: TextInputAction.next,
                    decoration: _input('Email'),
                    onChanged: (_) {
                      if (_error != null) {
                        setState(() {
                          _error = null;
                        });
                      }
                    },
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _passwordController,
                    obscureText: true,
                    textInputAction: TextInputAction.done,
                    onSubmitted: (_) {
                      if (!_loading) {
                        _login();
                      }
                    },
                    decoration: _input('Contraseña'),
                    onChanged: (_) {
                      if (_error != null) {
                        setState(() {
                          _error = null;
                        });
                      }
                    },
                  ),
                  const SizedBox(height: 16),
                  if (_error != null)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Text(
                        _error!,
                        style: const TextStyle(color: Colors.red),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _loading ? null : _login,
                      child: _loading
                          ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Text('Ingresar'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
