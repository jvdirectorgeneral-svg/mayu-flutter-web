import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../services/auth_service.dart';
import '../services/marketplace_service.dart';
import '../services/superadmin_service.dart';
import 'login_screen.dart';
import 'pharmacy_admin_screen.dart';
import 'pharmacy_logistics_screen.dart';
import 'pharmacy_points_admin_screen.dart';
import 'doctor_prescriber_sales_admin_screen.dart';

class PharmacyDashboardScreen extends StatefulWidget {
  const PharmacyDashboardScreen({super.key});

  @override
  State<PharmacyDashboardScreen> createState() =>
      _PharmacyDashboardScreenState();
}

class _PharmacyDashboardScreenState extends State<PharmacyDashboardScreen> {
  final MarketplaceService _service = MarketplaceService();
  final SuperAdminService _superAdminService = SuperAdminService();
  final AuthService _authService = AuthService();

  bool _loading = true;
  String? _error;

  List<dynamic> _products = [];
  List<dynamic> _categories = [];

  String _search = '';
  int _categoryFilter = 0;

  Map<String, String> _accessCodes = const {
    'pharmacy_points': '0001',
    'doctor_prescriber': '0001',
    'pharmacy_admin': '4444',
    'pharmacy_logistics': '8888',
  };

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final categoriesResult = await _service.getAdminCategories();
    final productsResult = await _service.getAdminProducts();
    final accessCodesResult = await _superAdminService.getPharmacyAccessCodes(
      farmaciaScope: true,
    );

    if (!mounted) return;

    if (categoriesResult['statusCode'] == 200 &&
        productsResult['statusCode'] == 200) {
      setState(() {
        _categories = categoriesResult['data']?['items'] is List
            ? categoriesResult['data']['items']
            : [];

        _products = productsResult['data']?['items'] is List
            ? productsResult['data']['items']
            : [];

        if (accessCodesResult['statusCode'] == 200) {
          final items = accessCodesResult['data']?['items'];
          if (items is Map) {
            _accessCodes = {
              'pharmacy_points':
                  (items['pharmacy_points']?['code'] ?? '0001').toString(),
              'doctor_prescriber':
                  (items['doctor_prescriber']?['code'] ?? '0001').toString(),
              'pharmacy_admin':
                  (items['pharmacy_admin']?['code'] ?? '4444').toString(),
              'pharmacy_logistics':
                  (items['pharmacy_logistics']?['code'] ?? '8888').toString(),
            };
          }
        }

        _loading = false;
      });
    } else {
      setState(() {
        _loading = false;
        _error = categoriesResult['data']?['detail']?.toString() ??
            productsResult['data']?['detail']?.toString() ??
            'No se pudo cargar Marketplace';
      });
    }
  }

  String _codeFor(String key) {
    return _accessCodes[key] ?? '';
  }

  List<dynamic> get _filteredProducts {
    return _products.where((item) {
      final product = Map<String, dynamic>.from(item);
      final name = (product['name'] ?? '').toString().toLowerCase();
      final categoryId =
          int.tryParse((product['category_id'] ?? 0).toString()) ?? 0;

      final matchesSearch = name.contains(_search.toLowerCase());
      final matchesCategory =
          _categoryFilter == 0 || categoryId == _categoryFilter;

      return matchesSearch && matchesCategory;
    }).toList();
  }

  Future<void> _logout() async {
    await _authService.logout();

    if (!mounted) return;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  Future<void> _openPharmacyAdmin() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const PharmacyAdminScreen()),
    );

    if (!mounted) return;
    await _loadData();
  }

  Future<void> _openPharmacyLogistics() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const PharmacyLogisticsScreen()),
    );

    if (!mounted) return;
    await _loadData();
  }

  Future<void> _openPharmacyPoints() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const PharmacyPointsAdminScreen()),
    );

    if (!mounted) return;
    await _loadData();
  }

  Future<void> _openDoctorPrescriberSales() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const DoctorPrescriberSalesAdminScreen(),
      ),
    );

    if (!mounted) return;
    await _loadData();
  }

  Future<void> _requestDashboardAccess({
    required String title,
    required String code,
    required Future<void> Function() onApproved,
  }) async {
    final controller = TextEditingController();
    String? errorText;

    final approved = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text(title),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'Ingresa el código de acceso para continuar.',
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: controller,
                    autofocus: true,
                    obscureText: true,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: 'Código',
                      border: const OutlineInputBorder(),
                      errorText: errorText,
                    ),
                    onSubmitted: (_) {
                      if (controller.text.trim() == code) {
                        Navigator.pop(dialogContext, true);
                      } else {
                        setDialogState(() {
                          errorText = 'Código incorrecto';
                        });
                      }
                    },
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext, false),
                  child: const Text('Cancelar'),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (controller.text.trim() == code) {
                      Navigator.pop(dialogContext, true);
                    } else {
                      setDialogState(() {
                        errorText = 'Código incorrecto';
                      });
                    }
                  },
                  child: const Text('Entrar'),
                ),
              ],
            );
          },
        );
      },
    );

    if (approved == true && mounted) {
      await onApproved();
    }
  }

  Future<void> _showCategoryDialog({Map<String, dynamic>? category}) async {
    final bool isEdit = category != null;

    final nameController = TextEditingController(
      text: isEdit ? (category['name'] ?? '').toString() : '',
    );

    final descriptionController = TextEditingController(
      text: isEdit ? (category['description'] ?? '').toString() : '',
    );

    bool active = isEdit ? category['active'] == true : true;

    await showDialog(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text(isEdit ? 'Editar categoría' : 'Crear categoría'),
              content: SizedBox(
                width: 460,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: nameController,
                      decoration: const InputDecoration(
                        labelText: 'Nombre de la categoría',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: descriptionController,
                      minLines: 2,
                      maxLines: 3,
                      decoration: const InputDecoration(
                        labelText: 'Descripción',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 8),
                    SwitchListTile(
                      value: active,
                      title: const Text('Categoría activa'),
                      onChanged: (value) {
                        setDialogState(() {
                          active = value;
                        });
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Cancelar'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    final name = nameController.text.trim();
                    final description = descriptionController.text.trim();

                    if (name.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('El nombre es obligatorio'),
                        ),
                      );
                      return;
                    }

                    final result = isEdit
                        ? await _service.updateCategory(
                            categoryId: category['id'],
                            name: name,
                            description: description,
                            active: active,
                          )
                        : await _service.createCategory(
                            name: name,
                            description: description,
                            active: active,
                          );

                    if (!mounted) return;

                    Navigator.pop(dialogContext);

                    if (result['statusCode'] == 200 ||
                        result['statusCode'] == 201) {
                      await _loadData();
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            result['data']?['detail']?.toString() ??
                                'No se pudo guardar la categoría',
                          ),
                        ),
                      );
                    }
                  },
                  child: const Text('Guardar'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _deleteCategory(Map<String, dynamic> category) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Eliminar categoría'),
          content: Text('¿Seguro que deseas eliminar "${category['name']}"?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Eliminar'),
            ),
          ],
        );
      },
    );

    if (confirm != true) return;

    final result = await _service.deleteCategory(categoryId: category['id']);

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      await _loadData();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No se pudo eliminar la categoría',
          ),
        ),
      );
    }
  }

  Future<void> _showProductDialog({Map<String, dynamic>? product}) async {
    final bool isEdit = product != null;

    final nameController = TextEditingController(
      text: isEdit ? (product['name'] ?? '').toString() : '',
    );

    final priceController = TextEditingController(
      text: isEdit ? (product['price'] ?? 0).toString() : '0',
    );

    final stockController = TextEditingController(
      text: isEdit ? (product['stock'] ?? 0).toString() : '0',
    );

    final presentationController = TextEditingController(
      text: isEdit ? (product['presentation'] ?? '').toString() : '',
    );

    final shortDescriptionController = TextEditingController(
      text: isEdit ? (product['short_description'] ?? '').toString() : '',
    );

    final descriptionController = TextEditingController(
      text: isEdit ? (product['description'] ?? '').toString() : '',
    );

    final benefitsController = TextEditingController(
      text: isEdit ? (product['benefits'] ?? '').toString() : '',
    );

    final ingredientsController = TextEditingController(
      text: isEdit ? (product['ingredients'] ?? '').toString() : '',
    );

    final suggestedDoseController = TextEditingController(
      text: isEdit ? (product['suggested_dose'] ?? '').toString() : '',
    );

    final usageController = TextEditingController(
      text: isEdit ? (product['usage_instructions'] ?? '').toString() : '',
    );

    final warningsController = TextEditingController(
      text: isEdit ? (product['warnings'] ?? '').toString() : '',
    );

    final imageController = TextEditingController(
      text: isEdit ? (product['image_url'] ?? '').toString() : '',
    );

    final videoUrlController = TextEditingController(
      text: isEdit ? (product['video_url'] ?? '').toString() : '',
    );

    int selectedCategoryId = isEdit
        ? int.tryParse((product['category_id'] ?? 0).toString()) ?? 0
        : 0;

    bool active = isEdit ? product['active'] == true : true;
    bool uploadingImage = false;
    String imageUrl = imageController.text.trim();

    await showDialog(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text(isEdit ? 'Editar producto' : 'Crear producto'),
              content: SizedBox(
                width: 620,
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      TextField(
                        controller: nameController,
                        decoration: const InputDecoration(
                          labelText: 'Nombre del producto',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<int>(
                        initialValue: selectedCategoryId,
                        decoration: const InputDecoration(
                          labelText: 'Categoría',
                          border: OutlineInputBorder(),
                        ),
                        items: [
                          const DropdownMenuItem(
                            value: 0,
                            child: Text('Sin categoría'),
                          ),
                          ..._categories.map((item) {
                            final category = Map<String, dynamic>.from(item);
                            return DropdownMenuItem<int>(
                              value: category['id'],
                              child: Text(category['name'] ?? 'Categoría'),
                            );
                          }),
                        ],
                        onChanged: (value) {
                          if (value == null) return;
                          setDialogState(() {
                            selectedCategoryId = value;
                          });
                        },
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: priceController,
                        keyboardType: const TextInputType.numberWithOptions(
                          decimal: true,
                        ),
                        decoration: const InputDecoration(
                          labelText: 'Precio',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: stockController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'Stock',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: presentationController,
                        decoration: const InputDecoration(
                          labelText: 'Presentación',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: shortDescriptionController,
                        decoration: const InputDecoration(
                          labelText: 'Descripción corta',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: descriptionController,
                        minLines: 2,
                        maxLines: 4,
                        decoration: const InputDecoration(
                          labelText: 'Descripción',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: benefitsController,
                        minLines: 2,
                        maxLines: 4,
                        decoration: const InputDecoration(
                          labelText: 'Beneficios',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: ingredientsController,
                        minLines: 2,
                        maxLines: 4,
                        decoration: const InputDecoration(
                          labelText: 'Ingredientes',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: suggestedDoseController,
                        minLines: 2,
                        maxLines: 4,
                        decoration: const InputDecoration(
                          labelText: 'Dosis sugerida',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: usageController,
                        minLines: 2,
                        maxLines: 4,
                        decoration: const InputDecoration(
                          labelText: 'Modo de uso',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: warningsController,
                        minLines: 2,
                        maxLines: 4,
                        decoration: const InputDecoration(
                          labelText: 'Advertencias',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: videoUrlController,
                        decoration: const InputDecoration(
                          labelText: 'Link de video de usos',
                          hintText: 'https://youtube.com/...',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.play_circle_outline),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (imageUrl.isNotEmpty)
                            ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.network(
                                imageUrl,
                                height: 160,
                                width: double.infinity,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Container(
                                  height: 160,
                                  color: Colors.teal.withValues(alpha: 0.10),
                                  child: const Center(
                                    child: Icon(Icons.image_not_supported),
                                  ),
                                ),
                              ),
                            ),
                          if (imageUrl.isNotEmpty) const SizedBox(height: 10),
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton.icon(
                              onPressed: uploadingImage
                                  ? null
                                  : () async {
                                      final picker = ImagePicker();

                                      final picked = await picker.pickImage(
                                        source: ImageSource.gallery,
                                        imageQuality: 85,
                                      );

                                      if (picked == null) return;

                                      setDialogState(() {
                                        uploadingImage = true;
                                      });

                                      final uploadResult =
                                          await _service.uploadMarketplaceImage(
                                        file: picked,
                                      );

                                      if (!mounted) return;

                                      setDialogState(() {
                                        uploadingImage = false;
                                      });

                                      if (uploadResult['statusCode'] == 200) {
                                        final uploadedUrl = uploadResult['data']
                                                    ?['image_url']
                                                ?.toString() ??
                                            '';

                                        imageController.text = uploadedUrl;

                                        setDialogState(() {
                                          imageUrl = uploadedUrl;
                                        });
                                      } else {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          SnackBar(
                                            content: Text(
                                              uploadResult['data']?['detail']
                                                      ?.toString() ??
                                                  'No se pudo subir la imagen',
                                            ),
                                          ),
                                        );
                                      }
                                    },
                              icon: uploadingImage
                                  ? const SizedBox(
                                      height: 18,
                                      width: 18,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                      ),
                                    )
                                  : const Icon(Icons.upload_file),
                              label: Text(
                                uploadingImage
                                    ? 'Subiendo imagen...'
                                    : 'Subir imagen JPG / PNG',
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      SwitchListTile(
                        value: active,
                        title: const Text('Mostrar en Marketplace'),
                        subtitle: Text(
                          active
                              ? 'Producto visible al público'
                              : 'Producto oculto',
                        ),
                        onChanged: (value) {
                          setDialogState(() {
                            active = value;
                          });
                        },
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Cancelar'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    final name = nameController.text.trim();

                    if (name.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('El nombre es obligatorio'),
                        ),
                      );
                      return;
                    }

                    final result = isEdit
                        ? await _service.updateProduct(
                            productId: product['id'],
                            name: name,
                            categoryId: selectedCategoryId,
                            price:
                                double.tryParse(priceController.text.trim()) ??
                                    0,
                            stock:
                                int.tryParse(stockController.text.trim()) ?? 0,
                            presentation: presentationController.text.trim(),
                            shortDescription:
                                shortDescriptionController.text.trim(),
                            description: descriptionController.text.trim(),
                            benefits: benefitsController.text.trim(),
                            ingredients: ingredientsController.text.trim(),
                            suggestedDose: suggestedDoseController.text.trim(),
                            usageInstructions: usageController.text.trim(),
                            warnings: warningsController.text.trim(),
                            imageUrl: imageController.text.trim(),
                            videoUrl: videoUrlController.text.trim(),
                            active: active,
                          )
                        : await _service.createProduct(
                            name: name,
                            categoryId: selectedCategoryId == 0
                                ? null
                                : selectedCategoryId,
                            price:
                                double.tryParse(priceController.text.trim()) ??
                                    0,
                            stock:
                                int.tryParse(stockController.text.trim()) ?? 0,
                            presentation: presentationController.text.trim(),
                            shortDescription:
                                shortDescriptionController.text.trim(),
                            description: descriptionController.text.trim(),
                            benefits: benefitsController.text.trim(),
                            ingredients: ingredientsController.text.trim(),
                            suggestedDose: suggestedDoseController.text.trim(),
                            usageInstructions: usageController.text.trim(),
                            warnings: warningsController.text.trim(),
                            imageUrl: imageController.text.trim(),
                            videoUrl: videoUrlController.text.trim(),
                            active: active,
                          );

                    if (!mounted) return;

                    Navigator.pop(dialogContext);

                    if (result['statusCode'] == 200 ||
                        result['statusCode'] == 201) {
                      await _loadData();
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            result['data']?['detail']?.toString() ??
                                'No se pudo guardar el producto',
                          ),
                        ),
                      );
                    }
                  },
                  child: const Text('Guardar'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _toggleProduct(Map<String, dynamic> product) async {
    final int id = int.tryParse((product['id'] ?? 0).toString()) ?? 0;
    final bool active = product['active'] == true;

    if (id == 0) return;

    final result = await _service.updateProduct(
      productId: id,
      active: !active,
    );

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      await _loadData();
    }
  }

  Future<void> _deleteProduct(Map<String, dynamic> product) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Eliminar producto'),
          content: Text('¿Seguro que deseas eliminar "${product['name']}"?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Eliminar'),
            ),
          ],
        );
      },
    );

    if (confirm != true) return;

    final result = await _service.deleteProduct(productId: product['id']);

    if (!mounted) return;

    if (result['statusCode'] == 200) {
      await _loadData();
    }
  }

  Widget _imagePlaceholder() {
    return Container(
      width: 72,
      height: 72,
      color: Colors.teal.withValues(alpha: 0.10),
      child: const Icon(Icons.local_pharmacy, color: Colors.teal),
    );
  }

  Widget _productCard(Map<String, dynamic> product) {
    final bool active = product['active'] == true;
    final imageUrl = (product['image_url'] ?? '').toString();
    final videoUrl = (product['video_url'] ?? '').toString();

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: imageUrl.isNotEmpty
                  ? Image.network(
                      imageUrl,
                      width: 72,
                      height: 72,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => _imagePlaceholder(),
                    )
                  : _imagePlaceholder(),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    product['name']?.toString() ?? 'Producto',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  Text(
                      'Categoría: ${product['category_name'] ?? 'Sin categoría'}'),
                  Text('Precio: \$${product['price'] ?? 0}'),
                  Text('Stock: ${product['stock'] ?? 0}'),
                  if ((product['presentation'] ?? '').toString().isNotEmpty)
                    Text('Presentación: ${product['presentation']}'),
                  if (videoUrl.isNotEmpty)
                    const Text(
                      'Video de usos: agregado',
                      style: TextStyle(color: Colors.blue),
                    ),
                  Text(
                    active ? 'Visible en Marketplace' : 'Oculto',
                    style: TextStyle(
                      color: active ? Colors.green : Colors.red,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            IconButton(
              icon: const Icon(Icons.edit),
              onPressed: () => _showProductDialog(product: product),
            ),
            IconButton(
              icon: Icon(
                active ? Icons.visibility_off : Icons.visibility,
                color: active ? Colors.red : Colors.green,
              ),
              onPressed: () => _toggleProduct(product),
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () => _deleteProduct(product),
            ),
          ],
        ),
      ),
    );
  }

  Widget _categoryCard(Map<String, dynamic> category) {
    final bool active = category['active'] == true;

    return Card(
      child: ListTile(
        leading: Icon(
          Icons.folder,
          color: active ? Colors.teal : Colors.grey,
        ),
        title: Text(category['name'] ?? 'Categoría'),
        subtitle: Text(active ? 'Activa' : 'Inactiva'),
        trailing: Wrap(
          children: [
            IconButton(
              icon: const Icon(Icons.edit),
              onPressed: () => _showCategoryDialog(category: category),
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () => _deleteCategory(category),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final products = _filteredProducts;

    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F1),
      appBar: AppBar(
        title: const Text('Dashboard Farmacia Mayu'),
        actions: [
          IconButton(onPressed: _loadData, icon: const Icon(Icons.refresh)),
          IconButton(onPressed: _logout, icon: const Icon(Icons.logout)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Text(
                    _error!,
                    style: const TextStyle(color: Colors.red),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadData,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      const Text(
                        'Farmacia Magistral Mayu',
                        style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Gestiona categorías, productos y pedidos del Marketplace Farmacia Magistral Mayu.',
                      ),
                      const SizedBox(height: 18),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () => _requestDashboardAccess(
                                title: 'Puntos Farmacia',
                                code: _codeFor('pharmacy_points'),
                                onApproved: _openPharmacyPoints,
                              ),
                              icon: const Icon(Icons.stars),
                              label: const Text('Puntos Farmacia'),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () => _requestDashboardAccess(
                                title: 'Doctor Prescriptor',
                                code: _codeFor('doctor_prescriber'),
                                onApproved: _openDoctorPrescriberSales,
                              ),
                              icon: const Icon(Icons.medical_services),
                              label: const Text('Doctor Prescriptor'),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 18),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () => _requestDashboardAccess(
                                title: 'Administrador Farmacia',
                                code: _codeFor('pharmacy_admin'),
                                onApproved: _openPharmacyAdmin,
                              ),
                              icon: const Icon(Icons.admin_panel_settings),
                              label: const Text('Administrador Farmacia'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.teal,
                                foregroundColor: Colors.white,
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () => _requestDashboardAccess(
                                title: 'Logística Farmacia',
                                code: _codeFor('pharmacy_logistics'),
                                onApproved: _openPharmacyLogistics,
                              ),
                              icon: const Icon(Icons.local_shipping),
                              label: const Text('Logística Farmacia'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.brown,
                                foregroundColor: Colors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 18),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () => _showCategoryDialog(),
                              icon: const Icon(Icons.create_new_folder),
                              label: const Text('Nueva categoría'),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () => _showProductDialog(),
                              icon: const Icon(Icons.add),
                              label: const Text('Nuevo producto'),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 22),
                      TextField(
                        decoration: const InputDecoration(
                          labelText: 'Buscar producto',
                          prefixIcon: Icon(Icons.search),
                          border: OutlineInputBorder(),
                        ),
                        onChanged: (value) {
                          setState(() {
                            _search = value;
                          });
                        },
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<int>(
                        initialValue: _categoryFilter,
                        decoration: const InputDecoration(
                          labelText: 'Filtrar por categoría',
                          border: OutlineInputBorder(),
                        ),
                        items: [
                          const DropdownMenuItem(
                              value: 0, child: Text('Todas')),
                          ..._categories.map((item) {
                            final category = Map<String, dynamic>.from(item);
                            return DropdownMenuItem<int>(
                              value: category['id'],
                              child: Text(category['name'] ?? 'Categoría'),
                            );
                          }),
                        ],
                        onChanged: (value) {
                          if (value == null) return;
                          setState(() {
                            _categoryFilter = value;
                          });
                        },
                      ),
                      const SizedBox(height: 22),
                      const Text(
                        'Categorías Marketplace',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 10),
                      if (_categories.isEmpty)
                        const Text('No hay categorías registradas')
                      else
                        ..._categories.map(
                          (item) => _categoryCard(
                            Map<String, dynamic>.from(item),
                          ),
                        ),
                      const SizedBox(height: 22),
                      const Text(
                        'Productos Marketplace',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 10),
                      if (products.isEmpty)
                        const Padding(
                          padding: EdgeInsets.all(30),
                          child: Center(
                            child: Text('No hay productos registrados'),
                          ),
                        )
                      else
                        ...products.map(
                          (item) => _productCard(
                            Map<String, dynamic>.from(item),
                          ),
                        ),
                      const SizedBox(height: 80),
                    ],
                  ),
                ),
    );
  }
}
