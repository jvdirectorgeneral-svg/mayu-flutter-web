import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/pharmacy_loyalty_service.dart';

class PharmacyCustomerRecoverScreen extends StatefulWidget {
  const PharmacyCustomerRecoverScreen({super.key});

  @override
  State<PharmacyCustomerRecoverScreen> createState() =>
      _PharmacyCustomerRecoverScreenState();
}

class _PharmacyCustomerRecoverScreenState
    extends State<PharmacyCustomerRecoverScreen> {
  final PharmacyLoyaltyService _service = PharmacyLoyaltyService();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  bool _loading = false;
  Map<String, dynamic>? _card;

  @override
  void dispose() {
    _emailController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _recover() async {
    final email = _emailController.text.trim();
    final phone = _phoneController.text.trim();
    if (email.isEmpty || phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Ingresa correo y teléfono')),
      );
      return;
    }

    setState(() => _loading = true);
    final result = await _service.recoverCard(email: email, phone: phone);
    if (!mounted) return;
    setState(() => _loading = false);

    if (result['statusCode'] == 200) {
      final data = Map<String, dynamic>.from(result['data']);
      setState(() {
        _card = Map<String, dynamic>.from(data['card'] as Map);
      });
      final sent = data['email_sent'] == true;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            sent
                ? 'Listo. También enviamos los enlaces a tu correo.'
                : 'Tarjeta encontrada. Puedes descargarla desde aquí.',
          ),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['data']?['detail']?.toString() ??
                'No pudimos recuperar la tarjeta',
          ),
        ),
      );
    }
  }

  Future<void> _open(String? url) async {
    final cleanUrl = url?.trim();
    if (cleanUrl == null || cleanUrl.isEmpty) return;
    await launchUrl(Uri.parse(cleanUrl), mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    final card = _card;
    return Scaffold(
      appBar: AppBar(title: const Text('Recuperar tarjeta')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text(
            'Ingresa el correo y teléfono usados al activar tu Tarjeta Mayu Magistral.',
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 18),
          TextField(
            controller: _emailController,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(
              labelText: 'Correo',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _phoneController,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
              labelText: 'Teléfono',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 18),
          ElevatedButton.icon(
            onPressed: _loading ? null : _recover,
            icon: const Icon(Icons.restore),
            label: Text(_loading ? 'Buscando...' : 'Recuperar tarjeta'),
          ),
          if (card != null) ...[
            const SizedBox(height: 22),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      card['customer_name']?.toString() ?? '',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(card['card_code']?.toString() ?? ''),
                    const SizedBox(height: 12),
                    Text('${card['points_balance'] ?? 0} puntos'),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () =>
                            _open(card['apple_wallet_url']?.toString()),
                        icon: const Icon(Icons.wallet),
                        label: const Text('Descargar Wallet iOS'),
                      ),
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: () =>
                            _open(card['google_wallet_url']?.toString()),
                        icon: const Icon(Icons.account_balance_wallet),
                        label: const Text('Descargar Wallet Android'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
