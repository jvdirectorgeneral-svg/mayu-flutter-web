import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import 'firebase_options.dart';
import 'core/url_strategy_config.dart';
import 'screens/login_screen.dart';
import 'screens/paypal_success_screen.dart';
import 'screens/membership_paypal_success_screen.dart';
import 'screens/marketplace_screen.dart';
import 'theme/app_theme.dart';

Future<void> _firebaseMessagingBackgroundHandler(
  RemoteMessage message,
) async {
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  configureUrlStrategy();

  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );

    FirebaseMessaging.onBackgroundMessage(
      _firebaseMessagingBackgroundHandler,
    );

    await FirebaseMessaging.instance.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );
  } catch (e) {
    debugPrint('Firebase init error: $e');
  }

  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    final notification = message.notification;
    final title = notification?.title ?? message.data['title'] ?? 'Mayu';
    final body = notification?.body ?? message.data['message'] ?? '';

    mayuMessengerKey.currentState?.showSnackBar(
      SnackBar(
        content: Text(body.isEmpty ? title : '$title\n$body'),
        duration: const Duration(seconds: 6),
      ),
    );
  });

  runApp(const MayuApp());
}

final GlobalKey<ScaffoldMessengerState> mayuMessengerKey =
    GlobalKey<ScaffoldMessengerState>();

class MayuApp extends StatelessWidget {
  const MayuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mayu Wellness',
      debugShowCheckedModeBanner: false,
      scaffoldMessengerKey: mayuMessengerKey,
      theme: AppTheme.lightTheme,
      onGenerateRoute: (settings) {
        final name = settings.name ?? '';
        final uri = Uri.tryParse(name);

        if (uri != null) {
          final publicPath = uri.path.toLowerCase().replaceAll(RegExp(r'/+$'), '');
          if (publicPath == '/marketplacefarmaciamayu' ||
              publicPath == '/marketplace-farmacia-mayu') {
            return MaterialPageRoute(
              builder: (_) => const MarketplaceScreen(),
            );
          }
        }

        if (uri != null && uri.path == '/membership/paypal-success') {
          return MaterialPageRoute(
            builder: (_) => MembershipPaypalSuccessScreen(
              userId: int.tryParse(uri.queryParameters['user_id'] ?? ''),
              subscriptionId: uri.queryParameters['subscription_id'] ??
                  uri.queryParameters['paypal_order_id'],
              paymentStatus: uri.queryParameters['payment'],
              planLevel: int.tryParse(uri.queryParameters['plan_level'] ?? ''),
            ),
          );
        }

        if (uri != null &&
            (uri.path == '/paypal-success' ||
                uri.path == '/marketplace/paypal-success')) {
          return MaterialPageRoute(
            builder: (_) => PayPalSuccessScreen(
              paypalOrderId: uri.queryParameters['paypal_order_id'],
              paymentId: uri.queryParameters['payment_id'],
              paymentStatus: uri.queryParameters['payment'],
            ),
          );
        }

        return null;
      },
      home: const LoginScreen(),
    );
  }
}
