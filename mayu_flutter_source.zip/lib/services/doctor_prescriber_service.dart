import 'dart:convert';
import 'dart:async';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

import '../core/api_config.dart';
import 'auth_service.dart';

class DoctorPrescriberService {
  static const String _tokenKey = 'doctor_prescriber_access_token';
  static const String _doctorKey = 'doctor_prescriber';

  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  final AuthService _mayuAuth = AuthService();

  Future<bool> hasDoctorSession() async {
    final token = await _storage.read(key: _tokenKey);
    return token != null && token.isNotEmpty;
  }

  Future<void> logoutDoctor() async {
    await _storage.delete(key: _tokenKey);
    await _storage.delete(key: _doctorKey);
  }

  Future<Map<String, dynamic>> register({
    required String name,
    required String email,
    required String phone,
    required String birthDate,
    required String city,
    required String bankName,
    required String bankAccountType,
    required String bankAccountNumber,
    required String bankAccountNumberConfirm,
    required bool acceptedPolicies,
  }) async {
    final hiddenPassword =
        'doctor-${email.trim().toLowerCase()}-${phone.trim()}-${DateTime.now().millisecondsSinceEpoch}';

    final response = await _safeRequest(
      () => http.post(
        Uri.parse('${ApiConfig.baseUrl}/doctor-prescribers/register'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'name': name.trim(),
          'email': email.trim(),
          'phone': phone.trim(),
          'password': hiddenPassword,
          'birth_date': birthDate.trim(),
          'city': city.trim(),
          'bank_name': bankName.trim(),
          'bank_account_type': bankAccountType.trim(),
          'bank_account_number': bankAccountNumber.trim(),
          'bank_account_number_confirm': bankAccountNumberConfirm.trim(),
          'accepted_terms': acceptedPolicies,
          'accepted_privacy_policy': acceptedPolicies,
          'accepted_digital_policy': acceptedPolicies,
        }),
      ),
    );

    if (response['statusCode'] == 200) {
      await _saveDoctorSession(response['data']);
    }
    return response;
  }

  Future<Map<String, dynamic>> recoverCard({
    required String email,
    required String phone,
  }) async {
    final response = await _safeRequest(
      () => http.post(
        Uri.parse('${ApiConfig.baseUrl}/doctor-prescribers/recover-card'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'email': email.trim(),
          'phone': phone.trim(),
        }),
      ),
    );

    if (response['statusCode'] == 200) {
      await _saveDoctorSession(response['data']);
    }
    return response;
  }

  Future<Map<String, dynamic>> getMyDoctorCard() async {
    final headers = await _getDoctorHeaders();
    return _safeRequest(
      () => http.get(
        Uri.parse('${ApiConfig.baseUrl}/doctor-prescribers/me'),
        headers: headers,
      ),
    );
  }

  Future<Map<String, dynamic>> resolveDoctor(String identifier) async {
    final headers = await _getMayuAdminHeaders();
    return _safeRequest(
      () => http.get(
        Uri.parse(
          '${ApiConfig.baseUrl}/doctor-prescribers/resolve/${Uri.encodeComponent(identifier)}',
        ),
        headers: headers,
      ),
    );
  }

  Future<Map<String, dynamic>> creditDoctorSale({
    required String identifier,
    required double amount,
    required String reference,
    double deductionPercent = 0,
    String? note,
  }) async {
    final headers = await _getMayuAdminHeaders();
    return _safeRequest(
      () => http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/doctor-prescribers/admin/credit/${Uri.encodeComponent(identifier)}',
        ),
        headers: headers,
        body: jsonEncode({
          'amount': amount,
          'reference': reference.trim(),
          'deduction_percent': deductionPercent,
          'note': _optional(note),
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> payDoctorBalance({
    required String identifier,
    String? note,
  }) async {
    final headers = await _getMayuAdminHeaders();
    return _safeRequest(
      () => http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/doctor-prescribers/admin/pay/${Uri.encodeComponent(identifier)}',
        ),
        headers: headers,
        body: jsonEncode({
          'note': _optional(note),
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> listDoctors() async {
    final headers = await _getMayuAdminHeaders();
    return _safeRequest(
      () => http.get(
        Uri.parse('${ApiConfig.baseUrl}/doctor-prescribers/admin/doctors'),
        headers: headers,
      ),
    );
  }

  Future<void> _saveDoctorSession(Map<String, dynamic> data) async {
    final token = data['access_token']?.toString();
    if (token != null && token.isNotEmpty) {
      await _storage.write(key: _tokenKey, value: token);
    }

    final doctor = data['doctor'];
    if (doctor is Map) {
      await _storage.write(
        key: _doctorKey,
        value: jsonEncode(Map<String, dynamic>.from(doctor)),
      );
    }
  }

  Future<Map<String, String>> _getDoctorHeaders() async {
    final token = await _storage.read(key: _tokenKey);
    return {
      'Content-Type': 'application/json',
      if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
    };
  }

  Future<Map<String, String>> _getMayuAdminHeaders() async {
    final headers = await _mayuAuth.getAuthHeaders();
    return {...headers, 'Content-Type': 'application/json'};
  }

  Future<Map<String, dynamic>> _safeRequest(
    Future<http.Response> Function() callback,
  ) async {
    try {
      final response = await callback().timeout(const Duration(seconds: 20));
      final data = _decodeBody(response.body);
      return {'statusCode': response.statusCode, 'data': data};
    } on TimeoutException {
      return {
        'statusCode': 504,
        'data': {
          'detail':
              'El servidor tardó demasiado en responder. Revisa Render o intenta nuevamente en unos segundos.',
        },
      };
    } catch (error) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $error'},
      };
    }
  }

  Map<String, dynamic> _decodeBody(String body) {
    if (body.isEmpty) return {};
    final decoded = jsonDecode(body);
    if (decoded is Map) {
      return Map<String, dynamic>.from(decoded);
    }
    if (decoded is List) {
      return {'items': decoded};
    }
    return {'detail': decoded.toString()};
  }

  String? _optional(String? value) {
    final cleaned = value?.trim();
    return cleaned == null || cleaned.isEmpty ? null : cleaned;
  }
}
