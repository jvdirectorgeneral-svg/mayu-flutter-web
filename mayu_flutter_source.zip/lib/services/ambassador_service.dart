import 'dart:convert';
import 'package:http/http.dart' as http;

import '../core/api_config.dart';
import 'auth_service.dart';

class AmbassadorService {
  static String get baseUrl => ApiConfig.baseUrl;
  static final AuthService _authService = AuthService();

  static Map<String, dynamic> _safeDecode(http.Response response) {
    try {
      final decoded = response.body.isNotEmpty ? jsonDecode(response.body) : {};

      if (decoded is Map<String, dynamic>) return decoded;
      if (decoded is List) return {'items': decoded};

      return {'data': decoded};
    } catch (_) {
      return {
        'detail': response.body.isNotEmpty
            ? response.body
            : 'Respuesta inválida del servidor',
      };
    }
  }

  static Future<Map<String, String>> _headers({bool auth = false}) async {
    if (!auth) {
      return {'Content-Type': 'application/json'};
    }

    final authHeaders = await _authService.getAuthHeaders();

    return {
      ...authHeaders,
      'Content-Type': 'application/json',
    };
  }

  static Future<Map<String, dynamic>> _handleResponse(
    http.Response response,
  ) async {
    return {
      'statusCode': response.statusCode,
      'data': _safeDecode(response),
    };
  }

  static Map<String, dynamic> _cleanBody(Map<String, dynamic> body) {
    final clean = Map<String, dynamic>.from(body);

    clean.removeWhere((key, value) {
      if (value == null) return true;
      if (value is String && value.trim().isEmpty) return true;
      return false;
    });

    return clean;
  }

  static Future<Map<String, dynamic>> _get(
    String path, {
    bool auth = true,
  }) async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl$path'),
            headers: await _headers(auth: auth),
          )
          .timeout(const Duration(seconds: 25));

      return _handleResponse(response);
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $e'},
      };
    }
  }

  static Future<Map<String, dynamic>> _post(
    String path, {
    required Map<String, dynamic> body,
    bool auth = false,
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl$path'),
            headers: await _headers(auth: auth),
            body: jsonEncode(_cleanBody(body)),
          )
          .timeout(const Duration(seconds: 25));

      return _handleResponse(response);
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $e'},
      };
    }
  }

  static List<dynamic> _safeItems(dynamic data) {
    if (data is Map && data['items'] is List) {
      return List<dynamic>.from(data['items']);
    }

    return [];
  }

  static Map<String, dynamic> _safeMap(dynamic data) {
    if (data is Map<String, dynamic>) return data;
    if (data is Map) return Map<String, dynamic>.from(data);
    return {};
  }

  // =========================
  // REGISTRO Y LOGIN
  // =========================

  static Future<Map<String, dynamic>> registerAmbassador({
    required String name,
    required String email,
    required String phone,
    required String birthDate,
    required String password,
    required String nationalId,
    required String address,
    required String bankName,
    required String accountType,
    required String bankAccountNumber,
    String? bankAccountHolder,
    String? bankIdentification,
    String? paymentNotes,
  }) async {
    return _post(
      '/ambassadors/register',
      auth: false,
      body: {
        'name': name.trim(),
        'email': email.trim().toLowerCase(),
        'phone': phone.trim(),
        'birth_date': birthDate.trim(),
        'password': password,
        'national_id': nationalId.trim(),
        'address': address.trim(),
        'bank_name': bankName.trim(),
        'account_type': accountType.trim(),
        'bank_account_type': accountType.trim(),
        'bank_account_number': bankAccountNumber.trim(),
        'bank_account_holder': bankAccountHolder?.trim(),
        'bank_identification': bankIdentification?.trim(),
        'payment_notes': paymentNotes?.trim(),
      },
    );
  }

  static Future<Map<String, dynamic>> loginAmbassador({
    required String email,
    required String password,
  }) async {
    final result = await _post(
      '/ambassadors/login',
      auth: false,
      body: {
        'email': email.trim().toLowerCase(),
        'password': password,
      },
    );

    if (result['statusCode'] == 200) {
      final data = _safeMap(result['data']);
      final token = data['access_token'];
      final user = data['user'];

      if (token != null && token.toString().trim().isNotEmpty) {
        await _authService.saveToken(token.toString());
      }

      if (user is Map) {
        await _authService.saveUser(Map<String, dynamic>.from(user));
      }
    }

    return result;
  }

  // =========================
  // PERFIL / TARJETA / DASHBOARD
  // =========================

  static Future<Map<String, dynamic>> getProfile(int ambassadorId) async {
    return _get('/ambassadors/$ambassadorId', auth: true);
  }

  static Future<Map<String, dynamic>> getCard(int ambassadorId) async {
    return _get('/ambassadors/$ambassadorId/card', auth: true);
  }

  static Future<Map<String, dynamic>> getDashboard(int ambassadorId) async {
    return _get('/ambassadors/$ambassadorId/dashboard', auth: true);
  }

  static Future<Map<String, dynamic>> getAffiliateDeliveryHistory({
    required int ambassadorId,
    required int userId,
  }) async {
    return _get(
      '/ambassadors/$ambassadorId/affiliates/$userId/history',
      auth: true,
    );
  }

  // =========================
  // COMISIONES DEL EMBAJADOR
  // =========================

  static Future<Map<String, dynamic>> getCommissions(int ambassadorId) async {
    return _get('/commissions/ambassador/$ambassadorId', auth: true);
  }

  static Future<Map<String, dynamic>> getCommissionSummary(
    int ambassadorId,
  ) async {
    return _get('/commissions/ambassador/$ambassadorId/summary', auth: true);
  }

  static Future<Map<String, dynamic>> getPendingCommissions(
    int ambassadorId,
  ) async {
    final result = await getCommissions(ambassadorId);

    if (result['statusCode'] != 200) return result;

    final data = _safeMap(result['data']);
    final items = _safeItems(data);

    final pending = items.where((item) {
      final map = _safeMap(item);
      return map['status'] == 'pending';
    }).toList();

    return {
      'statusCode': 200,
      'data': {
        ...data,
        'total_items': pending.length,
        'items': pending,
      },
    };
  }

  static Future<Map<String, dynamic>> getPaidCommissions(
    int ambassadorId,
  ) async {
    final result = await getCommissions(ambassadorId);

    if (result['statusCode'] != 200) return result;

    final data = _safeMap(result['data']);
    final items = _safeItems(data);

    final paid = items.where((item) {
      final map = _safeMap(item);
      return map['status'] == 'paid';
    }).toList();

    return {
      'statusCode': 200,
      'data': {
        ...data,
        'total_items': paid.length,
        'items': paid,
      },
    };
  }
}
