import 'dart:convert';
import 'package:http/http.dart' as http;

import '../core/api_config.dart';

class PayphoneService {
  Map<String, dynamic> _safeDecode(http.Response response) {
    try {
      final decoded = response.body.isNotEmpty ? jsonDecode(response.body) : null;

      if (decoded is Map<String, dynamic>) {
        return decoded;
      }

      return {'data': decoded};
    } catch (_) {
      return {'detail': response.body};
    }
  }

  Future<Map<String, dynamic>> createInitialMembershipPayment({
    required int userId,
    required int planLevel,
    required bool acceptedRecurringDebit,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/payphone/membership/create-initial-payment',
    );

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'user_id': userId,
          'plan_level': planLevel,
          'accepted_recurring_debit': acceptedRecurringDebit,
        }),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error creando pago PayPhone: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> confirmInitialMembershipPayment({
    required String clientTransactionId,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/payphone/membership/confirm-initial-payment',
    );

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'clientTransactionId': clientTransactionId,
        }),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error confirmando pago PayPhone: $e'},
      };
    }
  }
}