import 'dart:convert';
import 'package:http/http.dart' as http;

import '../core/api_config.dart';
import 'auth_service.dart';

class PaymentService {
  final AuthService _authService = AuthService();

  Future<Map<String, String>> _headers() async {
    final authHeaders = await _authService.getAuthHeaders();

    return {
      ...authHeaders,
      'Content-Type': 'application/json',
    };
  }

  Map<String, dynamic> _handleResponse(http.Response response) {
    dynamic data;

    try {
      data = response.body.isNotEmpty ? jsonDecode(response.body) : null;
    } catch (_) {
      data = {
        'detail': response.body.isNotEmpty
            ? response.body
            : 'Respuesta inválida del servidor',
      };
    }

    return {
      'statusCode': response.statusCode,
      'data': data,
    };
  }

  Future<Map<String, dynamic>> createPayPalOrder({
    required int userId,
    required int planLevel,
    double? amount,
    String currency = 'USD',
  }) async {
    final Map<String, dynamic> body = {
      'user_id': userId,
      'plan_level': planLevel,
      'currency': currency,
    };

    if (amount != null) {
      body['amount'] = amount;
    }

    try {
      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/payments/paypal/create-order'),
        headers: await _headers(),
        body: jsonEncode(body),
      );

      return _handleResponse(response);
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {
          'detail': 'Error creando orden PayPal: $e',
        },
      };
    }
  }

  Future<Map<String, dynamic>> capturePayPalOrder({
    required String paypalOrderId,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/payments/paypal/capture-order'),
        headers: await _headers(),
        body: jsonEncode({
          'paypal_order_id': paypalOrderId,
        }),
      );

      return _handleResponse(response);
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {
          'detail': 'Error capturando orden PayPal: $e',
        },
      };
    }
  }

  Future<Map<String, dynamic>> getPayPalOrderStatus({
    required String paypalOrderId,
  }) async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.baseUrl}/payments/paypal/order/$paypalOrderId'),
        headers: await _headers(),
      );

      return _handleResponse(response);
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {
          'detail': 'Error consultando estado PayPal: $e',
        },
      };
    }
  }
}