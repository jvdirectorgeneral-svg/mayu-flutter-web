Future<Map<String, dynamic>> tokenizeNuveiCard(
  Map<String, dynamic> configuration,
) {
  throw UnsupportedError(
    'El registro Nuvei está disponible actualmente en Mayu Wellness Web.',
  );
}

Future<Map<String, dynamic>> completeNuvei3DS(
  Map<String, dynamic> action,
) {
  throw UnsupportedError(
    'La verificación Nuvei 3DS está disponible actualmente en Mayu Wellness Web.',
  );
}
