Future<Map<String, dynamic>> tokenizeNuveiCard(
  Map<String, dynamic> configuration,
) {
  throw UnsupportedError(
    'El registro Nuvei está disponible actualmente en Mayu Wellness Web.',
  );
}
