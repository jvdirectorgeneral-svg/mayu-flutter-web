import 'dart:convert';
import 'package:http/http.dart' as http;
import '../core/api_config.dart';

class PlanService {
  Future<List<dynamic>> getPlans() async {
    final url = Uri.parse('${ApiConfig.baseUrl}/plans/');

    final response = await http.get(
      url,
      headers: {
        'Content-Type': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }

    throw Exception('Error al cargar planes');
  }

  Future<Map<String, dynamic>> getPlanOptions(int planId) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/plan-selection/plans/$planId/options');

    final response = await http.get(
      url,
      headers: {
        'Content-Type': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }

    throw Exception('Error al cargar opciones del plan');
  }
}