import 'dart:convert';
import 'package:http/http.dart' as http;

class PlanChangeService {
  final String baseUrl = "https://mayu-wellness-backend-v1.onrender.com";

  Future<Map<String, dynamic>> requestPlanChange({
    required int userId,
    required int requestedPlanId,
  }) async {
    final response = await http.post(
      Uri.parse(
        '$baseUrl/plan-change/request?user_id=$userId&requested_plan_id=$requestedPlanId',
      ),
    );

    return jsonDecode(response.body);
  }

  Future<List<dynamic>> getPlanChangeRequests(int userId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/plan-change/user/$userId'),
    );

    return jsonDecode(response.body);
  }
}