import 'dart:convert';
import 'package:http/http.dart' as http;
import '../core/api_config.dart';

class MemberCardService {
  final String baseUrl = ApiConfig.baseUrl;

  Future<Map<String, dynamic>> generateMemberCard(int userId) async {
    return _post('/member-cards/generate/$userId');
  }

  Future<Map<String, dynamic>> regenerateCard(int userId) async {
    return generateMemberCard(userId);
  }

  Future<Map<String, dynamic>> getMemberCardByUser(int userId) async {
    return _get('/member-cards/user/$userId');
  }

  Future<Map<String, dynamic>> getGoogleWalletPass(int userId) async {
    return _get('/member-cards/google-wallet/$userId');
  }

  Future<Map<String, dynamic>> getAppleWalletPass(int userId) async {
    return _get('/member-cards/apple-wallet/$userId');
  }

  String getCardImageUrl(int userId) {
    return '$baseUrl/member-cards/user/$userId/image';
  }

  String getCardWebUrl(int userId) {
    return '$baseUrl/member-cards/user/$userId/web';
  }

  String getAppleWalletUrl(int userId) {
    return '$baseUrl/member-cards/apple-wallet/$userId';
  }

  String getGoogleWalletUrl(int userId) {
    return '$baseUrl/member-cards/google-wallet/$userId';
  }

  String getValidateCardUrl(String qrToken) {
    return '$baseUrl/member-cards/validate/$qrToken';
  }

  Future<bool> validateCardQr(String qrToken) async {
    try {
      final response = await http.get(Uri.parse(getValidateCardUrl(qrToken)));
      return response.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  String buildSocioWhatsAppMessage({
    required String name,
    required int userId,
  }) {
    final cardUrl = getCardWebUrl(userId);

    return '''
Hola 👋

Te compartimos tu tarjeta digital Mayu Wellness Club.

Socio: $name

Tarjeta:
$cardUrl

Mayu Wellness Club
''';
  }

  String buildRecoverCardMessage({
    required String name,
    required int userId,
  }) {
    final cardUrl = getCardWebUrl(userId);

    return '''
Hola 👋

Solicito recuperación de tarjeta Mayu Wellness Club.

Usuario: $name
ID: $userId

Tarjeta:
$cardUrl

Gracias.
''';
  }

  Future<Map<String, dynamic>> _get(String path) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl$path'),
        headers: {'Content-Type': 'application/json'},
      );

      return _response(response);
    } catch (e) {
      return _connectionError(e);
    }
  }

  Future<Map<String, dynamic>> _post(String path) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl$path'),
        headers: {'Content-Type': 'application/json'},
      );

      return _response(response);
    } catch (e) {
      return _connectionError(e);
    }
  }

  Map<String, dynamic> _connectionError(Object e) {
    return {
      'statusCode': 500,
      'data': {'detail': 'Error de conexión: $e'},
    };
  }

  Map<String, dynamic> _response(http.Response response) {
    try {
      final dynamic decoded =
          response.body.isNotEmpty ? jsonDecode(response.body) : {};

      return {
        'statusCode': response.statusCode,
        'data': decoded,
      };
    } catch (_) {
      return {
        'statusCode': response.statusCode,
        'data': {
          'detail': response.body.isNotEmpty
              ? response.body
              : 'Respuesta inválida del servidor',
        },
      };
    }
  }
}