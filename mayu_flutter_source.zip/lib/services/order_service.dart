import 'dart:convert';
import 'package:http/http.dart' as http;

import '../core/api_config.dart';
import 'auth_service.dart';

class OrderService {
  final AuthService _authService = AuthService();

  Future<Map<String, String>> _headers() async {
    final headers = await _authService.getAuthHeaders();

    return {
      ...headers,
      'Content-Type': 'application/json',
    };
  }

  Map<String, dynamic> _safeDecode(http.Response response) {
    try {
      final decoded = response.body.isNotEmpty ? jsonDecode(response.body) : {};

      if (decoded is Map<String, dynamic>) return decoded;

      return {'items': decoded};
    } catch (_) {
      return {
        'detail': response.body.isNotEmpty
            ? response.body
            : 'Respuesta inválida del servidor',
      };
    }
  }

  Future<Map<String, dynamic>> getOrders({
    String? status,
    String? city,
    int? month,
    int? year,
    String? search,
  }) async {
    final queryParams = <String, String>{};

    if (status != null && status.trim().isNotEmpty) {
      queryParams['status'] = status.trim();
    }

    if (city != null && city.trim().isNotEmpty) {
      queryParams['city'] = city.trim();
    }

    if (month != null) {
      queryParams['month'] = month.toString();
    }

    if (year != null) {
      queryParams['year'] = year.toString();
    }

    if (search != null && search.trim().isNotEmpty) {
      queryParams['search'] = search.trim();
    }

    final url = Uri.parse('${ApiConfig.baseUrl}/orders').replace(
      queryParameters: queryParams.isEmpty ? null : queryParams,
    );

    try {
      final response = await http.get(
        url,
        headers: await _headers(),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> updateOrderStatus({
    required int orderId,
    required String status,
    String? logisticsNotes,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/orders/$orderId/status');

    final body = <String, dynamic>{
      'status': status,
    };

    if (logisticsNotes != null && logisticsNotes.trim().isNotEmpty) {
      body['logistics_notes'] = logisticsNotes.trim();
    }

    try {
      final response = await http.put(
        url,
        headers: await _headers(),
        body: jsonEncode(body),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> updateOrderTracking({
    required int orderId,
    String? carrier,
    String? trackingNumber,
    String? trackingUrl,
    String? shippingNotes,
    String? note,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/orders/$orderId/tracking');

    final body = <String, dynamic>{
      'carrier': carrier?.trim(),
      'tracking_number': trackingNumber?.trim(),
      'tracking_url': trackingUrl?.trim(),
      'shipping_notes': shippingNotes?.trim(),
      'note': note?.trim(),
    };

    body.removeWhere((key, value) => value == null || value == '');

    try {
      final response = await http.put(
        url,
        headers: await _headers(),
        body: jsonEncode(body),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> approveOrder({
    required int orderId,
    String? approvalNotes,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/orders/$orderId/approve');

    try {
      final response = await http.put(
        url,
        headers: await _headers(),
        body: jsonEncode({
          'approval_notes':
              approvalNotes ?? 'Pagos OK - orden liberada a logística',
        }),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> createManualOrder({
    required int userId,
    required int month,
    required int year,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/orders/create-manual');

    try {
      final response = await http.post(
        url,
        headers: await _headers(),
        body: jsonEncode({
          'user_id': userId,
          'month': month,
          'year': year,
        }),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> getUserOrders({
    required int userId,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/orders/user/$userId');

    try {
      final response = await http.get(
        url,
        headers: await _headers(),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> getOrderDetail({
    required int orderId,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/orders/$orderId');

    try {
      final response = await http.get(
        url,
        headers: await _headers(),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $e'},
      };
    }
  }
}