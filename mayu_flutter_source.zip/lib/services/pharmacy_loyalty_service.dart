import 'dart:convert';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

import '../core/api_config.dart';
import 'auth_service.dart';

class PharmacyLoyaltyService {
  static const String _tokenKey = 'pharmacy_customer_access_token';
  static const String _customerKey = 'pharmacy_customer';

  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  final AuthService _mayuAuth = AuthService();

  Future<bool> hasPharmacySession() async {
    final token = await _storage.read(key: _tokenKey);
    return token != null && token.isNotEmpty;
  }

  Future<void> logoutPharmacyCustomer() async {
    await _storage.delete(key: _tokenKey);
    await _storage.delete(key: _customerKey);
  }

  Future<Map<String, dynamic>> login({
    required String email,
    required String password,
  }) async {
    final response = await _safeRequest(
      () => http.post(
        Uri.parse('${ApiConfig.baseUrl}/pharmacy-loyalty/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email.trim(), 'password': password}),
      ),
    );

    if (response['statusCode'] == 200) {
      await _savePharmacySession(response['data']);
      await savePharmacyPushToken();
    }

    return response;
  }

  Future<Map<String, dynamic>> register({
    required String name,
    required String email,
    required String phone,
    required String birthDate,
    String? city,
    required bool acceptedPolicies,
  }) async {
    final hiddenPassword =
        'farmacia-${email.trim().toLowerCase()}-${phone.trim()}-${DateTime.now().millisecondsSinceEpoch}';

    final response = await _safeRequest(
      () => http.post(
        Uri.parse('${ApiConfig.baseUrl}/pharmacy-loyalty/register'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'name': name.trim(),
          'email': email.trim(),
          'phone': phone.trim(),
          'password': hiddenPassword,
          'birth_date': birthDate.trim(),
          'city': _optional(city),
          'reference': _optional('Fecha nacimiento: ${birthDate.trim()}'),
          'accepted_terms': acceptedPolicies,
          'accepted_privacy_policy': acceptedPolicies,
          'accepted_digital_policy': acceptedPolicies,
        }),
      ),
    );

    if (response['statusCode'] == 200) {
      await _savePharmacySession(response['data']);
      await savePharmacyPushToken();
    }

    return response;
  }

  Future<Map<String, dynamic>> recoverCard({
    required String email,
    required String phone,
  }) async {
    return _safeRequest(
      () => http.post(
        Uri.parse('${ApiConfig.baseUrl}/pharmacy-loyalty/recover-card'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email.trim(), 'phone': phone.trim()}),
      ),
    );
  }

  Future<Map<String, dynamic>> getMyCard() async {
    final headers = await _getPharmacyHeaders();
    return _safeRequest(
      () => http.get(
        Uri.parse('${ApiConfig.baseUrl}/pharmacy-loyalty/me'),
        headers: headers,
      ),
    );
  }

  Future<Map<String, dynamic>> resolveCard(String identifier) async {
    final headers = await _getMayuAdminHeaders();
    return _safeRequest(
      () => http.get(
        Uri.parse(
          '${ApiConfig.baseUrl}/pharmacy-loyalty/resolve/${Uri.encodeComponent(identifier)}',
        ),
        headers: headers,
      ),
    );
  }

  Future<Map<String, dynamic>> creditPurchase({
    required String identifier,
    required double amount,
    required String reference,
    String? note,
  }) async {
    final headers = await _getMayuAdminHeaders();
    return _safeRequest(
      () => http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/pharmacy-loyalty/admin/credit/${Uri.encodeComponent(identifier)}',
        ),
        headers: headers,
        body: jsonEncode({
          'amount': amount,
          'reference': reference.trim(),
          'note': _optional(note),
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> listPharmacyCustomers() async {
    final headers = await _getMayuAdminHeaders();
    return _safeRequest(
      () => http.get(
        Uri.parse('${ApiConfig.baseUrl}/pharmacy-loyalty/admin/customers'),
        headers: headers,
      ),
    );
  }

  Future<Map<String, dynamic>> sendTestPush(String identifier) async {
    final headers = await _getMayuAdminHeaders();
    return _safeRequest(
      () => http.post(
        Uri.parse(
          '${ApiConfig.baseUrl}/pharmacy-loyalty/admin/test-push/${Uri.encodeComponent(identifier)}',
        ),
        headers: headers,
      ),
    );
  }

  Future<Map<String, dynamic>> savePharmacyPushToken() async {
    try {
      final token = await _storage.read(key: _tokenKey);
      if (token == null || token.isEmpty) {
        return {
          'statusCode': 401,
          'data': {'detail': 'Tarjeta farmacia sin sesión activa'},
        };
      }

      final messaging = FirebaseMessaging.instance;
      final settings = await messaging.requestPermission(
        alert: true,
        badge: true,
        sound: true,
      );

      if (settings.authorizationStatus == AuthorizationStatus.denied) {
        return {
          'statusCode': 403,
          'data': {'detail': 'Permiso de notificaciones denegado'},
        };
      }

      if (!kIsWeb && defaultTargetPlatform == TargetPlatform.iOS) {
        for (int i = 0; i < 15; i++) {
          final apnsToken = await messaging.getAPNSToken();
          if (apnsToken != null && apnsToken.isNotEmpty) break;
          await Future.delayed(const Duration(seconds: 2));
        }
      }

      final fcmToken = await messaging.getToken();
      if (fcmToken == null || fcmToken.isEmpty) {
        return {
          'statusCode': 400,
          'data': {'detail': 'Token push vacío'},
        };
      }

      final platform = kIsWeb ? 'web' : defaultTargetPlatform.name;
      final result = await _safeRequest(
        () => http.post(
          Uri.parse('${ApiConfig.baseUrl}/pharmacy-loyalty/push-token'),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer $token',
          },
          body: jsonEncode({'token': fcmToken, 'platform': platform}),
        ),
      );
      debugPrint('PUSH FARMACIA GUARDADO: ${jsonEncode(result['data'])}');
      return result;
    } catch (error) {
      debugPrint('PUSH FARMACIA ERROR: $error');
      return {
        'statusCode': 500,
        'data': {'detail': 'No se pudo guardar push farmacia: $error'},
      };
    }
  }

  Future<void> _savePharmacySession(Map<String, dynamic> data) async {
    final token = data['access_token']?.toString();
    if (token != null && token.isNotEmpty) {
      await _storage.write(key: _tokenKey, value: token);
    }

    final customer = data['customer'];
    if (customer is Map) {
      await _storage.write(
        key: _customerKey,
        value: jsonEncode(Map<String, dynamic>.from(customer)),
      );
    }
  }

  Future<Map<String, String>> _getPharmacyHeaders() async {
    final token = await _storage.read(key: _tokenKey);
    return {
      'Content-Type': 'application/json',
      if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
    };
  }

  Future<Map<String, String>> _getMayuAdminHeaders() async {
    final headers = await _mayuAuth.getAuthHeaders();
    return {...headers, 'Content-Type': 'application/json'};
  }

  Future<Map<String, dynamic>> _safeRequest(
    Future<http.Response> Function() callback,
  ) async {
    try {
      final response = await callback();
      final data = _decodeBody(response.body);
      return {'statusCode': response.statusCode, 'data': data};
    } catch (error) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $error'},
      };
    }
  }

  Map<String, dynamic> _decodeBody(String body) {
    if (body.isEmpty) return {};
    final decoded = jsonDecode(body);
    if (decoded is Map) {
      return Map<String, dynamic>.from(decoded);
    }
    return {'detail': decoded.toString()};
  }

  String? _optional(String? value) {
    final cleaned = value?.trim();
    if (cleaned == null || cleaned.isEmpty) return null;
    return cleaned;
  }
}
