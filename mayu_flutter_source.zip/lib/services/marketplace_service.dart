import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:image_picker/image_picker.dart';

import '../core/api_config.dart';
import 'auth_service.dart';

class MarketplaceService {
  final AuthService _authService = AuthService();

  Map<String, dynamic> _safeDecode(http.Response response) {
    try {
      final decoded =
          response.body.isNotEmpty ? jsonDecode(response.body) : null;

      if (decoded is Map<String, dynamic>) return decoded;

      return {'items': decoded};
    } catch (_) {
      return {
        'detail': response.body.isNotEmpty
            ? response.body
            : 'Respuesta inválida del servidor',
      };
    }
  }

  Future<Map<String, String>> _authHeaders() async {
    final headers = await _authService.getAuthHeaders();

    return {
      ...headers,
      'Content-Type': 'application/json',
    };
  }

  Future<Map<String, dynamic>> _handleRequest(
    Future<http.Response> Function(Map<String, String>) request,
  ) async {
    try {
      final headers = await _authHeaders();
      final response = await request(headers);

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> uploadMarketplaceImage({
    required XFile file,
  }) async {
    try {
      final uri = Uri.parse('${ApiConfig.baseUrl}/marketplace/upload-image');
      final headers = await _authService.getAuthHeaders();

      final request = http.MultipartRequest('POST', uri);
      request.headers.addAll(headers);

      final bytes = await file.readAsBytes();
      final fileName = file.name.toLowerCase();

      MediaType contentType = MediaType('image', 'jpeg');

      if (fileName.endsWith('.png')) {
        contentType = MediaType('image', 'png');
      } else if (fileName.endsWith('.jpg') || fileName.endsWith('.jpeg')) {
        contentType = MediaType('image', 'jpeg');
      } else if (fileName.endsWith('.webp')) {
        contentType = MediaType('image', 'webp');
      }

      request.files.add(
        http.MultipartFile.fromBytes(
          'file',
          bytes,
          filename: file.name,
          contentType: contentType,
        ),
      );

      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error subiendo imagen: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> getPublicCategories() async {
    final url = Uri.parse('${ApiConfig.baseUrl}/marketplace/categories');
    return _handleRequest((headers) => http.get(url, headers: headers));
  }

  Future<Map<String, dynamic>> getPublicProducts({
    int? categoryId,
    String? search,
  }) async {
    final Map<String, String> queryParams = {};

    if (categoryId != null && categoryId != 0) {
      queryParams['category_id'] = categoryId.toString();
    }

    if (search != null && search.trim().isNotEmpty) {
      queryParams['search'] = search.trim();
    }

    final url = Uri.parse('${ApiConfig.baseUrl}/marketplace/products').replace(
      queryParameters: queryParams.isEmpty ? null : queryParams,
    );

    return _handleRequest((headers) => http.get(url, headers: headers));
  }

  Future<Map<String, dynamic>> getAdminCategories() async {
    final url = Uri.parse('${ApiConfig.baseUrl}/marketplace/admin/categories');
    return _handleRequest((headers) => http.get(url, headers: headers));
  }

  Future<Map<String, dynamic>> createCategory({
    required String name,
    String? description,
    bool active = true,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/marketplace/categories');

    return _handleRequest(
      (headers) => http.post(
        url,
        headers: headers,
        body: jsonEncode({
          'name': name.trim(),
          'description': description?.trim(),
          'active': active,
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> updateCategory({
    required int categoryId,
    String? name,
    String? description,
    bool? active,
  }) async {
    final url =
        Uri.parse('${ApiConfig.baseUrl}/marketplace/categories/$categoryId');

    return _handleRequest(
      (headers) => http.put(
        url,
        headers: headers,
        body: jsonEncode({
          if (name != null) 'name': name.trim(),
          if (description != null) 'description': description.trim(),
          if (active != null) 'active': active,
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> deleteCategory({
    required int categoryId,
  }) async {
    final url =
        Uri.parse('${ApiConfig.baseUrl}/marketplace/categories/$categoryId');

    return _handleRequest((headers) => http.delete(url, headers: headers));
  }

  Future<Map<String, dynamic>> getAdminProducts() async {
    final url = Uri.parse('${ApiConfig.baseUrl}/marketplace/admin/products');
    return _handleRequest((headers) => http.get(url, headers: headers));
  }

  Future<Map<String, dynamic>> createProduct({
    required String name,
    int? categoryId,
    required double price,
    required int stock,
    String? imageUrl,
    String? videoUrl,
    String? shortDescription,
    String? description,
    String? benefits,
    String? ingredients,
    String? suggestedDose,
    String? usageInstructions,
    String? warnings,
    String? presentation,
    bool active = true,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/marketplace/products');

    return _handleRequest(
      (headers) => http.post(
        url,
        headers: headers,
        body: jsonEncode({
          'name': name.trim(),
          'category_id': categoryId,
          'price': price,
          'stock': stock,
          'image_url': imageUrl?.trim(),
          'video_url': videoUrl?.trim(),
          'short_description': shortDescription?.trim(),
          'description': description?.trim(),
          'benefits': benefits?.trim(),
          'ingredients': ingredients?.trim(),
          'suggested_dose': suggestedDose?.trim(),
          'usage_instructions': usageInstructions?.trim(),
          'warnings': warnings?.trim(),
          'presentation': presentation?.trim(),
          'active': active,
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> updateProduct({
    required int productId,
    String? name,
    int? categoryId,
    double? price,
    int? stock,
    String? imageUrl,
    String? videoUrl,
    String? shortDescription,
    String? description,
    String? benefits,
    String? ingredients,
    String? suggestedDose,
    String? usageInstructions,
    String? warnings,
    String? presentation,
    bool? active,
  }) async {
    final url =
        Uri.parse('${ApiConfig.baseUrl}/marketplace/products/$productId');

    return _handleRequest(
      (headers) => http.put(
        url,
        headers: headers,
        body: jsonEncode({
          if (name != null) 'name': name.trim(),
          if (categoryId != null) 'category_id': categoryId,
          if (price != null) 'price': price,
          if (stock != null) 'stock': stock,
          if (imageUrl != null) 'image_url': imageUrl.trim(),
          if (videoUrl != null) 'video_url': videoUrl.trim(),
          if (shortDescription != null)
            'short_description': shortDescription.trim(),
          if (description != null) 'description': description.trim(),
          if (benefits != null) 'benefits': benefits.trim(),
          if (ingredients != null) 'ingredients': ingredients.trim(),
          if (suggestedDose != null) 'suggested_dose': suggestedDose.trim(),
          if (usageInstructions != null)
            'usage_instructions': usageInstructions.trim(),
          if (warnings != null) 'warnings': warnings.trim(),
          if (presentation != null) 'presentation': presentation.trim(),
          if (active != null) 'active': active,
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> deleteProduct({
    required int productId,
  }) async {
    final url =
        Uri.parse('${ApiConfig.baseUrl}/marketplace/products/$productId');

    return _handleRequest((headers) => http.delete(url, headers: headers));
  }

  Future<Map<String, dynamic>> createOrder({
    required String customerName,
    required String customerPhone,
    String? customerEmail,
    String? city,
    String? address,
    String? deliveryNotes,
    String? billingName,
    String? billingIdentification,
    String? billingEmail,
    String? billingPhone,
    String? billingAddress,
    String? discountCode,
    String? pharmacyLoyaltyIdentifier,
    String? doctorPrescriberIdentifier,
    required List<Map<String, dynamic>> items,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/marketplace/orders');

    return _handleRequest(
      (headers) => http.post(
        url,
        headers: headers,
        body: jsonEncode({
          'customer_name': customerName.trim(),
          'customer_phone': customerPhone.trim(),
          'customer_email': customerEmail?.trim(),
          'city': city?.trim(),
          'address': address?.trim(),
          'delivery_notes': deliveryNotes?.trim(),
          'billing_name': billingName?.trim(),
          'billing_identification': billingIdentification?.trim(),
          'billing_email': billingEmail?.trim(),
          'billing_phone': billingPhone?.trim(),
          'billing_address': billingAddress?.trim(),
          'discount_code': discountCode?.trim(),
          'pharmacy_loyalty_identifier': pharmacyLoyaltyIdentifier?.trim(),
          'doctor_prescriber_identifier': doctorPrescriberIdentifier?.trim(),
          'items': items,
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> getAdminOrders() async {
    final url = Uri.parse('${ApiConfig.baseUrl}/marketplace/admin/orders');

    return _handleRequest(
      (headers) => http.get(
        url,
        headers: headers,
      ),
    );
  }

  Future<Map<String, dynamic>> getMyMarketplaceOrders() async {
    final url = Uri.parse('${ApiConfig.baseUrl}/marketplace/my-orders');
    return _handleRequest((headers) => http.get(url, headers: headers));
  }

  Future<Map<String, dynamic>> getMyMarketplaceOrder({
    required int orderId,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/marketplace/my-orders/$orderId',
    );
    return _handleRequest((headers) => http.get(url, headers: headers));
  }

  Future<Map<String, dynamic>> updateMarketplaceOrderByAdmin({
    required int orderId,
    String? paymentStatus,
    String? status,
    String? shippingNotes,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/marketplace/admin/orders/$orderId/admin',
    );

    return _handleRequest(
      (headers) => http.put(
        url,
        headers: headers,
        body: jsonEncode({
          if (paymentStatus != null) 'payment_status': paymentStatus,
          if (status != null) 'status': status,
          if (shippingNotes != null) 'shipping_notes': shippingNotes,
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> updateMarketplaceOrderByLogistics({
    required int orderId,
    String? status,
    String? carrier,
    String? trackingNumber,
    String? trackingUrl,
    String? shippingNotes,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/marketplace/admin/orders/$orderId/logistics',
    );

    return _handleRequest(
      (headers) => http.put(
        url,
        headers: headers,
        body: jsonEncode({
          if (status != null) 'status': status,
          if (carrier != null) 'carrier': carrier,
          if (trackingNumber != null) 'tracking_number': trackingNumber,
          if (trackingUrl != null) 'tracking_url': trackingUrl,
          if (shippingNotes != null) 'shipping_notes': shippingNotes,
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> createMarketplacePayPalCartOrder({
    required int userId,
    required String buyerName,
    required String buyerPhone,
    required String buyerEmail,
    String? city,
    String? address,
    String? deliveryNotes,
    String? billingName,
    String? billingIdentification,
    String? billingEmail,
    String? billingPhone,
    String? billingAddress,
    String? discountCode,
    String? pharmacyLoyaltyIdentifier,
    String? doctorPrescriberIdentifier,
    required List<Map<String, dynamic>> items,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/payments/paypal/marketplace/create-cart-order',
    );

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'item_type': 'pharmacy',
          'user_id': userId,
          'buyer_name': buyerName.trim(),
          'buyer_phone': buyerPhone.trim(),
          'buyer_email': buyerEmail.trim(),
          'city': city?.trim(),
          'address': address?.trim(),
          'delivery_notes': deliveryNotes?.trim(),
          'billing_name': billingName?.trim(),
          'billing_identification': billingIdentification?.trim(),
          'billing_email': billingEmail?.trim(),
          'billing_phone': billingPhone?.trim(),
          'billing_address': billingAddress?.trim(),
          'discount_code': discountCode?.trim(),
          'pharmacy_loyalty_identifier': pharmacyLoyaltyIdentifier?.trim(),
          'doctor_prescriber_identifier': doctorPrescriberIdentifier?.trim(),
          'currency': 'USD',
          'items': items,
        }),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error creando carrito PayPal: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> createMarketplacePayPhoneCartOrder({
    required int userId,
    required String buyerName,
    required String buyerPhone,
    required String buyerEmail,
    String? city,
    String? address,
    String? deliveryNotes,
    String? billingName,
    String? billingIdentification,
    String? billingEmail,
    String? billingPhone,
    String? billingAddress,
    String? discountCode,
    String? pharmacyLoyaltyIdentifier,
    String? doctorPrescriberIdentifier,
    required List<Map<String, dynamic>> items,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/payphone/marketplace/create-cart-order',
    );

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'item_type': 'pharmacy',
          'user_id': userId,
          'buyer_name': buyerName.trim(),
          'buyer_phone': buyerPhone.trim(),
          'buyer_email': buyerEmail.trim(),
          'city': city?.trim(),
          'address': address?.trim(),
          'delivery_notes': deliveryNotes?.trim(),
          'billing_name': billingName?.trim(),
          'billing_identification': billingIdentification?.trim(),
          'billing_email': billingEmail?.trim(),
          'billing_phone': billingPhone?.trim(),
          'billing_address': billingAddress?.trim(),
          'discount_code': discountCode?.trim(),
          'pharmacy_loyalty_identifier': pharmacyLoyaltyIdentifier?.trim(),
          'doctor_prescriber_identifier': doctorPrescriberIdentifier?.trim(),
          'currency': 'USD',
          'items': items,
        }),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error creando link PayPhone: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> confirmMarketplacePayPhoneOrder({
    String? clientTransactionId,
    String? transactionId,
    int? id,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/payphone/marketplace/confirm-order',
    );

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          if (clientTransactionId != null && clientTransactionId.trim().isNotEmpty)
            'clientTransactionId': clientTransactionId.trim(),
          if (transactionId != null && transactionId.trim().isNotEmpty)
            'transactionId': transactionId.trim(),
          if (id != null) 'id': id,
        }),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error verificando pago PayPhone: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> createMarketplacePayPalOrder({
    required int productId,
    required int userId,
    int quantity = 1,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/payments/paypal/marketplace/create-order',
    );

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'item_type': 'pharmacy',
          'item_id': productId,
          'user_id': userId,
          'quantity': quantity,
        }),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error creando orden PayPal: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> captureMarketplacePayPalOrder({
    required String paypalOrderId,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/payments/paypal/marketplace/capture-order',
    );

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'paypal_order_id': paypalOrderId,
        }),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error capturando pago PayPal: $e'},
      };
    }
  }
}
