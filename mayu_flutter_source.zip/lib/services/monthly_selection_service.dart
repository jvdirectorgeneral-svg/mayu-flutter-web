  import 'dart:convert';
  import 'package:http/http.dart' as http;

  import '../core/api_config.dart';
  import 'auth_service.dart';

  class MonthlySelectionService {
    String get baseUrl => ApiConfig.baseUrl;

    final AuthService _authService = AuthService();

    Map<String, dynamic> _handleResponse(http.Response response) {
      dynamic data;

      try {
        data = response.body.isNotEmpty ? jsonDecode(response.body) : null;
      } catch (_) {
        data = {
          'detail': response.body.isNotEmpty
              ? response.body
              : 'Respuesta inválida del servidor',
        };
      }

      return {
        'statusCode': response.statusCode,
        'data': data,
      };
    }

    Future<Map<String, String>> _authHeaders() async {
      final headers = await _authService.getAuthHeaders();

      return {
        ...headers,
        'Content-Type': 'application/json',
      };
    }

    Map<String, String> _publicHeaders() {
      return {
        'Content-Type': 'application/json',
      };
    }

    List<Map<String, String>> _buildItems(List<String> productNames) {
      return productNames
          .where((name) => name.trim().isNotEmpty)
          .map((name) => {
                'product_name': name.trim(),
              })
          .toList();
    }

    Future<Map<String, dynamic>> initMonthlySelection({
      required int userId,
    }) async {
      final response = await http.post(
        Uri.parse('$baseUrl/monthly-selection/init'),
        headers: await _authHeaders(),
        body: jsonEncode({
          'user_id': userId,
        }),
      );

      return _handleResponse(response);
    }

    Future<Map<String, dynamic>> initMonthlySelectionAfterPayment({
      required int userId,
    }) async {
      final response = await http.post(
        Uri.parse('$baseUrl/monthly-selection/init-after-payment'),
        headers: _publicHeaders(),
        body: jsonEncode({
          'user_id': userId,
        }),
      );

      return _handleResponse(response);
    }

    Future<Map<String, dynamic>> saveSelections({
      required int selectionId,
      required List<String> productNames,
    }) async {
      final response = await http.post(
        Uri.parse('$baseUrl/monthly-selection/$selectionId/save-items'),
        headers: await _authHeaders(),
        body: jsonEncode({
          'force_save': true,
          'items': _buildItems(productNames),
        }),
      );

      return _handleResponse(response);
    }

    Future<Map<String, dynamic>> saveInitialSelections({
      required int selectionId,
      required List<String> productNames,
    }) async {
      return saveInitialSelectionsAfterPayment(
        selectionId: selectionId,
        productNames: productNames,
      );
    }

    Future<Map<String, dynamic>> saveInitialSelectionsAfterPayment({
      required int selectionId,
      required List<String> productNames,
    }) async {
      final response = await http.post(
        Uri.parse(
          '$baseUrl/monthly-selection/$selectionId/save-items-after-payment',
        ),
        headers: _publicHeaders(),
        body: jsonEncode({
          'force_save': true,
          'items': _buildItems(productNames),
        }),
      );

      return _handleResponse(response);
    }

    Future<Map<String, dynamic>> saveInitialColoide({
      required int selectionId,
      required String coloideName,
    }) async {
      return saveInitialSelectionsAfterPayment(
        selectionId: selectionId,
        productNames: [coloideName],
      );
    }
  }