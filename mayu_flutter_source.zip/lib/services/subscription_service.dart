import 'dart:convert';
import 'package:http/http.dart' as http;

import '../core/api_config.dart';
import 'auth_service.dart';

class SubscriptionService {
  final AuthService _authService = AuthService();

  Future<Map<String, String>> _headers() async {
    final authHeaders = await _authService.getAuthHeaders();

    return {
      ...authHeaders,
      'Content-Type': 'application/json',
    };
  }

  Map<String, dynamic> _handleResponse(http.Response response) {
    dynamic data;

    try {
      data = response.body.isNotEmpty ? jsonDecode(response.body) : null;
    } catch (_) {
      data = {
        'detail': response.body.isNotEmpty
            ? response.body
            : 'Respuesta inválida del servidor',
      };
    }

    return {
      'statusCode': response.statusCode,
      'data': data,
    };
  }

  Map<String, dynamic> _handleError(String message, Object error) {
    return {
      'statusCode': 500,
      'data': {
        'detail': '$message: $error',
      },
    };
  }

  String? getApproveUrl(Map<String, dynamic>? data) {
    if (data == null) return null;

    final directUrl = data['approve_url'] ?? data['approval_url'];

    if (directUrl != null && directUrl.toString().trim().isNotEmpty) {
      return directUrl.toString();
    }

    final links = data['links'];

    if (links is List) {
      for (final link in links) {
        if (link is Map && link['rel'] == 'approve') {
          final href = link['href'];
          if (href != null && href.toString().trim().isNotEmpty) {
            return href.toString();
          }
        }
      }
    }

    return null;
  }

  Future<Map<String, dynamic>> createSubscription({
    required int userId,
    required int planLevel,
    String? startTime,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/payments/paypal/subscriptions/create',
    );

    try {
      final response = await http.post(
        url,
        headers: await _headers(),
        body: jsonEncode({
          'user_id': userId,
          'plan_level': planLevel,
          if (startTime != null) 'start_time': startTime,
        }),
      );

      return _handleResponse(response);
    } catch (e) {
      return _handleError('Error creando suscripción PayPal', e);
    }
  }

  Future<Map<String, dynamic>> getSubscriptionStatus({
    required int userId,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/payments/paypal/subscriptions/status/$userId',
    );

    try {
      final response = await http.get(
        url,
        headers: await _headers(),
      );

      return _handleResponse(response);
    } catch (e) {
      return _handleError('Error consultando suscripción PayPal', e);
    }
  }

  Future<Map<String, dynamic>> activateLevel1Subscription({
    required int userId,
    required String subscriptionId,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/payments/paypal/subscriptions/activate-level-1',
    );

    try {
      final response = await http.post(
        url,
        headers: await _headers(),
        body: jsonEncode({
          'user_id': userId,
          'subscription_id': subscriptionId,
        }),
      );

      return _handleResponse(response);
    } catch (e) {
      return _handleError('Error activando suscripción PayPal', e);
    }
  }

  Future<Map<String, dynamic>> createPaypalProduct({
    required String name,
    required String description,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/payments/paypal/subscriptions/create-product',
    );

    try {
      final response = await http.post(
        url,
        headers: await _headers(),
        body: jsonEncode({
          'name': name,
          'description': description,
        }),
      );

      return _handleResponse(response);
    } catch (e) {
      return _handleError('Error creando producto PayPal', e);
    }
  }

  Future<Map<String, dynamic>> createPaypalPlan({
    required String productId,
    required int planLevel,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/payments/paypal/subscriptions/create-plan',
    );

    try {
      final response = await http.post(
        url,
        headers: await _headers(),
        body: jsonEncode({
          'product_id': productId,
          'plan_level': planLevel,
          'currency': 'USD',
        }),
      );

      return _handleResponse(response);
    } catch (e) {
      return _handleError('Error creando plan PayPal', e);
    }
  }

  Future<Map<String, dynamic>> debugPaypal() async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/payments/paypal/subscriptions/debug',
    );

    try {
      final response = await http.get(
        url,
        headers: await _headers(),
      );

      return _handleResponse(response);
    } catch (e) {
      return _handleError('Error revisando configuración PayPal', e);
    }
  }
}