@JS()
library;

import 'dart:js_interop';

@JS('MayuNuvei.openTokenization')
external JSPromise<JSAny?> _openTokenization(JSAny configuration);

Future<Map<String, dynamic>> tokenizeNuveiCard(
  Map<String, dynamic> configuration,
) async {
  final result = await _openTokenization(configuration.jsify()!).toDart;
  final converted = result?.dartify();
  if (converted is Map) {
    return Map<String, dynamic>.from(converted);
  }
  throw StateError('Nuvei devolvió una respuesta de tokenización inválida.');
}
