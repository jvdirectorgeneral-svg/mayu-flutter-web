@JS()
library;

import 'dart:js_interop';

@JS('MayuNuvei.openTokenization')
external JSPromise<JSAny?> _openTokenization(JSAny configuration);

@JS('MayuNuvei.complete3DS')
external JSPromise<JSAny?> _complete3DS(JSAny action);

Future<Map<String, dynamic>> tokenizeNuveiCard(
  Map<String, dynamic> configuration,
) async {
  final result = await _openTokenization(configuration.jsify()!).toDart;
  final converted = result?.dartify();
  if (converted is Map) {
    return Map<String, dynamic>.from(converted);
  }
  throw StateError('Nuvei devolvió una respuesta de tokenización inválida.');
}

Future<Map<String, dynamic>> completeNuvei3DS(
  Map<String, dynamic> action,
) async {
  final result = await _complete3DS(action.jsify()!).toDart;
  final converted = result?.dartify();
  if (converted is Map) {
    return Map<String, dynamic>.from(converted);
  }
  throw StateError('Nuvei devolvió una respuesta 3DS inválida.');
}
