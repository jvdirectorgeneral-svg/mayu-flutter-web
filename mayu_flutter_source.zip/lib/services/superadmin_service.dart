import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../core/api_config.dart';
import 'auth_service.dart';

class SuperAdminService {
  final AuthService _authService = AuthService();

  Map<String, dynamic> _safeDecode(http.Response response) {
    try {
      final decoded =
          response.body.isNotEmpty ? jsonDecode(response.body) : null;

      if (decoded is Map<String, dynamic>) return decoded;

      return {'items': decoded};
    } catch (_) {
      return {
        'detail': response.body.isNotEmpty
            ? response.body
            : 'Respuesta inválida del servidor',
      };
    }
  }

  Future<Map<String, dynamic>> _handleRequest(
    Future<http.Response> Function(Map<String, String>) request,
  ) async {
    try {
      final headers = await _authService.getAuthHeaders();
      headers['Content-Type'] = 'application/json';

      final response = await request(headers);

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $e'},
      };
    }
  }

  String _cleanRole(String role) {
    return role.trim().toLowerCase();
  }

  Future<Map<String, dynamic>> getSuperAdminProfile() async {
    final url = Uri.parse('${ApiConfig.baseUrl}/superadmin/me');
    return _handleRequest((headers) => http.get(url, headers: headers));
  }

  Future<Map<String, dynamic>> updateSuperAdminProfile({
    required String name,
    required String email,
    required String phone,
    required String cedula,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/superadmin/me');

    return _handleRequest(
      (headers) => http.put(
        url,
        headers: headers,
        body: jsonEncode({
          'name': name.trim(),
          'email': email.trim().toLowerCase(),
          'phone': phone.trim(),
          'cedula': cedula.trim(),
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> updateSuperAdminPassword({
    required String newPassword,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/superadmin/me/password');

    return _handleRequest(
      (headers) => http.put(
        url,
        headers: headers,
        body: jsonEncode({'new_password': newPassword.trim()}),
      ),
    );
  }

  Future<Map<String, dynamic>> getInternalUsers() async {
    final url = Uri.parse('${ApiConfig.baseUrl}/superadmin/internal-users');
    return _handleRequest((headers) => http.get(url, headers: headers));
  }

  Future<Map<String, dynamic>> getPharmacyAccessCodes({
    bool farmaciaScope = false,
  }) async {
    final path = farmaciaScope
        ? '/superadmin/pharmacy-access-codes/farmacia'
        : '/superadmin/pharmacy-access-codes';
    final url = Uri.parse('${ApiConfig.baseUrl}$path');

    return _handleRequest((headers) => http.get(url, headers: headers));
  }

  Future<Map<String, dynamic>> updatePharmacyAccessCodes({
    required String pharmacyPoints,
    required String doctorPrescriber,
    required String pharmacyAdmin,
    required String pharmacyLogistics,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/superadmin/pharmacy-access-codes',
    );

    return _handleRequest(
      (headers) => http.put(
        url,
        headers: headers,
        body: jsonEncode({
          'pharmacy_points': pharmacyPoints.trim(),
          'doctor_prescriber': doctorPrescriber.trim(),
          'pharmacy_admin': pharmacyAdmin.trim(),
          'pharmacy_logistics': pharmacyLogistics.trim(),
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> getAllUsers() async {
    final url = Uri.parse('${ApiConfig.baseUrl}/users');
    return _handleRequest((headers) => http.get(url, headers: headers));
  }

  Future<Map<String, dynamic>> createInternalUser({
    required String name,
    required String email,
    required String password,
    required String cedula,
    required String role,
    required String phone,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/superadmin/internal-users');
    final cleanRole = _cleanRole(role);

    debugPrint('CREANDO USUARIO INTERNO CON ROL: $cleanRole');

    return _handleRequest(
      (headers) => http.post(
        url,
        headers: headers,
        body: jsonEncode({
          'name': name.trim(),
          'email': email.trim().toLowerCase(),
          'password': password.trim(),
          'phone': phone.trim(),
          'cedula': cedula.trim(),
          'role': cleanRole,
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> updateInternalUser({
    required int userId,
    required String name,
    required String email,
    required String cedula,
    required String role,
    required String phone,
  }) async {
    final url =
        Uri.parse('${ApiConfig.baseUrl}/superadmin/internal-users/$userId');

    return _handleRequest(
      (headers) => http.put(
        url,
        headers: headers,
        body: jsonEncode({
          'name': name.trim(),
          'email': email.trim().toLowerCase(),
          'phone': phone.trim(),
          'cedula': cedula.trim(),
          'role': _cleanRole(role),
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> resetInternalUserPassword({
    required int userId,
    required String newPassword,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/superadmin/internal-users/$userId/reset-password',
    );

    return _handleRequest(
      (headers) => http.put(
        url,
        headers: headers,
        body: jsonEncode({'new_password': newPassword.trim()}),
      ),
    );
  }

  Future<Map<String, dynamic>> resetAnyUserPassword({
    required int userId,
    required String newPassword,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/superadmin/users/$userId/reset-password',
    );

    return _handleRequest(
      (headers) => http.put(
        url,
        headers: headers,
        body: jsonEncode({'new_password': newPassword.trim()}),
      ),
    );
  }

  Future<Map<String, dynamic>> updateInternalUserStatus({
    required int userId,
    required bool isActive,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/superadmin/internal-users/$userId/status',
    );

    return _handleRequest(
      (headers) => http.put(
        url,
        headers: headers,
        body: jsonEncode({'is_active': isActive}),
      ),
    );
  }

  Future<Map<String, dynamic>> updateAnyUserStatus({
    required int userId,
    required bool isActive,
  }) async {
    final url =
        Uri.parse('${ApiConfig.baseUrl}/superadmin/users/$userId/status');

    return _handleRequest(
      (headers) => http.put(
        url,
        headers: headers,
        body: jsonEncode({'is_active': isActive}),
      ),
    );
  }

  Future<Map<String, dynamic>> deleteUser({
    required int userId,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/superadmin/users/$userId');
    return _handleRequest((headers) => http.delete(url, headers: headers));
  }

  Future<Map<String, dynamic>> deleteUserFull({
    required int userId,
  }) async {
    final url =
        Uri.parse('${ApiConfig.baseUrl}/superadmin/users/$userId/full-delete');

    return _handleRequest((headers) => http.delete(url, headers: headers));
  }

  Future<Map<String, dynamic>> getProducts() async {
    final url = Uri.parse('${ApiConfig.baseUrl}/products/');
    return _handleRequest((headers) => http.get(url, headers: headers));
  }

  Future<Map<String, dynamic>> createProduct({
    required String name,
    required double price,
    required String description,
    required String category,
    String? imageUrl,
    bool active = true,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/products/');

    return _handleRequest(
      (headers) => http.post(
        url,
        headers: headers,
        body: jsonEncode({
          'name': name.trim(),
          'price': price,
          'description': description.trim(),
          'image_url': imageUrl?.trim(),
          'category': category.trim(),
          'active': active,
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> updateProduct({
    required int productId,
    String? name,
    double? price,
    String? description,
    String? category,
    String? imageUrl,
    bool? active,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/products/$productId');

    return _handleRequest(
      (headers) => http.put(
        url,
        headers: headers,
        body: jsonEncode({
          'name': name?.trim(),
          'price': price,
          'description': description?.trim(),
          'image_url': imageUrl?.trim(),
          'category': category?.trim(),
          'active': active,
        }),
      ),
    );
  }
}