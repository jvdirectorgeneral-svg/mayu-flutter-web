class CartService {
  static final CartService _instance = CartService._internal();

  factory CartService() => _instance;

  CartService._internal();

  final List<Map<String, dynamic>> _items = [];

  List<Map<String, dynamic>> get items => List.unmodifiable(_items);

  bool get isEmpty => _items.isEmpty;

  int get itemCount => _items.fold<int>(
        0,
        (sum, item) => sum + ((item['quantity'] ?? 1) as int),
      );

  double get subtotal {
    double total = 0;

    for (final item in _items) {
      final product = Map<String, dynamic>.from(item['product']);
      final quantity = item['quantity'] ?? 1;
      final price = double.tryParse((product['price'] ?? 0).toString()) ?? 0;

      total += price * quantity;
    }

    return total;
  }

  void addProduct(Map<String, dynamic> product) {
    final productId = product['id'];

    final index = _items.indexWhere(
      (item) => item['product']['id'] == productId,
    );

    if (index >= 0) {
      _items[index]['quantity'] = (_items[index]['quantity'] ?? 1) + 1;
    } else {
      _items.add({
        'product': product,
        'quantity': 1,
      });
    }
  }

  void increaseQuantity(int productId) {
    final index = _items.indexWhere(
      (item) => item['product']['id'] == productId,
    );

    if (index >= 0) {
      _items[index]['quantity'] = (_items[index]['quantity'] ?? 1) + 1;
    }
  }

  void decreaseQuantity(int productId) {
    final index = _items.indexWhere(
      (item) => item['product']['id'] == productId,
    );

    if (index >= 0) {
      final quantity = _items[index]['quantity'] ?? 1;

      if (quantity <= 1) {
        _items.removeAt(index);
      } else {
        _items[index]['quantity'] = quantity - 1;
      }
    }
  }

  void removeProduct(int productId) {
    _items.removeWhere(
      (item) => item['product']['id'] == productId,
    );
  }

  void clear() {
    _items.clear();
  }

  List<Map<String, dynamic>> toOrderItems() {
    return _items.map((item) {
      return {
        'product_id': item['product']['id'],
        'quantity': item['quantity'] ?? 1,
      };
    }).toList();
  }
}