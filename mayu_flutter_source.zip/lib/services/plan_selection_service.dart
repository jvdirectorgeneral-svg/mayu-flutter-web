import 'dart:convert';
import 'package:http/http.dart' as http;

class PlanSelectionService {
  final String baseUrl = "https://mayu-wellness-backend-v1.onrender.com";

  Future<Map<String, dynamic>> startPlan({
    required int userId,
    required int planLevel,
  }) async {
    final response = await http.post(
      Uri.parse(
        '$baseUrl/plan-selection/start?user_id=$userId&plan_id=$planLevel',
      ),
      headers: {
        "Content-Type": "application/json",
      },
    );

    final data = response.body.isNotEmpty ? jsonDecode(response.body) : null;

    return {
      "statusCode": response.statusCode,
      "data": data,
    };
  }
}