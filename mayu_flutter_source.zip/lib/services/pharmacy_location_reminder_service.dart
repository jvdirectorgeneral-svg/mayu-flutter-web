import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:geolocator/geolocator.dart';

class PharmacyLocationReminderService {
  PharmacyLocationReminderService._();

  static final PharmacyLocationReminderService instance =
      PharmacyLocationReminderService._();

  static const List<_MayuStoreGeofence> _stores = [
    _MayuStoreGeofence(
      id: 'mayu_magistral_quito',
      name: 'Mayu Magistral Quito',
      plusCode: 'RG99+5H Quito',
      latitude: -0.1795625,
      longitude: -78.4785625,
    ),
    _MayuStoreGeofence(
      id: 'mayu_magistral_cuenca',
      name: 'Mayu Magistral Cuenca',
      plusCode: '3XWP+X2 Cuenca',
      latitude: -2.9000625,
      longitude: -79.0124375,
    ),
  ];

  static const double _radiusMeters = 100;
  static const bool _testMode = true;
  static const String _lastNotificationKey =
      'pharmacy_location_last_notification_at';

  final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  bool _initialized = false;
  StreamSubscription<Position>? _positionSubscription;

  Future<void> startLocationReminders() async {
    if (_testMode) {
      await showTestNotification();
      return;
    }

    await checkAndNotifyIfNearStore();

    if (kIsWeb || _positionSubscription != null) return;

    try {
      await _initializeNotifications();

      final permission = await _ensureLocationPermission();
      if (!permission) return;

      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return;

      const settings = LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 50,
      );

      _positionSubscription = Geolocator.getPositionStream(
        locationSettings: settings,
      ).listen((position) {
        unawaited(_notifyIfPositionIsNearStore(position));
      });
    } catch (error) {
      debugPrint('MAYU MAGISTRAL GPS STREAM ERROR: $error');
    }
  }

  Future<void> checkAndNotifyIfNearStore() async {
    if (kIsWeb) return;

    try {
      await _initializeNotifications();

      if (_testMode) {
        await showTestNotification();
        return;
      }

      final permission = await _ensureLocationPermission();
      if (!permission) return;

      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return;

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 8),
      );

      await _notifyIfPositionIsNearStore(position);
    } catch (error) {
      debugPrint('MAYU MAGISTRAL GPS ERROR: $error');
    }
  }

  Future<void> showTestNotification() async {
    if (kIsWeb) return;

    try {
      await _initializeNotifications();

      await _notifications.show(
        id: 74099,
        title: 'Farmacia Mayu te saluda 🌿',
        body:
            'Modo prueba: estás cerca de Mayu Magistral. Recuerda: el cambio de tu vida está a 100 metros. Cumple tus objetivos y metas de salud.',
        notificationDetails: const NotificationDetails(
          android: AndroidNotificationDetails(
            'mayu_magistral_location_test',
            'Mayu Magistral ubicación prueba',
            channelDescription:
                'Prueba de recordatorios de ubicación Mayu Magistral',
            importance: Importance.high,
            priority: Priority.high,
          ),
          iOS: DarwinNotificationDetails(
            presentAlert: true,
            presentBadge: true,
            presentSound: true,
          ),
        ),
      );
    } catch (error) {
      debugPrint('MAYU MAGISTRAL GPS TEST ERROR: $error');
    }
  }

  Future<void> _notifyIfPositionIsNearStore(Position position) async {
    final nearestStore = _nearestStore(position);
    if (nearestStore == null) return;

    if (!await _canNotifyToday(nearestStore.store.id)) return;

    await _storage.write(
      key: _lastNotificationStorageKey(nearestStore.store.id),
      value: DateTime.now().toIso8601String(),
    );

    await _notifications.show(
      id: nearestStore.store.notificationId,
      title: 'Farmacia Mayu te saluda 🌿',
      body:
          'Estás cerca de ${nearestStore.store.name}. Recuerda: el cambio de tu vida está a 100 metros. Cumple tus objetivos y metas de salud.',
      notificationDetails: const NotificationDetails(
        android: AndroidNotificationDetails(
          'mayu_magistral_location',
          'Mayu Magistral ubicación',
          channelDescription:
              'Recordatorios cuando estás cerca de Farmacia Mayu Magistral',
          importance: Importance.high,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(
          presentAlert: true,
          presentBadge: true,
          presentSound: true,
        ),
      ),
    );
  }

  Future<void> _initializeNotifications() async {
    if (_initialized) return;

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const ios = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    await _notifications.initialize(
      settings: const InitializationSettings(android: android, iOS: ios),
    );

    _initialized = true;
  }

  Future<bool> _ensureLocationPermission() async {
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    return permission == LocationPermission.whileInUse ||
        permission == LocationPermission.always;
  }

  _NearbyStore? _nearestStore(Position position) {
    _NearbyStore? nearest;

    for (final store in _stores) {
      final distance = _distanceInMeters(
        position.latitude,
        position.longitude,
        store.latitude,
        store.longitude,
      );

      if (distance > _radiusMeters) continue;

      if (nearest == null || distance < nearest.distanceMeters) {
        nearest = _NearbyStore(store: store, distanceMeters: distance);
      }
    }

    return nearest;
  }

  Future<bool> _canNotifyToday(String storeId) async {
    final value = await _storage.read(key: _lastNotificationStorageKey(storeId));
    if (value == null || value.isEmpty) return true;

    final last = DateTime.tryParse(value);
    if (last == null) return true;

    return DateTime.now().difference(last) > const Duration(hours: 12);
  }

  String _lastNotificationStorageKey(String storeId) =>
      '${_lastNotificationKey}_$storeId';

  double _distanceInMeters(
    double lat1,
    double lon1,
    double lat2,
    double lon2,
  ) {
    const earthRadius = 6371000.0;
    final dLat = _degreesToRadians(lat2 - lat1);
    final dLon = _degreesToRadians(lon2 - lon1);
    final a =
        sin(dLat / 2) * sin(dLat / 2) +
        cos(_degreesToRadians(lat1)) *
            cos(_degreesToRadians(lat2)) *
            sin(dLon / 2) *
            sin(dLon / 2);
    final c = 2 * atan2(sqrt(a), sqrt(1 - a));
    return earthRadius * c;
  }

  double _degreesToRadians(double degrees) => degrees * pi / 180;
}

class _MayuStoreGeofence {
  const _MayuStoreGeofence({
    required this.id,
    required this.name,
    required this.plusCode,
    required this.latitude,
    required this.longitude,
  });

  final String id;
  final String name;
  final String plusCode;
  final double latitude;
  final double longitude;

  int get notificationId => id.hashCode.abs() % 100000;
}

class _NearbyStore {
  const _NearbyStore({
    required this.store,
    required this.distanceMeters,
  });

  final _MayuStoreGeofence store;
  final double distanceMeters;
}
