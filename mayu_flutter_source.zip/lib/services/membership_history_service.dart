import 'dart:convert';
import 'package:http/http.dart' as http;

import '../core/api_config.dart';
import 'auth_service.dart';

class MembershipHistoryService {
  final AuthService _authService = AuthService();

  String get baseUrl => ApiConfig.baseUrl;

  Map<String, dynamic> _safeDecode(http.Response response) {
    try {
      final decoded = response.body.isNotEmpty ? jsonDecode(response.body) : {};
      return decoded is Map<String, dynamic>
          ? decoded
          : {'data': decoded};
    } catch (_) {
      return {
        'detail': response.body.isNotEmpty
            ? response.body
            : 'Respuesta inválida del servidor',
      };
    }
  }

  Future<Map<String, String>> _headers() async {
    final authHeaders = await _authService.getAuthHeaders();

    return {
      ...authHeaders,
      'Content-Type': 'application/json',
    };
  }

  Future<Map<String, dynamic>> getMembershipHistory(int userId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/monthly-selection/user/$userId/history'),
        headers: await _headers(),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> getUpcomingDelivery(int userId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/monthly-selection/user/$userId/upcoming'),
        headers: await _headers(),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> trackOrder({
    required int orderId,
  }) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/orders/$orderId'),
        headers: await _headers(),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $e'},
      };
    }
  }
}