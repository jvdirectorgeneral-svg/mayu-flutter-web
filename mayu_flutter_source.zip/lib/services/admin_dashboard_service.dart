import 'dart:convert';
import 'package:http/http.dart' as http;

import '../core/api_config.dart';
import 'auth_service.dart';

class AdminDashboardService {
  final AuthService _authService = AuthService();

  Future<Map<String, String>> _headers() async {
    final headers = await _authService.getAuthHeaders();

    return {
      ...headers,
      'Content-Type': 'application/json',
    };
  }

  Future<Map<String, dynamic>> _handleResponse(http.Response response) async {
    try {
      final dynamic data =
          response.body.isNotEmpty ? jsonDecode(response.body) : null;

      return {
        'statusCode': response.statusCode,
        'data': data,
      };
    } catch (_) {
      return {
        'statusCode': response.statusCode,
        'data': {
          'detail': response.body.isNotEmpty
              ? response.body
              : 'Respuesta inválida del servidor',
        },
      };
    }
  }

  Map<String, dynamic> _cleanBody(Map<String, dynamic> body) {
    body.removeWhere((key, value) {
      if (value == null) return true;
      if (value is String && value.trim().isEmpty) return true;
      return false;
    });

    return body;
  }

  Future<Map<String, dynamic>> _get(String path) async {
    final response = await http.get(
      Uri.parse('${ApiConfig.baseUrl}$path'),
      headers: await _headers(),
    );

    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> _put(
    String path, {
    Map<String, dynamic>? body,
  }) async {
    final response = await http.put(
      Uri.parse('${ApiConfig.baseUrl}$path'),
      headers: await _headers(),
      body: body == null ? null : jsonEncode(_cleanBody(body)),
    );

    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> _post(
    String path, {
    Map<String, dynamic>? body,
  }) async {
    final response = await http.post(
      Uri.parse('${ApiConfig.baseUrl}$path'),
      headers: await _headers(),
      body: body == null ? null : jsonEncode(_cleanBody(body)),
    );

    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> getSummary() async {
    return _get('/admin-dashboard/summary');
  }

  Future<Map<String, dynamic>> getUsers() async {
    return _get('/admin-dashboard/users');
  }

  Future<Map<String, dynamic>> updateMember({
    required int userId,
    String? name,
    String? email,
    String? phone,
    String? cedula,
    String? city,
    String? address,
    String? reference,
    String? deliveryNotes,
    int? membershipLevel,
    bool? membershipActive,
    bool? isActive,
  }) async {
    return _put(
      '/admin-dashboard/users/$userId',
      body: {
        'name': name?.trim(),
        'email': email?.trim().toLowerCase(),
        'phone': phone?.trim(),
        'cedula': cedula?.trim(),
        'city': city?.trim(),
        'address': address?.trim(),
        'reference': reference?.trim(),
        'delivery_notes': deliveryNotes?.trim(),
        'membership_level': membershipLevel,
        'membership_active': membershipActive,
        'is_active': isActive,
      },
    );
  }

  Future<Map<String, dynamic>> updateUserPhone({
    required int userId,
    required String phone,
  }) async {
    return _put(
      '/admin-dashboard/users/$userId/phone',
      body: {'phone': phone.trim()},
    );
  }

  Future<Map<String, dynamic>> resetUserPassword({
    required int userId,
    required String newPassword,
  }) async {
    return _put(
      '/admin-dashboard/users/$userId/reset-password',
      body: {'new_password': newPassword.trim()},
    );
  }

  Future<Map<String, dynamic>> getAmbassadors() async {
    return _get('/admin-dashboard/ambassadors');
  }

  Future<Map<String, dynamic>> updateAmbassador({
    required int ambassadorId,
    String? name,
    String? email,
    String? phone,
    String? cedula,
    String? ambassadorCode,
    String? status,
    bool? isActive,
    String? bankName,
    String? bankAccountType,
    String? bankAccountNumber,
    String? bankAccountHolder,
    String? bankIdentification,
    String? paymentNotes,
  }) async {
    return _put(
      '/admin-dashboard/ambassadors/$ambassadorId',
      body: {
        'name': name?.trim(),
        'email': email?.trim().toLowerCase(),
        'phone': phone?.trim(),
        'cedula': cedula?.trim(),
        'ambassador_code': ambassadorCode?.trim(),
        'status': status?.trim(),
        'is_active': isActive,
        'bank_name': bankName?.trim(),
        'bank_account_type': bankAccountType?.trim(),
        'bank_account_number': bankAccountNumber?.trim(),
        'bank_account_holder': bankAccountHolder?.trim(),
        'bank_identification': bankIdentification?.trim(),
        'payment_notes': paymentNotes?.trim(),
      },
    );
  }

  // Endpoint antiguo: mantiene compatibilidad.
  Future<Map<String, dynamic>> getPayments() async {
    return _get('/admin-dashboard/payments');
  }

  // Nuevo: solo pagos de membresías / afiliaciones.
  Future<Map<String, dynamic>> getMembershipPayments() async {
    return _get('/admin-dashboard/membership-payments');
  }



  // Nuevo: ciclos de membresía con selección + orden.
  Future<Map<String, dynamic>> getMembershipCycles() async {
    return _get('/admin-dashboard/membership-cycles');
  }

  Future<Map<String, dynamic>> verifyPayment({
    required int paymentId,
    String? notes,
  }) async {
    return _put(
      '/admin-dashboard/payments/$paymentId/verify',
      body: {
        'verification_notes':
            notes?.trim() ?? 'Pago OK confirmado por administración',
      },
    );
  }

  Future<Map<String, dynamic>> sendMemberPush({
    required int userId,
    String? title,
    String? message,
  }) async {
    return _post(
      '/admin-dashboard/users/$userId/push',
      body: {
        'title': title?.trim() ?? 'Mayu Wellness Club',
        'message': message?.trim() ??
            'Tu membresía Mayu está activa. La salud es nuestros hábitos de todos los días.',
      },
    );
  }

  Future<Map<String, dynamic>> getOrders() async {
    return _get('/admin-dashboard/orders');
  }

  Future<Map<String, dynamic>> approveOrder({
    required int orderId,
    String? notes,
  }) async {
    return _put(
      '/admin-dashboard/orders/$orderId/approve',
      body: {
        'approval_notes':
            notes?.trim() ?? 'Pagos OK - orden liberada a logística',
      },
    );
  }

  Future<Map<String, dynamic>> getPendingCommissions() async {
    return _get('/commissions/pending');
  }

  Future<Map<String, dynamic>> getPaidCommissions() async {
    return _get('/commissions/paid');
  }

  Future<Map<String, dynamic>> getGeneralCommissionsSummary() async {
    return _get('/commissions/summary/general');
  }

  Future<Map<String, dynamic>> getAmbassadorsRanking() async {
    return _get('/commissions/ranking/ambassadors');
  }

  Future<Map<String, dynamic>> getAmbassadorsCommissionRanking() async {
    return getAmbassadorsRanking();
  }

  Future<Map<String, dynamic>> getCommissionsByAmbassador({
    required int ambassadorId,
  }) async {
    return _get('/commissions/ambassador/$ambassadorId');
  }

  Future<Map<String, dynamic>> getCommissionSummaryByAmbassador({
    required int ambassadorId,
  }) async {
    return _get('/commissions/ambassador/$ambassadorId/summary');
  }

  Future<Map<String, dynamic>> markCommissionPaid({
    required int commissionId,
  }) async {
    return _put('/commissions/$commissionId/mark-paid');
  }

  Future<Map<String, dynamic>> markCommissionAsPaid({
    required int commissionId,
  }) async {
    return markCommissionPaid(commissionId: commissionId);
  }

  Future<Map<String, dynamic>> payPendingCommissionsByAmbassador({
    required int ambassadorId,
  }) async {
    return _post('/commissions/ambassador/$ambassadorId/pay-pending');
  }

  Future<Map<String, dynamic>> generateMonthlyCommissions({
    int? month,
    int? year,
  }) async {
    return _post(
      '/commissions/generate-monthly',
      body: {
        'month': month,
        'year': year,
      },
    );
  }

  Future<Map<String, dynamic>>
      getOldPendingCommissionsFromAdminDashboard() async {
    return _get('/admin-dashboard/commissions/pending');
  }
}