import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:image_picker/image_picker.dart';

import '../core/api_config.dart';
import 'auth_service.dart';

class MarketingService {
  final AuthService _authService = AuthService();

  Future<Map<String, String>> _headers() async {
    final headers = await _authService.getAuthHeaders();

    return {
      ...headers,
      'Content-Type': 'application/json',
    };
  }

  Future<Map<String, dynamic>> _handleResponse(
    http.Response response,
  ) async {
    try {
      final data = response.body.isNotEmpty ? jsonDecode(response.body) : null;

      return {
        'statusCode': response.statusCode,
        'data': data,
      };
    } catch (_) {
      return {
        'statusCode': response.statusCode,
        'data': {
          'detail': response.body.isNotEmpty
              ? response.body
              : 'Respuesta inválida del servidor',
        },
      };
    }
  }

  // =========================
  // SUBIR IMAGEN MARKETING
  // =========================
  Future<Map<String, dynamic>> uploadMarketingImage({
    required XFile file,
  }) async {
    try {
      final uri = Uri.parse(
        '${ApiConfig.baseUrl}/marketing/upload-image',
      );

      final headers = await _authService.getAuthHeaders();

      final request = http.MultipartRequest(
        'POST',
        uri,
      );

      request.headers.addAll(headers);

      final bytes = await file.readAsBytes();

      final fileName = file.name.toLowerCase();

      MediaType contentType = MediaType('image', 'jpeg');

      if (fileName.endsWith('.png')) {
        contentType = MediaType('image', 'png');
      } else if (fileName.endsWith('.jpg') || fileName.endsWith('.jpeg')) {
        contentType = MediaType('image', 'jpeg');
      } else if (fileName.endsWith('.webp')) {
        contentType = MediaType('image', 'webp');
      }

      request.files.add(
        http.MultipartFile.fromBytes(
          'file',
          bytes,
          filename: file.name,
          contentType: contentType,
        ),
      );

      final streamedResponse = await request.send();

      final response = await http.Response.fromStream(
        streamedResponse,
      );

      return _handleResponse(response);
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {
          'detail': 'Error subiendo imagen: $e',
        },
      };
    }
  }

  // =========================
  // DASHBOARD
  // =========================
  Future<Map<String, dynamic>> getDashboard() async {
    final response = await http.get(
      Uri.parse('${ApiConfig.baseUrl}/marketing/dashboard'),
      headers: await _headers(),
    );

    return _handleResponse(response);
  }

  // =========================
  // PREVIEW AUDIENCIA
  // =========================
  Future<Map<String, dynamic>> getAudiencePreview({
    required String channel,
    required String targetGroup,
  }) async {
    final uri = Uri.parse(
      '${ApiConfig.baseUrl}/marketing/audience-preview',
    ).replace(
      queryParameters: {
        'channel': channel,
        'target_group': targetGroup,
      },
    );

    final response = await http.get(
      uri,
      headers: await _headers(),
    );

    return _handleResponse(response);
  }

  // =========================
  // CAMPAÑAS
  // =========================
  Future<Map<String, dynamic>> getCampaigns({
    String? channel,
    String? status,
  }) async {
    final Map<String, String> queryParams = {};

    if (channel != null && channel.trim().isNotEmpty) {
      queryParams['channel'] = channel.trim();
    }

    if (status != null && status.trim().isNotEmpty) {
      queryParams['status'] = status.trim();
    }

    final uri = Uri.parse(
      '${ApiConfig.baseUrl}/marketing/campaigns',
    ).replace(
      queryParameters: queryParams.isEmpty ? null : queryParams,
    );

    final response = await http.get(
      uri,
      headers: await _headers(),
    );

    return _handleResponse(response);
  }

  // =========================
  // DETALLE CAMPAÑA
  // =========================
  Future<Map<String, dynamic>> getCampaignDetail({
    required int campaignId,
  }) async {
    final response = await http.get(
      Uri.parse(
        '${ApiConfig.baseUrl}/marketing/campaigns/$campaignId',
      ),
      headers: await _headers(),
    );

    return _handleResponse(response);
  }

  // =========================
  // CREAR CAMPAÑA
  // =========================
  Future<Map<String, dynamic>> createCampaign({
    required String title,
    required String message,
    String? subject,
    String? imageUrl,
    String? scheduledAt,
    required String channel,
    required String targetGroup,
  }) async {
    final cleanSubject =
        subject != null && subject.trim().isNotEmpty ? subject.trim() : null;

    final cleanImageUrl =
        imageUrl != null && imageUrl.trim().isNotEmpty ? imageUrl.trim() : null;

    final cleanScheduledAt = scheduledAt != null && scheduledAt.trim().isNotEmpty
        ? scheduledAt.trim()
        : null;

    final response = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/marketing/campaigns'),
      headers: await _headers(),
      body: jsonEncode({
        'title': title.trim(),
        'message': message.trim(),
        'subject': cleanSubject,
        'image_url': cleanImageUrl,
        'scheduled_at': cleanScheduledAt,
        'channel': channel,
        'target_group': targetGroup,
        'status': cleanScheduledAt == null ? 'draft' : 'scheduled',
      }),
    );

    return _handleResponse(response);
  }

  // =========================
  // ENVIAR CAMPAÑA AHORA
  // =========================
  Future<Map<String, dynamic>> sendCampaign({
    required int campaignId,
  }) async {
    final response = await http.post(
      Uri.parse(
        '${ApiConfig.baseUrl}/marketing/campaigns/send',
      ),
      headers: await _headers(),
      body: jsonEncode({
        'campaign_id': campaignId,
      }),
    );

    return _handleResponse(response);
  }

  // =========================
  // EJECUTAR CAMPAÑAS PROGRAMADAS MANUALMENTE
  // =========================
  Future<Map<String, dynamic>> runScheduledCampaigns() async {
    final response = await http.post(
      Uri.parse(
        '${ApiConfig.baseUrl}/marketing/campaigns/run-scheduled',
      ),
      headers: await _headers(),
    );

    return _handleResponse(response);
  }
}