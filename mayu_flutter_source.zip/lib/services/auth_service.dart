import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';

import '../core/api_config.dart';

const String mayuWebPushVapidKey = String.fromEnvironment(
  'MAYU_WEB_PUSH_VAPID_KEY',
  defaultValue: '',
);

class AuthService {
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  // =========================
  // 🔐 LOGIN
  // =========================
  Future<bool> login({
    required String email,
    required String password,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/login');

    try {
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'email': email,
          'password': password,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final token = data['access_token'];

        if (token != null) {
          await saveToken(token.toString());

          if (data['user'] != null && data['user'] is Map) {
            await saveUser(Map<String, dynamic>.from(data['user']));
          }

          await saveFcmToken();

          return true;
        }
      }

      debugPrint('LOGIN ERROR: ${response.body}');
      return false;
    } catch (e) {
      debugPrint('LOGIN EXCEPTION: $e');
      return false;
    }
  }

  // =========================
  // 💾 GUARDAR TOKEN / USER
  // =========================
  Future<void> saveToken(String token) async {
    await _storage.write(
      key: 'access_token',
      value: token,
    );
  }

  Future<void> saveUser(Map<String, dynamic> user) async {
    await _storage.write(
      key: 'user',
      value: jsonEncode(user),
    );
  }

  // =========================
  // 🔔 GUARDAR TOKEN PUSH FCM
  // =========================
  Future<void> saveFcmToken() async {
    try {
      final token = await getToken();

      if (token == null || token.isEmpty) {
        return;
      }

      final messaging = FirebaseMessaging.instance;

      final settings = await messaging.requestPermission(
        alert: true,
        badge: true,
        sound: true,
      );

      if (settings.authorizationStatus == AuthorizationStatus.denied) {
        debugPrint('PUSH TOKEN: permisos denegados');
        return;
      }

      if (!kIsWeb && defaultTargetPlatform == TargetPlatform.iOS) {
        String? apnsToken;

        for (int i = 0; i < 15; i++) {
          apnsToken = await messaging.getAPNSToken();

          if (apnsToken != null && apnsToken.isNotEmpty) {
            debugPrint('APNS TOKEN OK: $apnsToken');
            break;
          }

          debugPrint('Esperando APNS token...');
          await Future.delayed(const Duration(seconds: 2));
        }

        if (apnsToken == null || apnsToken.isEmpty) {
          debugPrint('APNS TOKEN NO DISPONIBLE');
          return;
        }
      }

      final fcmToken = kIsWeb && mayuWebPushVapidKey.isNotEmpty
          ? await messaging.getToken(vapidKey: mayuWebPushVapidKey)
          : await messaging.getToken();

      if (fcmToken == null || fcmToken.isEmpty) {
        debugPrint('FCM TOKEN VACIO');
        return;
      }

      debugPrint('FCM TOKEN OK: $fcmToken');

      String platform = 'unknown';

      if (kIsWeb) {
        platform = 'web';
      } else {
        platform = defaultTargetPlatform.name;
      }

      final url = Uri.parse('${ApiConfig.baseUrl}/marketing/push-token');

      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({
          'token': fcmToken,
          'platform': platform,
        }),
      );

      if (response.statusCode == 200) {
        debugPrint('PUSH TOKEN GUARDADO: ${response.body}');
      } else {
        debugPrint('PUSH TOKEN ERROR ${response.statusCode}: ${response.body}');
      }
    } catch (e) {
      debugPrint('PUSH TOKEN EXCEPTION: $e');
    }
  }

  // =========================
  // 🔥 FORGOT PASSWORD
  // =========================
  Future<bool> forgotPassword({
    required String email,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/forgot-password');

    try {
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'email': email,
        }),
      );

      if (response.statusCode == 200) {
        return true;
      }

      debugPrint('FORGOT ERROR: ${response.body}');
      return false;
    } catch (e) {
      debugPrint('FORGOT EXCEPTION: $e');
      return false;
    }
  }

  // =========================
  // ✅ VERIFY CODE
  // =========================
  Future<bool> verifyRecoveryCode({
    required String email,
    required String code,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/verify-recovery-code');

    try {
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'email': email,
          'code': code,
        }),
      );

      if (response.statusCode == 200) {
        return true;
      }

      debugPrint('VERIFY CODE ERROR: ${response.body}');
      return false;
    } catch (e) {
      debugPrint('VERIFY CODE EXCEPTION: $e');
      return false;
    }
  }

  // =========================
  // 🔐 RESET PASSWORD
  // =========================
  Future<Map<String, dynamic>?> resetPasswordWithCode({
    required String email,
    required String code,
    required String newPassword,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/reset-password-with-code');

    try {
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'email': email,
          'code': code,
          'new_password': newPassword,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data;
      }

      debugPrint('RESET PASSWORD ERROR: ${response.body}');
      return null;
    } catch (e) {
      debugPrint('RESET PASSWORD EXCEPTION: $e');
      return null;
    }
  }

  // =========================
  // 🔑 OBTENER TOKEN
  // =========================
  Future<String?> getToken() async {
    return await _storage.read(key: 'access_token');
  }

  // =========================
  // 👤 OBTENER USER
  // =========================
  Future<Map<String, dynamic>?> getUser() async {
    final userStr = await _storage.read(key: 'user');

    if (userStr != null) {
      return jsonDecode(userStr) as Map<String, dynamic>;
    }

    return null;
  }

  // =========================
  // 📡 HEADERS AUTORIZADOS
  // =========================
  Future<Map<String, String>> getAuthHeaders() async {
    final token = await getToken();

    return {
      'Content-Type': 'application/json',
      if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
    };
  }

  // =========================
  // 🚪 LOGOUT
  // =========================
  Future<void> logout() async {
    await _storage.deleteAll();
  }
}