import 'dart:convert';
import 'package:http/http.dart' as http;

import '../core/api_config.dart';
import 'auth_service.dart';

class MembershipService {
  String get baseUrl => ApiConfig.baseUrl;

  final AuthService _authService = AuthService();

  Map<String, dynamic> _handleResponse(http.Response response) {
    dynamic data;

    try {
      data = response.body.isNotEmpty ? jsonDecode(response.body) : null;
    } catch (_) {
      data = {
        'detail': response.body.isNotEmpty
            ? response.body
            : 'Respuesta inválida del servidor',
      };
    }

    return {
      'statusCode': response.statusCode,
      'data': data,
    };
  }

  Map<String, dynamic> _handleError(String message, Object error) {
    return {
      'statusCode': 500,
      'data': {
        'detail': '$message: $error',
      },
    };
  }

  Future<Map<String, String>> _headers() async {
    final authHeaders = await _authService.getAuthHeaders();

    return {
      ...authHeaders,
      'Content-Type': 'application/json',
    };
  }

  Future<Map<String, dynamic>> initSelection(int userId) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/monthly-selection/init'),
        headers: await _headers(),
        body: jsonEncode({
          'user_id': userId,
        }),
      );

      return _handleResponse(response);
    } catch (e) {
      return _handleError('Error iniciando selección mensual', e);
    }
  }

  Future<Map<String, dynamic>> getSelection(int userId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/monthly-selection/user/$userId'),
        headers: await _headers(),
      );

      return _handleResponse(response);
    } catch (e) {
      return _handleError('Error obteniendo selección mensual', e);
    }
  }

  Future<Map<String, dynamic>> getSelectionHistory(int userId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/monthly-selection/user/$userId/history'),
        headers: await _headers(),
      );

      return _handleResponse(response);
    } catch (e) {
      return _handleError('Error obteniendo historial de entregas', e);
    }
  }

  Future<Map<String, dynamic>> getUpcomingDelivery(int userId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/monthly-selection/user/$userId/upcoming'),
        headers: await _headers(),
      );

      return _handleResponse(response);
    } catch (e) {
      return _handleError('Error obteniendo próxima entrega', e);
    }
  }

  Future<Map<String, dynamic>> saveSelection(
    int selectionId,
    String productName,
  ) async {
    return saveSelectionItems(
      selectionId,
      [productName],
    );
  }

  Future<Map<String, dynamic>> saveSelectionItems(
    int selectionId,
    List<String> productNames,
  ) async {
    final cleanProducts = productNames
        .map((name) => name.trim())
        .where((name) => name.isNotEmpty)
        .toList();

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/monthly-selection/$selectionId/save-items'),
        headers: await _headers(),
        body: jsonEncode({
          'force_save': true,
          'items': cleanProducts
              .map(
                (name) => {
                  'product_name': name,
                },
              )
              .toList(),
        }),
      );

      return _handleResponse(response);
    } catch (e) {
      return _handleError('Error guardando selección mensual', e);
    }
  }

  Future<Map<String, dynamic>> getCycleInfo() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/monthly-selection/cycle-info'),
        headers: await _headers(),
      );

      return _handleResponse(response);
    } catch (e) {
      return _handleError('Error obteniendo ciclo operativo', e);
    }
  }
}