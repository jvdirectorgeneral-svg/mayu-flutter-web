import 'dart:convert';
import 'package:http/http.dart' as http;
import '../core/api_config.dart';

class RegisterService {
  Map<String, dynamic> _handleResponse(http.Response response) {
    dynamic data;

    try {
      data = response.body.isNotEmpty ? jsonDecode(response.body) : null;
    } catch (_) {
      data = {
        'detail': response.body.isNotEmpty
            ? response.body
            : 'Respuesta inválida del servidor',
      };
    }

    return {
      'statusCode': response.statusCode,
      'data': data,
    };
  }

  Future<Map<String, dynamic>> registerUser({
    required String name,
    required String email,
    required String phone,
    required String cedula,
    String? birthDate,
    required String city,
    required String address,
    required String reference,
    required String deliveryNotes,
    String? phoneSecondary,
    required String password,
    String? ambassadorCode,
    required bool acceptedTerms,
    required bool acceptedPrivacyPolicy,
    required bool acceptedDigitalPolicy,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/users');

    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'name': name,
        'email': email,
        'phone': phone,
        'cedula': cedula,
        'birth_date': birthDate,
        'city': city,
        'address': address,
        'reference': reference,
        'delivery_notes': deliveryNotes,
        'phone_secondary': phoneSecondary,
        'password': password,
        'ambassador_code': ambassadorCode,
        'accepted_terms': acceptedTerms,
        'accepted_privacy_policy': acceptedPrivacyPolicy,
        'accepted_digital_policy': acceptedDigitalPolicy,
      }),
    );

    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> assignMembership({
    required int userId,
    required int level,
    required bool active,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/users/$userId/membership');

    final response = await http.put(
      url,
      headers: {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'level': level,
        'active': active,
      }),
    );

    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> getPlanOptions({
    required int planId,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/plan-selection/plans/$planId/options',
    );

    final response = await http.get(
      url,
      headers: {
        'Content-Type': 'application/json',
      },
    );

    return _handleResponse(response);
  }
}