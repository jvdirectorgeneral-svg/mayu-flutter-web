import 'dart:convert';
import 'package:http/http.dart' as http;
import '../core/api_config.dart';
import 'auth_service.dart';

class SupervisorDashboardService {
  final AuthService _authService = AuthService();
  final String baseUrl = ApiConfig.baseUrl;

  Future<Map<String, String>> _headers() async {
    final headers = await _authService.getAuthHeaders();
    return {
      ...headers,
      'Content-Type': 'application/json',
    };
  }

  Map<String, dynamic> _handleResponse(http.Response response) {
    try {
      final dynamic data =
          response.body.isNotEmpty ? jsonDecode(response.body) : null;

      return {
        'statusCode': response.statusCode,
        'data': data,
      };
    } catch (_) {
      return {
        'statusCode': response.statusCode,
        'data': {
          'detail': response.body.isNotEmpty
              ? response.body
              : 'Respuesta inválida del servidor',
        },
      };
    }
  }


  Future<Map<String, dynamic>> _safeGet(String path) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl$path'),
        headers: await _headers(),
      );
      return _handleResponse(response);
    } catch (error) {
      return {
        'statusCode': 0,
        'data': {
          'detail': 'No se pudo conectar con $path: $error',
        },
      };
    }
  }

  // =========================
  // SUPERVISOR DASHBOARD
  // =========================
  Future<Map<String, dynamic>> getKpis() async {
    return _safeGet('/supervisor-dashboard/kpis');
  }

  Future<Map<String, dynamic>> getPlanDistribution() async {
    return _safeGet('/supervisor-dashboard/plan-distribution');
  }

  Future<Map<String, dynamic>> getAmbassadorRanking() async {
    return _safeGet('/supervisor-dashboard/ambassador-ranking');
  }

  Future<Map<String, dynamic>> getMonthlyUsersGrowth() async {
    return _safeGet('/supervisor-dashboard/monthly-users-growth');
  }

  Future<Map<String, dynamic>> getMonthlyCommissionsGrowth() async {
    return _safeGet('/supervisor-dashboard/monthly-commissions-growth');
  }

  Future<Map<String, dynamic>> getAdminSummary() async {
    return _safeGet('/supervisor-dashboard/summary');
  }

  Future<Map<String, dynamic>> getAdminPayments() async {
    return _safeGet('/supervisor-dashboard/payments');
  }

  Future<Map<String, dynamic>> getAdminOrders() async {
    return _safeGet('/supervisor-dashboard/orders');
  }

  Future<Map<String, dynamic>> getAdminUsers() async {
    return _safeGet('/admin-dashboard/users');
  }

  Future<Map<String, dynamic>> getAdminAmbassadors() async {
    return _safeGet('/admin-dashboard/ambassadors');
  }

  Future<Map<String, dynamic>> getAdminPendingCommissions() async {
    return _safeGet('/admin-dashboard/commissions/pending');
  }

}