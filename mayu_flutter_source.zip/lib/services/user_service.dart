import 'dart:convert';
import 'package:http/http.dart' as http;
import 'auth_service.dart';
import '../core/api_config.dart';

class UserService {
  final AuthService _authService = AuthService();

  Future<Map<String, dynamic>?> getMe() async {
    final token = await _authService.getToken();

    if (token == null) return null;

    final url = Uri.parse('${ApiConfig.baseUrl}/me');

    final response = await http.get(
      url,
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }

    return null;
  }
}