import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:image_picker/image_picker.dart';

import '../core/api_config.dart';
import 'auth_service.dart';

class EducationService {
  final AuthService _authService = AuthService();

  Map<String, dynamic> _safeDecode(http.Response response) {
    try {
      final decoded =
          response.body.isNotEmpty ? jsonDecode(response.body) : null;

      if (decoded is Map<String, dynamic>) return decoded;

      return {'items': decoded};
    } catch (_) {
      return {
        'detail': response.body.isNotEmpty
            ? response.body
            : 'Respuesta inválida del servidor',
      };
    }
  }

  Future<Map<String, String>> _authHeaders() async {
    final headers = await _authService.getAuthHeaders();

    return {
      ...headers,
      'Content-Type': 'application/json',
    };
  }

  Future<Map<String, dynamic>> _handleRequest(
    Future<http.Response> Function(Map<String, String>) request,
  ) async {
    try {
      final headers = await _authHeaders();
      final response = await request(headers);

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $e'},
      };
    }
  }

  String buildProtectedViewUrlWithAccessCode({
    required String? protectedPath,
    required String accessCode,
  }) {
    final rawPath = (protectedPath ?? '').trim();
    final cleanCode = accessCode.trim();

    if (rawPath.isEmpty || cleanCode.isEmpty) return '';

    final encodedCode = Uri.encodeComponent(cleanCode);

    if (rawPath.startsWith('http://') || rawPath.startsWith('https://')) {
      final separator = rawPath.contains('?') ? '&' : '?';
      return '$rawPath${separator}access_code=$encodedCode';
    }

    return '${ApiConfig.baseUrl}$rawPath?access_code=$encodedCode';
  }

  Future<Map<String, dynamic>> uploadEducationFile({
    required XFile file,
  }) async {
    try {
      final uri = Uri.parse('${ApiConfig.baseUrl}/education/upload-file');
      final headers = await _authService.getAuthHeaders();

      final request = http.MultipartRequest('POST', uri);
      request.headers.addAll(headers);

      final bytes = await file.readAsBytes();
      final fileName = file.name.toLowerCase();

      MediaType contentType = MediaType('application', 'octet-stream');

      if (fileName.endsWith('.png')) {
        contentType = MediaType('image', 'png');
      } else if (fileName.endsWith('.jpg') || fileName.endsWith('.jpeg')) {
        contentType = MediaType('image', 'jpeg');
      } else if (fileName.endsWith('.webp')) {
        contentType = MediaType('image', 'webp');
      } else if (fileName.endsWith('.pdf')) {
        contentType = MediaType('application', 'pdf');
      } else if (fileName.endsWith('.mp4')) {
        contentType = MediaType('video', 'mp4');
      } else if (fileName.endsWith('.mov')) {
        contentType = MediaType('video', 'quicktime');
      }

      request.files.add(
        http.MultipartFile.fromBytes(
          'file',
          bytes,
          filename: file.name,
          contentType: contentType,
        ),
      );

      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error subiendo archivo: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> getPublicCategories() async {
    final url = Uri.parse('${ApiConfig.baseUrl}/education/categories');
    return _handleRequest((headers) => http.get(url, headers: headers));
  }

  Future<Map<String, dynamic>> getPublicResources({
    int? categoryId,
    String? resourceType,
    String? search,
  }) async {
    final Map<String, String> queryParams = {};

    if (categoryId != null && categoryId != 0) {
      queryParams['category_id'] = categoryId.toString();
    }

    if (resourceType != null && resourceType.trim().isNotEmpty) {
      queryParams['resource_type'] = resourceType.trim();
    }

    if (search != null && search.trim().isNotEmpty) {
      queryParams['search'] = search.trim();
    }

    final url = Uri.parse('${ApiConfig.baseUrl}/education/resources').replace(
      queryParameters: queryParams.isEmpty ? null : queryParams,
    );

    return _handleRequest((headers) => http.get(url, headers: headers));
  }

  Future<Map<String, dynamic>> getStoreResources({
    int? categoryId,
    String? search,
    String language = 'es',
  }) async {
    final Map<String, String> queryParams = {};

    if (categoryId != null && categoryId != 0) {
      queryParams['category_id'] = categoryId.toString();
    }

    if (search != null && search.trim().isNotEmpty) {
      queryParams['search'] = search.trim();
    }

    queryParams['language'] = language.trim();

    final url =
        Uri.parse('${ApiConfig.baseUrl}/education/store/resources').replace(
      queryParameters: queryParams,
    );

    try {
      final response = await http.get(url);

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> getAdminCategories() async {
    final url = Uri.parse('${ApiConfig.baseUrl}/education/admin/categories');
    return _handleRequest((headers) => http.get(url, headers: headers));
  }

  Future<Map<String, dynamic>> getAdminResources() async {
    final url = Uri.parse('${ApiConfig.baseUrl}/education/admin/resources');
    return _handleRequest((headers) => http.get(url, headers: headers));
  }

  Future<Map<String, dynamic>> createCategory({
    required String name,
    String? description,
    bool active = true,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/education/categories');

    return _handleRequest(
      (headers) => http.post(
        url,
        headers: headers,
        body: jsonEncode({
          'name': name.trim(),
          'description': description?.trim(),
          'active': active,
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> updateCategory({
    required int categoryId,
    String? name,
    String? description,
    bool? active,
  }) async {
    final url =
        Uri.parse('${ApiConfig.baseUrl}/education/categories/$categoryId');

    return _handleRequest(
      (headers) => http.put(
        url,
        headers: headers,
        body: jsonEncode({
          if (name != null) 'name': name.trim(),
          if (description != null) 'description': description.trim(),
          if (active != null) 'active': active,
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> deleteCategory({
    required int categoryId,
  }) async {
    final url =
        Uri.parse('${ApiConfig.baseUrl}/education/categories/$categoryId');

    return _handleRequest((headers) => http.delete(url, headers: headers));
  }

  Future<Map<String, dynamic>> createResource({
    required String title,
    int? categoryId,
    String resourceType = 'pdf',
    String? fileUrl,
    String? externalUrl,
    String? coverImageUrl,
    double price = 0,
    String? description,
    String? contentText,
    String? plantCommonName,
    String? plantScientificName,
    String? plantFamily,
    String? plantOrigin,
    String? plantUses,
    String? plantPartsUsed,
    String? plantPreparation,
    String? plantWarnings,
    bool active = true,
    bool freeForMembers = true,
    bool marketplaceOnly = false,
    String language = 'es',
    String contentType = 'general',
    List<String>? videoUrls,
    List<Map<String, dynamic>>? onlineFiles,
    String? downloadPdfUrl,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/education/resources');

    return _handleRequest(
      (headers) => http.post(
        url,
        headers: headers,
        body: jsonEncode({
          'title': title.trim(),
          'category_id': categoryId,
          'resource_type': resourceType.trim(),
          'file_url': fileUrl?.trim(),
          'external_url': externalUrl?.trim(),
          'cover_image_url': coverImageUrl?.trim(),
          'price': price,
          'description': description?.trim(),
          'content_text': contentText?.trim(),
          'plant_common_name': plantCommonName?.trim(),
          'plant_scientific_name': plantScientificName?.trim(),
          'plant_family': plantFamily?.trim(),
          'plant_origin': plantOrigin?.trim(),
          'plant_uses': plantUses?.trim(),
          'plant_parts_used': plantPartsUsed?.trim(),
          'plant_preparation': plantPreparation?.trim(),
          'plant_warnings': plantWarnings?.trim(),
          'active': active,
          'free_for_members': freeForMembers,
          'marketplace_only': marketplaceOnly,
          'language': language.trim(),
          'content_type': contentType.trim(),
          'video_urls': videoUrls ?? [],
          'online_files': onlineFiles ?? [],
          'download_pdf_url': downloadPdfUrl?.trim(),
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> updateResource({
    required int resourceId,
    String? title,
    int? categoryId,
    String? resourceType,
    String? fileUrl,
    String? externalUrl,
    String? coverImageUrl,
    double? price,
    String? description,
    String? contentText,
    String? plantCommonName,
    String? plantScientificName,
    String? plantFamily,
    String? plantOrigin,
    String? plantUses,
    String? plantPartsUsed,
    String? plantPreparation,
    String? plantWarnings,
    bool? active,
    bool? freeForMembers,
    bool? marketplaceOnly,
    String? language,
    String? contentType,
    List<String>? videoUrls,
    List<Map<String, dynamic>>? onlineFiles,
    String? downloadPdfUrl,
  }) async {
    final url =
        Uri.parse('${ApiConfig.baseUrl}/education/resources/$resourceId');

    return _handleRequest(
      (headers) => http.put(
        url,
        headers: headers,
        body: jsonEncode({
          if (title != null) 'title': title.trim(),
          if (categoryId != null) 'category_id': categoryId,
          if (resourceType != null) 'resource_type': resourceType.trim(),
          if (fileUrl != null) 'file_url': fileUrl.trim(),
          if (externalUrl != null) 'external_url': externalUrl.trim(),
          if (coverImageUrl != null) 'cover_image_url': coverImageUrl.trim(),
          if (price != null) 'price': price,
          if (description != null) 'description': description.trim(),
          if (contentText != null) 'content_text': contentText.trim(),
          if (plantCommonName != null)
            'plant_common_name': plantCommonName.trim(),
          if (plantScientificName != null)
            'plant_scientific_name': plantScientificName.trim(),
          if (plantFamily != null) 'plant_family': plantFamily.trim(),
          if (plantOrigin != null) 'plant_origin': plantOrigin.trim(),
          if (plantUses != null) 'plant_uses': plantUses.trim(),
          if (plantPartsUsed != null) 'plant_parts_used': plantPartsUsed.trim(),
          if (plantPreparation != null)
            'plant_preparation': plantPreparation.trim(),
          if (plantWarnings != null) 'plant_warnings': plantWarnings.trim(),
          if (active != null) 'active': active,
          if (freeForMembers != null) 'free_for_members': freeForMembers,
          if (marketplaceOnly != null) 'marketplace_only': marketplaceOnly,
          if (language != null) 'language': language.trim(),
          if (contentType != null) 'content_type': contentType.trim(),
          if (videoUrls != null) 'video_urls': videoUrls,
          if (onlineFiles != null) 'online_files': onlineFiles,
          if (downloadPdfUrl != null) 'download_pdf_url': downloadPdfUrl.trim(),
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> deleteResource({
    required int resourceId,
  }) async {
    final url =
        Uri.parse('${ApiConfig.baseUrl}/education/resources/$resourceId');

    return _handleRequest((headers) => http.delete(url, headers: headers));
  }

  Future<Map<String, dynamic>> createAccessCode({
    required int resourceId,
    String? buyerName,
    String? buyerEmail,
    String? buyerPhone,
    int maxUses = 30,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/education/store/access-codes');

    return _handleRequest(
      (headers) => http.post(
        url,
        headers: headers,
        body: jsonEncode({
          'resource_id': resourceId,
          'buyer_name': buyerName?.trim(),
          'buyer_email': buyerEmail?.trim(),
          'buyer_phone': buyerPhone?.trim(),
          'max_uses': maxUses,
        }),
      ),
    );
  }

  Future<Map<String, dynamic>> validateAccessCode({
    required String accessCode,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/education/store/access-codes/validate',
    );

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'access_code': accessCode.trim(),
        }),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> createEducationOrder({
    required String buyerName,
    required String buyerPhone,
    required String buyerEmail,
    required List<Map<String, dynamic>> items,
  }) async {
    final url = Uri.parse('${ApiConfig.baseUrl}/education/store/orders');

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'buyer_name': buyerName.trim(),
          'buyer_phone': buyerPhone.trim(),
          'buyer_email': buyerEmail.trim(),
          'items': items,
          'payment_method': 'paypal',
        }),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error de conexión: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> createMarketplacePayPalOrder({
    required int resourceId,
    required int userId,
    required String buyerName,
    required String buyerPhone,
    required String buyerEmail,
    int quantity = 1,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/payments/paypal/marketplace/create-order',
    );

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'item_type': 'education',
          'item_id': resourceId,
          'user_id': userId,
          'quantity': quantity,
          'buyer_name': buyerName.trim(),
          'buyer_phone': buyerPhone.trim(),
          'buyer_email': buyerEmail.trim(),
        }),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error creando orden PayPal: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> createMarketplacePayPalCartOrder({
    required int userId,
    required String buyerName,
    required String buyerPhone,
    required String buyerEmail,
    required List<Map<String, dynamic>> items,
    String currency = 'USD',
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/payments/paypal/marketplace/create-cart-order',
    );

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'item_type': 'education',
          'user_id': userId,
          'buyer_name': buyerName.trim(),
          'buyer_phone': buyerPhone.trim(),
          'buyer_email': buyerEmail.trim(),
          'currency': currency,
          'items': items,
        }),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error creando carrito PayPal: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> createMarketplacePayPhoneCartOrder({
    required int userId,
    required String buyerName,
    required String buyerPhone,
    required String buyerEmail,
    required List<Map<String, dynamic>> items,
    String currency = 'USD',
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/payphone/marketplace/create-cart-order',
    );

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'item_type': 'education',
          'user_id': userId,
          'buyer_name': buyerName.trim(),
          'buyer_phone': buyerPhone.trim(),
          'buyer_email': buyerEmail.trim(),
          'currency': currency,
          'items': items,
        }),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error creando pago PayPhone: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> confirmMarketplacePayPhoneOrder({
    required String clientTransactionId,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/payphone/marketplace/confirm-order',
    );

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'clientTransactionId': clientTransactionId,
        }),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error confirmando pago PayPhone: $e'},
      };
    }
  }

  Future<Map<String, dynamic>> captureMarketplacePayPalOrder({
    required String paypalOrderId,
  }) async {
    final url = Uri.parse(
      '${ApiConfig.baseUrl}/payments/paypal/marketplace/capture-order',
    );

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'paypal_order_id': paypalOrderId,
        }),
      );

      return {
        'statusCode': response.statusCode,
        'data': _safeDecode(response),
      };
    } catch (e) {
      return {
        'statusCode': 500,
        'data': {'detail': 'Error capturando pago PayPal: $e'},
      };
    }
  }
}
