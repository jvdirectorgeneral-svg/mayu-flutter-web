importScripts('https://www.gstatic.com/firebasejs/10.13.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.13.2/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: 'AIzaSyDFbI6tzsUT8Ic62H8FkXpBUnzd35SpiHg',
  appId: '1:444898111736:web:c24fc9663827795dcb0b0d',
  messagingSenderId: '444898111736',
  projectId: 'mayu-wellness-club-a3c17',
  authDomain: 'mayu-wellness-club-a3c17.firebaseapp.com',
  storageBucket: 'mayu-wellness-club-a3c17.firebasestorage.app',
  measurementId: 'G-1NSKKBFRVD',
});

firebase.messaging();
